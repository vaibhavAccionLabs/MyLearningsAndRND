import React, { Component } from 'react';

import styles from 'css/components/PaymentTable';
import classNames from 'classnames/bind';
import ReactTable from "react-table";
import "react-table/react-table.css";
import SelectForm from './SelectForm';


const cx = classNames.bind(styles);
class PaymentTable extends Component {
  constructor(props) {
    super(props);
    this.renderEditable = this.renderEditable.bind(this);
    this.renderEditableCombo = this.renderEditableCombo.bind(this);
    this.state = {
      msg: ''
    }
  }

  renderEditableCombo(cellInfo) {
    let disabled = false;
    if (cellInfo.original.c_order_payment_id) {
      disabled = true;
    }
    return (
      <div>
        <SelectForm
          disabled={disabled}
          type="payment_type" rel="payment_type" options={this.props.payment_types} value={parseInt(cellInfo.original.payment_mode)} save={(data) => {
            const payments = [...this.props.payments];
            payments[cellInfo.index][cellInfo.column.id] = data.value;
            this.props.renderEditable(payments);
          }} />
      </div>
    );
  }
  renderEditable(cellInfo) {
    let disabled = false;
    if (cellInfo.original.c_order_payment_id) {
      disabled = true;
    }
    return (
      <div className={cx('input-group')}>
        <input
          disabled={disabled}
          style={{ backgroundColor: "#fafafa", textAlign: "center" }}
          type="text"
          onChange={(e) => {
            const payments = [...this.props.payments];
            let msg=""
            payments[cellInfo.index][cellInfo.column.id] = e.target.value;
            let total_paid_amount = 0;
            payments.length > 0 && payments.map((payment, index) => {
              total_paid_amount += payment.amount && parseInt(payment.amount) || 0;
            });

            if (total_paid_amount > this.props.total_amount) {
               msg= 'Entered amount should not be greater than the total bill amount'
              this.setState({
                msg: msg
              });
            } else {
               msg= ''
              this.setState({
                msg: msg
              });
            }
            this.props.renderEditable(payments,msg);

          }}

          value={this.props.payments[cellInfo.index][cellInfo.column.id]}
        />
      </div>
    );
  }
  renderDelete(cellInfo) {
    let disabled = false;
    if (cellInfo.original.c_order_payment_id) {
      disabled = true;
    }
    return (
      <div className={cx('input-group')}>
        <button

          disabled={disabled}
        >
          DELETE
        </button>
      </div>
    );
  }
  render() {
    // let add_button_isdisabled = false;
    let { msg } = this.state;
    let errorMsg = "";
    let {payments} = this.props;

    // if (payments) {
    //   let payment = payments[payments.length - 1];
    //   if ((payment.amount == null || payment.amount === "" ) && (payment.payment_mode == null || payment.payment_mode === "")) {
    //     add_button_isdisabled = true;
    //     msg = "Empty Payment Row Already Exists";
    //   }
    //   if(payment.c_order_payment_id){
    //     add_button_isdisabled = false;
    //     msg = this.state.msg;
    //   }
    // }
    if (msg) {
      errorMsg = <div className={cx("table_error_msg")}>{msg}</div>;
    }
    return (
      <div>
        <button
          type="button"
          onClick={this.props.onRowAdd}
          className={cx("table_btn", "payment-add-row-button")}
        >Add New Row</button>
        {errorMsg}
        <div style={{
          maxHeight: '250px',
          overflowY: 'scroll'
        }}>
          <ReactTable
            data={this.props.payments}
            showPagination={false}
            pageSize={10}
            columns={[
              {
                Header: "S.No",
                accessor: "id",
                Cell: (cellInfo) => {
                  return (
                    <div
                      style={{ backgroundColor: "#fafafa", textAlign: "center" }}
                    >{cellInfo.index + 1}</div>
                  )
                }
              },
              {
                Header: "Payment Mode",
                accessor: "payment_mode",
                Cell: this.renderEditableCombo
              }, {
                Header: "Amount Paid",
                accessor: "amount",
                Cell: this.renderEditable
              },
              {
                Header: "Reference",
                accessor: "reference",
                Cell: this.renderEditable
              }
            ]}
            defaultPageSize={10}
            className="-striped -highlight"
          />
        </div>
      </div>
    );

  }

}

export default PaymentTable;