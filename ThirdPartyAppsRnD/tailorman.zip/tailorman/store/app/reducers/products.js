import * as types from 'types';

import _ from 'lodash';

const fabricImages = [{
	item_type_id: 12,
	folderPath: 'product/RTW/Shirts/',
	folderHrPath: 'product/RTWHR/Shirts/',
	name: 'shirts',
	count: 6
}, {
	item_type_id: 13,
	folderPath: 'product/RTW/Bundy/',
	folderHrPath: 'product/RTWHR/Bundy/',
	name: 'bundy',
	count: 4
}, {
	item_type_id: 15,
	folderPath: 'product/RTW/Jackets/',
	folderHrPath: 'product/RTWHR/Jackets/',
	name: 'jacket',
	count: 5
}, {
	item_type_id: 27,
	folderPath: 'product/RTW/Shorts/',
	folderHrPath: 'product/RTWHR/Shorts/',
	name: 'shorts',
	count: 5
}, {
	item_type_id: 14,
	folderPath: 'product/RTW/Trousers/',
	folderHrPath: 'product/RTWHR/Trousers/',
	name: 'Trouser',
	count: 5
}, {
	item_type_id: 28,
	folderPath: 'product/RTW/Waistcoat/',
	folderHrPath: 'product/RTWHR/Waistcoat/',
	name: 'waistcoat',
	count: 4
}];

const AWSHostInitialUrl = 'https://s3.ap-south-1.amazonaws.com/assets.web.tm/'

function getProductImages(fabricDetails, rtwImage, getHr) {
	debugger;
	var imageObject = _.find(fabricImages, { item_type_id: fabricDetails.item_type_id });

	if (imageObject) {
		var images;
		if (fabricDetails.mtm_flag == "N" && getHr) {
			if (fabricDetails.rtw_image_count > 0) {
				images = [];
				for (var i = 1; i <= fabricDetails.rtw_image_count; i++) {
					images.push(`${AWSHostInitialUrl}${imageObject.folderHrPath}${fabricDetails.product_sku_code}/${fabricDetails.product_sku_code}_${i}.jpg`);
				}
			} else {
				images = [`${AWSHostInitialUrl}${imageObject.folderHrPath}${fabricDetails.product_sku_code}/${fabricDetails.product_sku_code}.jpg`];
			}
			return images;
		}

		if (fabricDetails.mtm_flag == "N" && rtwImage) {
			images = `${AWSHostInitialUrl}${imageObject.folderPath}${fabricDetails.product_sku_code}/${fabricDetails.product_sku_code}.jpg`;
		} else {
			if (fabricDetails.rtw_image_count > 0) {
				images = [];
				for (var i = 1; i <= fabricDetails.rtw_image_count; i++) {
					images.push(`${AWSHostInitialUrl}${imageObject.folderPath}${fabricDetails.product_sku_code}/${fabricDetails.product_sku_code}_${i}.jpg`);
				}
			} else {
				images = [`${AWSHostInitialUrl}${imageObject.folderPath}${fabricDetails.product_sku_code}/${fabricDetails.product_sku_code}.jpg`];
			}
		}
		return images;
	} else if (fabricDetails.is_bundled === 'Y' && fabricDetails.bundled_sku_list && fabricDetails.item_type_id === 23) {
		let imagesList = [];
		if (fabricDetails.mtm_flag == "N" && rtwImage) {
			imagesList = AWSHostInitialUrl + `product/RTW/Suits/${fabricDetails.product_sku_code}/${fabricDetails.product_sku_code}.jpg`;
		}
		return imagesList;
	} else {
		return [
			AWSHostInitialUrl + 'product/' + fabricDetails.fabric_sku_code + '.jpg',
			AWSHostInitialUrl + 'product/' + fabricDetails.product_sku_code + '.jpg'
		];
	 }
}

const modifyproducts = (
	state = {
		selectedProduct: {},
		deletedProduct: [],
		uploadedProduct: []
	},
	action
) => {
	switch (action.type) {
		case types.USER_SELECTED_PPRODUCT:
			let selectedProduct = action.product;
			selectedProduct.image_url_path = getProductImages(selectedProduct, true);
			selectedProduct.imageUrl = getProductImages(selectedProduct);
			if(selectedProduct.mtm_flag === "N"){
				selectedProduct.high_res_image_url =  getProductImages(selectedProduct, '', true);
			}
			return {
				...state,
				selectedProduct
			}
			break;
		case types.DELETE_PPRODUCT_LIST:
			let getstate = { ...state };
			
		
			if (getstate.deletedProduct && getstate.deletedProduct.indexOf(action.product) === -1) {
				let updatedArr = getstate.deletedProduct.concat(action.product);
				//let data = action.product;
				if(action.product.includes("RTWHR")){
					debugger;
					var HR_IMAGES = getstate.selectedProduct.high_res_image_url;
					HR_IMAGES.splice( HR_IMAGES.indexOf(action.product), 1 );
					getstate.selectedProduct.high_res_image_url = HR_IMAGES;
						console.log("New Deleted item",HR_IMAGES);
				}
				return {
					...state,
					deletedProduct: updatedArr,
					selectedProduct:getstate.selectedProduct
				}
			}
			break;
		case types.UPLOAD_PRODUCT_LIST:
			let getUploadedProduct = { ...state };
			if (getUploadedProduct.uploadedProduct && !_.find(getUploadedProduct.uploadedProduct, { 'customPathName': action.product.customPathName })) {
				let updatedArr = getUploadedProduct.uploadedProduct.concat(action.product);
				return {
					...state,
					uploadedProduct: updatedArr
				}
			}
			break;
		case types.CLEAR_DELETE_PPRODUCT_LIST:
			return {
				...state,
				deletedProduct: []
			}
			break;
		case types.CLEAR_UPLOAD_PRODUCT_LIST:
			return {
				...state,
				uploadedProduct: []
			}
			break;
		case types.UPDATE_RTW_IMAGE_COUNT:
			//here update the value of selected product : --- 
			let getselecedProduct = { ...state };
			if (getselecedProduct.selectedProduct.rtw_image_count) {
				getselecedProduct.selectedProduct.rtw_image_count = getselecedProduct.selectedProduct.rtw_image_count + action.count
			}
			return {
				...state,
				selectedProduct: getselecedProduct.selectedProduct
			}
			break;
		case types.PREVIEW_RTW_IMAGE:
			let getSelectedProductWithNewImage = { ...state };
			if (action.updateType == "rtw") {
				if (getSelectedProductWithNewImage.selectedProduct.imageUrl) {
					getSelectedProductWithNewImage.selectedProduct.imageUrl = getSelectedProductWithNewImage.selectedProduct.imageUrl.concat(action.imgData);
				}
			} else if (action.updateType == "rtwhr") {
				if (getSelectedProductWithNewImage.selectedProduct.high_res_image_url) {
					getSelectedProductWithNewImage.selectedProduct.high_res_image_url = getSelectedProductWithNewImage.selectedProduct.high_res_image_url.concat(action.imgData);
				}
			} else if (action.updateType == "rtwdefault") {
				if (getSelectedProductWithNewImage.selectedProduct.high_res_image_url) {
					getSelectedProductWithNewImage.selectedProduct.image_url_path = action.imgData;
				}
			} else if (action.updateType == "product") {
				if (getSelectedProductWithNewImage.selectedProduct.image_url_path) {
					getSelectedProductWithNewImage.selectedProduct.image_url_path[1] = action.imgData;
				}
			} else if (action.updateType == "fabric") {
				if (getSelectedProductWithNewImage.selectedProduct.image_url_path) {
					getSelectedProductWithNewImage.selectedProduct.image_url_path[0] = action.imgData;
				}
			}
			return {
				...state,
				selectedProduct: getSelectedProductWithNewImage.selectedProduct
			}
			break;
		default:
			return state;
	}
}

export default modifyproducts;