import * as types from 'types';
import {
    combineReducers
} from 'redux';

import { fabricDesignDependency } from 'util';

const selectedForm = (
    state = '',
    action
) => {
    switch (action.type) {
        case types.SELECT_ORDER_FORM:
            return action.order_form_type;
        default:
            return state;
    }
};

const thumbnails = (
    state = [],
    action
) => {
    switch (action.type) {
        case types.ORDER_ADD_IMAGE_THUMBNAIL:
            return [...state, action.imageDataURL];
        case types.ORDER_POPULATE_THUMBNAILS:
            return action.imageDataURLs;
        default:
            return state;
    }
}
const thumbnail = (
    state = {
        show: false,
        dataURL: ''
    }, action
) => {
    switch (action.type) {
        case types.SHOW_THUMBNAIL:
            return {
                show: action.show,
                dataURL: action.thumbnail
            };
        default:
            return state;
    }
}
const selectedSaleItem = (
    state = -1,
    action
) => {
    switch (action.type) {
        case types.ORDER_SALE_ITEM_SELECT:
            return action.index;
        default:
            return state;
    }
}
const calculateDiscount = (couponDetails, total_amount) => {
    let discountAmount = 0;
    let discount_value = 0;
    if (couponDetails && (couponDetails.type == "redeempoints") && (couponDetails.redeem_applied == true)) {
        discountAmount = (couponDetails.points_redeem_value * 100 )/total_amount;
        discount_value = couponDetails.points_redeem_value;
    } else if (couponDetails && (couponDetails.type == "coupon") && (couponDetails.coupon_applied == true)) {
        if (couponDetails.is_absolute == "false" || couponDetails.is_absolute == false ) {
            discountAmount = couponDetails.points;
            discount_value = couponDetails.points;
        } else {
            discountAmount = (couponDetails.points * 100 )/total_amount;
            discount_value = couponDetails.points;
        }
    }
    return {
        discount_percentage : discountAmount,
        discount_value
    };
};
const details = (state = {
    tailor_id: 0,
    salesman_id: 0,
    payment_type_id: 1,
    priority_id: 1,
    benificiary_phone: '',
    thumbnails: [],
    occasion: '',
    total_amount: 0,
    is_full_payment: true,
    billing_address: '',
    delivery_address: '',
    half_amount: 0,
    PIN: 0,
    loyality_points: 0,
    current_tier: "NA",
    discount_redeem_coupon_type: 'Promocode',
    loyality_tier_discount: {},
    loyality_tier_discount_obj: {},
    coupon_details: {},
    shipping_charges: 0,
    benificiary_name: '',
    benificiary_email: '',
    occasion_date: null,
    coupon_details: {},
    shipping_charges: 0,
    approved_details: null,
    pending_amount: [],
    popup_status: false,
    delivery_location_id: 0,
    fiton_location_id: 0,
}, action) => {
    switch (action.type) {
        case types.ORDER_DETAILS_UPDATE_TAILOR:
            return {
                ...state,
                tailor_id: action.tailor_id
            }
        case types.ORDER_DETAILS_UPDATE_SALESMAN:
            return {
                ...state,
                salesman_id: action.salesman_id
            }
        case types.ORDER_DETAILS_UPDATE_PIN:
            return {
                ...state,
                PIN: action.pin
            }
        case types.ORDER_DETAILS_UPDATE_PIN_Date:
            return {
                ...state,
                pindate: action.pindate
            }
        case types.ORDER_DETAILS_UPDATE_PAYMENT_TYPE:
            return {
                ...state,
                payment_type_id: action.payment_type_id
            }
        case types.ORDER_DETAILS_UPDATE_PRIORITY_TYPE:
            return {
                ...state,
                priority_id: action.priority_id
            };
        case types.ORDER_DETAILS_UPDATE_FULL_PAYMENT_FLAG:

            return {
                ...state,
                is_full_payment: action.is_full_payment
            };
        case types.ORDER_DETAILS_UPDATE_OCCASION:
            return {
                ...state,
                occasion: action.occasion
            };
        case types.ORDER_DETAILS_UPDATE_BENIFICIARY_PHONE:
            return {
                ...state,
                benificiary_phone: action.benificiary_phone
            };
        case types.ORDER_DETAILS_UPDATE_BENIFICIARY_NAME:
            return {
                ...state,
                benificiary_name: action.benificiary_name
            };
        case types.ORDER_DETAILS_UPDATE_BENIFICIARY_EMAIL:
            return {
                ...state,
                benificiary_email: action.benificiary_email
            };
        case types.ORDER_DETAILS_UPDATE_OCCASION_DATE:
            return {
                ...state,
                occasion_date: action.date
            };
        case types.ORDER_DETAILS_UPDATE_TOTAL_AMOUNT:
            return {
                ...state,
                total_amount: action.total_amount
            };
        case types.ORDER_DETAILS_UPDATE_HALF_AMOUNT:
            return {
                ...state,
                half_amount: action.half_amount
            };
        case types.ORDER_DETAILS_UPDATE_SHIPPING_CHARGES:
            return {
                ...state,
                shipping_charges: action.shipping_charges
            };
        case types.ORDER_DETAILS_APPROVED_BY:

            return {
                ...state,
                approved_details: action.approved_details
            };
        case types.ORDER_DETAILS_UPDATE_PENDING_AMOUNT:
            return {
                ...state,
                pending_amount: action.pending_amount
            };
        case types.ORDER_DETAILS_UPDATE:
            return {
                is_full_payment: true,
                ...action.order_details
            };
        case types.SELECT_ORDER:
            return {
                is_full_payment: true,
                ...action.order
            }
        case types.SAVE_LOYALITY_POINTS:
            return {
                ...state,
                loyality_points: action.loyality_points_and_tier.loyality_points || 0,
                current_tier: action.loyality_points_and_tier.current_tier
            };
        case types.DISCOUNT_REDEEM_COUPON_TYPE:
        // debugger;
            return {
                ...state,
                discount_redeem_coupon_type: action.discount_redeem_coupon_type
            };
        case types.SAVE_COUPON_DETAILS:
            /**
             * Need to Implement for the Filter Flag is_payment_mode
             */
            let coupon_details = action.coupon_details;
            coupon_details = Object.assign({
                ...coupon_details,
                ...calculateDiscount(coupon_details,state.total_amount)
            });
            let order_discounts = state.discounts || [];
            if (_.isArray(order_discounts)) {
                order_discounts.push(coupon_details);
            } else {
                order_discounts = [order_discounts, coupon_details];
            }
            return {
                ...state,
                discounts: order_discounts
            }
        case types.COUPON_RESPONSE_DETAILS:
            return {
                ...state,
                coupon_details: action.coupon_details
            }
        case types.ORDER_DETAILS_UPDATE_BILLINGADDRESS:
            return {
                ...state,
                billing_address: action.address
            }
        case types.ORDER_DETAILS_UPDATE_DELIVERYADDRESS:
            return {
                ...state,
                delivery_address: action.address
            }
        case types.SAVE_LOYALITY_TIER_DISCOUNT:
            return {
                ...state,
                loyality_tier_discount: action.data
            }
        case types.SAVE_LOYALITY_TIER_DISCOUNT_OBJECT:
            return {
                ...state,
                loyality_tier_discount_obj: action.data
            }
        case types.ORDER_ITEMS_POPULATE:
            return {
                ...state,
                details_loading: false
            }
        case types.ORDER_ITEMS_LOADING:
            return {
                ...state,
                details_loading: true
            }
        case types.ORDER_PENDING_DETAILS_UPDATE:
            return {
                ...state,
                tailor_id: action.order_details.tailor_id,
                salesman_id: action.order_details.sales_man_id,
                occasion: action.order_details.occasion,
                benificiary_phone: action.order_details.benficiary_mobile,
                benificiary_name: action.order_details.benficiary_name,
                benificiary_email: action.order_details.benificiary_email,
                occasion_date: action.order_details.occation_date,
                delivery_location_id: action.order_details.delivery_location_id ? parseInt(action.order_details.delivery_location_id) : "",
                fiton_location_id: action.order_details.fiton_location_id ? parseInt(action.order_details.fiton_location_id) : "",
                store_id: action.order_details.store_id
            }
        case types.OPEN_PAYMENT_POPUP:
            return {
                ...state,
                popup_status: action.popup_status
            }
        case types.ORDER_DETAILS_UPDATE_DELIVERYLOCATION:
            return {
                ...state,
                delivery_location_id: action.delivery_location_id
            }
        case types.ORDER_DETAILS_UPDATE_FITONLOCATION:
            return {
                ...state,
                fiton_location_id: action.fiton_location_id
            }

        default:
            return state;
    }
}



const isFormOpen = (state = {
    measurements: false,
    styles: false,
    saleItem: false,
    signature: false
}, action) => {
    switch (action.type) {
        case types.ORDER_SALE_ITEM_OPEN_MEASUREMENTS:
            return {
                ...state,
                measurements: !action.close
            }
        case types.ORDER_SALE_ITEM_OPEN_STYLES:
            return {
                ...state,
                styles: !action.close
            }
        case types.ORDER_SALES_OPEN_FORM:
            return {
                ...state,
                saleItem: !action.close
            }
        case types.OPEN_SIGNATURE:
            return {
                ...state,
                signature: !action.close
            }
        default:
            return state;
    }
}

const sales = (state = [], action) => {
    switch (action.type) {
        case types.UPDATE_ORDER_SALES_INIT_SALE_ITEM:
            let newState = _.cloneDeep(state);
            newState[newState.length - 1]['comment'] = action.comment;

            return newState;
        case types.ORDER_SALES_INIT_SALE_ITEM:
            return [...state, {
                measurement_type: 1,
                item_type_id: action.item_type,
                comment: action.comment || '',
                profile_id: -1,
                is_new_measurements: true,
                is_new_style: true,
                style: -1,
                finish_type_id: 0,
                discount_type: types.UPCHARGE_UNIT_VALUE,
                order_flag: 1,
                ...action.data
            }];
        case types.ORDER_ITEMS_POPULATE:
            return [...action.sales];
        case types.ORDER_SALES_UPDATE_SALE_ITEM_ENTRY:
            let new_state = _.cloneDeep(state);

            new_state[action.payload.index][action.payload.field] = action.payload.value;
            new_state[action.payload.index]['fabric_designs'] = fabricDesignDependency(new_state[action.payload.index]['fabric_designs']);

            return new_state;
        case types.ORDER_SALE_ITEM_DELETE:
            let updatedState = state.filter((saleItem, index) => {
                return index !== parseInt(action.index)
            });
            return updatedState;
        case types.ORDER_SALES_UPDATE_SALE_ITEM:
            const customizer = (obj, src) => {
                if (obj) {
                    return obj;
                }
            }
            state[action.index] = _.mergeWith(action.order_item, state[action.index], customizer);
            return [...state];
        default:
            return state;
    }
}

const measurements = (state = [], action) => {
    switch (action.type) {
        case types.UPDATE_MEASUREMENTS_VALUES:
            let new_state = _.cloneDeep(state);

            new_state[action.payload.field] = action.payload.value;
            return new_state;
        case types.CLEAR_MEASUREMENTS_VALUES:
            return [];
        default:
            return state;
    }
}

const invoice = (state = {}, action) => {
    switch (action.type) {
        case types.POPULATE_INVOICE_DATA:
            return action.details;
        default:
            return state;
    }
}



const orderReducer = combineReducers({
    selectedForm,
    details,
    sales,
    isFormOpen,
    selectedSaleItem,
    thumbnails,
    thumbnail,
    invoice,
    measurements
});

export default orderReducer;