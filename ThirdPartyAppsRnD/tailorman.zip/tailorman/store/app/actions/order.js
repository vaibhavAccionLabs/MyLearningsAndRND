import * as types from 'types';
import {
	polyfill
} from 'es6-promise';
import {
	push
} from 'react-router-redux';
import request from 'axios';
import moment from 'moment';
polyfill();
import { fetchCustomerAddress } from './list';


function makeRequest(method, data, api) {
	return request[method](api, data);
}
export function updateMessage(type, message) {
	return {
		type,
		message
	}
}

export function updateCustomerGender(value) {
	return {
		type: types.ORDER_CUSTOMER_UPDATE_GENDER,
		gender: value[0]
	}
}
export function updatePopupStatus(value) {
	return {
		type: types.OPEN_PAYMENT_POPUP,
		popup_status: !value
	}
}

export function updateAddressType(profile) {
	return dispatch => {
		return makeRequest('post', profile, '/order/customer/addresstype').then(response => {
			dispatch(fetchCustomerAddress(profile.customer_id));

		});
	}
}
export function updateCustomerSource(value) {
	return {
		type: types.ORDER_CUSTOMER_UPDATE_SOURCE,
		source_id: value
	}
}

export function updateCustomerIsNew(value) {
	return {
		type: types.ORDER_CUSTOMER_UPDATE_IS_NEW_CUSTOMER,
		isNewCustomer: value[0]
	}
}

export function updateCustomerPincode(pincode) {
	return {
		type: types.ORDER_CUSTOMER_UPDATE_PINCODE,
		pincode
	}
}

export function updateCustomerPhone(phone) {
	return {
		type: types.ORDER_CUSTOMER_UPDATE_PHONE,
		phone
	}
}

export function updateOrderTotal(total_amount) {
	return {
		type: types.ORDER_DETAILS_UPDATE_TOTAL_AMOUNT,
		total_amount
	}
}


export function selectOrder(order, redirect) {
	return dispatch => {
		dispatch({
			type: types.SELECT_ORDER,
			order
		});
		if (redirect)
			dispatch(push('/order/details'));
	}
}

export function saveMeasurementProfile(profile, measurements, index) {
	return dispatch => {
		return makeRequest('post', profile, '/order/customer/profile').then((response) => {
			if (response.status === 200) {
				profile.profile_id = response.data.profile_id;
				return profile;
			}
		}).then(function (profile) {
			dispatch({
				type: types.ORDER_SALES_UPDATE_SALE_ITEM_ENTRY,
				payload: {
					value: profile,
					field: 'profile',
					index
				}
			});
			return saveMeasurements(profile.profile_id, measurements);
		})
	}
}

export function saveProfile(profile, measurements) {
	var profileSave = (profile) => {
		let url = null;
		if (profile.profile_id && profile.profile_id > 0) {
			url = '/order/customer/profile/update';
		} else {
			url = '/order/customer/profile';
		}
		return makeRequest('post', profile, url).then((response) => {
			if (response.status === 200) {
				profile.profile_id = profile.profile_id || response.data.profile_id;
				return profile;
			}
		})
	}
	return profileSave(profile).then(function (profile) {
		if (measurements && measurements.length > 0) {
			return saveMeasurements(profile.profile_id, measurements).then(function (profile_id) {
				if (profile.thumbnails && profile.thumbnails.length > 0) {
					return saveMeasurementImageInDB(profile.thumbnails, profile_id);

				} else {
					return profile_id;
				}

			})
		} else {
			if (profile.thumbnails && profile.thumbnails.length > 0) {
				return saveMeasurementImageInDB(profile.thumbnails, profile.profile_id);

			} else {
				return profile.profile_id;
			}

		}
	});
}

export function saveStyleProfile(profile) {
	let url = '/order/customer/style/profile';
	return makeRequest('post', profile, url).then((response) => {
		if (response.status === 200) {
			profile.profile_id = response.data.profile_id;
			return profile;
		}
	})
}
export function saveMeasurementImageInDB(thumbnails, profile_id) {

	const _profileimage = {
		profile_id,
		thumbnails
	};
	return makeRequest('post', _profileimage, '/order/item/bulkimageupload')
		.then((imageResponse) => {
			if (imageResponse.status === 200)
				return imageResponse.data;
			else
				console.log("Something went wrong when saving measurmenets");
		})
		.then(function () {
			return profile_id;
		});

}
export function getThumbnails(order_id) {
	return dispatch => {
		return makeRequest('get', null, '/details/image?order_id=' + order_id + "&image_id=" + types.IMAGE_TYPE_MEASUREMENT).then((response) => {
			let imageDataURLs = [];
			if (response.status === 200) {
				if (response.data && response.data.length > 0) {
					imageDataURLs = response.data.map((image) => {
						var convertImage = (image) => {
							let dataURL = '';
							image.forEach((charCode) => {
								dataURL += String.fromCharCode(charCode);
							})
							return dataURL;
						}
						return convertImage(image.image.data);
					});
				}
			}
			dispatch({
				type: types.ORDER_POPULATE_THUMBNAILS,
				imageDataURLs
			})
		});
	}
}
export function fetchMeasurementsImages(profile_id) {
	return dispatch => {
		return makeRequest('get', null, '/details/profile/image?profile_id=' + profile_id).then((response) => {
			let imageDataURLs = [];
			if (response.status === 200) {
				if (response.data && response.data.length > 0) {
					imageDataURLs = response.data.map((image) => {
						var convertImage = (image) => {
							let dataURL = '';
							image.forEach((charCode) => {
								dataURL += String.fromCharCode(charCode);
							})
							return dataURL;
						}
						return convertImage(image.image.data);
					});
				}
			}
			dispatch({
				type: types.ORDER_POPULATE_THUMBNAILS,
				imageDataURLs
			})
		});
	}

}

export function showThumbnail(thumbnail, show) {
	return {
		type: types.SHOW_THUMBNAIL,
		show,
		thumbnail
	}
}


export function getOrderItems(order_id, customer_id) {
	return dispatch => {
		makeRequest('get', null, '/order/itemList?order_id=' + order_id).then((response) => {
			if (response.status === 200) {
				var sales = response.data.map((sale) => {
					sale.style = sale.style_id || sale.sku_id;
					sale.fiton_date = (sale.fit_on_date) ? moment(sale.fit_on_date).format('YYYY-MM-DD') : '';
					sale.customer_delivery_date = (sale.customer_delivery_date) ? moment(sale.customer_delivery_date).format('YYYY-MM-DD') : '';
					sale.customer_fit_on_date = (sale.customer_fit_on_date) ? moment(sale.customer_fit_on_date).format('YYYY-MM-DD') : '';
					sale.sku = sale.sku || sale.style;
					sale.name = sale.display_name;
					sale.id = sale.order_item_id;
					sale.discount_value = sale.discount_value || sale.discount;
					sale.delivery_date = (sale.delivery_date) ? moment(sale.delivery_date).format('YYYY-MM-DD') : '';
					sale.finish_type_id = sale.finish_type_id || sale.finish_type;
					sale.is_new_measurements = (sale.profile_id > -1) ? false : true;
					sale.order_flag = sale.order_flag || 1;
					sale.upcharges = sale.upcharge || []
					return sale;
				});
				Promise.all(sales.map((sale) => {
					return makeRequest('get', null, '/order/item/fabricDesign?order_item_id=' + sale.order_item_id).then((response) => {
						if (response.status === 200) {
							return response.data;
						}
					});
				})).then((fabricDesigns) => {
					for (var i = 0; i < sales.length; i++) {
						if (fabricDesigns[i][0]) {
							sales[i].fabric_designs = fabricDesigns[i][0].fabric_design;
							sales[i].fabric_design_comment = fabricDesigns[i][0].comment;
							if (fabricDesigns[i][0].profile_id) {
								sales[i].is_new_style = false;
								sales[i].style_profile_id = fabricDesigns[i][0].profile_id;
							} else if (fabricDesigns[i][0].selected_profile_id) {
								sales[i].is_new_style = false;
								sales[i].style_profile_id = fabricDesigns[i][0].selected_profile_id;
							}
						}
					}
					return;
				}).then(() => {
					return Promise.all(sales.map((sale) => {
						return makeRequest('get', null, '/profiles?item_type_id=' + sale.item_type_id + "&customer_id=" + customer_id).then((profiles) => {
							if (sale.profile_id && (sale.profile_id > -1)) {
								profiles = profiles.data;
								const profile = _.find(profiles, {
									profile_id: parseInt(sale.profile_id)
								});

								profile.name = profile.profile_name;
								profile.profile_id = sale.profile_id;
								const measurement_upcharge = sale.upcharges ? _.find(sale.upcharges, {
									type: 'Higher Size Upcharge'
								}) : false;
								return getUpchargedMeasurementProfile(profile, sale.item_type_id, measurement_upcharge).then((profile) => {
									sale.profile = profile;
									return sale;
								});
							} else {
								return sale;
							}
						});
					}))
				}).then(() => {

					return Promise.all(sales.map((sale) => {
						return makeRequest('get', null, '/order/item/rtwmeasurement?order_item_id=' + sale.order_item_id).then((rtw_measurement) => {

							let measurement_data = rtw_measurement.data && rtw_measurement.data.length > 0 && rtw_measurement.data[0];

							if (measurement_data && measurement_data.fabric_measurements) {

								// sale.fabric_measurement = measurement_data.fabric_measurements;
								//sale = Object.assign({}, sale, measurement_data.fabric_measurements);
								sale = {
									...measurement_data.fabric_measurements,
									...sale
								}
							}
							return sale;
						});
					}))
				}).then((sales) => {
					dispatch({
						type: types.ORDER_ITEMS_POPULATE,
						sales
					});
				});
			}
		});
	}
}

function getUpchargedMeasurementProfile(profile, type_id, has_measurement_upcharge) {
	return makeRequest('get', null, '/profile/values?profile_id=' + profile.profile_id).then((response) => {
		if (response.status === 200) {
			const values = response.data;
			return makeRequest('get', null, '/list/measurementField?item_type_id=' + type_id + "&measurement_type_id=" + profile.measurement_source_id).then(response => {
				if (response.status === 200) {
					const fields = response.data;
					profile.measurements = values.map((value) => {
						const field = _.find(fields, {
							measurement_type_id: value.measurement_type_id
						});
						if (!has_measurement_upcharge) {

							if (field && field.upcharge_limit > 0 && field.upcharge_limit <= value.value) {
								value.upcharge = {
									type: 'Higher Size Upcharge',
									value: (field.upcharge_persentage > 0) ? field.upcharge_persentage : field.upcharge_value,
									unit: (field.upcharge_persentage > 0) ? types.UPCHARGE_UNIT_PERCENTAGE : types.UPCHARGE_UNIT_VALUE,
								}
							}
						}
						value.id = value.measurement_type_id;
						return value;
					});
					profile.values = profile.measurements;
					return profile;
				} else {
					return profile;
				}
			});
		} else {
			return profile;
		}
	});
}
export function updateSaleItemProfile(profile, item_type, saleItemIndex) {
	return dispatch => {
		getUpchargedMeasurementProfile(profile, item_type).then((profile) => {
			dispatch(updateSaleItemEntry(profile, 'profile', saleItemIndex));
		})
	}
}
export function updateSaleStyleItemProfile(profile, item_type, saleItemIndex) {
	return dispatch => {
		//getUpchargedMeasurementProfile(profile, item_type).then((profile) => {
		dispatch(updateSaleItemEntry(profile, 'style_profile', saleItemIndex));
		//})
	}
}

export function getUpCharge(fabricDesign) {
	let upcharge = [];
	fabricDesign.forEach((type) => {
		type.Designs.forEach((design) => {
			if (design.selected > 0 && design.upcharge && design.upcharge > 0) {
				upcharge.push({
					type: design.name,
					value: design.upcharge
				});
			}
		});
	});
	return upcharge;
}

export function updateCustomer(customer) {
	customer.mobile = customer.phone;
	console.log(customer, parseInt(customer.customer_id) > 0, customer.id > 0, customer.customer_id > 0 || customer.id > 0);
	let url = '/order/customer';
	if (customer.customer_id > 0 || customer.id > 0)
		url = '/order/customer/update';
	return dispatch => {
		makeRequest('post', customer, url).then((response) => {
			if (response.status === 200) {
				if (!(customer.customer_id > 0 || customer.id > 0))
					customer.customer_id = response.data.customer_id;
				dispatch({
					type: types.ORDER_CUSTOMER_UPDATE,
					customer
				});
				dispatch(updateMessage(types.ORDER_CUSTOMER_SAVE_SUCCESS, 'Customer ' + customer.name + ' has been updated'));
			} else {
				console.log("Something went wrong with the request", err);
			}
		});
		dispatch(push('/order/details'));
	}
}

export function saveImage(imageDataURL, order_id, type) {
	return dispatch => {
		makeRequest('post', {
			dataURL: imageDataURL,
			order_id: order_id,
			type: type
		}, '/order/saveImage').then(response => {
			if (response.status === 200) {
				dispatch({
					type: types.ORDER_ADD_IMAGE_THUMBNAIL,
					imageDataURL
				})
			} else {
				console.log("Something went wrong with the request", err);
			}
		});
	}
}
const isStylingMismatch = (new_style_upcharge, old_style_upcharge) => {

	if (!_.isArray(new_style_upcharge)) {
		new_style_upcharge = [];
	}
	if (!_.isArray(old_style_upcharge)) {
		old_style_upcharge = [];
	}
	let matched = false;
	let formatedOldUpcharge = _.filter(old_style_upcharge, (_upcharge) => {
		if (_upcharge.type == 'Higher Size Upcharge' || _upcharge.type == 'High Priority Delivery') {
			return false;
		}
		return true;
	});
	let newStylingAddition = _.differenceBy(new_style_upcharge, formatedOldUpcharge, (type) => {
		return `${type.type}-${type.value}`;
	});
	let newStylingDeletion = _.differenceBy(formatedOldUpcharge, new_style_upcharge, (type) => {
		return `${type.type}-${type.value}`;
	});
	let allStylings = old_style_upcharge;
	if (newStylingDeletion.length > 0) {
		matched = true;
		allStylings = allStylings.map((_style) => {
			let deletionStyleIndex = _.find(newStylingDeletion, {
				type: _style.type
			});
			if (!deletionStyleIndex) {
				return _style;
			}
		});
		allStylings = _.compact(allStylings);
	}
	if (newStylingAddition.length > 0) {
		matched = true;
		allStylings = _.concat(allStylings, newStylingAddition);
	}
	if (matched) {
		return allStylings;
	}
	// return true; // If mismatch Exists
	return matched; // If there is no Mismatch
};
export function saveUpcharges(order_id, order_item_id, new_style_upcharge = [], old_style_upcharge = []) {
	let stylingMatch = isStylingMismatch(new_style_upcharge, old_style_upcharge);
	if (stylingMatch) {
		return dispatch => {
			makeRequest('post', {
				order_item_id: order_item_id,
				upcharge: stylingMatch,
				order_id: order_id
			}, '/order/updateupcharge').then(response => {
				if (response.status === 200) {
					console.log('Updated upcharge successfully')
				} else {
					console.log("Something went wrong with the request", err);
				}
			});
		}
	} else {
		return dispatch => {

		}
	}
}


//An Image to be uploaded in AWS s3
//and update in DB
export function saveImageAWS(file, order_id, type, pdf_upload = false) {
	// var order_id = order_id;
	if (pdf_upload) {
		return dispatch => {
			getSignedUrl(file, order_id, type, pdf_upload)
				.then(data => {
					return uploadImagetoAWS(file, data.data.requestUrl, data.data.imageUrl);
				})
				.then(imageUrl => {
					return updatePdfInDB(imageUrl, order_id)
				})
				.then(imageDataURL => {
					window.scrollTo(0, 0);
					dispatch({
						type: types.UPDATE_WORK_ORDERS_BESPOKE_VALUE,
						orderId: imageDataURL.order_id,
						imageDataURL: imageDataURL.imageDataURL
					});
					dispatch(updateMessage('IMAGE_UPLOADED_SUCCESS', 'File uploaded successfully!'));
				})
				.catch(error => {
					window.scrollTo(0, 0);
					dispatch(updateMessage('IMAGE_UPLOADED_FAILURE', 'Failed to upload the image!'));
				});
		}
	} else {
		return dispatch => {
			getSignedUrl(file, order_id, type)
				.then(data => {
					return uploadImagetoAWS(file, data.data.requestUrl, data.data.imageUrl);
				})
				.then(imageUrl => {
					return updateImageInDB(imageUrl, order_id, type)
				})
				.then(imageDataURL => {
					dispatch(updateMessage('IMAGE_UPLOADED_SUCCESS', 'Image uploaded successfully!'));
					dispatch({
						type: types.ORDER_ADD_IMAGE_THUMBNAIL,
						imageDataURL
					})
					dispatch({
						type: types.UPDATE_WORK_ORDERS_MEASUREMENT_IMAGES,
						orderId: order_id,
						imageDataURL: imageDataURL
					});
				})
				.catch(error => {
					console.log('Error to upload the image: ', error);
					dispatch(updateMessage('IMAGE_UPLOADED_FAILURE', 'Failed to upload the image!'));
				});
		}
	}
}

//An Image to be uploaded in AWS s3
export function saveMeasurementProfileImageInAWS(file, profile_id, type) {
	return dispatch => {
		getSignedUrl(file, profile_id, type)
			.then(data => {
				return uploadImagetoAWS(file, data.data.requestUrl, data.data.imageUrl);
			})
			// .then(imageUrl => {
			// 	return updateImageInDB(imageUrl, order_id, type)
			// })
			.then(imageDataURL => {
				dispatch(updateMessage('IMAGE_UPLOADED_SUCCESS', 'Image uploaded successfully!'));
				dispatch({
					type: types.ORDER_ADD_IMAGE_THUMBNAIL,
					imageDataURL
				})
			})
			.catch(error => {
				console.log('Error to upload the image: ', error);
				dispatch(updateMessage('IMAGE_UPLOADED_FAILURE', 'Failed to upload the image!'));
			});
	}
}


//To get the s3 signed url
export function getSignedUrl(file, order_id, type, pdf_upload) {

	var fileObject = {
		type: file.type,
		size: file.size,
		name: file.name,
		order_id: order_id
	};
	console.log('fileObject: ', fileObject);

	return makeRequest('post', {
		file: fileObject,
		pdfFormat: pdf_upload
	}, '/s3/image/getsignedurl')
		.then((response) => {
			let data = response.data;

			return data;
		})
		.catch((error) => {
			console.log('Error on getting signed request : ', error);
			throw new Error(error.message);
		});
}

//To upload into AWS s3 image using signed url
export function uploadImagetoAWS(file, signed_request, response_url) {
	var options = {
		headers: {
			'Content-Type': file.type
		}
	};

	return request
		.put(signed_request, file, options)
		.then((data) => {
			return response_url;
		})
		.catch((error) => {
			throw new Error(error.message);
		});
}

//To update in DB
export function updateImageInDB(imageDataURL, order_id, type) {
	return makeRequest('post', {
		dataURL: imageDataURL,
		order_id: order_id,
		type: type
	}, '/order/saveImage')
		.then((response) => {
			return imageDataURL;
		})
		.catch((error) => {
			throw new Error(error.message);
		});
}
export function updatePdfInDB(imageDataURL, order_id) {
	return makeRequest('post', {
		dataURL: imageDataURL,
		order_id: order_id
	}, '/order/savePdf')
		.then((response) => {
			return { imageDataURL, order_id };
		})
		.catch((error) => {
			throw new Error(error.message);
		});
}

export function updatePriorityType(priority_type) {
	return {
		type: types.ORDER_DETAILS_UPDATE_PRIORITY_TYPE,
		priority_id: priority_type
	}
}
export function updateFullPaymentFlag(value) {

	return {
		type: types.ORDER_DETAILS_UPDATE_FULL_PAYMENT_FLAG,
		is_full_payment: value
	}
}

export function updateTailor(tailor) {
	return {
		type: types.ORDER_DETAILS_UPDATE_TAILOR,
		tailor_id: tailor
	}
}

export function updateSalesman(salesman_id) {
	return {
		type: types.ORDER_DETAILS_UPDATE_SALESMAN,
		salesman_id
	}
}
export function updateDeliveryLocation(delivery_location_id) {
	return {
		type: types.ORDER_DETAILS_UPDATE_DELIVERYLOCATION,
		delivery_location_id
	}
}
export function updateFitonLocation(fiton_location_id) {
	return {
		type: types.ORDER_DETAILS_UPDATE_FITONLOCATION,
		fiton_location_id
	}
}

export function updateOrderPIN(pin) {
	return {
		type: types.ORDER_DETAILS_UPDATE_PIN,
		pin
	}
}
export function updateOrderPINDate(pindate) {
	return {
		type: types.ORDER_DETAILS_UPDATE_PIN_Date,
		pindate
	}
}
export function updateOccasion(occasion) {
	return {
		type: types.ORDER_DETAILS_UPDATE_OCCASION,
		occasion
	}
}

export function updatePaymentType(payment_type_id) {
	return {
		type: types.ORDER_DETAILS_UPDATE_PAYMENT_TYPE,
		payment_type_id
	}
}

export function updateBenificiaryPhone(benificiary_phone) {
	return {
		type: types.ORDER_DETAILS_UPDATE_BENIFICIARY_PHONE,
		benificiary_phone
	}
}
export function updateBenificiaryName(benificiary_name) {
	return {
		type: types.ORDER_DETAILS_UPDATE_BENIFICIARY_NAME,
		benificiary_name
	}
}
export function updateBenificiaryEmail(benificiary_email) {
	return {
		type: types.ORDER_DETAILS_UPDATE_BENIFICIARY_EMAIL,
		benificiary_email
	}
}

export function updateOccasionDate(date) {
	return {
		type: types.ORDER_DETAILS_UPDATE_OCCASION_DATE,
		date
	}
}

export function updateDeliveryAddress(address) {
	return {
		type: types.ORDER_DETAILS_UPDATE_DELIVERYADDRESS,
		address
	}
}
export function updateBillingAddress(address) {
	return {
		type: types.ORDER_DETAILS_UPDATE_BILLINGADDRESS,
		address
	}
}
function openFormSaleItem(close) {
	return {
		type: types.ORDER_SALES_OPEN_FORM,
		close
	}
}

function openFormMeasurements(close) {
	return {
		type: types.ORDER_SALE_ITEM_OPEN_MEASUREMENTS,
		close
	}
}

function openSignature(close) {
	return {
		type: types.OPEN_SIGNATURE,
		close
	}
}

function openFormStyles(close) {
	return {
		type: types.ORDER_SALE_ITEM_OPEN_STYLES,
		close
	}
}

export function initNewSaleItem(item_type, customer_id, sales, fabric_details = {}) {
	let existComment = false;
	item_type = parseInt(item_type);
	sales && sales.map((item, index) => {
		if (item && item.item_type_id == item_type) {
			existComment = item.comment || true;
		}
	});

	return dispatch => {
		dispatch({
			type: types.FETCH_LIST_MEASUREMENT_FIELDS,
			measurement_fields: []
		});

		dispatch({
			type: types.FETCH_LIST_FABRIC_DESIGN_FIELDS,
			fabric_design_fields: []
		});

		dispatch({
			type: types.ORDER_SALES_INIT_SALE_ITEM,
			item_type,
			comment: (typeof existComment === 'string') ? existComment : '',
			data: fabric_details
		});

		if (!existComment) {
			makeRequest('get', null, `/order/latestcomment?customer_id=${customer_id}&item_type_id=${item_type}`)
				.then((res) => {
					let data = res.data && res.data.data;

					let comment = (data && data.comment) || '';

					dispatch({
						type: types.UPDATE_ORDER_SALES_INIT_SALE_ITEM,
						item_type,
						comment
					});
				})
				.catch((error) => {
					console.error(error);
				})
		}
	};
}
export function deleteSaleItem(saleItem, order_item_id, index, fabric_measurement) {
	return dispatch => {
		if (order_item_id && parseInt(order_item_id) > 0) {
			const formValues = _.cloneDeep(fabric_measurement);
			formValues.type = 'DELETE ORDER';
			formValues.record_id = saleItem.order_item_id;
			formValues.item_type_id = saleItem.item_type_id;
			formValues.order_item_id = order_item_id;

			makeRequest('post', formValues, '/order/item/delete').then((response) => {
				if (response.status === 200) {
					if (!fabric_measurement.isMTM) {
						console.log('SALEEE ITEMMM', saleItem);
						makeRequest('post', fabric_measurement, '/order/measurementinventory');

					}
					dispatch(updateMessage(types.DELETE_ORDER_ITEM_SUCCESS, 'The order item has been deleted the records'));
					dispatch({
						type: types.ORDER_SALE_ITEM_DELETE,
						index
					});
				} else {
					dispatch(updateMessage(types.DELETE_ORDER_ITEM_FAILURE, "something went wrong with the deletion of order item"));
				}
			});

		} else {
			dispatch({
				type: types.ORDER_SALE_ITEM_DELETE,
				index
			});
		}

	}
}

export function selectSaleItem(index) {
	return {
		type: types.ORDER_SALE_ITEM_SELECT,
		index
	}
}
export function updateSaleItemEntry(value, field, index) {
	return {
		type: types.ORDER_SALES_UPDATE_SALE_ITEM_ENTRY,
		payload: {
			value,
			field,
			index
		}
	}
}
export function updateMeasurements(value, field) {
	return {
		type: types.UPDATE_MEASUREMENTS_VALUES,
		payload: {
			value,
			field
		}
	}
}
export function removeMeasurements(clear) {
	return {
		type: types.CLEAR_MEASUREMENTS_VALUES,
		payload: {
			clear
		}
	}
}



export function savePhoto(imageURL, order_id) {
	makeRequest('post', {
		order_id,
		imageURL
	}, '/order/photos').then((response) => {
		if (response.status === 200) {
			return response.data;
		} else {
			console.log("something went wrong with the saving of the photographs");
		}
	})
}

export function saveThumbnail(dataURL) {
	return {
		type: types.ORDER_ADD_IMAGE_THUMBNAIL,
		dataURL
	}
}

function saveOrderDetails(order_details) {
	debugger;
	return {
		type: types.ORDER_DETAILS_UPDATE,
		order_details
	}
}

function getPendingOrderDetails(order_details) {
	return {
		type: types.ORDER_PENDING_DETAILS_UPDATE,
		order_details
	}
}
export function openForm(type, close) {
	return dispatch => {
		switch (type) {
			case 'measurements':
				dispatch(openFormMeasurements(close));
				break;
			case 'styles':
				dispatch(openFormStyles(close));
				break;
			case 'saleItem':
				dispatch(openFormSaleItem(close));
				break;
			case 'signature':
				dispatch(openSignature(close));
				break;
		}
	}
}

export function saveOrderItem(order_item, is_update, index) {
	return dispatch => {
		var url = (is_update) ? '/order/item/update' : '/order/item';
		if (!is_update && order_item && order_item.order_item_id > 0 && order_item.workflow_id === 2) {
			url = '/order/altered/item';
		}
		makeRequest('post', order_item, url).then((saleResponse) => {
			if (!is_update && !order_item.order_item_id)
				order_item.order_item_id = saleResponse.data.order_item_id;
			if (saleResponse.status === 200) {
				if (!order_item.isMTM) {
					if ((!is_update) || (order_item.old_fabric_measurement && order_item.fabric_measurement.product_sku_code == order_item.old_fabric_measurement.product_sku_code)) {
						//const tempFabricMeasurement = _.cloneDeep(order_item.fabric_measurement);
						order_item.fabric_measurement.qty = (order_item.qty) - (order_item.old_qty);
						order_item.fabric_measurement.store_id = order_item.store_id;

						order_item.fabric_measurement.type = 'ORDER';
						order_item.fabric_measurement.record_id = order_item.order_item_id;
						order_item.fabric_measurement.item_type_id = order_item.item_type_id;
						makeRequest('post', order_item.fabric_measurement, '/order/measurementinventory');
					} else {
						let oldFabricMeasurement = {};
						oldFabricMeasurement = order_item.old_fabric_measurement;
						oldFabricMeasurement.qty = -oldFabricMeasurement.qty;
						makeRequest('post', oldFabricMeasurement, '/order/measurementinventory');
						order_item.fabric_measurement.qty = order_item.qty;
						order_item.fabric_measurement.store_id = order_item.store_id;

						order_item.fabric_measurement.type = 'ORDER';
						order_item.fabric_measurement.record_id = order_item.order_item_id;
						order_item.fabric_measurement.item_type_id = order_item.item_type_id;

						makeRequest('post', order_item.fabric_measurement, '/order/measurementinventory');

					}
				}
				if (order_item.thumbnails && order_item.thumbnails.length > 0) {
					let thumbnailsObj = {
						order_id: order_item.order_id,
						thumbnails: order_item.thumbnails,
						type: types.IMAGE_TYPE_MEASUREMENT
					}
					makeRequest('post', thumbnailsObj, '/order/updatemeasurementimages');
				}
				if (order_item.order_item_id &&
					order_item.style_profile &&
					order_item.style_profile.name &&
					order_item.style_profile.profile_id == -1
				) {
					let style_profile = {
						...order_item.style_profile,
						order_item_id: order_item.order_item_id,
					};
					saveStyleProfile(style_profile).then((profile) => {
						order_item.style_profile = profile;
						order_item.style_profile_id = profile.profile_id;
						saveFabricDesign(order_item.order_item_id, profile.fabric_design, profile.fabric_design_comment, profile.profile_id, profile.name);
						dispatch(updateMessage(types.SALE_ITEM_SAVE_SUCCESS, 'Sale Item details have been saved'));
						dispatch({
							type: types.ORDER_SALES_UPDATE_SALE_ITEM,
							order_item,
							index
						});
					});
				} else {
					if (order_item.order_item_id && order_item.style_profile_id > 0 && order_item.style_profile) {
						saveFabricDesign(order_item.order_item_id, order_item.style_profile.fabric_design, order_item.style_profile.comment, order_item.style_profile_id, order_item.style_profile.name);
					}
					dispatch(updateMessage(types.SALE_ITEM_SAVE_SUCCESS, 'Sale Item details have been saved'));
					dispatch({
						type: types.ORDER_SALES_UPDATE_SALE_ITEM,
						order_item,
						index
					})
				}

			} else {
				console.log("something went wrong with the sale request");
			}
		})
	}
}
export function saveCommentOrderItems(order_item, order_sales_items) {
	return dispatch => {
		var url = '/order/item/update';
		order_sales_items.map((item, index) => {
			if (item && item.order_item_id && item.order_item_id != order_item.order_item_id && order_item.item_type_id == item.item_type_id) {
				item.comment = order_item.comment;
				/*
					Representing the Upcharges in the Array Instead of Object
				*/
				item.upcharges = (item.upcharges && _.isArray(item.upcharges)) ? item.upcharges : [];
				makeRequest('post', item, url).then((saleResponse) => {
					if (saleResponse.status === 200) {
						dispatch({
							type: types.ORDER_SALES_UPDATE_SALE_ITEM,
							order_item: item,
							index
						});
					}
				});
			}
		});
	}
}
export function saveMeasurements(profile_id, measurements) {
	if (measurements && measurements.length > 0) {
		const _measurement = {
			profile_id,
			measurements
		};

		return makeRequest('post', _measurement, '/order/item/bulkmeasurement')
			.then((measurementResponse) => {
				if (measurementResponse.status === 200)
					return measurementResponse.data;
				else
					console.log("Something went wrong when saving measurmenets");
			})
			.then(function () {
				return profile_id;
			});
	} else {
		return profile_id;
	}
	// return Promise.all(measurements.map((measurement) => {
	// 	const _measurement = {
	// 		type_id: measurement.id,
	// 		profile_id: profile_id,
	// 		value: measurement.value
	// 	};
	// 	return makeRequest('post', _measurement, '/order/item/measurement').then((measurementResponse) => {
	// 		if (measurementResponse.status === 200)
	// 			return measurementResponse.data;
	// 		else
	// 			console.log("Something went wrong when saving measurmenets");
	// 	})
	// })).then(function () {
	// 	return profile_id;
	// });
}

export function saveFabricDesign(order_item_id, fabric_design, comment, profile_id) {

	return makeRequest('post', {
		fabric_design,
		comment,
		profile_id
	}, '/order/item/fabricDesign?order_item_id=' + order_item_id).then(fabricDesignResponse => {
		if (fabricDesignResponse.status === 200)
			return fabricDesignResponse.data;
		else
			console.log("Something went wrong when saving Fabric Design");
	});
}
export function saveStyleFabricDesign(order_item_id, profile_id, fabric_design_comment) {
	return makeRequest('post', {
		order_item_id,
		profile_id,
		fabric_design_comment
	}, '/order/item/style/fabricDesign').then(fabricDesignResponse => {
		if (fabricDesignResponse.status === 200)
			console.log('Succesfully Updated');
		else
			console.log("Something went wrong when saving Fabric Design");
	});
}

function saveOrder(order, isUpdate) {
	debugger;
	if (!order.details.total_amount)
		order.details.total_amount = 0;
	const url = isUpdate ? '/order/details/update' : '/order/details';
	return makeRequest('post', order.details, url).then((response) => {
		if (response.status === 200) {
			if (response.data.order_id)
				order.details.order_id = response.data.order_id;
			return order;
		}
	})
}
export function updateOrderDetails(details) {
	debugger;
	return dispatch => {
		const order = {
			details
		};
		const isUpdate = details.order_id > 0;
		saveOrder(order, isUpdate).then(function (order) {
			dispatch(saveOrderDetails(order.details));
			dispatch(push('/order/sales'));
			dispatch(updateMessage(types.ORDER_DETAILS_SAVE_SUCCESS, 'Order details have been saved'));

		});
	}
}

export function getTaxes(item_type_id, discount, store_id, completeUpchargeMrp, sku_code) {
	let url = '/order/taxes?item_type_id=' + parseInt(item_type_id) + '&sku_code=' + sku_code;
	if (parseInt(discount) > 0) {
		url += '&has_discount=true';
	}
	url += '&store_id=' + store_id;
	url += `&total=${completeUpchargeMrp}`;
	return makeRequest('get', null, url).then((response) => {
		if (response.status === 200) {
			return response.data;

		} else {
			console.log("Something went wrong when getting taxes");
		}
	});
}

export function getDiscountedTotal(sale) {
	let mrp = getUpChargedTotal(sale, sale.mrp);
	if (!sale.discount_type)
		sale.discount_type = types.UPCHARGE_UNIT_VALUE;
	if (sale.discount_type && sale.discount_value) {
		switch (sale.discount_type) {
			case types.UPCHARGE_UNIT_VALUE:
				mrp = Math.floor(parseFloat(mrp) - parseFloat(sale.discount_value / sale.qty));
				break;
			case types.UPCHARGE_UNIT_PERCENTAGE:
				mrp = mrp - Math.floor((mrp * (sale.discount_value) / 100));
				break;
		}
	}
	return parseFloat(mrp).toFixed(2);
}

export function getUpChargedTotal(sale, mrp) {
	let upChargeList = [];

	if (sale.upcharges && sale.upcharges.length > 0)
		upChargeList = sale.upcharges;
	if (sale.profile && sale.profile.measurements && sale.profile.measurements.length > 0)
		upChargeList = upChargeList.concat(_.compact(_.map(sale.profile.measurements, 'upcharge')));

	const totalUpCharge = upChargeList.reduce((_prev, _sale) => {
		if (_sale.type != types.DELIVERY_UPCHARGE) {
			if (_sale.unit == types.UPCHARGE_UNIT_VALUE)
				return _prev + parseInt(_sale.value);
			else if (_sale.unit == types.UPCHARGE_UNIT_PERCENTAGE)
				return _prev + Math.floor(sale.mrp * _sale.value / 100);
			else if (_sale.value)
				return _prev + parseInt(_sale.value);
		} else {
			return _prev;
		}
	}, 0);

	return ((parseFloat(mrp) + totalUpCharge)).toFixed(2);
}
export function fetchUpdatedOrderWithTaxCalc(sales, store_id) {

	return Promise.all(sales.map((sale) => {
		let completeUpchargeMrp = getDiscountedTotal(sale);
		var sku_code = sale.product_sku || sale.display_sku;
		return getTaxes(sale.item_type_id, sale.discount_value, store_id, completeUpchargeMrp, sku_code);
	})).then((_taxes) => {
		const taxes = _taxes.map((tax) => {
			return _.orderBy(tax, ['order'], ['asc'])
		});
		for (var i = 0; i < sales.length; i++) {
			const discountedTotal = getDiscountedTotal(sales[i]);

			sales[i].taxes = taxes[i];
			sales[i].upcharges = (sales[i].upcharges && _.isArray(sales[i].upcharges)) ? sales[i].upcharges : [];
			const delivery_upcharge = sales[i].upcharges.reduce((prev, next) => {
				if (next.type == types.DELIVERY_UPCHARGE) {
					return prev + next.value;
				} else {
					return prev;
				}
			}, 0);
			let totalTax = 0;
			let completeTaxPercent = 0;
			sales[i].taxes && sales[i].taxes.map((tax) => {
				completeTaxPercent += tax.percent;
			});
			let _dicountedTotal = parseFloat(discountedTotal) + (parseFloat(delivery_upcharge));
			let _temptax = (_dicountedTotal / (100 + completeTaxPercent) * 100);
			// let _temp_delivery_upcharge = (parseFloat(delivery_upcharge) / (100 + completeTaxPercent) * 100);
			sales[i].taxes = sales[i].taxes.map((tax) => {
				tax.value = ((parseFloat(tax.percent) / 100) * _temptax);
				tax.mrp_before_tax = parseFloat(_temptax);
				// tax.delivery_before_tax = _temp_delivery_upcharge;
				// tax.delivery_tax = ((parseFloat(tax.percent) / 100) * _temp_delivery_upcharge);
				// _temptax = _temptax - tax.value;
				totalTax += tax.value;
				return tax;
			});
			sales[i].discountedMRP = discountedTotal;
			sales[i].totalBeforeMRP = discountedTotal - totalTax;
			sales[i].subTotal = ((parseFloat(discountedTotal) + parseFloat(delivery_upcharge)) * sales[i].qty); //+ parseFloat(delivery_upcharge);
		}
		const _sales = _.cloneDeep(sales);
		var total = _sales.reduce((prev, next) => {
			return prev + parseInt(next.subTotal);
		}, 0);
		return {
			_sales,
			total
		}
	});
}
export function calculateTaxes(sales, store_id, load_discounts = false, order_details) {

	return dispatch => {
		dispatch({
			type: types.ORDER_ITEMS_LOADING
		});
		fetchUpdatedOrderWithTaxCalc(sales, store_id).then(({
			_sales,
			total
		}) => {
			dispatch({
				type: types.ORDER_ITEMS_POPULATE,
				sales: _sales
			});
			dispatch(updateOrderTotal(total));
			if (load_discounts) {
				order_details.total_amount = total;
				dispatch(loadLoalityDiscounts(_sales, order_details));
			}
		});
	}

}

export function getDeliveryUpcharge(item_type_id, priority_id) {
	if (parseInt(item_type_id) > 0 && parseInt(priority_id) > 0) {
		return makeRequest('get', null, '/priority/upcharge?item_type=' + item_type_id + "&priority_id=" + priority_id).then((response) => {
			if (response.status === 200) {
				const priority = _.find(response.data, {
					priority_id: parseInt(priority_id)
				})
				if (priority && priority.delivery_upcharge > 0)
					return priority.delivery_upcharge;
				else
					return false;
			} else {
				return false;
			}
		}).catch((err) => {
			return false;
		})
	} else {
		return Promise.resolve(false);
	}
}


export function getInvoiceDetails(customer_id, order_id) {
	return dispatch => {
		const details = {};
		makeRequest('get', null, '/details/customer?customer_id=' + customer_id).then((response) => {
			if (response.status === 200) {
				details.customer = response.data;
			}
			return;
		}).then(() => {
			return makeRequest('get', null, '/details/list/order?order_id=' + order_id).then((response) => {
				if (response.status === 200) {
					details.sales = response.data;
				}
			})
		}).then(() => {
			return makeRequest('get', null, '/details/order?order_id=' + order_id).then((response) => {
				if (response.status === 200) {
					details.order = response.data;
				}
			})
		}).then(() => {
			return makeRequest('get', null, '/details/image?order_id=' + order_id + '&image_id=' + types.IMAGE_TYPE_SIGNATURE).then((response) => {
				if (response.status === 200) {
					details.signature = '';
					if (response.data[0] && response.data[0].image) {
						response.data[0].image.data.forEach((charCode) => {
							details.signature += String.fromCharCode(charCode);
						})
					}
				}
			})
		}).then(() => {
			dispatch({
				type: types.POPULATE_INVOICE_DATA,
				details
			})
		});
	}
}

export function calculateShippingTaxes(order) {
	let shipping_taxes = [];
	let shipping_cgst = '';
	let shipping_rate = '';

	shipping_rate = (order.shipping_charges && order.shipping_charges > 0) ? parseFloat(order.shipping_charges / (112) * 100) : null;
	shipping_cgst = (shipping_rate && shipping_rate > 0) ? parseFloat(shipping_rate * 0.06) : null;

	shipping_taxes = [{ "delivery_tax": 0, "name": "CGST", "mrp_before_tax": shipping_rate, "percent": 6, "value": shipping_cgst, "delivery_before_tax": 0, "order": 1 }, { "delivery_tax": 0, "name": "SGST", "mrp_before_tax": shipping_rate, "percent": 6, "value": shipping_cgst, "delivery_before_tax": 0, "order": 2 }]

	return shipping_taxes;

}

export function saveCompleteOrder(order, user) {
	order.details.shipping_taxes = calculateShippingTaxes(order.details);
	let newSalesArray = updateCouponAmountInOrderItemLevel(order.sales, order.details);
	if (newSalesArray) {
		newSalesArray = order.sales;
	}
	// if (newSalesArray) {
	// 	dispatch(calculateTaxes(newSalesArray, store_id));
	// }
	return dispatch => {
		return fetchUpdatedOrderWithTaxCalc(newSalesArray, order.details.store_id).then(({
			_sales,
			total
		}) => {
			order.details.total_amount = total;
			order.sales = _sales;
			//save Order Items and get Order ID
			return makeRequest('post', order.details, '/order/details/update').then((response) => {
				if (response.status === 200) {
					//order.details.order_id = response.data.order_id;
					dispatch(saveOrderDetails(order.details));
					return order;
				} else {
					console.log("Something went wrong with the request");
				}
			}).then((order) => {
				return Promise.all(newSalesArray.map((sale) => {
					if (sale.taxes) {
						return makeRequest('post', sale, '/order/item/update').then((response) => {
							if (response.status === 200) {
								return;
							}
						})
					} else {
						return {};
					}
				})).then((responses) => {
					return order;
				});
			}).then((order) => {
				//makeRequest('get', null, '/order/invoice?customer_id=' + order.details.customer_id + "&order_id=" + order.details.order_id);
				if (!order.details.is_full_payment) {
					makeRequest('get', null, '/getreceiptdetails?order_id=' + order.details.order_id);
				}
				// makeRequest('get', null, '/order/sendpiemail?order_id=' + order.details.order_id);
				// makeRequest('get', null, '/getinvoicedetails?order_id=' + order.details.order_id);
				// makeRequest('get', null, '/order/sendpiemail?order_id=' + order.details.order_id);
				makeRequest('get', null, `/order/sendinvoicewithpi?order_id=${order.details.order_id}`);
				// makeRequest('get', null, '/getinvoicedetails?order_id=' + order.details.order_id);

				dispatch(updateMessage(types.ORDER_SAVE_SUCCESS, 'The order has been saved'));
				dispatch({
					type: 'CLEAR_DATA'
				});
				dispatch(push('/stores'));
			});
		});
	}
}

export function reset() {
	return dispatch => {
		dispatch({
			type: 'RESET_STATES'
		});
	}
}
function saveLoyalityPoints(loyality_points_and_tier) {
	return {
		type: types.SAVE_LOYALITY_POINTS,
		loyality_points_and_tier
	}
}

export function loadLoyalityPoints(store_id, customer_id) {
	var requestObj = {
		store_id: store_id,
		customer_id: customer_id
	}
	return dispatch => {
		return makeRequest('post', requestObj, '/getlayalitypoints').then((response) => {
			if (response.status === 200) {
				var data = response.data.data
				dispatch(saveLoyalityPoints(data));
			}
		});
	}
}
export function saveDiscountType(discount_redeem_coupon_type) {
	return {
		type: types.DISCOUNT_REDEEM_COUPON_TYPE,
		discount_redeem_coupon_type
	}
}
export function setCouponRedeemStatus(coupon_details) {
	return {
		type: types.COUPON_RESPONSE_DETAILS,
		coupon_details
	}

}
export function setOrderLevelCoupon(coupon_details) {
	return {
		type: types.SAVE_COUPON_DETAILS,
		coupon_details
	}
}
export function validatePromoCode(promocode, mobile, store_id) {
	var requestObj = {
		promocode: promocode,
		mobile: mobile,
		store_id: store_id
	}
	return dispatch => {
		return makeRequest('post', requestObj, '/iscouponredeemable').then((response) => {
			if (response.status === 200) {
				let redeemable = response.data.data.response.coupons.redeemable;
				dispatch(setCouponRedeemStatus({
					type: "coupon",
					is_redeemable: redeemable.is_redeemable,
					message: redeemable.item_status.message,
					points: redeemable.series_info ? redeemable.series_info.discount_value : null,
					discount_type: redeemable.series_info ? redeemable.series_info.discount_type : null,
					code: redeemable.code
				}))
			}
		});
	}
}
export function calculateDiscounts(discounts, total_amount) {
	let discountAmount = 0, discountComment = '';
	discounts && discounts.map((_discount, index) => {
		if (_discount && !_discount.is_payment_mode && !_discount.is_calculated) {
			if (_discount.type == "redeempoints" && _discount.redeem_applied == true) {
				discountAmount += ((_discount.points_redeem_value * 100) / total_amount);

			} else if (_discount.type == "coupon" && _discount.coupon_applied == true) {
				if (_discount.is_absolute == "false" || _discount.is_absolute == false) {
					discountAmount += ((parseFloat(couponDetails.points) * 100) / total_amount);
				} else {
					discountAmount += couponDetails.points;
				}
			}
			discountComment += _discount.name;
		}
	});
	return {
		discountAmount : parseFloat(discountAmount.toFixed(2)),
		discountComment
	};
}

export function updateCouponAmountInOrderItemLevel(sales, orderDetails) {
	var discountObj = calculateDiscounts(orderDetails.discounts, orderDetails.total_amount);
	if (discountObj.discountAmount) {
		let newSalesArray = sales.map((orderItem, index) => {
			let bill_amount = orderItem.bill_amount || orderItem.subTotal;
			if (orderItem.discount_type == 2) {
				orderItem.discount_value = parseFloat(orderItem.discount_value || 0) + discountObj.discountAmount;
			} else {
				orderItem.discount_value = parseFloat(orderItem.discount_value || 0) + (bill_amount * discountObj.discountAmount) / 100;
				orderItem.discount_type = 1;
			}
			orderItem.discount_value = parseFloat( (orderItem.discount_value || 0 ).toFixed(2));
			orderItem.discount_comment = `${orderItem.discount_comment || ""} ${discountObj.discountComment}`;
			return orderItem;
		});
		return newSalesArray;
	}
	return false;
}
export function savePromoCode(promocode, mobile, store_id, sales, total_amount) {
	var requestObj = {
		promocode: promocode,
		mobile: mobile,
		store_id: store_id
	}
	return dispatch => {
		return makeRequest('post', requestObj, '/redeemcoupon').then((response) => {
			if (response.status === 200 && response.data.data.response.coupons) {
				let couponResponse = response.data.data.response.coupons;
				let couponObj = {
					type: "coupon",
					is_redeemable: couponResponse.coupon.item_status.success,
					message: couponResponse.coupon.item_status.message,
					points: couponResponse.coupon.coupon_value ? couponResponse.coupon.coupon_value : null,
					discount_type: couponResponse.coupon.discount_code ? couponResponse.coupon.discount_code : null,
					code: couponResponse.coupon.code,
					is_absolute: couponResponse.coupon.is_absolute == "false" ? false : true,
					coupon_applied: couponResponse.coupon.item_status.success == "true" ? true : false,
					is_payment_mode: false,
					name: 'Loyality Coupon Discount'
				};
				dispatch(setCouponRedeemStatus(couponObj));
				if (couponObj.coupon_applied) {
					dispatch(setOrderLevelCoupon(couponObj));
				}

				// let newSalesArray = updateCouponAmountInOrderItemLevel(couponObj, sales, store_id, total_amount, promocode);
				// if (newSalesArray) {
				// 	dispatch(calculateTaxes(newSalesArray, store_id));
				// }
			} else {
				console.log("error in  Capillary API");
			}
		});
	}
}

export function validateRedeemPoints(redeem_points, mobile, store_id) {
	var requestObj = {
		redeem_points: redeem_points,
		mobile: mobile,
		store_id: store_id
	}
	return dispatch => {
		return makeRequest('post', requestObj, '/validatepoints').then((response) => {
			if (response.status === 200) {
				let redeemPointsValidationObj = response.data.data.response.validation_code.code;
				dispatch(setCouponRedeemStatus({
					type: "validatepoints",
					is_redeemable: redeemPointsValidationObj.item_status.success,
					message: redeemPointsValidationObj.item_status.message,
					points: redeemPointsValidationObj.points,
					discount_type: null

				}))
			}
		});
	}
}
export function redeemPointsCode(value, points, mobile, store_id, sales, total_amount) {
	var requestObj = {
		redeem_points: points,
		mobile: mobile,
		store_id: store_id,
		validation_code: value
	}
	return dispatch => {
		return makeRequest('post', requestObj, '/ispointsredeemable').then((response) => {
			if (response.status === 200 && response.data.data.response.points) {
				let redeemablePointsObj = response.data.data.response.points.redeemable;
				let couponObj = {
					type: "redeempoints",
					is_redeemable: redeemablePointsObj.is_redeemable,
					message: redeemablePointsObj.item_status.message,
					points: redeemablePointsObj.points ? redeemablePointsObj.points : null,
					points_currency_ratio: redeemablePointsObj.points_currency_ratio,
					points_redeem_value: redeemablePointsObj.points_redeem_value,
					redeem_applied: redeemablePointsObj.is_redeemable == "true" ? true : false,
					validation_code: value,
					is_payment_mode: false,
					name: 'Loyality Points Discount',
					is_absolute: true
					//code:redeemable.code,
					//	points_redeemed:redeemablePointsObj.points_redeemed
				};
				dispatch(setCouponRedeemStatus(couponObj));
				if (couponObj.redeem_applied) {
					dispatch(setOrderLevelCoupon(couponObj));
				}
				// let newSalesArray = updateCouponAmountInOrderItemLevel(couponObj, sales, store_id, total_amount, 'Loyality Points');
				// if (newSalesArray) {
				// 	dispatch(calculateTaxes(newSalesArray, store_id));
				// }
			}
		});
	}
}
export function updateHalfPayment(half_amount) {
	return {
		type: types.ORDER_DETAILS_UPDATE_HALF_AMOUNT,
		half_amount
	}
}
export function updatePendingAmount(pending_amount) {
	return {
		type: types.ORDER_DETAILS_UPDATE_PENDING_AMOUNT,
		pending_amount
	}
}

export function updateShippingCharges(shipping_charges) {
	return {
		type: types.ORDER_DETAILS_UPDATE_SHIPPING_CHARGES,
		shipping_charges
	}
}

export function updateApprovedBy(approved_details) {

	return {
		type: types.ORDER_DETAILS_APPROVED_BY,
		approved_details
	}
}


export function cartAddressInsert(formValues) {
	return dispatch => {
		return makeRequest('post', formValues, '/insertcustomeraddress').then(response => {
			if (response.status === 200) {
				dispatch(fetchCustomerAddress(formValues.customer_id));
				var message = formValues.m_customer_addresses_id ? "updated" : "added"
				dispatch(updateMessage('INSERT_ADDRESS_SUCCESS', `Address has been ${message} successfully`));
				window.scrollTo(0, 0);
			} else {
				dispatch(updateMessage('INSERT_ADDRESS_FAILURE', `Failed to ${message} the address`));
				window.scrollTo(0, 0);
			}

		});
	}
}
export function getStylingUpchargeDiscount(current_tier, sales, store_id, order_id, customer_id) {
	var requestObj = {
		current_tier: current_tier,
		order_id: order_id,
		customer_id: customer_id,
		discount_type: 'Order Styling',
		sales: sales
	}
	return dispatch => {
		return makeRequest('post', requestObj, '/get/loyality/tier/discount').then((response) => {
			if (response.status === 200) {
				var data = response.data[0] || {};
				dispatch(saveLoyalityTierDiscount(data));

				let newSalesObj = updateLoyalityAmountInOrderItemLevel(data, sales, store_id);
				if (newSalesObj) {
					dispatch(calculateTaxes(newSalesObj.newSalesArray, store_id));
					var obj = {};
					if (data.styling_discount) {
						obj['styling_discount'] = {
							customer_id: customer_id,
							order_id: order_id,
							fyear_id: 1,
							capilary_charge_rules_id: 1,
							discount_amount: newSalesObj.data.styling_discount
						}
					}
					if (data.measurement_discount) {
						obj['measurement_discount'] = {
							customer_id: customer_id,
							order_id: order_id,
							fyear_id: 1,
							capilary_charge_rules_id: 2,
							discount_amount: newSalesObj.data.measurement_discount
						}
					}

					dispatch(saveLoyalityTierDiscountObj(obj));
				}
			}
		});
	}
}


export function calculateOrderItemUpcharges(orderItem) {
	var totalOrderItemUpcharge = 0;
	orderItem.upcharges.map((item, index) => {
		if (item.type != types.DELIVERY_UPCHARGE) {
			if (item.unit == types.UPCHARGE_UNIT_VALUE)
				totalOrderItemUpcharge = totalOrderItemUpcharge + parseInt(item.value);
			else if (item.unit == types.UPCHARGE_UNIT_PERCENTAGE)
				totalOrderItemUpcharge = totalOrderItemUpcharge + Math.floor(sale.mrp * item.value / 100);
			else if (item.value)
				totalOrderItemUpcharge = totalOrderItemUpcharge + parseInt(item.value);
		} else {
			totalOrderItemUpcharge = totalOrderItemUpcharge;
		}
	});

	return totalOrderItemUpcharge;

}
export function calculateUpcharges(sales) {
	var totalUpchargeAmount = 0;
	sales.map((orderItem, index) => {
		totalUpchargeAmount = totalUpchargeAmount + calculateOrderItemUpcharges(orderItem);

	});

	return totalUpchargeAmount;

}
export function calculateMeasurementUpcharges(sales) {
	var totalOrderItemUpcharge = 0;
	sales.map((sale, index) => {
		totalOrderItemUpcharge = totalOrderItemUpcharge + calculateOrderItemMeasurementUpcharges(sale);

	});


	return totalOrderItemUpcharge;

}

export function calculateOrderItemMeasurementUpcharges(sale) {
	var totalOrderItemUpcharge = 0;
	var measurementUpchargeArray = [];
	if (sale.profile && sale.profile.measurements && sale.profile.measurements.length > 0) {

		console.log("upcharges.concat(_.compact(_.map(sale.profile.measurements, 'upcharge')));", _.compact(_.map(sale.profile.measurements, 'upcharge')));
		measurementUpchargeArray = _.compact(_.map(sale.profile.measurements, 'upcharge'));

		measurementUpchargeArray.map((item, index) => {
			if (item.type != 'High Priority Delivery') {
				if (item.unit == 1)
					totalOrderItemUpcharge = totalOrderItemUpcharge + parseInt(item.value);
				else if (item.unit == 2) {
					console.log("upcharge", Math.floor(sale.mrp * item.value / 100), item.value);
					totalOrderItemUpcharge = totalOrderItemUpcharge + Math.floor(sale.mrp * item.value / 100);
				}
				else if (item.value)
					totalOrderItemUpcharge = totalOrderItemUpcharge + parseInt(item.value);
			} else {
				totalOrderItemUpcharge = totalOrderItemUpcharge;
			}
		});
	}
	return totalOrderItemUpcharge;
}

export function updateLoyalityAmountInOrderItemLevel(data, sales, store_id) {
	var totalMeasurementDiscountAmountPercent = 0;
	var totalStyleDiscountAmountPercent = 0;
	if (data.styling_discount > 0) {
		let totalStyleUpchargeAmount = calculateUpcharges(sales);
		totalStyleDiscountAmountPercent = (data.styling_discount * 100) / totalStyleUpchargeAmount;

	}
	if (data.measurement_discount > 0) {
		let totalMeasurementUpchargeAmount = calculateMeasurementUpcharges(sales);
		totalMeasurementDiscountAmountPercent = (data.measurement_discount * 100) / totalMeasurementUpchargeAmount;
	}
	if (data.measurement_discount > 0 || data.styling_discount > 0) {
		let newSalesArray = sales.map((orderItem, index) => {
			let applyDiscount = 0;
			let styling_upcharge_amount = calculateOrderItemUpcharges(orderItem) || 0;
			let measurement_upcharge_amount = calculateOrderItemMeasurementUpcharges(orderItem) || 0;
			if (styling_upcharge_amount > 0) {
				applyDiscount = applyDiscount + (styling_upcharge_amount * totalStyleDiscountAmountPercent) / 100;
			}
			if (measurement_upcharge_amount > 0) {
				applyDiscount = applyDiscount + (measurement_upcharge_amount * totalMeasurementDiscountAmountPercent) / 100;
			}

			if (data.styling_discount > 0 && data.measurement_discount > 0) {
				orderItem.discount_value = applyDiscount;
				orderItem.discount_comment = "Loyalty Styling && Measurement Discount";
			} else if (data.styling_discount > 0) {
				orderItem.discount_value = applyDiscount;
				orderItem.discount_comment = "Loyalty Styling Discount";
			} else if (data.measurement_discount > 0) {
				orderItem.discount_value = applyDiscount;
				orderItem.discount_comment = "Loyalty Measurement Discount";
			}


			return orderItem
		});

		return {
			newSalesArray,
			data
		}
	};

	return false;

}

function saveLoyalityTierDiscount(data) {
	return {
		type: types.SAVE_LOYALITY_TIER_DISCOUNT,
		data
	}
}

function saveLoyalityTierDiscountObj(data) {
	return {
		type: types.SAVE_LOYALITY_TIER_DISCOUNT_OBJECT,
		data
	}
}
function getStyleUpcharge(_sale) {
	let STYLE = 0;
	let upChargeList = [];
	if (_sale.upcharges && _sale.upcharges.length > 0)
		upChargeList = _sale.upcharges;

	upChargeList.map((_osale) => {
		if (_osale.type != types.DELIVERY_UPCHARGE && _osale.type != 'Higher Size Upcharge') {
			if (_osale.unit == types.UPCHARGE_UNIT_VALUE)
				STYLE += ((parseInt(_osale.value)) * parseInt(_sale.qty));
			else if (_osale.unit == types.UPCHARGE_UNIT_PERCENTAGE)
				STYLE += ((Math.floor(_sale.mrp * _osale.value / 100)) * parseInt(_sale.qty));
			else if (_osale.value)
				STYLE += ((parseInt(_osale.value)) * parseInt(_sale.qty));
		}
	}, 0);
	return STYLE;
}
function getMeasurementUpcharge(sale) {
	let ALTER = 0;
	let measurementupChargeList = [];
	if (sale.profile && sale.profile.measurements && sale.profile.measurements.length > 0) {
		measurementupChargeList = _.compact(_.map(sale.profile.measurements, 'upcharge')) || [];
	}
	let upChargeList = [];
	if (sale.upcharges && sale.upcharges.length > 0) {
		upChargeList = _.filter(sale.upcharges, { type: 'Higher Size Upcharge' });
		measurementupChargeList = measurementupChargeList.concat(upChargeList);
	}
	measurementupChargeList.map((_upcharge) => {
		if (_upcharge.unit == types.UPCHARGE_UNIT_VALUE)
			ALTER += ((parseInt(_upcharge.value)) * parseInt(sale.qty));
		else if (_upcharge.unit == types.UPCHARGE_UNIT_PERCENTAGE)
			ALTER += ((Math.floor(sale.mrp * _upcharge.value / 100)) * parseInt(sale.qty));
		else if (_upcharge.value)
			ALTER += ((parseInt(_upcharge.value)) * parseInt(sale.qty));
	});
	return ALTER;
}
function calculateDiscountFields(sales, order) {
	let STYLE = 0;
	let DELIVERY = 0;
	let ALTER = 0;
	sales && sales.map((sale) => {
		ALTER += getMeasurementUpcharge(sale);
		STYLE += getStyleUpcharge(sale);
	});
	return {
		STYLE,
		DELIVERY,
		ALTER
	}
}
export function loadLoyalityDiscontTransaction(customer_id) {

	return dispatch => {
		dispatch({
			type: types.LOAD_LOYALITY_TRANSACTIONS_LOADING
		});
		return makeRequest('get', null, `/loyalitydiscounttransaction?customer_id=${customer_id}`).then((response) => {
			if (response.data.status) {
				dispatch({
					type: types.LOAD_LOYALITY_TRANSACTIONS_SUCCESS,
					data: response.data.data
				})
			} else {
				dispatch({
					type: types.LOAD_LOYALITY_TRANSACTIONS_FAILURE
				})
			}

		}).catch(() => {
			dispatch({
				type: types.LOAD_LOYALITY_TRANSACTIONS_FAILURE
			})
		})
	}
}
export function loadLoalityDiscounts(sales, orderDetails) {

	let upchargeDetails = calculateDiscountFields(sales, orderDetails);

	var requestObj = {
		...upchargeDetails,
		store_id: orderDetails.store_id,
		order_id: orderDetails.order_id,
		customer_id: orderDetails.customer_id,
		totalOrderAmount: orderDetails.total_amount
	};
	return dispatch => {
		return makeRequest('post', requestObj, '/loyalitytier/discount').then((response) => {
			if (response.status === 200) {
				if (response.data && response.data.data && response.data.data.length > 0) {
					let discount_array = response.data.data;
					discount_array.map((_discount) => {
						if (_discount.discount > 0) {
							if (_discount.charge_code == "STYLE") {
								let discount_percentage = (_discount.discount / requestObj.STYLE * 100);
								sales.map((_sale_item) => {
									let _style_upcharge = getStyleUpcharge(_sale_item);
									let _sale_item_discount = _sale_item.discount_value || 0;
									let _style_discount = (_style_upcharge * discount_percentage / 100);
									_sale_item.discount_value = parseInt(_sale_item.discount_value) || 0;
									_sale_item.discount_value += _style_discount;
									_sale_item.discount_comment = _sale_item.discount_comment || '';
									_sale_item.discount_comment += ' LOYALITY STYLE DISCOUNT';
									_sale_item.discount_type = 1;
								});
							} else if (_discount.charge_code == "ALTER") {

								let discount_percentage = (_discount.discount / requestObj.ALTER * 100);
								sales.map((_sale_item) => {
									let _measurement_upcharge = getMeasurementUpcharge(_sale_item);
									let _sale_item_discount = _sale_item.discount_value || 0;
									let _measurement_discount = (_measurement_upcharge * discount_percentage / 100);
									_sale_item.discount_value = parseInt(_sale_item.discount_value) || 0;
									_sale_item.discount_value += _measurement_discount;
									_sale_item.discount_comment = _sale_item.discount_comment || '';
									_sale_item.discount_comment += ' LOYALITY ALTERATION DISCOUNT';
									_sale_item.discount_type = 1;
								});
							}
						}
					});
					dispatch(saveLoyalityTierDiscount(discount_array));
					dispatch(calculateTaxes(sales, requestObj.store_id));
				}
			}
		});
	}

}



export function updatePendingOrderDetails(formValues) {
	return dispatch => {
		return makeRequest('post', formValues, '/updatependingorderdetails').then(response => {
			if (response.status === 200) {

				dispatch(push('/order/updatemeasurement'));
				dispatch(updateMessage('INSERT_ADDRESS_SUCCESS', `Order Details has been updated successfully`));
				window.scrollTo(0, 0);
			} else {
				dispatch(updateMessage('INSERT_ADDRESS_FAILURE', `Failed to update the order details`));
				window.scrollTo(0, 0);
			}

		});
	}
}

export function fetchOrderDetails(order_id) {
	const values = {
		order_id: order_id
	};
	return dispatch => {
		return makeRequest('post', values, '/fetchOrderDetails').then(response => {
			if (response.status === 200) {

				dispatch(getPendingOrderDetails(response.data));

			} else {
				dispatch(updateMessage('INSERT_ADDRESS_FAILURE', `Failed to fetch the order details`));
				window.scrollTo(0, 0);
			}

		});
	}

}
