import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';
import classNames from 'classnames/bind';
import styles from 'css/components/order/sales';
import SelectForm from 'components/SelectForm';
import MultipleChoice from 'components/MultipleChoice';
import ImageCapture from 'components/ImageCapture';
import Signature from 'components/Signature';
import PromoCode from 'components/Promocode';
import ReedomCode from 'components/Reedompoints';
import OrderPendingPaymentDetails from 'components/OrderPendingPaymentDetails';
import * as types from 'types';
import {
	push
} from 'react-router-redux';
import { fetchList } from '../../actions/list';
import _ from 'lodash';
import {
	updateOrderTotal,
	saveCompleteOrder,
	updateFullPaymentFlag,
	saveImage,
	saveImageAWS,
	calculateTaxes,
	updateOrderPIN,
	updateOrderPINDate,
	openForm,
	updateSaleItemEntry,
	updateMessage,
	loadLoyalityPoints,
	saveDiscountType,
	validatePromoCode,
	savePromoCode,
	validateRedeemPoints,
	redeemPointsCode,
	updateShippingCharges,
	updateHalfPayment,
	loadLoalityDiscounts,
	updateApprovedBy,
	updatePendingAmount,
	updatePopupStatus
} from '../../actions/order';
import { connect } from 'react-redux';
import ReactDOM from 'react-dom';
import back from 'images/back-arrow.png';
const cx = classNames.bind(styles);

class OrderPayment extends Component {
	constructor(props) {
		super(props);
		this.renderSaleItems = this.renderSaleItems.bind(this);
		this.saveOrder = this.saveOrder.bind(this);
		this.updateFullPayment = this.updateFullPayment.bind(this);
		this.saveImageAWS = this.saveImageAWS.bind(this);
		this.updateDetails = this.updateDetails.bind(this);
		this.isEdited = false;
		this.toggleSignature = this.toggleSignature.bind(this);
		this.saveSignature = this.saveSignature.bind(this);
		this.updateDiscount = this.updateDiscount.bind(this);
		this.updateSubTotals = this.updateSubTotals.bind(this);
		this.updateDiscountComment = this.updateDiscountComment.bind(this);
		this.onPromoRedeemSave = this.onPromoRedeemSave.bind(this);
		this.validatePromoCode = this.validatePromoCode.bind(this);
		this.savePromoCode = this.savePromoCode.bind(this);
		this.validateRedeemPoints = this.validateRedeemPoints.bind(this);
		this.redeemCode = this.redeemCode.bind(this);
		this.onAddPaymentClick = this.onAddPaymentClick.bind(this);
	}

	componentDidMount() {
		if (this.props.lists) {
			if (this.props.lists.payment_types && this.props.lists.payment_types.length === 0)
				this.props.dispatch(fetchList('payment_type'));
		}
		this.props.dispatch(loadLoyalityPoints(this.props.order.details.store_id, this.props.order.details.customer_id));
		this.props.dispatch(calculateTaxes(this.props.order.sales, this.props.order.details.store_id, true, this.props.order.details));
		window.scrollTo(0, 0);
	}
	shouldComponentUpdate(props, state) {
		return this.props.order !== props.order;
	}

	updateDiscount(saleIndex, value, rel) {
		if (_.isArray(value)) {
			switch (value[0]) {
				case '%':
					this.props.dispatch(updateSaleItemEntry(types.UPCHARGE_UNIT_PERCENTAGE, 'discount_type', saleIndex));
					break;
				case 'INR':
					this.props.dispatch(updateSaleItemEntry(types.UPCHARGE_UNIT_VALUE, 'discount_type', saleIndex));
					break;
			}
		} else {
			this.props.dispatch(updateSaleItemEntry(value.target.value, 'discount_value', saleIndex));
		}
	}

	updateDiscountComment(saleIndex, value, rel) {

		this.props.dispatch(updateSaleItemEntry(value.target.value, 'discount_comment', saleIndex));
	}
	updateSubTotals() {
		this.props.dispatch(calculateTaxes(this.props.order.sales, this.props.order.details.store_id));
	}

	renderSaleItems() {
		const self = this;
		return this.props.order.sales.map(function (sale, _index) {
			const upCharges = (sale) => {
				if (sale.upcharges || sale.profile) {
					let upcharges = (sale.upcharges && _.isArray(sale.upcharges)) ? sale.upcharges : [];
					if (sale.profile && sale.profile.measurements && sale.profile.measurements.length > 0) {
						upcharges = upcharges.concat(_.compact(_.map(sale.profile.measurements, 'upcharge')));
					}
					const calcUpcharge = (sale, upcharge) => {
						if (upcharge.unit === types.UPCHARGE_UNIT_PERCENTAGE)
							return Math.floor(parseFloat(sale.mrp) * parseFloat(upcharge.value) / 100);
						else if (upcharge.unit == types.UPCHARGE_UNIT_VALUE)
							return upcharge.value;
						else if (upcharge.value)
							return upcharge.value;
					}
					const additionals = upcharges.map((upcharge, index) => {
						if (upcharge.type != types.DELIVERY_UPCHARGE)
							return (<div key={index}><span className={cx('label')}>{upcharge.type.toLowerCase()}</span><span className={cx('value')}>{calcUpcharge(sale, upcharge)}</span></div>);
					});
					return (<div><span className={cx('label')}>Additional Charges <em>(per item)</em></span>{additionals}</div>);
				}
			}

			const taxes = (sale) => {
				if (sale.taxes && sale.taxes.length > 0) {
					const _taxes = sale.taxes.map((tax, index) => {
						return (
							<div key={index}><span className={cx('label')}>{tax.name}</span><span className={cx('value')}>{tax.percent + "%"}</span></div>
						);
					});
					return (<div><span className={cx('label')}>Taxes <em>(per item)</em></span>{_taxes}</div>);
				}
			};

			const totalTax = (sale) => {
				if (sale.taxes && sale.taxes.length > 0) {
					return (sale.taxes.reduce((prev, next) => { return prev + next.value }, 0).toFixed(2));
				}
			}


			let upcharges = 0;

			if (sale.upcharges && sale.upcharges.length > 0) {
				upcharges = sale.upcharges.reduce((prev, next) => { return prev + next.value }, 0);
			}

			const saleDiscountType = (sale.discount_type == types.UPCHARGE_UNIT_PERCENTAGE) ? '%' : 'INR';

			let delivery_upcharge_item = null;
			const delivery_upcharge = _.find(sale.upcharges, { type: types.DELIVERY_UPCHARGE })
			if (delivery_upcharge) {
				delivery_upcharge_item = <div><span className={cx('label')}>Delivery</span><span className={cx('value')}>{delivery_upcharge.value}</span></div>
			}

			const getGrossValue = (sale, totalTax) => {
				let mrp = sale.discountedMRP;
				if (!_.isNaN(totalTax)) {
					return mrp - totalTax;
				} else {
					return '';
				}
			}

			return (
				<li key={_index}>
					<div><span className={cx('label')}>{sale.display_name}</span></div>
					<div><span className={cx('label')}>Base Mrp</span><span className={cx('value')}>{!_.isNaN(parseFloat(sale.mrp).toFixed(2)) ? sale.mrp : ''}</span></div>
					{upCharges(sale)}
					<div className={cx('discount')}>
						<span className={cx('label')}>Discount</span>
						<div className={cx('value-group')}>
							<input type="number" rel="discount" onChange={self.updateDiscount.bind(this, _index)} value={sale.discount_value ? sale.discount_value : 0} />
							<MultipleChoice isMultiple={false} forceSelect={true} rel="discount_type" options={['%', 'INR']} selected={saleDiscountType} save={self.updateDiscount.bind(this, _index)} />
							<button className={cx('action')} onClick={self.updateSubTotals}>add</button>
						</div>
					</div>
					<div className={cx('input-group')} ><span className={cx('label')}>Discount Comment</span><input type="text" className={cx('large')} rel="discount_comment" onChange={self.updateDiscountComment.bind(this, _index)} value={sale.discount_comment ? sale.discount_comment : ""} ></input></div>
					{/* <div><span className={cx('label')}>Gross Value <em>(per item)</em></span><span className={cx('value')}>{getGrossValue(sale, totalTax(sale)).toFixed(2)}</span></div>
					{taxes(sale)}
					<div><span className={cx('label')}>Total Tax <em>(per item)</em></span><span className={cx('value')}>{!_.isNaN(totalTax(sale)) ? totalTax(sale) : ''}</span></div> */}
					{delivery_upcharge_item}
					<div><span className={cx('label')}>Quantity</span><span className={cx('value')}>{sale.qty}</span></div>
					<div><span className={cx('label')}>Sub Total</span><span className={cx('value')}>{!_.isNaN(parseFloat(sale.subTotal).toFixed(2)) ? sale.subTotal : ''}</span></div>
				</li>
			);
		})
	}

	saveImageAWS(file) {
		this.props.dispatch(saveImageAWS(file, this.props.order.details.order_id, types.IMAGE_TYPE_INVOICE));
	}
	updateFullPayment(value, type) {

		if (value[0] == 'yes') {
			value = true;
		} else {
			value = false;
		}

		switch (type) {
			case 'order_flag':
				const _val = value ? 2 : 1;
				this.props.order.sales.map((sale, index) => {
					this.props.dispatch(updateSaleItemEntry(_val, 'order_flag', index));
				});
				break;
			case 'is_full_payment':
				this.props.dispatch(updateFullPaymentFlag(value));
				break;
		}

	}
	updateDetails(type, data) {
		switch (type) {
			case 'pin':
				this.props.dispatch(updateOrderPIN(ReactDOM.findDOMNode(this.refs.PIN).value));
				break;
			case 'pindate':
				this.props.dispatch(updateOrderPINDate(ReactDOM.findDOMNode(this.refs.PINDate).value));
				break;
			case 'total':
				this.props.dispatch(updateOrderTotal(ReactDOM.findDOMNode(this.refs.total_amount).value));
				this.isEdited = true;
				break;
			case 'half_amount':
				this.props.dispatch(updateHalfPayment(ReactDOM.findDOMNode(this.refs.halfPayment).value));
				this.isEdited = true;
				break;
			case 'approved_by':
				this.props.dispatch(updateApprovedBy(ReactDOM.findDOMNode(this.refs.approvedBy).value));
				//this.props.dispatch(updateSaleItemEntry(ReactDOM.findDOMNode(this.refs.approvedBy).value, 'approved_by', saleIndex));
				this.isEdited = true;
				break;
			case 'pending_amount':
				this.props.dispatch(updatePendingAmount(data));
				this.isEdited = true;
				break;
			case 'shipping_charges':
				this.props.dispatch(updateShippingCharges(ReactDOM.findDOMNode(this.refs.shippingCharges).value));
				this.props.dispatch(updateSaleItemEntry(ReactDOM.findDOMNode(this.refs.shippingCharges).value, 'shipping_charges', saleIndex));
				this.isEdited = true;
				break;
		}
	}
	onAddPaymentClick() {
		this.props.dispatch(updatePopupStatus(this.props.order.details.popup_status));
	}

	saveOrder() {
		let order = this.props.order;
		var _total_order_amount = order.details.shipping_charges ? (Number(order.details.shipping_charges) + order.details.total_amount) : order.details.total_amount;
		if(this.getLoyalityDiscount(order.details.discounts,order.details.total_amount)){
			_total_order_amount = _total_order_amount - this.getLoyalityDiscount(order.details.discounts,order.details.total_amount);
		}
		function validate(order) {
			let measurent_missing = false;
			let approval_field;
			let approval_missing = false;
			if (order.details.pending_amount.length == 0) {
				return 'Please Enter the Payment Details';
			}
			let totalPaymentAmount = 0;
			order.details.pending_amount.map((_pending_amount) => {
				totalPaymentAmount += parseFloat(_pending_amount.amount);
			});
			if (_total_order_amount != totalPaymentAmount && order.details.is_full_payment) {
				return 'Please Mark the Full Payment Flag to NO , Order payment is In-Complete';
			}
			// if (!order.details.PIN) {
			// 	return 'Please Enter the Proforma Invoice Number';
			// }
			// if (!order.details.pindate) {
			// 	return 'Please Enter the Proforma Invoice Date';
			// }
			let discount_comment_missing = false;
			for (var i = 0; i < order.sales.length; i++) {
				// if (order.sales[i].isMTM) {
				// 	if (order.sales[i].profile_id <= 0 && order.sales[i].order_flag == 1) {
				// 		//measurent_missing = true;
				// 	}
				// }
				if (order.sales[i].discount_value && order.sales[i].discount_value != 0) {
					if (!order.sales[i].discount_comment) {
						discount_comment_missing = true;
					}
				}
			}
			if (order.details.is_full_payment == false) {
				approval_field = order.details.approved_details;
				if (!approval_field) {
					approval_missing = true;
				}
			}
			if (measurent_missing && discount_comment_missing) {
				return 'Please put the order on hold, as one or more of the sale items donot have measurements and discount comment'
			} else if (measurent_missing) {
				return 'Please put the order on hold, as one or more of the sale items donot have measurement'
			} else if (discount_comment_missing) {
				return 'Please put the order on hold, as one or more of the sale items donot have discount comment'
			} else if (approval_missing) {
				return 'Please enter approved_by details'
			} else {
				return null;
			}
		}
		let validateMessage = validate(this.props.order);
		if (!validateMessage) {
			const order = this.props.order;

			order.sales = order.sales.map((sale) => {
				sale.profile_id = sale.profile_id || -1;
				if (sale.isMTM) {
					let upcharges = sale.upcharges || [];
					// if (sale.profile && sale.prof ile.measurements) {
					// 	upcharges = upcharges.concat(_.compact(_.map(sale.profile.measurements, 'upcharge')))
					// }
					sale.upcharges = upcharges;
				}
				return sale;
			});
			order.workflow_stage_id = 13;
			order.details.total_amount = _total_order_amount;
			this.props.dispatch(saveCompleteOrder(order, this.props.user.user));
		} else {
			this.props.dispatch(updateMessage('MEARSUREMENT_FORM_VALIDATION', validateMessage));
			window.scrollTo(0, 0);
		}

	}
	toggleSignature() {
		this.props.dispatch(openForm('signature', this.props.order.isFormOpen.signature));
	}
	saveSignature(dataURL) {
		this.props.dispatch(saveImage(dataURL, this.props.order.details.order_id, types.IMAGE_TYPE_SIGNATURE));
	}
	onPromoRedeemSave(value, type) {
		let { order: { details } } = this.props;
		details.coupon_details
		//if(details.coupon_details && !details.coupon_details.coupon_applied){
			// debugger;
		this.props.dispatch(saveDiscountType(value[0]));
		///	}

	}
	validatePromoCode(value) {
		let mobile = this.props.customer.mobile || null;
		let store_id = this.props.order.details.store_id || null;
		this.props.dispatch(validatePromoCode(value, mobile, store_id));
	}
	savePromoCode(value) {
		let mobile = this.props.customer.mobile || null;
		let store_id = this.props.order.details.store_id || null;
		this.props.dispatch(savePromoCode(value, mobile, store_id, this.props.order.sales, this.props.order.details.total_amount));
		//tax calculation
	}
	validateRedeemPoints(value) {
		let mobile = this.props.customer.mobile || null;
		let store_id = this.props.order.details.store_id || null;
		this.props.dispatch(validateRedeemPoints(value, mobile, store_id));
	}
	redeemCode(value, points) {
		let mobile = this.props.customer.mobile || null;
		let store_id = this.props.order.details.store_id || null;
		this.props.dispatch(redeemPointsCode(value, points, mobile, store_id, this.props.order.sales, this.props.order.details.total_amount));
	}
	// calculateDiscounts(couponDetails, total_amount) {
	// 	let discountAmount, amountAfterDiscount;
	// 	if (couponDetails && (couponDetails.type == "redeempoints") && (couponDetails.redeem_applied == true)) {
	// 		discountAmount = (couponDetails.points_redeem_value);
	// 		// discountAmount =(couponDetails.points_currency_ratio*couponDetails.points_redeem_value);
	// 		amountAfterDiscount = total_amount - discountAmount;

	// 	} else if (couponDetails && (couponDetails.type == "coupon") && (couponDetails.coupon_applied == true)) {
	// 		if (couponDetails.is_absolute == "false") {
	// 			discountAmount = (total_amount * couponDetails.points) / 100;
	// 			amountAfterDiscount = total_amount - discountAmount;
	// 		} else {
	// 			discountAmount = couponDetails.points;
	// 			amountAfterDiscount = total_amount - discountAmount;
	// 		}
	// 	}
	// 	return {
	// 		discountAmount: discountAmount || null,
	// 		amountAfterDiscount: amountAfterDiscount || null
	// 	}
	// }
	getPaymentMode(payment_modes, payment_mode_id) {
		var payment_mode = _.find(payment_modes, { id: payment_mode_id });
		return payment_mode && payment_mode.name
	}
	getLoyalityDiscount(discounts,total_amount) {
		let total_discount_percent = 0;
		discounts && discounts.map((_discount) => {
			if (_discount && !_discount.is_payment_mode) {
				if(_discount.is_absolute){
					total_discount_percent += ((_discount.discount_value * 100 )/total_amount);
				}else{
					total_discount_percent += parseFloat(_discount.discount_percentage);
				}
			}
		});
		return ( total_amount * total_discount_percent)/100;
	}
	getOrderDiscount(order_details) {
		let discounts = order_details.discounts;
		if (!_.isArray(discounts)) {
			discounts = [discounts];
		}
		// const discount_amount = (discount_percentage) => {
		// 	debugger;
		// 	return (order_details.total_amount * discount_percentage) / 100;
		// };
		// let discount_ele = discounts && discounts.map((_discount) => {
		// 	if (_discount && !_discount.is_payment_mode) {
		// 		return;
		// 	}
		// });
		return (<ul className={cx('cart')}>
			<div className="discount_amount total">
				<span htmlFor="total_amount" style={{ "word-spacing": "2px" }}>{"Loyality Discount"}</span>
				<span className='amount'>{this.getLoyalityDiscount(discounts,order_details.total_amount)}</span>
			</div>
		</ul>);
	}
	render() {
		let signature = null;
		// debugger;
		let { 
			order: { 
				details: { 
					details_loading, 
					discount_redeem_coupon_type, 
					pending_amount, 
					popup_status,
					discounts
				} 
			} 
		} = this.props;
		// debugger;
		//	let discountObj = this.calculateDiscounts(this.props.order.details.coupon_details, this.props.order.details.total_amount);
		if (this.props.order.isFormOpen.signature) {
			signature = <Signature save={this.saveSignature} rel="customer_signature" close={this.toggleSignature} />
		}

		let shipping_charges = this.props.order.details.shipping_charges || 0;
		let total_amount = this.props.order.details.total_amount;
		total_amount = total_amount + Number(shipping_charges) - ( this.getLoyalityDiscount(discounts,total_amount));

		let approveField = (this.props.order.details.is_full_payment == false) ? <div className={cx('input-group')}>
			<label htmlFor="approvedBy">Order Approved By
			<em className={'mandatory'}>*</em>
			</label>
			<input className={cx('small')} type="text" ref="approvedBy" value={this.props.order.details.approved_details} onChange={this.updateDetails.bind(this, 'approved_by')} />
		</div> : '';
		return (
			<div className={cx('container')}>
				{(details_loading && (<div className={cx('loading-mask-wrapper')}>
					<div className={cx('loading-mask-inner-wrapper')}>
						<div style={{ margin: 'auto' }}>
							<div className={cx('loading-mask')}>
							</div>
							<div style={{
								textAlign: 'center',
								color: 'white',
								paddingTop: '10px'
							}}>
								Please Wait...
						</div>
						</div>
					</div>
				</div>))}
				<h1>Payment</h1>
				<div className={cx('header-note')}>
					<span className={cx('header-label')}>Customer:   </span>
					<span className={cx('header-content')}>{this.props.customer.name}</span>
				</div>
				<Link to="/order" className={cx('review')}>
					Review
				</Link>
				<Link to="/order/sales" className={cx('back')} ><img src={back} /></Link>
				<div className={cx('form-container')}>
					{/* <div className={cx('input-group')}>
						<label htmlFor="total_amount">Proforma Invoice Number</label>
						<input className={cx('large')} type="text" ref="PIN" value={this.props.order.details.PIN} onChange={this.updateDetails.bind(this, 'pin')} />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="total_amount">Proforma Invoice Date</label>
						<input className={cx('large')} type="datetime-local" ref="PINDate" value={this.props.order.details.pindate} onChange={this.updateDetails.bind(this, 'pindate')} />
					</div> */}
					<ul className={cx('cart')}>
						{this.renderSaleItems()}
					</ul>
					<ImageCapture addImage={this.saveImageAWS} />
					<div className={cx('input-group')}>
						<label htmlFor="is_full_payment">Full Payment</label>
						<MultipleChoice isMultiple={false} options={['yes', 'no']} selected={(this.props.order.details.is_full_payment === false) ? 'no' : 'yes'} rel="is_full_payment" save={this.updateFullPayment} />
					</div>
					{approveField}
					{/* {(this.props.order.details.is_full_payment == false) ? (<div className={cx('input-group')}>
						<label htmlFor="total_amount">Enter Half Payment Amount</label>
						<input className={cx('small')} type="number" ref="halfPayment" value={this.props.order.details.half_amount} onChange={this.updateDetails.bind(this, 'half_amount')} />
					</div>) : ""}
					 */}
					<button style={{
						backgroundColor: 'black',
						color: 'white',
						border: '1px solid black',
						boxShadow: 'none',
						padding: '10px 20px',
						cursor: 'pointer',
						textDecoration: 'none'
					}} className={cx('primary')} onClick={this.onAddPaymentClick}>Add Payment Details</button>

					{pending_amount.length > 0 ? (<div className={cx('payment-details')}>
						<table>
							<tr>
								<th>Payment Mode</th>
								<th>Amount</th>
								<th>Reference</th>
							</tr>
							{pending_amount && pending_amount.map((item) => {
								return (<tr><td>{this.getPaymentMode(this.props.lists.payment_types, item.payment_mode)}</td>
									<td>{item.amount}</td>
									<td>{item.reference}</td></tr>)
							})}

						</table>
					</div>) : ""}
					<OrderPendingPaymentDetails
						onAddPendingAmount={this.updateDetails}
						openPaymentPopup={popup_status}
						pending_amount={pending_amount || []}
						total_amount={total_amount}
						onAddPaymentClick={this.onAddPaymentClick}
						payment_types={this.props.lists.payment_types} />
					{/* {(this.props.order.details.is_full_payment ==false)? (<div className={cx('input-group')}>
						<label htmlFor="total_amount">Enter Half Payment Amount</label>
						<input className={cx('small')} type="number" ref="halfPayment" value={this.props.order.details.half_amount} onChange={this.updateDetails.bind(this, 'half_amount')} />
					</div> ):""} */}
					<div className={cx('input-group')}>
						<label htmlFor="is_on_hold">On Hold</label>
						<MultipleChoice isMultiple={false} options={['yes', 'no']} selected={(this.props.order.sales && this.props.order.sales[0] && this.props.order.sales[0].order_flag == 1) ? 'no' : 'yes'} rel="order_flag" save={this.updateFullPayment} />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="is_on_hold">Discount</label>
						<MultipleChoice isMultiple={false} options={['Promocode', 'Redeem']} selected={discount_redeem_coupon_type != "Redeem" ? "Promocode" : "Redeem"} rel="promo_redeem" save={this.onPromoRedeemSave} />
						{(discount_redeem_coupon_type != "Redeem") ?
							(
								<PromoCode
									validatePromoCode={this.validatePromoCode}
									coupon_details={this.props.order.details.coupon_details}
									discounts={this.props.order.details.discounts}
									savePromoCode={this.savePromoCode} />
							) : (
								<ReedomCode
									dispatch={this.props.dispatch}
									orderdetails={this.props.order.details}
									validateRedeemPoints={this.validateRedeemPoints}
									discounts={this.props.order.details.discounts}
									redeemCode={this.redeemCode}
								/>
							)
						}
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="shippingCharges">Enter Shipping Charges</label>
						<input className={cx('small')} type="number" ref="shippingCharges" value={this.props.order.details.shipping_charges} onChange={this.updateDetails.bind(this, 'shipping_charges')} />
					</div>
					{this.getOrderDiscount(this.props.order.details)}
					{signature}
					<ul className={cx('cart')}>
						<div className="discount_amount total">
							<span htmlFor="total_amount" style={{ "word-spacing": "2px" }}>Total Amount</span>
							<span className='amount'>{total_amount}</span>
						</div>
					</ul>

					<button className={cx('action', 'primary')} onClick={this.toggleSignature}>Add Customer Signature</button>
					{
						//<a className={cx('action', 'secondary')} target="_blank" to={"/order/invoice?customer_id="+ this.props.customer.customer_id+"&order_id="+this.props.order.details.order_id}>Email Invoice</a>
					}
					<button className={cx('submit', 'action', 'primary')} onClick={this.saveOrder}>Save Order</button>
				</div>
			</div>
		);
	}
}

OrderPayment.propTypes = {
	user: PropTypes.object,
	customer: PropTypes.object,
	order: PropTypes.object,
	lists: PropTypes.object
};


function mapStateToProps({ order, lists, user, customer }) {
	return {
		order,
		lists,
		user,
		customer
	};
}
// <PromoCode dispatch={this.props.dispatch} orderdetails={this.props.order.details}/>
// Connects React component to the redux store
// It does not modify the component class passed to it
// Instead, it returns a new, connected component class, for you to use.
export default connect(mapStateToProps, null, null, { withRef: true })(OrderPayment);
// <div className={cx('input-group')}>
// 						<label htmlFor="total_amount">Total Amount</label>
// 						<input className={cx('large')} type="text" ref="total_amount" value={!this.props.order.details.total_amount ? '' : this.props.order.details.total_amount} />
// 					</div>
// 					<div className={cx('input-group')}>
// 						<label htmlFor="total_amount">Discount Amount</label>
// 						<input className={cx('large')} type="text" ref="discountamount" value={!this.props.order.details.discount.discountamount ? '' : this.props.order.details.discount.discountamount} />
// 					</div>
// <div className={cx('input-group')}>
// 						<label htmlFor="total_amount" style={{"word-spacing":"2px"}}>Total Amount after discount</label>
// 						<input className={cx('large')} type="text" ref="total_amount" value={!amountafterdiscount ? '' : amountafterdiscount} />
// 					</div>