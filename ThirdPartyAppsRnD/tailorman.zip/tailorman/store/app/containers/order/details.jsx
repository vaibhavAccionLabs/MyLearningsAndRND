import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';

import classNames from 'classnames/bind';
import styles from 'css/components/order/details';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import {
	updatePriorityType,
	updatePaymentType,
	updateTailor,
	updateOrderDetails,
	updateBenificiaryPhone,
	updateOccasion,
	updateSalesman,
	updateMessage,
	updateDeliveryAddress,
	updateBillingAddress
} from '../../actions/order';
import { fetchList, fetchCustomerAddress } from '../../actions/list';
import NumberForm from '../../components/NumberForm';
import SelectForm from '../../components/SelectForm';
import back from 'images/back-arrow.png';
import moment from 'moment';

const cx = classNames.bind(styles);

class OrderDetails extends Component {
	constructor(props) {
		super(props);
		this.saveValues = this.saveValues.bind(this);
		this.saveSelectFormValue = this.saveSelectFormValue.bind(this);
		// // this.saveNumberFieldValue = this.saveNumberFieldValue.bind(this);
		// this.getSelected = this.getSelected.bind(this);
		//this.getOccasionID = this.getOccasionID.bind(this);
		this.state = {
			delivery_address: null,
			billing_address: null,
			gst_number: false
		}
	}

	componentDidMount() {
		// if (this.props.lists) {
			// if (this.props.lists.payment_types && this.props.lists.payment_types.length === 0)
			// 	this.props.dispatch(fetchList('payment_type'));
			// if (this.props.lists.tailors && this.props.lists.tailors.length === 0)
			// 	this.props.dispatch(fetchList('tailor'));
			// if (this.props.lists.occasions && this.props.lists.occasions.length === 0)
			// 	this.props.dispatch(fetchList('occasion'));
			// if (this.props.lists.salesmen && this.props.lists.salesmen.length === 0)
			// 	this.props.dispatch(fetchList('salesman'));
		// }
		this.props.dispatch(fetchCustomerAddress(this.props.customer.customer_id));
		window.scrollTo(0, 0)
	}

	gstNumberValidate(gstnumber){
		var gstinformat = new RegExp('^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$');
		if (gstinformat.test(gstnumber)) {
			return true
		}else{
			return false
		}
	}
	saveValues() {
debugger;
		const _that = this;
		const customer_addresses = this.props.lists.customer_addresses;
		// let address_list_b = _.filter(this.props.lists.customer_addresses,{'address_type':'Shipping'});
		// let address_list_d = _.filter(this.props.lists.customer_addresses,{'address_type':'Delivery'});
		const getDisplayName = () => {
			const _input_value = ReactDOM.findDOMNode(this.refs.order_name).value;
			if (_input_value.trim().length == 0) {
				return ReactDOM.findDOMNode(_that.refs.date).value;
			} else {
				return _input_value;
			}
		};
		let default_billing_address;
		let default_delivery_address;
		customer_addresses && customer_addresses.map((address) => {
			if (address && address.default_address) {
				if (address.address_type == "Shipping") {
					default_delivery_address = address.address;
				} else {
					default_billing_address = address.address;
				}
			}
		});
		let order_details = _that.props.order.details;

		const billing_address = order_details.billing_address || default_billing_address;
		const delivery_address = order_details.delivery_address || default_delivery_address;

		let formValues = {
			order_date 			: ReactDOM.findDOMNode(_that.refs.date).value,
			payment_details 	: '',
			comment 			: ReactDOM.findDOMNode(_that.refs.comment).value,
			gstnumber 			: _that.refs.gstnumber && ReactDOM.findDOMNode(_that.refs.gstnumber).value,
			billing_address 	: billing_address,
			delivery_address 	: delivery_address,
			display_name 		: getDisplayName(),
			payment_type_id 	: 1,
			customer_id 		: _that.props.customer.customer_id,
			user_id 			: _that.props.user.user.id || _that.props.user.user.user_id,
			store_id 			: _that.props.stores.selected.store_id,
			order_id 			: order_details.order_id,
			total_amount 		: order_details.total_amount,
			shipping_charges 	: order_details.shipping_charges,
			is_full_payment 	: order_details.is_full_payment,
			approved_details 	: order_details.approved_by,
			pending_amount 		: order_details.pending_amount || []
		};
		formValues = Object.assign({},formValues,{
			tailor_id 			: order_details.tailor_id || 0,
			order_type_id  		: order_details.order_type_id,
			benificiary_name 	: order_details.benficiary_name,
			benificiary_mobile 	: order_details.benficiary_mobile,
			benificiary_email  	: order_details.benificiary_email,
			salesman_id 		: order_details.sales_man_id || 0,
			occasion 			: order_details.occasion,
			occasion_date 		: order_details.occation_date,
			shipping_taxes 		: order_details.shipping_taxes,
			coupon_details 		: order_details.coupon_details
		});
		
		if (formValues.display_name.length > 0 && formValues.billing_address && formValues.delivery_address) {
			if((this.state.gst_number && formValues.gstnumber === '') || (this.state.gst_number && !this.gstNumberValidate(formValues.gstnumber))){
				this.props.dispatch(updateMessage('MEARSUREMENT_FORM_VALIDATION', 'Valid GST Number Is Required For Corporate Orders'));
				window.scrollTo(0, 0)
			}else{
				this.props.dispatch(updateOrderDetails(formValues));
			}
		} else {
			this.props.dispatch(updateMessage('MEARSUREMENT_FORM_VALIDATION', 'Shipping Address and Billing Address are mandatory'));
			window.scrollTo(0, 0)
		}

	}
	saveSelectFormValue(selected, type) {
		switch (type) {
			case 'payment_type':
				this.props.dispatch(updatePaymentType(selected.value));
				break;
			case 'tailor':
				this.props.dispatch(updateTailor(selected.value));
				break;
			case 'occasion':
				const occasion = _.find(this.props.lists.occasions, { id: parseInt(selected.value) }).name;
				this.props.dispatch(updateOccasion(occasion));
				break;
			case 'salesman_id':
				this.props.dispatch(updateSalesman(selected.value));
				break;
			case 'delivery_address':

				this.props.dispatch(updateDeliveryAddress(selected.value));
				break;
			case 'billing_address':
				this.props.dispatch(updateBillingAddress(selected.value));
				break;

		}
	}
	getSelected(type) {
		// switch (type) {
		// 	// case 'payment_type':
		// 	// 	if (this.props.lists.payment_types && this.props.lists.payment_types.length > 0 && this.props.order.details.payment_type)
		// 	// 		return _.find(this.props.lists.payment_types, { id: this.props.order.details.payment_type }).name;
		// 	// 	else
		// 	// 		return '';
		// 	case 'tailor':
		// 		if (this.props.lists.tailors && this.props.lists.tailors.length > 0 && this.props.order.details.tailor)
		// 			return _.find(this.props.lists.tailors, { id: this.props.order.details.tailor_id }).id;
		// 		else
		// 			return '';
		// 	case 'salesman_id':
		// 		if (this.props.lists.salesmen && this.props.lists.salesmen.length > 0 && this.props.order.details.salesman_id)
		// 			return _.find(this.props.lists.salesmen, { id: this.props.order.details.salesman_id }).id;
		// 		else
		// 			return '';
		// }
	}

	// saveNumberFieldValue(value, type) {
	// 	switch (type) {
	// 		case 'benificiary_phone':
	// 			this.props.dispatch(updateBenificiaryPhone(value));
	// 	}
	// }

	toggleGstnumber(){
		debugger;
		let corporateorder = this.corporateOrders;
		let gstnumber = this.refs.gstnumber && this.refs.gstnumber.value;


		if(corporateorder.checked){
			this.setState({
				gst_number:true
			});
		}else if(gstnumber === ''){
			this.props.order.details.gstnumber = '';
			this.setState({
				gst_number:false
			});
		}else{
			this.setState({
				gst_number:false
			});
		}



	}

	render() {
		debugger;
		let address_list_b = _.filter(this.props.lists.customer_addresses, { 'address_type': 'Shipping' });
		let address_list_d = _.filter(this.props.lists.customer_addresses, { 'address_type': 'Delivery' });
		let default_billing = null;
		let default_delivery = null;
		const billing_address_list = [];
		address_list_b && address_list_b.map(function (address) {
			if (address.default_address) {
				default_billing = address.address;
			}
			billing_address_list.push({
				name: address.address,
				id: address.address
			})
		});
		const delivery_address_list = [];
		address_list_d && address_list_d.map(function (address) {
			if (address.default_address) {
				default_delivery = address.address;
			}
			delivery_address_list.push({
				name: address.address,
				id: address.address
			})
		});
		const default_delivery_address = this.props.order.details.delivery_address || default_delivery;
		const default_billing_address = this.props.order.details.billing_address || default_billing;
		return (
			<div className={cx('container')}>
				<div className={cx('header-note')}>
					<span className={cx('header-label')}>Customer:   </span>
					<span className={cx('header-content')}>{this.props.customer.name}</span>
				</div>
				<Link to="/order" className={cx('review')}>
					Review
				</Link>
				<Link to="/order/customer" className={cx('back')} ><img src={back} /></Link>
				<h1>Order Details</h1>
				<div className={cx('form-container')}>
					<div className={cx('input-group')}>
						<label htmlFor="date">Order Date</label>
						<input type="date" id="date" ref="date" defaultValue={this.props.order.details.order_date || moment().format('YYYY-MM-DD')} />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="date">Order Name</label>
						<input type="text" id="order_name" ref="order_name" defaultValue={this.props.order.details.display_name} />
					</div>
					{/* <div className={cx('input-group')}>
						<label htmlFor="occasion">Occasion</label>
						<SelectForm type="occasion" rel="occasion" options={this.props.lists.occasions} value={this.getOccasionID()} save={this.saveSelectFormValue} />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="occasion_date">Occasion Date</label>
						<input type="date" id="occasion_date" ref="occasion_date" defaultValue={this.props.order.details.occasion_date} />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="benificiery_name">Benificiary Name</label>
						<input type="text" id="benificiary_name" ref="benificiary_name" defaultValue={this.props.order.details.benificiary_name} />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="benificiary_email">Benificiary Email</label>
						<input type="email" id="benificiary_email" ref="benificiary_email" defaultValue={this.props.order.details.benificiary_email} />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="benificiary_phone">Benificiary Phone</label>
						// <NumberForm type="phone" rel="benificiary_phone" save={this.saveNumberFieldValue} default={this.props.order.details.benificiary_phone} />
					</div> */}
					<div className={cx('input-group')}>
						<label htmlFor="billing_address">Billing Address <em className={cx('mandatory')}>*</em></label>
						<SelectForm type="billing_address" rel="billing_address" options={billing_address_list} value={default_billing_address} save={this.saveSelectFormValue} />
						{/* <textarea id="billing_address" ref="billing_address" defaultValue={this.props.order.details.billing_address} ></textarea> */}
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="delivery_address">Delivery Address <em className={cx('mandatory')}>*</em> </label>
						<SelectForm type="delivery_address" rel="delivery_address" options={delivery_address_list} value={default_delivery_address} save={this.saveSelectFormValue} />
						{/* <textarea id="delivery_address" ref="delivery_address" defaultValue={this.props.order.details.delivery_address} ></textarea> */}
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="delivery_address">Corporate Orders </label>
						<input type="checkbox" rel="corporate_orders" 
						ref={(ref) => {this.corporateOrders = ref}} 
						style={{'width': '20px','height': '20px'}}
						checked={(this.state.gst_number || this.props.order.details.gstnumber)?true:false}
						onClick={this.toggleGstnumber.bind(this)}/>
					</div>
					{(this.state.gst_number || this.props.order.details.gstnumber)?
					<div className={cx('input-group')}>
					<label htmlFor="gst_number">GST Number<em className={cx('mandatory')}>*</em></label>
					<input type="text" ref="gstnumber" rel="gst_number" defaultValue={this.props.order.details.gstnumber}/>
					</div> : ''}
					{/* <div className={cx('input-group')}>
						<label htmlFor="payment_type">Payment Type <em className = {cx('mandatory')}>*</em></label>
						<SelectForm type="payment_type" rel="payment_type" options={this.props.lists.payment_types} value={this.props.order.details.payment_type_id} save={this.saveSelectFormValue} />
					</div> */}
					{/* <div className={cx('input-group')}>
						<label htmlFor="tailor">Tailor <em className = {cx('mandatory')}>*</em> </label>
						<SelectForm type="tailor" rel="tailor" options={this.props.lists.tailors} value={this.props.order.details.tailor_id} save={this.saveSelectFormValue} />
					</div> */}
					{/* <div className={cx('input-group')}>
						<label htmlFor="tailor">Salesman <em className = {cx('mandatory')}>*</em> </label>
						<SelectForm type="salesman_id" rel="salesman_id" options={this.props.lists.salesmen} value={this.props.order.details.salesman_id} save={this.saveSelectFormValue} />
					</div> */}
					{/* <div className={cx('input-group')}>
						<label htmlFor="payment_details">Payment Details</label>
						<input type="text" id="payment_details" ref="payment_details" defaultValue={this.props.order.details.payment_details} />
					</div> */}
					<div className={cx('input-group')}>
						<label htmlFor="comments">Comments</label>
						<textarea id="comment" ref="comment" defaultValue={this.props.order.details.comment} ></textarea>
					</div>
					<div className={cx('divider')}></div>
					<button onClick={this.saveValues} className={cx('action', 'primary')}>Save</button>
				</div>
			</div>
		);
	}
}


OrderDetails.propTypes = {
	order: PropTypes.object,
	lists: PropTypes.object,
	user: PropTypes.object,
	stores: PropTypes.object,
	customer: PropTypes.object
};


function mapStateToProps({ order, lists, user, stores, customer }) {
	return {
		order,
		lists,
		user,
		stores,
		customer
	};
}

export default connect(mapStateToProps)(OrderDetails);