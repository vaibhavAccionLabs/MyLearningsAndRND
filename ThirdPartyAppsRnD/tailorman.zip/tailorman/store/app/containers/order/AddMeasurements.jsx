import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';
import classNames from 'classnames/bind';
import styles from 'css/components/workorder';
import back from 'images/back-arrow.png';
import * as types from 'types';


import {
	push
} from 'react-router-redux';
import { fetchList } from '../../actions/list';
import MeasurementsForm from 'components/MeasurementsForm';

import _ from 'lodash';
import SelectForm from 'components/SelectForm';
import {
	updateMessage, openForm, saveProfile, updateMeasurements, removeMeasurements, showThumbnail, saveMeasurementProfileImageInAWS
} from 'actions/order';
import { connect } from 'react-redux';
import ImageGallery from 'components/ImageGallery';


const cx = classNames.bind(styles);

class AddMeasurements extends Component {
	constructor(props) {
		super(props);
		this.selectItemType = this.selectItemType.bind(this);
		this.loadFields = this.loadFields.bind(this);
		this.saveMeasurements = this.saveMeasurements.bind(this);
		this.closeForm = this.closeForm.bind(this);
		this.showMessage = this.showMessage.bind(this);
		this.saveImageAWS = this.saveImageAWS.bind(this);
		this.showPreviewImage = this.showPreviewImage.bind(this);
		this.state = {
			item_type_id: ""
		}
	}


	componentDidMount() {
		this.props.dispatch(fetchList('item_type'));
		this.props.dispatch(fetchList('measurement_type'));
		document.body.classList.add("scroll-hidden");

	}
	componentWillUnmount(){
		document.body.classList.remove("scroll-hidden");
	}
	showPreviewImage(dataURL, show) {
		this.props.dispatch(showThumbnail(dataURL, show));
	}

	selectItemType(selectedItem) {

		this.setState({
			item_type_id: selectedItem.value
		})
		this.props.dispatch(removeMeasurements(true));
		this.props.dispatch(fetchList('measurement_field', { clear: true }));

	}

	loadFields(type, item_type_id, measurement_type_id, clear) {
		switch (type) {
			case 'measurements':
				this.props.dispatch(fetchList('measurement_field', { item_type_id: item_type_id, measurement_type_id: measurement_type_id, clear }));
				break;
		}
	}
	closeForm(type) {
		this.props.dispatch(push('/customer/actions'));
	}
	saveMeasurements(value, isTemp) {
		if (isTemp) {
			this.props.dispatch(updateMeasurements(value, 'measurements'));
			return;
		}

		value.profile.customer_id = this.props.customer.customer_id;
		value.profile.item_type_id = this.state.item_type_id;
		value.profile.thumbnails = this.props.order.thumbnails;
		saveProfile(value.profile, value.measurements).then(function (profile_id) {

			this.props.dispatch(push('/customer/actions'));
		}.bind(this));

	}
	saveImageAWS(file) {
		this.props.dispatch(saveMeasurementProfileImageInAWS(file, 'profile_measurement_image', types.IMAGE_TYPE_MEASUREMENT));

	}

	showMessage(type, value) {
		this.props.dispatch(updateMessage(type, value));
	}

	render() {
		let { item_type_id } = this.state;
		let {item_types} = this.props.lists;
		var mesaurementForm = "";
		var profile = {
			comment: '',
			name: '',
			item_type_id: 0,
			measurement_source_id: -1,
			profile_id: null
		}
		let item_type_options = [];
		item_types && item_types.map((_item_type)=>{	
			if(_item_type.mtm_flag=="Y"){
				item_type_options.push(_item_type);
			}
		});
		return (<div>
			<div className={cx('half','add-measure-scroll')} style={{}}>
				<div className={cx('container')}>
					<h1 className={cx("title-header")}>Add New Measurements </h1>
					<Link to="/customer/actions" className={cx('back')} ><img src={back} /></Link>
					<div className={cx('input-group')}>
						<SelectForm
							type="item_type"
							rel="item_type"
							options={item_type_options}
							value={item_type_id}
							save={this.selectItemType}
						/>
					</div>
					{(item_type_id) ? (<MeasurementsForm
						lists={this.props.lists}
						item_type_id={item_type_id}
						loadFields={this.loadFields.bind(this, 'measurements', item_type_id)}
						close={this.closeForm.bind(this, 'measurements')}
						save={this.saveMeasurements}
						profile={profile}
						addImage={this.saveImageAWS}
						message={this.showMessage} />) : ""}
				</div>
			</div>
			<div className={cx('half', 'stick-right', 'slick-wrapper','add-measure-scroll')}>
				<ImageGallery thumbnails={this.props.order.thumbnails} thumbnail={this.props.order.thumbnail} showThumbnail={this.showPreviewImage} /> </div></div>)
	}
}

AddMeasurements.propTypes = {
	workorder: PropTypes.object,
	user: PropTypes.object,
	lists: PropTypes.object,
	history: PropTypes.object,
};


function mapStateToProps({ customer, lists, history, order }) {
	return {
		customer,
		lists,
		history,
		order
	};
}

// Connects React component to the redux store
// It does not modify the component class passed to it
// Instead, it returns a new, connected component class, for you to use.
export default connect(mapStateToProps)(AddMeasurements);