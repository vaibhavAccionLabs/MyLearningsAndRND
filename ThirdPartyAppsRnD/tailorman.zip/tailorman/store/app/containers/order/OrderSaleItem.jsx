import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';

import { Link } from 'react-router';
import { push } from 'react-router-redux';

import { connect } from 'react-redux';

import classNames from 'classnames/bind';

import styles from 'css/components/order/sales';

import SelectForm from 'components/SelectForm';
import SearchList from 'components/SearchList';
import CustomImage from 'components/CustomImage';
import MultipleChoice from 'components/MultipleChoice';
import Collapse, { Panel } from 'rc-collapse';
import MeasurementsForm from 'components/MeasurementsForm';
import StylesForm from 'components/StylesForm';
import * as types from 'types';
import ImageGallery from 'components/ImageGallery';
import ImageCapture from 'components/ImageCapture';

import { fetchList, clearList, setActiveKey } from '../../actions/list';
import { saveImageAWS, showThumbnail } from '../../actions/order';
import {
    selectSaleItem,
    initNewSaleItem,
    updateSaleItemEntry,
    deleteSaleItem,
    saveOrderItem,
    updateSaleItemProfile,
    updateMessage,
    getDeliveryUpcharge,
    saveCommentOrderItems,
    saveProfile,
    openForm,
    saveStyleProfile,
    updateSaleStyleItemProfile,
    fetchMeasurementsImages
} from '../../actions/order';
import { setActiveKey as setStyleFormActiveKey } from '../../actions/history';
import {
    getItemTypeDropDown,
    getStyleLiningDropDown
} from 'actions/workorder';


import back from 'images/back-arrow.png';

import { DELIVERY_UPCHARGE, UPCHARGE_UNIT_VALUE } from 'types';

const cx = classNames.bind(styles);

class OrderSaleItem extends Component {
    constructor(props) {
        super(props);

        this.isMTM = false;
        this.selected_fabric_details = {};
        this.saleItem = {};
        this.itemType = {};
        this.accordion = true;
        this.save = this.save.bind(this);
        this.delete = this.delete.bind(this);
        this.selectStyle = this.selectStyle.bind(this);
        this.searchFabrics = this.searchFabrics.bind(this);
        this.toggleProfile = this.toggleProfile.bind(this);
        this.renderStyleList = this.renderStyleList.bind(this);
        this.getFabricOptions = this.getFabricOptions.bind(this);
        this.saveSelectFormValues = this.saveSelectFormValues.bind(this);
        this.getStylingAndMeasurements = this.getStylingAndMeasurements.bind(this);
        this.toggleAccordion = this.toggleAccordion.bind(this);
        this.addImage = this.addImage.bind(this);
        this.styleFormToggleAccordion = this.styleFormToggleAccordion.bind(this);
        this.saveMeasurements = this.saveMeasurements.bind(this);
        this.closeForm = this.closeForm.bind(this);
        this.saveFabricDesign = this.saveFabricDesign.bind(this);
        this.showMessage = this.showMessage.bind(this);
        this.showPreviewImage = this.showPreviewImage.bind(this);
        this.toggleStylingProfile = this.toggleStylingProfile.bind(this);
        this.toggleUpchargeMeasurement = this.toggleUpchargeMeasurement.bind(this);
        //this.getUpcharge = this.getUpcharge.bind(this);
        // this.state = {
        //     modified: false
        // }

    }
    closeForm(type) {
        this.props.dispatch(openForm(type, true));
    }
    createNewOrderItem(suitSaleItem) {
        let {
            order: { sales },
            params: { item_type_id, id },
            customer: { customer_id },
            lists: { item_types, styles, measurement_types, priorities },
            dispatch
        } = this.props;

        dispatch(initNewSaleItem(suitSaleItem.item_type_id, customer_id, sales));
    }
    toggleAccordion(activeKey) {
        this.props.dispatch(setActiveKey(activeKey));
    }
    styleFormToggleAccordion(activeKey) {
        this.props.dispatch(setStyleFormActiveKey(activeKey));
    }
    showMessage(type, value) {
        this.props.dispatch(updateMessage(type, value));
    }
    saveFabricDesign(fabric_design, comment, upCharges = [], obj, value) {
        if (value && value.profile) {
            upCharges = this.refs.styleform && this.refs.styleform.getUpchargeObject();
        }
        let sale_item_upcharges = this.saleItem.upcharge || this.saleItem.upcharges || [];
        sale_item_upcharges = _.isArray(sale_item_upcharges) ? sale_item_upcharges : [];
        let delivery_upcharge = sale_item_upcharges.filter((upcharge) => {
            return upcharge.type == DELIVERY_UPCHARGE;
        });
        if (delivery_upcharge && delivery_upcharge.length > 0) {
            upCharges.push(delivery_upcharge[0]);
        }
        let higher_size_upcharge = sale_item_upcharges.filter((upcharge) => {
            return upcharge.type == "Higher Size Upcharge";
        });

        if (higher_size_upcharge && higher_size_upcharge.length > 0) {
            upCharges.push(higher_size_upcharge[0]);
        }
        this.props.dispatch(updateSaleItemEntry(fabric_design, 'fabric_designs', this.props.params.id));
        this.props.dispatch(updateSaleItemEntry(comment, 'fabric_design_comment', this.props.params.id));
        this.props.dispatch(updateSaleItemEntry(upCharges, 'upcharges', this.props.params.id));
        let saleItem = this.saveStyleSaleItemPayload || this.saleItem;
        saleItem = Object.assign({},saleItem,{
            fabric_designs : fabric_design,
            fabric_design_comment : comment,
            upcharges : upCharges
        });
        this.saveSaleItemPayload = saleItem;
        if (value && value.profile) {
            value.profile.customer_id = this.props.customer.customer_id;
            value.profile.item_type_id = saleItem.item_type_id;
            saleItem = Object.assign({}, saleItem, {
                style_profile: value.profile,
                style_profile_id: value.profile.profile_id,
                is_new_style: false,
            });
        }
        this.saveSaleItemPayload = saleItem;
    }

    loadFields(type, item_type_id, measurement_type_id, clear) {
        switch (type) {
            case 'styles':
                this.props.dispatch(fetchList('fabric_design_field', { item_type_id: item_type_id, clear: clear }));
                break;
            case 'measurements':
                this.props.dispatch(fetchList('measurement_field', { item_type_id: item_type_id, measurement_type_id: measurement_type_id, clear }));
                break;
        }
    }

    componentDidMount() {
        let {
            order: { sales },
            params: { item_type_id, id },
            customer: { customer_id },
            lists: { item_types, styles, measurement_types, priorities },
            dispatch
        } = this.props;

        if (!sales[id]) {
            dispatch(initNewSaleItem(item_type_id, customer_id, sales));
        } else {
            this.saleItem = sales[id];
        }
        const item_type_details = _.find(this.props.lists.item_types, { item_type_id: parseInt(this.props.params.item_type_id) });
        this.isMTM = item_type_details ? item_type_details.isMTM : false;
        this.props.dispatch(updateSaleItemEntry(this.isMTM, 'isMTM', this.props.params.id));
        if (this.props.lists.item_types && this.props.lists.item_types.length === 0)
            this.props.dispatch(fetchList('item_type'));
        if (this.props.lists.styles && this.props.lists.styles.length === 0)
            this.props.dispatch(fetchList('style'));
        if (this.props.lists.measurement_types && this.props.lists.measurement_types.length === 0)
            this.props.dispatch(fetchList('measurement_type'));
        if (this.props.lists.priorities && this.props.lists.priorities.length === 0)
            this.props.dispatch(fetchList('priority'));
        this.itemType = _.find(this.props.lists.item_types, { item_type_id: parseInt(this.props.params.item_type_id) });
        // this.props.dispatch(fetchList('profile', { item_type_id: parseInt(this.props.params.item_type_id), customer_id: this.props.customer.customer_id }));
        this.props.dispatch(fetchList('style_profile', { item_type_id: parseInt(this.props.params.item_type_id), customer_id: this.props.customer.customer_id }));
        this.props.dispatch(fetchList('finish_type', { item_type_id, id }));
        this.props.dispatch(fetchList('rtwmeasurements', { store_id: parseInt(this.props.order.details.store_id), item_type_id: parseInt(this.props.params.item_type_id) }));
        this.props.dispatch(getItemTypeDropDown(item_type_id));
        this.props.dispatch(getStyleLiningDropDown())
        window.scrollTo(0, 0);
    }


    saveSelectFormValues(selected, type) {
        switch (type) {
            case 'style':
                const fabric = _.find(this.props.lists.fabrics, { fabric_id: parseInt(selected.value) });
                ReactDOM.findDOMNode(this.refs.mrp).value = fabric.shirt_mrp;
                ReactDOM.findDOMNode(this.refs.sku).value = fabric.sku_code;
                this.props.dispatch(updateSaleItemEntry(fabric.shirt_mrp, 'mrp', this.props.params.id));
                this.props.dispatch(updateSaleItemEntry(fabric.sku_code, 'sku', this.props.params.id));
                this.props.dispatch(updateSaleItemEntry(selected.value, 'style', this.props.params.id));
                break;
            case 'profile_id':
                const profile = _.find(this.props.lists.profiles, { id: parseInt(selected.value) });
                this.props.dispatch(updateSaleItemProfile(profile, this.props.order.sales[this.props.params.id].item_type_id, this.props.params.id));
                this.props.dispatch(updateSaleItemEntry(parseInt(selected.value), type, this.props.params.id));
                this.props.dispatch(fetchMeasurementsImages(parseInt(selected.value), type, this.props.params.id));
                break;
            case 'style_profile_id':

                const style_profile = _.find(this.props.lists.style_profiles, { id: parseInt(selected.value) });
                this.props.dispatch(updateSaleItemEntry(false, 'is_new_style', this.props.params.id));
                this.props.dispatch(updateSaleStyleItemProfile(style_profile, this.props.order.sales[this.props.params.id].item_type_id, this.props.params.id));
                this.props.dispatch(updateSaleItemEntry(parseInt(selected.value), type, this.props.params.id));
                this.saveFabricDesign(this.props.order.sales[this.props.params.id].fabric_design, this.props.order.sales[this.props.params.id].comment, this.props.order.sales[this.props.params.id].upcharge, null, this.props.order.sales[this.props.params.id]);
                //  this.props.dispatch(updateSaleStyleItemProfile(style_profile, this.props.order.sales[this.props.params.id].comment, this.props.params.id));
                // this.refs.comment.value = style_profile.comment || null;
                break;
            case 'priority_id':
                getDeliveryUpcharge(this.saleItem.item_type_id, selected.value).then((delivery_upcharge) => {
                    let upcharges = this.saleItem.upcharge || this.saleItem.upcharges || [];
                    upcharges = _.isArray(upcharges) ? upcharges : [];
                    if (upcharges.length > 0) {
                        upcharges = _.compact(upcharges.filter((upcharge) => {
                            return upcharge.type != DELIVERY_UPCHARGE;
                        }));
                    }
                    if (delivery_upcharge) {
                        upcharges.push({
                            type: DELIVERY_UPCHARGE,
                            value: delivery_upcharge,
                            unit: UPCHARGE_UNIT_VALUE
                        });
                    }
                    this.props.dispatch(updateSaleItemEntry(parseInt(selected.value), type, this.props.params.id));
                    this.props.dispatch(updateSaleItemEntry(upcharges, 'upcharges', this.props.params.id));
                })
                break;
            case 'comment':
                this.props.dispatch(updateSaleItemEntry(selected, type, this.props.params.id));
                break;
            case 'size':
            case 'fit':
                //case 'length':
                if (selected) {

                    this.props.dispatch(updateSaleItemEntry(selected.value, type, this.props.params.id));
                }
                break;
            default:
                this.props.dispatch(updateSaleItemEntry(parseInt(selected.value), type, this.props.params.id));
        }
    }

    getFabricOptions() {
        return this.props.lists.fabrics.map((fabric) => {
            return fabric.sku;
        });
    }

    toggleProfile(value) {
        if (value[0] == 'yes') {
            value = true;
        } else {
            value = false;
        }
        this.props.dispatch(updateSaleItemEntry(value, 'is_new_measurements', this.props.params.id));


    }
    toggleUpchargeMeasurement(value) {
        var upcharges = this.props.order.sales[this.props.params.id].upcharges;
        var upchargeIndex = _.findIndex(upcharges, { type: "Higher Size Upcharge" });

        var upcharge = {
            type: "Higher Size Upcharge",
            unit: 2,
            value: 15
        };
        if (value[0] == 'yes') {
            value = true;

        } else {
            value = false;
        }
        if (upchargeIndex > 0 && !value) {
                upcharges.filter((item, index) => {
                if (upchargeIndex != index) {
                    return item
                }
            })
        }
        if (upchargeIndex == -1 && value) {
            upcharges.push(upcharge);
        }
        this.props.dispatch(updateSaleItemEntry(value, 'is_upcharge_measurements', this.props.params.id));
        this.props.dispatch(updateSaleItemEntry(upcharges, 'upcharges', this.props.params.id));
    }
    toggleStylingProfile(value) {
        if (value[0] == 'yes') {
            value = true;
        } else {
            value = false;
        }
        this.props.dispatch(updateSaleItemEntry(value, 'is_new_style', this.props.params.id));
        if(value){
            this.props.dispatch(updateSaleItemEntry(-1, 'style_profile_id', this.props.params.id));
        }
    }
    addImage(file) {
        this.props.dispatch(saveImageAWS(file, this.props.order.details.order_id, types.IMAGE_TYPE_MEASUREMENT));
    }


    saveMeasurements(value, isTemp) {
        if (isTemp) {
            this.props.dispatch(updateSaleItemEntry(value, 'measurements', this.props.params.id));
            return;
        }
        let saleItem = this.saveSaleItemPayload;
        value.profile.customer_id = this.props.customer.customer_id;
        value.profile.item_type_id = saleItem.item_type_id;
        saveProfile(value.profile, value.measurements).then(function (profile_id) {
            value.profile.profile_id = profile_id;
            saleItem = Object.assign({}, saleItem, {
                profile: value.profile,
                profile_id: profile_id,
                measurement_source_id: value.profile.measurement_source_id,
                is_new_measurements: false,
                thumbnails: this.props.order.thumbnails
            });
            //  if(!this.styleItem ){
            const isUpdate = (saleItem.order_item_id) ? true : false;
            this.props.dispatch(saveOrderItem(saleItem, isUpdate, this.props.params.id));
            this.props.dispatch(push('/order/sales'));
            // }
            //this.setState({'saleItem':saleItem});

        }.bind(this));
    }
    save() {
        // var item = _.find(this.props.lists.item_types, { item_type_id: parseInt(this.props.params.item_type_id) });
        // var style = _.find(this.props.lists.sale_fabrics, { fabric_id: this.props.order.sales[this.props.params.id].style });
        this.selected_fabric_details = this.saleItem;//this.props.lists.details;
        const getDisplayName = (sale, isBundled) => {
            if (sale.display_name) {
                return sale.display_name;
            }
            if (isBundled) {
                return sale.item_type_name + " - " + sale.name + " - " + sale.product_sku_code;
            }
            if (sale) {
                return sale.code + " - " + sale.name + " - " + sale.product_sku_code;
            } else if (sale.display_name)
                return sale.display_name;
            else
                return '';
        }
        let saleItem = {};
        if (!this.isMTM) {
            let fabric_measurement = {};
            let { fit, length, size, qty } = this.saleItem;

            fabric_measurement.fit = fit;
            fabric_measurement.length = length;
            fabric_measurement.size = size;
            fabric_measurement.product_sku_code = this.saleItem.display_sku || this.saleItem.product_sku || this.saleItem.product_sku_code;
            fabric_measurement.qty = parseInt(ReactDOM.findDOMNode(this.refs.qty).value);
            saleItem = {
                style: this.props.order.sales[this.props.params.id].style,
                mrp: parseFloat(ReactDOM.findDOMNode(this.refs.mrp).value),
                qty: parseInt(ReactDOM.findDOMNode(this.refs.qty).value),
                // delivery_date: ReactDOM.findDOMNode(this.refs.delivery_date).value,
                fiton_date: this.props.order.sales[this.props.params.id].fiton_date,//ReactDOM.findDOMNode(this.refs.fiton_date).value,
                delivery_date: this.props.order.sales[this.props.params.id].delivery_date,//ReactDOM.findDOMNode(this.refs.delivery_date).value,
                priority_id: 1,
                order_id: this.props.order.details.order_id,
                display_name: getDisplayName(this.props.order.sales[this.props.params.id]),
                order_item_id: this.props.order.sales[this.props.params.id].order_item_id,
                workflow_id: 1,
                finish_type_id: 1,
                isMTM: this.isMTM,
                item_type_id: parseInt(this.props.params.item_type_id),
                profile_id: -1,
                comment: ReactDOM.findDOMNode(this.refs.comment).value,
                fabric_measurement: fabric_measurement,
                old_qty: this.props.order.sales[this.props.params.id].qty || 0,
                store_id: this.props.order.details.store_id,
                old_fabric_measurement: this.saleItem.fabric_measurement
            }
        } else {
            saleItem = {
                style: this.props.order.sales[this.props.params.id].style,
                mrp: parseFloat(ReactDOM.findDOMNode(this.refs.mrp).value),
                qty: parseInt(ReactDOM.findDOMNode(this.refs.qty).value),
                fiton_date: this.props.order.sales[this.props.params.id].fiton_date,//ReactDOM.findDOMNode(this.refs.fiton_date).value,
                delivery_date: this.props.order.sales[this.props.params.id].delivery_date,//ReactDOM.findDOMNode(this.refs.delivery_date).value,
                // fiton_date: (ReactDOM.findDOMNode(this.refs.fiton_date))?ReactDOM.findDOMNode(this.refs.fiton_date).value:null,
                // delivery_date: ReactDOM.findDOMNode(this.refs.delivery_date).value,
                customer_fit_on_date: (ReactDOM.findDOMNode(this.refs.customer_fit_on_date)) ? ReactDOM.findDOMNode(this.refs.customer_fit_on_date).value : null,
                customer_delivery_date: ReactDOM.findDOMNode(this.refs.customer_delivery_date).value,
                comment: ReactDOM.findDOMNode(this.refs.comment).value,
                item_type_id: parseInt(this.props.params.item_type_id),
                priority_id: this.props.order.sales[this.props.params.id].priority_id,
                workflow_id: 1,
                profile_id: -1,
                order_id: this.props.order.details.order_id,
                is_new_measurements: this.props.order.sales[this.props.params.id].is_new_measurements,
                is_new_style: this.props.order.sales[this.props.params.id].is_new_style,
                display_name: getDisplayName(this.props.order.sales[this.props.params.id]),
                order_item_id: this.props.order.sales[this.props.params.id].order_item_id,
                finish_type_id: this.props.order.sales[this.props.params.id].finish_type_id,
                thumbnails: this.props.order.thumbnails,
                isMTM: this.isMTM,
                workflow_stage_id: 13
            }
        };
        saleItem = Object.assign({},this.props.order.sales[this.props.params.id],saleItem);
        const isUpdate = (saleItem.order_item_id) ? true : false;
        // if (saleItem.is_new_measurements) {
        //     this.props.dispatch(updateSaleItemEntry(-1, 'profile_id', this.props.params.id));
        //     this.props.dispatch(updateSaleItemEntry(saleItem.profile_id, 'backup_profile_id', this.props.params.id));
        // }
        // if (saleItem.is_new_style) {
        // this.props.dispatch(updateSaleItemEntry(-1, 'style_profile_id', this.props.params.id));
        // this.props.dispatch(updateSaleItemEntry(saleItem.style_profile_id, 'backup_style_profile_id', this.props.params.id));
        // }
        //if (saleItem.style > 0 && saleItem.qty > 0 && saleItem.finish_type_id > 0 && saleItem.priority_id > 0) {
        if (saleItem.qty > 0 && saleItem.finish_type_id > 0 && saleItem.priority_id > 0) {

            if (this.refs && this.refs.styleform) {
                this.saveStyleSaleItemPayload = saleItem;
                if (!this.refs.styleform.saveAndClose()) {
                    console.log('Styles form returned invalid');
                    return false;
                }
            }
            // if (this.refs && this.refs.measurementform) {
            //     if (!this.saveSaleItemPayload)
            //         this.saveSaleItemPayload = saleItem;
            //     //  if(this.refs.styleform){
            //     //      this.styleItem = true;
            //     //  }
            //     this.refs.measurementform.save();
            // }

            // if (!(this.refs && this.refs.measurementform)) {
            if (this.refs && this.refs.styleform) {
                //  this.saveSaleItemPayload.comment = saleItem.comment;
                saleItem = this.saveSaleItemPayload;
            }
            if (this.selected_fabric_details && this.selected_fabric_details.bundled_sku_list) {
                let bundled_sku_list = this.selected_fabric_details.bundled_sku_list;
                let suitSaleItem = {
                    style: this.props.params.id,
                    mrp: bundled_sku_list[0].mrp,
                    qty: parseInt(ReactDOM.findDOMNode(this.refs.qty).value),
                    fiton_date: this.props.order.sales[this.props.params.id].fiton_date,
                    delivery_date: this.props.order.sales[this.props.params.id].delivery_date,
                    customer_fit_on_date: this.refs.customer_fit_on_date && ReactDOM.findDOMNode(this.refs.customer_fit_on_date).value,
                    customer_delivery_date: this.refs.customer_delivery_date && ReactDOM.findDOMNode(this.refs.customer_delivery_date).value,
                    comment: ReactDOM.findDOMNode(this.refs.comment).value,
                    item_type_id: bundled_sku_list[0].item_type_id,
                    priority_id: this.props.order.sales[this.props.params.id].priority_id,
                    workflow_id: 1,
                    profile_id: -1,
                    order_id: this.props.order.details.order_id,
                    is_new_measurements: this.props.order.sales[this.props.params.id].is_new_measurements,
                    display_name: getDisplayName(bundled_sku_list[0], true),
                    order_item_id: this.props.order.sales[this.props.params.id].order_item_id,
                    finish_type_id: this.props.order.sales[this.props.params.id].finish_type_id,
                    isMTM: this.isMTM,
                    fabric_measurement : saleItem.fabric_measurement,
                    workflow_stage_id : this.isMTM ? 13 : 1
                };
                suitSaleItem = Object.assign({},suitSaleItem,bundled_sku_list[0],{
                    style : bundled_sku_list[0].fabric_id,
                    sku : bundled_sku_list[0].fabric_sku_code
                });
                let suitSaleItem1 = {
                    style: this.props.params.id + 1,
                    mrp: bundled_sku_list[1].mrp,
                    qty: parseInt(ReactDOM.findDOMNode(this.refs.qty).value),
                    fiton_date: this.props.order.sales[this.props.params.id].fiton_date,//ReactDOM.findDOMNode(this.refs.fiton_date).value,
                    delivery_date: this.props.order.sales[this.props.params.id].delivery_date,//ReactDOM.findDOMNode(this.refs.delivery_date).value,
                    customer_fit_on_date: this.refs.customer_fit_on_date && ReactDOM.findDOMNode(this.refs.customer_fit_on_date).value,
                    customer_delivery_date: this.refs.customer_delivery_date && ReactDOM.findDOMNode(this.refs.customer_delivery_date).value,
                    comment: ReactDOM.findDOMNode(this.refs.comment).value,
                    item_type_id: bundled_sku_list[1].item_type_id,
                    priority_id: this.props.order.sales[this.props.params.id].priority_id,
                    workflow_id: 1,
                    profile_id: -1,
                    order_id: this.props.order.details.order_id,
                    is_new_measurements: this.props.order.sales[this.props.params.id].is_new_measurements,
                    display_name: getDisplayName(bundled_sku_list[1], true),
                    order_item_id: this.props.order.sales[this.props.params.id].order_item_id,
                    finish_type_id: this.props.order.sales[this.props.params.id].finish_type_id,
                    isMTM: this.isMTM,
                    fabric_measurement : saleItem.fabric_measurement,
                    workflow_stage_id : this.isMTM ? 13 : 1
                };
                suitSaleItem1 = Object.assign({},suitSaleItem1,bundled_sku_list[1],{
                    style : bundled_sku_list[1].fabric_id,
                    sku : bundled_sku_list[1].fabric_sku_code
                });
                this.props.dispatch(saveOrderItem(suitSaleItem, isUpdate, this.props.params.id));
                this.props.dispatch(saveOrderItem(suitSaleItem1, isUpdate, parseInt(this.props.params.id) + 1));

            } else {
                this.props.dispatch(saveOrderItem(saleItem, isUpdate, this.props.params.id));
                this.props.dispatch(saveCommentOrderItems(saleItem, this.props.order.sales));
            }
            this.props.dispatch(push('/order/sales'));
            // }

        } else {
            if (this.isMTM)
                this.props.dispatch(updateMessage('MEASUREMENT_FORM_VALIDATION', 'Please select SKU, Quantity, Finish type & Priority'));
            else
                this.props.dispatch(updateMessage('MEASUREMENT_FORM_VALIDATION', 'Please select SKU and update Quantity'));
            window.scrollTo(0, 0);
        }

    }

    delete() {
        let fabric_measurement = {};
        let { fit, length, size } = this.saleItem;

        fabric_measurement.fit = fit;
        fabric_measurement.length = length;
        fabric_measurement.size = size;
        fabric_measurement.product_sku_code = this.saleItem.display_sku || this.saleItem.product_sku || this.saleItem.product_sku_code;
        fabric_measurement.store_id = this.props.order.details.store_id;
        fabric_measurement.isMTM = this.isMTM;
        fabric_measurement.qty = -parseInt(this.props.order.sales[this.props.params.id].qty) || 0;

        this.props.dispatch(deleteSaleItem(this.props.order.sales[this.props.params.id], this.props.order.sales[this.props.params.id].order_item_id, this.props.params.id, fabric_measurement));
        this.props.dispatch(push('/order/sales'));
    }

    renderStyleList(style) {
        let getQunatity = "";
        if (!this.isMTM) {
            getQunatity = <span className={cx('select-phone')}>Qty: {style.quantity}</span>
        }
        return (
            <div>
                <span className={cx('select-main-label')}>{style.name}</span>
                <span className={cx('select-email')}>{style.mrp + " INR"}</span>
                <span className={cx('select-phone')}>{style.product_sku_code}</span>
                {getQunatity}
            </div>
        )
    }

    searchFabrics(keyword) {
        let { params: { item_type_id }, dispatch } = this.props;

        if (keyword.length === 0) {
            dispatch(clearList('fabric'));
        } else {
            let { fit, length, size } = this.saleItem;
            if (this.isMTM) {
                this.props.dispatch(fetchList('fabric', { keyword: keyword, item_type_id: this.props.params.item_type_id, isMTM: this.isMTM }));
            } else {
                if (fit && size) {

                    this.props.dispatch(fetchList('fabric', { keyword: keyword, item_type_id: this.props.params.item_type_id, product_fit: fit, product_size: size, product_length: length, isMTM: this.isMTM }));

                } else {
                    this.props.dispatch(updateMessage('MEASUREMENT_FORM_VALIDATION', 'Please select Size,Fit for SKU search'));
                    window.scrollTo(0, 0);
                }
            }
        }
    }

    selectStyle(id) {
        let refs = this.refs;
        let { params, lists: { fabrics }, dispatch } = this.props;

        const fabric = _.find(fabrics, { fabric_id: parseInt(id) });
        this.selected_fabric_details = fabric;
        ReactDOM.findDOMNode(refs.mrp).value = fabric.mrp;
        ReactDOM.findDOMNode(refs.description).value = fabric.name;
        ReactDOM.findDOMNode(refs.sku).value = fabric.product_sku_code;

        dispatch(updateSaleItemEntry(fabric.mrp, 'mrp', params.id));
        dispatch(updateSaleItemEntry(fabric.name, 'fabric_description', params.id));
        dispatch(updateSaleItemEntry(fabric.fabric_sku_code, 'sku', params.id));
        dispatch(updateSaleItemEntry(fabric.product_sku_code, 'display_sku', params.id));
        dispatch(updateSaleItemEntry(id, 'style', params.id));

    }

    showPreviewImage(dataURL, show) {
        this.props.dispatch(showThumbnail(dataURL, show));
    }
    getIsNewStyle(){
        let is_new_style = false;
        is_new_style = this.saleItem.is_new_style;
        if (this.saleItem && this.saleItem.style_profile_id > 0 ) {
            is_new_style  = false;
        }
        return is_new_style;
    }
    getStylingAndMeasurements() {
        let saleItem = this.saleItem;
        let is_new_style = this.getIsNewStyle();
        let upcharges = saleItem.upcharges || saleItem.upcharge || [];
        if (!_.isArray(upcharges)) {
            upcharges = [];
        }
        let stylePanel = "";
        if (saleItem.item_type_id == 31) {
            return (<div />);
        }
        let style_fabric_design = this.saleItem.fabric_designs;
        style_fabric_design = this.saleItem.style_profile ? this.saleItem.style_profile.fabric_design : style_fabric_design;
        
        let styleClassName = '';
        if (!is_new_style) {
            styleClassName = 'hideStylePanel'
        }
        stylePanel = (<Panel header="Product Styling" className={cx(styleClassName)}>
            <div className={cx('container')}>
                <StylesForm
                    lists={this.props.lists}
                    hideSaveCancelButton={true}
                    displayUpcharge={true}
                    ref="styleform"
                    save={this.saveFabricDesign}
                    close={this.closeForm.bind(this, 'styles')}
                    loadFields={this.loadFields.bind(this, 'styles', this.saleItem.item_type_id)}
                    fabricDesign={style_fabric_design}
                    comment={this.saleItem.fabric_design_comment}
                    toggleAccordion={this.toggleAccordion}
                    activeKey={this.props.lists.accordionKey}
                    message={this.showMessage}
                    profile={this.saleItem.style_profile}
                    //showProfileName={this.state.modified}
                    item_type_style_dropdown={this.props.workorder.item_type_style_dropdown}
                    item_style_lining_dropdown={this.props.workorder.item_style_lining_dropdown}
                    is_new_style={is_new_style}
                    style_profile_id={this.saleItem.style_profile_id}
                />
            </div>
        </Panel>);
        return (
            <Collapse defaultActiveKey={'0'}>
                {stylePanel}
                <ImageGallery thumbnails={this.props.order.thumbnails} thumbnail={this.props.order.thumbnail} showThumbnail={this.showPreviewImage} />
            </Collapse>
        );
    }

    render() {
        let {
            order: { sales },
            params: { id, item_type_id },
            lists: { fabrics, profiles, item_types, finish_types, priorities, style_profiles },
            customer: { name }
        } = this.props;
        let fabricImage = '';
        this.saleItem = sales[id];
        
        const is_upcharge_measurements = sales[id] ? ( sales[id].is_upcharge_measurements || false ) : false;
        let is_new_style = this.getIsNewStyle();
        
        if (this.saleItem && fabrics.length > 0 && this.saleItem.style > 0) {
            const fabric = _.find(fabrics, { fabric_id: parseInt(this.saleItem.style) });
            this.saleItem.sku = fabric ? fabric.fabric_sku_code : undefined;
        }
        let getMeasurements = "";
        if (!this.isMTM) {
            const orderItemId = this.saleItem && this.saleItem.order_item_id;
            const isUpdate = (orderItemId) ? true : false;
            getMeasurements = (<div><div className={cx('input-group')}>
                <label htmlFor="product_size">Select Size<em className={cx('mandatory')}>*</em></label>
                <SelectForm type="size" rel="size" options={this.props.lists.product_sizes} value={this.saleItem && this.saleItem.size} save={this.saveSelectFormValues} disabled={isUpdate} />
            </div>
                <div className={cx('input-group')}>
                    <label htmlFor="product_size">Select Fit<em className={cx('mandatory')}>*</em></label>
                    <SelectForm type="fit" rel="fit" options={this.props.lists.product_fits} value={this.saleItem && this.saleItem.fit} save={this.saveSelectFormValues} disabled={isUpdate} />
                </div>
            </div>)

        }
        let profileField = null;
        let styleProfileField = null;
        let fabricImageElement = '';
        const product_sku_code = this.saleItem.display_sku || this.saleItem.product_sku || this.saleItem.product_sku_code;

        if (this.saleItem && this.saleItem.sku) {
            fabricImage = `https://s3.ap-south-1.amazonaws.com/assets.web.tm/product/${this.saleItem.sku}.jpg`;
            fabricImageElement = <div className={cx('input-group')}>
                <label htmlFor="fabric_image_text">Fabric Image</label>
                <CustomImage src={fabricImage} width='210px' height='210px' />
            </div>;
        }
        if (!is_new_style) {
            styleProfileField = (<div className={cx('input-group')}>
                <label htmlFor="styleprofiles">Select from below Styling Profiles</label>
                <SelectForm type="styleprofiles" rel="style_profile_id" options={style_profiles} value={this.saleItem.style_profile_id} save={this.saveSelectFormValues} />
            </div>);
        }
        const item_type = _.find(item_types, { item_type_id: parseInt(item_type_id) }) || {};
        var disabledFinishType = false;
        if (item_type_id == 1) {
            disabledFinishType = true;
        }
        let customer_fiton_date = (item_type_id == 1) ? "" : (<span style={{ width: "100%" }}><div className={cx('input-group')}>
            <label htmlFor="customer_fit_on_date"> Customer Fit on Date</label>
            <input type="date" ref="customer_fit_on_date" defaultValue={this.saleItem && this.saleItem.customer_fit_on_date} />
        </div>
        </span>);
        let mtm_fields = (
            <div className={cx('benign-container')}>
                <div className={cx('input-group')}>
                    <label htmlFor="qty">Finish <em className={cx('mandatory')}>*</em></label>
                    <SelectForm type="finish_type_id" rel="finish_type_id" options={finish_types} value={this.saleItem && (this.saleItem.finish_type_id || this.saleItem.finish_type)} save={this.saveSelectFormValues} disabled={disabledFinishType} />
                </div>
                <div className={cx('input-group')}>
                    <label htmlFor="qty">Priority <em className={cx('mandatory')}>*</em></label>
                    <SelectForm type="priority_id" rel="priority_id" options={priorities} value={this.saleItem && this.saleItem.priority_id} save={this.saveSelectFormValues} />
                </div>
                <div className={cx('input-group')}>
                    <label htmlFor="is_upcharge_measurements">Higher Size Upcharge</label>
                    <MultipleChoice isMultiple={false} options={['yes', 'no']} selected={(is_upcharge_measurements === false) ? 'no' : 'yes'} rel="is_upcharge_measurements" save={this.toggleUpchargeMeasurement} />
                </div>
                {profileField}
                <div className={cx('input-group')}>
                    <label htmlFor="is_new_style_profile">Is New Styling</label>
                    <MultipleChoice isMultiple={false} options={['yes', 'no']} selected={(is_new_style === false) ? 'no' : 'yes'} rel="is_new_style" save={this.toggleStylingProfile} />
                </div>
                {styleProfileField}
            </div>
        );
        if (!this.isMTM) {
            mtm_fields = null;
            customer_fiton_date = null;
        }

        return (
            <div className={cx('container')}>
                <div className={cx('header-note')}>
                    <span className={cx('header-label')}>Customer:   </span>
                    <span className={cx('header-content')}>{name}</span>
                </div>
                <Link to="/order" className={cx('review')}>
                    Review
				</Link>
                {(this.isMTM && this.saleItem.item_type_id != 31) ? <ImageCapture addImage={this.addImage} /> : ""}
                <Link to="/order/sales" className={cx('back')} ><img src={back} /></Link>
                <div className={cx('form-container')}>
                    <h1>Sale Item</h1>
                    <div className={cx('input-group')}>
                        <label htmlFor="item_type">Item Type</label>
                        <input type="text" ref="item_type" defaultValue={item_type.descr} readOnly />
                    </div>
                    {getMeasurements}
                    <div className={cx('input-group')}>
                        <label htmlFor="desc">Description</label>
                        <input type="text" ref="description" defaultValue={this.saleItem && this.saleItem.name} readOnly />
                    </div>
                    {fabricImageElement}
                    <div className={cx('input-group')}>
                        <label htmlFor="sku">SKU</label>
                        <input type="text" ref="sku" defaultValue={product_sku_code} readOnly />
                    </div>
                    <div className={cx('input-group')}>
                        <label htmlFor="mrp">MRP</label>
                        <input type="number" min="0.00" step="0.01" ref="mrp" defaultValue={this.saleItem && this.saleItem.mrp} readOnly />
                    </div>

                    <div className={cx('input-group')}>
                        <label htmlFor="qty">quantity <em className={cx('mandatory')}>*</em> </label>
                        <input type="number" min="0" step="1" ref="qty" defaultValue={this.saleItem && this.saleItem.qty} />
                    </div>
                    {customer_fiton_date}
                    <div className={cx('input-group')}>
                        <label htmlFor="customer_delivery_date">Customer Delivery Date</label>
                        <input type="date" ref="customer_delivery_date" defaultValue={this.saleItem && this.saleItem.customer_delivery_date} />
                    </div>
                    {mtm_fields}
                    {this.isMTM ? this.getStylingAndMeasurements() : ""}
                    <div className={cx('input-group')}>
                        <label htmlFor="comments">Comments</label>
                        <textarea id="comment" ref="comment" value={this.saleItem && this.saleItem.comment} onChange={(e) => this.saveSelectFormValues(e.target.value, 'comment')}></textarea>
                    </div>
                    <button onClick={this.delete} className={cx('action', 'warning')}>Delete</button>
                    <button onClick={this.save} className={cx('action', 'primary')}>Save Sale</button>

                </div>
            </div>
        );
    }
}

OrderSaleItem.propTypes = {
    user: PropTypes.object,
    customer: PropTypes.object,
    order: PropTypes.object,
    lists: PropTypes.object,
    history: PropTypes.object,
    workorder: PropTypes.object
};


function mapStateToProps({ order, lists, user, customer, workorder }) {
    return {
        order,
        lists,
        user,
        customer,
        history,
        workorder
    };
}

export default connect(mapStateToProps, null, null, { withRef: true })(OrderSaleItem);