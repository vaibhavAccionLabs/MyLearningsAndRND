/**
 * Routes for express app
 */
import passport from 'passport';
import unsupportedMessage from '../db/unsupportedMessage';
import fs from 'fs';
import {
    controllers,
    passport as passportConfig
} from '../db';

const usersController = controllers && controllers.users;
const listsController = controllers && controllers.lists;
const ordersController = controllers && controllers.orders;
const dashboardController = controllers && controllers.dashboard;
const capillaryController =  controllers && controllers.capillary;
const orderStyleController = controllers && controllers.orderupdate;
const dbDumpController = controllers && controllers.dbdump;

export default (app) => {
    // user routes
    	if(orderStyleController) {
			app.post('/orderstyleupdate',orderStyleController.getPendingWorkOrders);
		}else {
			console.warn(unsupportedMessage('orderstyle routes'));
		}
    if (usersController) {
        app.post('/login', usersController.login);
        app.post('/logout', usersController.logout);
        app.post('/user/stores', usersController.getStores);
        app.get('/userdetails',usersController.getUserDetails);
    } else {
        console.warn(unsupportedMessage('users routes'));
    }

    if (passportConfig && passportConfig.google) {
        // google auth
        // Redirect the user to Google for authentication. When complete, Google
        // will redirect the user back to the application at
        // /auth/google/return
        // Authentication with google requires an additional scope param, for more info go
        // here https://developers.google.com/identity/protocols/OpenIDConnect#scope-param
        app.get('/auth/google', passport.authenticate('google', {
            scope: [
                'https://www.googleapis.com/auth/userinfo.profile',
                'https://www.googleapis.com/auth/userinfo.email'
            ]
        }));

		// Google will redirect the user to this URL after authentication. Finish the
		// process by verifying the assertion. If valid, the user will be logged in.
		// Otherwise, the authentication has failed.
		app.get('/oauth2callback',
			passport.authenticate('google', {
				successRedirect: '/',
				failureRedirect: '/login'
			})
		);
	}
    if(capillaryController){
		
		app.post('/getlayalitypoints', capillaryController.getLoyalityPoints);
		app.post('/iscouponredeemable',capillaryController.isCouponRedeemable);
		app.post('/ispointsredeemable',capillaryController.isPointsRedeemable);
		app.post('/redeempoints',capillaryController.redeemPoints);
		app.post('/validatepoints',capillaryController.validateRedeemPoints);
        app.post('/redeemcoupon',capillaryController.redeemCoupon);
        app.post('/customer/referfriend',capillaryController.referFriend);
    }
    if (listsController) {
        app.get('/list/tailor', listsController.getTailors);
        app.get('/list/priority', listsController.getPriorities);
        app.get('/list/paymentType', listsController.getPaymentTypes);
        app.get('/list/workflow', listsController.getWorkflows);
        app.get('/list/measurementField', listsController.getMeasurementFields);
        app.get('/list/measurementType', listsController.getMeasurementTypes);
        app.get('/list/style', listsController.getStyles);
        app.get('/list/itemType', listsController.getItemTypes);
        app.get('/list/fabric', listsController.searchFabrics);
        app.get('/list/sale/fabric',listsController.searchSaleFabrics);
        app.get('/list/customer', listsController.getCustomerList);
        app.get('/list/fabricDesignField', listsController.getFabricDesignFields);
        app.get('/list/customerSource', listsController.getCustomerSourceList);
        app.get('/list/occasion', listsController.getOccasions);
        app.get('/list/finishType', listsController.getFinishTypes);
        app.get('/list/salesman', listsController.getSalesmen);
        app.post('/list/workflowStage', listsController.getWorkFlowStageList);
        app.get('/list/workflow', listsController.getWorkFlowList);
        app.get('/list/searchRTW',listsController.getRTWList);
        app.get('/list/searchRTWStock',listsController.fetchRTWStock);
        app.get('/list/fetchSize',listsController.getSizeList);
        app.get('/list/fetchFit',listsController.getFitList);
        app.post('/list/inventoryTransfer',listsController.transferInventory);
        app.get('/list/rtwmeasurements',listsController.getRTWMeasurements);
        app.get('/list/store/inventory/count',listsController.getStoreInventory);
        app.post('/list/inventory/update',listsController.updateStoreInventory);
        app.get('/list/inventory/sheet',listsController.inventorySheet);
        app.get('/list/customerAddresses',listsController.getCustomerAddressList);
        app.post('/list/trackStockMovement',listsController.trackStockMovement);

        app.post('/list/inventory/stockdetails',listsController.fetchStockDetails);
        app.get('/pending/amounts',listsController.getPendingAmounts);
        app.get('/delivery/locations',listsController.getDeliveryLocations);
      
        
    } else {
        console.warn(unsupportedMessage('lists routes'));
    }

    if (ordersController) {
        //fetch details
        app.get('/orders', ordersController.getCustomerOrders);
        app.get('/ordershistory', ordersController.getOrdersHistory);
        app.get('/profiles', ordersController.getProfiles);
        app.get('/style/profiles',ordersController.getStyleProfiles);
        app.get('/profile/values', ordersController.getMeasurementProfileValues);
        app.get('/order/item/fabricDesign', ordersController.getOrderItemFabricDesign);
        app.get('/order/item/orderStyleProfile',ordersController.getOrderItemProfileStyling);
        app.get('/order/itemList', ordersController.getOrderItems);
        app.post('/order/item/delete', ordersController.deleteOrderItem);
        app.get('/order/images', ordersController.getImages);
        app.get('/order/taxes', ordersController.getTaxes);
        app.post('/workorders', ordersController.getWorkOrders);
        app.post('/workflow/stages', ordersController.getWorkOrderStageList);
        app.post('/workflow/stage', ordersController.saveWorkFlowStage);
        app.get('/details/order', ordersController.getOrderDetails);
        app.get('/details/customer', ordersController.getCustomerDetails);
        app.get('/details/order/item', ordersController.getOrderItemDetails);
        app.get('/details/order/workflowitem', ordersController.getWorkFlowOrderItemDetails);
        app.get('/details/list/order', ordersController.getOrderItemList);
        app.get('/details/image', ordersController.getImagesOfType);
        app.get('/details/profile/image',ordersController.getProfileImage);
        app.post('/order/updatemeasurementimages',ordersController.updateOrderProfileImage);
        app.post('/order/customer/addresstype',ordersController.updateCustomerAddressType);
        app.post('/insertcustomeraddress',ordersController.insertCustomerAddress);
        app.get('/order/invoice', ordersController.testPhantom);
        app.get('/order/sendpiemail', ordersController.sendPiEmail);
        app.get('/priority/upcharge', ordersController.getPriorityUpcharge);
        app.get('/workorder/measurements', ordersController.getWorkOrderMeasurementProfile);
        app.get('/orders/items/history', ordersController.getOrderHistory);
        app.post('/s3/image/getsignedurl', ordersController.getSignedUrl);
        app.post('/s3/image/signedurl',ordersController.getSignUrl);
        app.get('/details/onlinemeasurement', ordersController.getOrderItemOnlineMeasurements);
        app.get('/details/onlinefabric', ordersController.getOrderItemOnlineFabricDetails);
        app.get('/details/getstylebucket', ordersController.getOrderItemOnlineStyleBucketDetails);
        app.post('/order/measurementinventory', ordersController.updateMeasurementInventory);
        app.get('/details/list/item_type_style_dropdownlist', ordersController.getItemTypeDropDownList);
        app.get('/order/sendinvoicewithpi',ordersController.sendPIInvoiceEmail);
        app.post('/order/savegiftorder',ordersController.saveGiftOrder);
        app.post('/order/validatevocher',ordersController.validateGiftVocher);
        app.post('/gifts/searchlist',ordersController.getGiftVochersList);
        app.post('/gifts/transactions',ordersController.getGiftTransactions);
        app.get('/order/sendcustomeremail',ordersController.saveCustomerEmail);

       // app.post('/workorders/downloadpdf',ordersController.downloadBespokePdf);

        //save details
        app.post('/order/customer', ordersController.saveCustomer);
        app.post('/order/checkcustomer', ordersController.checkCustomer);
        app.post('/order/customer/update', ordersController.updateCustomer);
        app.post('/order/details', ordersController.saveDetails);
        app.post('/order/item', ordersController.saveOrderItem);
        app.post('/order/altered/item', ordersController.saveAlteredOrderItem);
        app.post('/order/item/update', ordersController.updateOrderItem);
        app.post('/order/item/measurement', ordersController.saveMeasurement);
        app.post('/order/item/bulkmeasurement', ordersController.saveBulkMeasurement);
        app.post('/order/item/bulkimageupload',ordersController.saveBulkImage)
        app.get('/order/item/rtwmeasurement',ordersController.getRTWMeasurementProfileValues);
        app.post('/order/item/fabricDesign', ordersController.saveFabricDesign);
        app.post('/order/item/style/fabricDesign',ordersController.saveStylingProfileOrder)
        app.post('/order/saveImage', ordersController.saveImage);
        app.post('/order/savePdf', ordersController.savePdf);
        app.post('/order/details/update', ordersController.updateDetails);
        app.post('/order/customer/profile', ordersController.saveProfile);
        app.post('/order/customer/style/profile', ordersController.saveStylingProfile);
        app.post('/order/customer/profile/update', ordersController.updateProfile);
        app.post('/order/updateupcharge',ordersController.updateUpcharge)
        // app.post('/orderitem/updateUpcharge',ordersController.updateUpcharge);
        app.get('/order/latestcomment', ordersController.getLatestItemTypeComment);
        app.get('/storeorderlist', ordersController.storetransactions);
        app.get('/orderdump',ordersController.getOrderDump);
        app.post('/stockupdate',ordersController.stockUpdate);
        app.get('/getinvoicedetails',ordersController.getInvoiceDetails);
        app.get('/getreceiptdetails',ordersController.getReceiptDetails);
        
        app.post('/updatecustomerdefaultaddress',ordersController.updateDefaultCustomerAddress);
        app.post('/loyalitytier/discount',ordersController.getLoyalityTierDiscount);
        app.get('/loyalitydiscounttransaction',ordersController.getLoyalityTierTransaction);
        app.post('/updatependingorderdetails',ordersController.updatePendingOrderDetails);
        app.post('/fetchOrderDetails',ordersController.fetchOrderDetails);
        // app.post('/order/details/update/pending/amount',ordersController.updatePendingAmount);
        app.post('/update/pending/amount',ordersController.updateStorePendingAmount);
        
        app.post('/update/order/item/measurement/profile',ordersController.updateMeasurementProfile);

        app.post('/update/product/updatethreedmeta',ordersController.updateThreedmetadata);

    } else {
        console.warn(unsupportedMessage('orders routes'));
    }
    if(dashboardController){
        app.post('/dashboard/queryresult', dashboardController.getqueryresults);
        app.get('/dashboard/queryfilter', dashboardController.getqueryfilters);
        app.post('/dashboard/querysave', dashboardController.getquerysave);
        app.get('/dashboard/getuserqueries',dashboardController.getuserqueries);
    }
    if(dbDumpController){
        app.get('/abandonedcart',dbDumpController.abandoneddata);
    }
}