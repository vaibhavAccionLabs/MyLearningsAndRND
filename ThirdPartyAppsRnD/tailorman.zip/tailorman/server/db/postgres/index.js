import { connect, controllers, passport } from '../sequelize';
import session from './session';

export { connect, controllers, passport, session };

export default {
  connect,
  controllers,
  passport,
  session
};
