//import Models from '../models';

//const User = Models.User;

export default (user, done) => {
	done(null, user)
		//   User.findById(id).then((user) => {
		//     done(null, user);
		//   }).catch(done);
};