import Models from '../models';
const db = Models.sequelize;
import _ from 'lodash';

const abondonedcartService = (options)=>{
    let query = 'select * from v_cart_abandoned';
    if(options){
        query = `${query} where`;
        options.map((option,index)=>{
            query = `${query} ${option.concatCondition} ${option.name} ${option.condition} ${option.value}`;
        });
    }
    return db.query(query).then((result) => {
        let formatedData = result[0] && result[0].map((order_details) => {
            if (order_details.order_items_list) {
                return order_details;
            }
        });
        return _.compact(formatedData);
    });
};
const mergeOrderWithOrderlines = (order_details) =>{
    let completeOrderDetails = [];
    order_details && order_details.map((_order_details)=>{
        _order_details.order_items_list && _order_details.order_items_list.map((order_line_item)=>{
            completeOrderDetails.push(Object.assign({},_order_details,order_line_item,{order_items_list : null}));
        });
    });
    return completeOrderDetails;
};
export function abandoneddata(req, res) {

    abondonedcartService().then((data)=>{
        let udata = mergeOrderWithOrderlines(data);
        if (req.query.download) {
            res.xls('data.xlsx', udata);
        } else {
            res.send(data);
        }
    }).catch(()=>{
        res.status(500).json({
            success: false,
            message: "Unable to Process Your Request"
        });
    });
}
export default {
    abandoneddata,
    abondonedcartService
};