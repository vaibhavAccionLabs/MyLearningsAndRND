import Models from '../models';
const db = Models.sequelize;
const request = require('request');
const capillaryBaseUrl = 'http://api.capillary.co.in/v1.1/';
import rp from 'request-promise';
import dbdump from "./dbdump";
import _ from 'lodash';
import orders from './orders';
setInterval(() => {
    if (process.env.TAILORMAN_ENV == 'PRODUCTION' || process.env.TAILORMAN_ENV == 'UAT') {
        syncCapillarydata();
        // triggerAbondanedCartEmails();
        triggerGiftVoucherEmails();
    }
}, 7200000);
const fabricImages = [{
    item_type_id: 12,
    folderPath: 'product/RTW/Shirts/',
    name: 'shirts',
    count: 6
}, {
    item_type_id: 13,
    folderPath: 'product/RTW/Bundy/',
    name: 'bundy',
    count: 4
}, {
    item_type_id: 15,
    folderPath: 'product/RTW/Jackets/',
    name: 'jacket',
    count: 5
}, {
    item_type_id: 27,
    folderPath: 'product/RTW/Shorts/',
    name: 'shorts',
    count: 5
}, {
    item_type_id: 14,
    folderPath: 'product/RTW/Trousers/',
    name: 'Trouser',
    count: 5
}, {
    item_type_id: 28,
    folderPath: 'product/RTW/Waistcoat/',
    name: 'waistcoat',
    count: 4
}];
const AWSHostInitialUrl = 'https://s3.ap-south-1.amazonaws.com/assets.web.tm/';
const getOrderItemFabricImage = (item) => {
    let rtw_image = true;
    if (item.mtm_flag === 'N') {
        var imageObject = _.find(fabricImages, { item_type_id: item.item_type_id });

        if (imageObject) {
            rtw_image = false;
            item.imageUrl = `${AWSHostInitialUrl}${imageObject.folderPath}${item.supplier_product_code}/${item.supplier_product_code}.jpg`;
        }
    }
    if (rtw_image) {
        item.imageUrl = AWSHostInitialUrl + 'product/' + item.sku_code + '.jpg';
    }
    return item;
};
const triggerGiftVoucherEmails = () => {
    db.query(`SELECT * FROM gift_vocher WHERE isactive='N' AND ispaymentprocessed = 'Y' AND delivery_date::date <= (now() AT TIME ZONE 'IST')::date`).then((data, i) => {
        
        if (data[0] && data[0].length > 0) {
            data[0].map((_data, index) => {
                db.query(`update gift_vocher SET isactive ='Y' where gift_vocher_id = :in_gift_vocher_id`, {
                    raw: true,
                    replacements: {
                        in_gift_vocher_id: _data.gift_vocher_id
                    }
                }).then(() => {
                    orders.proceedGiftVoucherEmail(_data);
                });
            })

        }
    });
}
const triggerAbondanedCartEmails = () => {
    let options = [{
        concatCondition: '',
        name: 'abon_mail_status',
        condition: '=',
        value: 'false'
    }, {
        concatCondition: 'AND',
        name: 'email',
        condition: 'is not',
        value: 'null'
    }, {
        concatCondition: 'AND',
        name: 'email',
        condition: '!=',
        value: "''"
    }, {
        concatCondition: 'AND',
        name: 'order_items_list',
        condition: 'is not',
        value: "null"
    }, {
        concatCondition: 'AND',
        name: 'created_time',
        condition: '<=',
        value: "NOW() - INTERVAL '24 HOUR'"
    }];
    dbdump.abondonedcartService(options).then((data) => {
        data = _.uniqBy(data, 'email');
        data && data.map((_data) => {
            _data.order_items_list = _data.order_items_list && _data.order_items_list.map((_order_line_item) => {

                if (_order_line_item.fabricmeasurement && _order_line_item.fabricmeasurement.size) {
                    _order_line_item.size = _order_line_item.fabricmeasurement.size;
                }
                if (_order_line_item.discount && _order_line_item.discount > 0) {
                    _order_line_item.is_discount = true;
                    let discount_amount = 0;
                    let discount_text = '';
                    switch (_order_line_item.discount_type) {
                        case 1:
                            discount_amount = parseFloat(_order_line_item.discount);
                            discount_text = `(₹ ${_order_line_item.discount} OFF)`;
                            break;
                        case 2:
                            discount_amount = Math.floor((_order_line_item.mrp * (_order_line_item.discount) / 100));
                            discount_text = `(${_order_line_item.discount}% OFF)`;
                            break;
                    }
                    _order_line_item.discounted_price = `₹ ${_order_line_item.mrp - discount_amount}`;
                    _order_line_item.discount_text = discount_text;
                }
                _order_line_item = getOrderItemFabricImage(_order_line_item);
                _order_line_item.original_price = `₹ ${_order_line_item.mrp}`;
                return _order_line_item;
            });
            orders.proceedAbondanedCartEmail(_data);
        });
    })
};
// import rp from 'request-promise';
const getCapillaryUrl = (type) => {
    switch (type) {
        case 'ORDERADD':
            return `${capillaryBaseUrl}transaction/add?format=json`;
        case 'CUSTOMERADD':
            return `${capillaryBaseUrl}customer/add?format=json`;
        case 'COUPONREDEEM':
            return `${capillaryBaseUrl}coupon/redeem?format=json`;
        case 'POINTSREDEEM':
            return `${capillaryBaseUrl}points/redeem?format=json`;
        case 'CUSTOMERUPDATE':
            return `${capillaryBaseUrl}customer/update?format=json`;
        default:
            break;
    }
}
const capillaryOrderCreation = (order_id, eventt_name, store_id) => {

    let record_store_id = store_id || null;
    let query = `select * from "SaveCapillaryActivities"('${eventt_name}',${order_id},false,now(),${record_store_id});`;

    return db.query(query).then((result) => {
        if (result[0][0].SaveCapillaryActivities) {
            return syncRequest(eventt_name, order_id);
        }
    });
}

const syncRequest = (event_name, order_id) => {
    switch (event_name) {
        case 'ORDER':
            return getOrderPayload(order_id).then(({ payload, user }) => {
                if (payload && user) {
                    makeCapillaryRequest(order_id, getCapillaryUrl('ORDERADD'), payload, user);
                    return true;
                }
            });
            break;
        case 'CUSTOMER':
            return getCustomerPayload(order_id).then(({ payload, user }) => {
                if (payload && user) {
                    makeCapillaryRequest(order_id, getCapillaryUrl('CUSTOMERADD'), payload, user);
                    return true;
                }
            });
        case "COUPON":
            return getCouponPayload(order_id).then(({ payload, user }) => {
                if (payload && user) {
                    makeCapillaryRequest(order_id, getCapillaryUrl('COUPONREDEEM'), payload, user);
                    return true;
                }
            });
        case 'CUSTOMERUPDATE':
            return getCustomerUpdatePayload(order_id).then(({ payload, user }) => {
                if (payload && user) {
                    makeCapillaryRequest(order_id, getCapillaryUrl('CUSTOMERUPDATE'), payload, user);
                    return true;
                }
            });
        case "REDEEM":
            return getRedeemPayload(order_id).then(({ payload, user }) => {
                makeCapillaryRequest(order_id, getCapillaryUrl('POINTSREDEEM'), payload, user);
                return true;
            });
        default:
            break;
    }
}
const syncCapillarydata = () => {
    if (process.env.TAILORMAN_ENV == 'PRODUCTION' || process.env.TAILORMAN_ENV == 'UAT') {
        let capillaryQuery = `select * from capillary_activities where status='false' and created_date >= NOW() - INTERVAL '24 HOUR'`;
        db.query(capillaryQuery).then((result) => {
            result[0].map((item, index) => {
                syncRequest(item.event_name, item.record_id);
            });
        });
    }
}
const getOrderPayload = (order_id) => {

    let query = `SELECT i.order_id as transaction_number ,i.display_name,i.sku_id,f.supplier_product_code,c.name,c.gender,c.mobile,c.email,c.address,o.comment,c.dob,c.customer_id,o.created_time as billing_time,o.total_amount as rate,o.payment_details,o.payment_type_id,i.qty, i.mrp,i.bill_amount,(i.qty*i.mrp)as value,i.discount, (select sum(boi.discount) from b_order_item boi where boi.order_id=o.order_id) as order_discount_value, (select sum(boi.bill_amount) from b_order_item boi where boi.order_id=o.order_id) as gross_amount,o.order_date,st.user_name,st.password,c.referral_code  FROM b_order_item i
	LEFT JOIN m_fabric f on i.sku_id = f.fabric_id
	JOIN b_order o ON o.order_id = i.order_id
	JOIN m_store st ON o.store_id = st.store_id
    LEFT JOIN m_customer c ON o.customer_id = c.customer_id  where i.order_id = ${order_id}`;

    return db.query(query).then((result) => {
        if (result && result[0] && result[0][0]) {

            let order_items = result[0].map((item, index) => {

                return {
                    "qty": item.qty,
                    "rate": item.mrp,
                    "description": item.display_name,
                    "discount_value": item.discount,
                    "amount": item.bill_amount,
                    "item_code": item.supplier_product_code,
                    "value": item.value
                }
            });
            let payload = {
                "root": {
                    "transaction": [{
                        "type": "regular",
                        "customer": {
                            "firstname": result[0][0].name,
                            "lastname": result[0][0].name,
                            "mobile": result[0][0].mobile || 999999990,
                            "email": result[0][0].email,
                            "external_id": result[0][0].customer_id,
                            "custom_fields": [
                                {
                                    "address_one": {
                                        "value": [result[0][0].address]
                                    }
                                },
                                {
                                    "birthday": {
                                        "value": [result[0][0].dob]
                                    }
                                },
                                {
                                    "customer_name": {
                                        "value": [result[0][0].name]
                                    }
                                },
                                {
                                    "gender": {
                                        "value": [result[0][0].dob]
                                    }
                                }
                            ]
                        },
                        "transaction_number": result[0][0].transaction_number,
                        "discount": result[0][0].order_discount_value,
                        "amount": result[0][0].rate,
                        "notes": result[0][0].comment,
                        "gross_amount": result[0][0].gross_amount,
                        "line_items": {
                            "line_item": order_items
                        },
                        "referral_code": result[0].referral_code

                    }]
                }
            }
            return {
                payload: payload,
                user: {
                    name: result[0][0].user_name,
                    password: result[0][0].password
                }
            }
        }
    });
}
const getCustomerUpdatePayload = (record_id) => {

    let query = `select ca.record_id as customer_id,ca.status,st.user_name,st.password,m.name,m.gender,m.mobile,m.email,m.address,m.dob,m.referral_code  from capillary_activities ca inner join m_customer m on ca.record_id = m.customer_id join m_store st on ca.store_id=st.store_id where ca.record_id= ${record_id}`;


    return db.query(query).then((result) => {
        if (result && result[0] && result[0][0]) {

            let payload = {
                "root": {
                    "customer": {
                        "id": result[0][0].customer_id,
                        "mobile": result[0][0].mobile,
                        "firstname": result[0][0].name,
                        "lastname": result[0][0].name,
                        "email": result[0][0].email,
                        "external_id": result[0][0].customer_id,
                        "custom_fields": [
                            {
                                "address_one": [
                                    result[0][0].address
                                ]
                            },
                            {
                                "birthday": [
                                    result[0][0].dob
                                ]
                            },
                            {
                                "customer_name": [
                                    result[0][0].name
                                ]
                            },
                            {
                                "gender": [
                                    result[0][0].gender
                                ]
                            }
                        ],
                        "referral_code": result[0][0].referral_code
                    }
                }


            }

            return {
                payload: payload,
                user: {
                    name: result[0][0].user_name,
                    password: result[0][0].password
                }
            }
        }
    });

}
const getCustomerPayload = (record_id) => {

    let query = `select ca.record_id as customer_id,ca.status,st.user_name,st.password,m.name,m.gender,m.mobile,m.email,m.address,m.dob,m.referral_code  from capillary_activities ca inner join m_customer m on ca.record_id = m.customer_id join m_store st on ca.store_id=st.store_id where ca.record_id= ${record_id}`;


    return db.query(query).then((result) => {
        if (result && result[0] && result[0][0]) {

            let payload = {
                "root": {
                    "customer": [{
                        "id": result[0][0].customer_id,
                        "mobile": result[0][0].mobile,
                        "firstname": result[0][0].name,
                        "lastname": result[0][0].name,
                        "email": result[0][0].email,
                        "external_id": result[0][0].customer_id,
                        "custom_fields": [
                            {
                                "address_one": [
                                    result[0][0].address
                                ]
                            },
                            {
                                "birthday": [
                                    result[0][0].dob
                                ]
                            },
                            {
                                "customer_name": [
                                    result[0][0].name
                                ]
                            },
                            {
                                "gender": [
                                    result[0][0].gender
                                ]
                            }
                        ],
                        "referral_code": result[0][0].referral_code
                    }]
                }


            }

            return {
                payload: payload,
                user: {
                    name: result[0][0].user_name,
                    password: result[0][0].password
                }
            }
        }
    });

}
const getCouponPayload = (record_id) => {


    let query = `select bo.redeemcoupon_json,st.user_name,st.password,c.mobile from b_order bo JOIN m_store st ON st.store_id = bo.store_id LEFT JOIN m_customer c ON bo.customer_id = c.customer_id where bo.order_id=${record_id}`;

    return db.query(query).then((result) => {
        var couponDetails = result[0][0].redeemcoupon_json;
        if (couponDetails && typeof couponDetails == "string") {
            couponDetails = JSON.parse(couponDetails);
        }
        let payload = {
            "root": {
                "coupon": {
                    "code": couponDetails.code,
                    "customer": {
                        "mobile": result[0][0].mobile,
                        "email": couponDetails.email || null,
                        "external_id": couponDetails.external_id || null
                    },
                    "transaction": {
                        "number": record_id
                    }
                }

            }
        }
        return {
            payload: payload,
            user: {
                name: result[0][0].user_name,
                password: result[0][0].password
            }
        }
    });

}
const getRedeemPayload = (record_id) => {


    let query = `select bo.redeemcoupon_json,st.user_name,st.password,c.mobile,c.customer_id,c.email from b_order bo JOIN m_store st ON st.store_id = bo.store_id  LEFT JOIN m_customer c ON bo.customer_id = c.customer_id where bo.order_id=${record_id}`;

    return db.query(query).then((result) => {
        var coupon_details = result[0][0].redeemcoupon_json;
        if (coupon_details && typeof coupon_details == "string") {
            coupon_details = JSON.parse(coupon_details);
        }
        let payload = {
            "root": {
                "redeem": {
                    "points_redeemed": coupon_details.points,
                    "transaction_number": record_id,
                    "customer": {
                        "mobile": result[0][0].mobile || null,
                        "email": result[0][0].email || null,
                        "external_id": result[0][0].customer_id || null
                    },
                    "validation_code": coupon_details.validation_code
                }
            }
        }
        return {
            payload: payload,
            user: {
                name: result[0][0].user_name,
                password: result[0][0].password
            }
        }
    });
}

const makeCapillaryRequest = (order_id, capillaryUrl, payload, authResult) => {
    request({
        url: capillaryUrl,
        method: "POST",
        json: true,
        headers: {
            'Content-Type': 'application/json;charset=utf-8',
            'Authorization': 'Basic ' + new Buffer(authResult.name + ':' + authResult.password).toString('base64')
        },
        body: payload
    }, function (err, response, body) {
        let jsonPayload = JSON.stringify(payload);
        if (body && body.response && body.response.status && body.response.status.code == 200) {
            jsonPayload = jsonPayload.replace(/'/g, "''");
            let query = `update capillary_activities set status=true,payload ='${jsonPayload}' where record_id = ${order_id}`;
            db.query(query).then((result) => {
                console.log("CAPILLARY SUCCESS");
            });
        } else {
            console.log('CAPILLARY FAILURE', order_id, capillaryUrl);
        }
    });
}
const getLoyalityPoints = (req, res) => {
    const loggedInCustomerId = req.body.customer_id;
    const store_id = req.body.store_id;
    const authQuery = `select user_name,password from m_store where store_id = ${store_id}`;
    if (!store_id || !loggedInCustomerId) {
        res.send({
            status: 'FALSE',
            error: false,
            data: 'Required Parameters are missing in the Request'
        });
        return;
    }
    db.query(authQuery).then((result) => {
        request({
            url: `http://api.capillary.co.in/v1.1/customer/get?format=json&external_id=${loggedInCustomerId}`,
            method: "GET",
            headers: {
                'Content-Type': 'application/json;charset=utf-8',
                'Authorization': 'Basic ' + new Buffer(result[0][0].user_name + ':' + result[0][0].password).toString('base64')
            },
        }, function (err, response, body) {

            let resBody = JSON.parse(body);
            if (resBody && resBody.response && resBody.response.status && resBody.response.status.code == 200) {
                res.send({
                    status: 'SUCCESS',
                    error: false,
                    data: {
                        loyality_points: resBody.response.customers.customer[0].loyalty_points,
                        current_tier: resBody.response.customers.customer[0].current_slab
                    }
                });
            } else {
                res.send({
                    status: 'FALSE',
                    error: false,
                    data: resBody.response
                });
            }
        });
    });
}

const isCouponRedeemable = (req, res) => {
    const mobile_num = req.body.mobile;
    const coupon_code = req.body.promocode;
    const store_id = req.body.store_id;

    let url = `http://api.capillary.co.in/v1.1/coupon/isredeemable?format=json&details=true&code=${coupon_code}&mobile=${mobile_num}`;

    makeRedeemRequest(url, 'GET', null, res, store_id);

}

const redeemCoupon = (req, res) => {
    const coupon_details = {
        coupon_code: req.body.promocode,
        mobile_num: req.body.mobile || null,
        email: req.email || null,
        external_id: req.external_id || null,
        store_id: req.body.store_id,
        order_id: req.body.order_id
    }

    let payload = {
        "root": {
            "coupon": {
                "code": coupon_details.coupon_code,
                "customer": {
                    "mobile": coupon_details.mobile_num,
                    "email": coupon_details.email,
                    "external_id": coupon_details.external_id
                },
                "transaction": {
                    "number": coupon_details.order_id
                }
            }

        }
    }
    console.log("@@@@@", payload);

    let couponUrl = 'http://api.capillary.co.in/v1.1/coupon/redeem?format=json';

    makeRedeemRequest(couponUrl, 'POST', payload, res, coupon_details.store_id);



}



const validateRedeemPoints = (req, res) => {

    // res.send({"status":"Error","error":true,"data":{"statusCode":200,"body":{"response":{"status":{"success":true,"code":200,"message":"Operation Successful"},"validation_code":{"code":{"mobile":"919948078346","email":"branjit.25@gmail.com","external_id":"[21821]","points":1,"item_status":{"success":true,"code":200,"message":"Validation Code Issued by SMS and Email"}}}}},"headers":{"date":"Mon, 11 Dec 2017 14:15:33 GMT","content-type":"application/json; charset=utf-8","transfer-encoding":"chunked","connection":"close","x-cap-requestid":"5A2E93050D79F","x-frame-options":"SAMEORIGIN, SAMEORIGIN, SAMEORIGIN","server":"CapWS","strict-transport-security":"max-age=63072000; includeSubdomains; preload"},"request":{"uri":{"protocol":"http:","slashes":true,"auth":null,"host":"api.capillary.co.in","port":80,"hostname":"api.capillary.co.in","hash":null,"search":"?format=json&mobile=9948078346&points=1","query":"format=json&mobile=9948078346&points=1","pathname":"/v1.1/points/validationcode","path":"/v1.1/points/validationcode?format=json&mobile=9948078346&points=1","href":"http://api.capillary.co.in/v1.1/points/validationcode?format=json&mobile=9948078346&points=1"},"method":"GET","headers":{"Content-Type":"application/json;charset=utf-8","Authorization":"Basic ZGVtby5wYXdhbjE6NjJjYzJkOGI0YmYyZDg3MjgxMjBkMDUyMTYzYTc3ZGY=","accept":"application/json","content-length":4}}}});
    // const redeem_points = req.body.redeem_points;
    // const mobile_num = req.body.mobile || 9948078346;
    // const store_id =req.body.store_id;
    // const url = `http://api.capillary.co.in/v1.1/points/validationcode?format=json&mobile=${mobile_num}&points=${redeem_points}`;
    // console.log("URLLL",url,req.body,);
    // makeRedeemRequest(url,'GET',null,res,store_id);

    const redeem_points = req.body.redeem_points;
    const mobile_num = req.body.mobile;
    const store_id = req.body.store_id;
    if (!mobile_num) {
        res.status(500).send({
            success: false,
            message: 'Mobile Number is Missing for the profile'
        });
    } else if (!redeem_points) {
        res.status(500).send({
            success: false,
            message: 'Redemption Points are Missing'
        });
    } else {
        const url = `http://api.capillary.co.in/v1.1/points/validationcode?format=json&mobile=${mobile_num}&points=${redeem_points}`;
        console.log("URLLL", url, req.body, );
        makeRedeemRequest(url, 'GET', null, res, store_id);
    }

}

const isPointsRedeemable = (req, res) => {
    console.log("REQUESTTT", req.body);

    // res.send({
    //     "status":"Error","error":true,"data":{"statusCode":200,"body":{"response":{"status":{"success":"true","code":200,"message":"Success"},"points":{"redeemable":{"mobile":"919948078346","email":"branjit.25@gmail.com","external_id":"[21821]","points":1,"is_redeemable":"true","points_redeem_value":1,"points_currency_ratio":"1","item_status":{"success":"true","code":800,"message":"Points can be redeemed"}}}}},"headers":{"date":"Mon, 11 Dec 2017 14:15:57 GMT","content-type":"application/json;charset=UTF-8","content-length":"508","connection":"close","x-application-context":"application:prod:1900","x-cap-request-id":"cd66ae10-10c9-4a65-91bd-537f8eb2840d","x-cap-requestid":"cd66ae10-10c9-4a65-91bd-537f8eb2840d","x-frame-options":"SAMEORIGIN, SAMEORIGIN, SAMEORIGIN","server":"CapWS","strict-transport-security":"max-age=63072000; includeSubdomains; preload"},"request":{"uri":{"protocol":"http:","slashes":true,"auth":null,"host":"api.capillary.co.in","port":80,"hostname":"api.capillary.co.in","hash":null,"search":"?format=json&points=1&validation_code=EGBNWY&mobile=9948078346","query":"format=json&points=1&validation_code=EGBNWY&mobile=9948078346","pathname":"/v1.1/points/isredeemable","path":"/v1.1/points/isredeemable?format=json&points=1&validation_code=EGBNWY&mobile=9948078346","href":"http://api.capillary.co.in/v1.1/points/isredeemable?format=json&points=1&validation_code=EGBNWY&mobile=9948078346"},"method":"GET","headers":{"Content-Type":"application/json;charset=utf-8","Authorization":"Basic ZGVtby5wYXdhbjE6NjJjYzJkOGI0YmYyZDg3MjgxMjBkMDUyMTYzYTc3ZGY=","accept":"application/json","content-length":4}}}}
    // );
    const coupon_details = {
        validation_code: req.body.validation_code,
        redeem_points: req.body.redeem_points,
        mobile_num: req.body.mobile,
        email: req.email || null,
        external_id: req.external_id || null
    }

    let couponUrl = `http://api.capillary.co.in/v1.1/points/isredeemable?format=json&points=${coupon_details.redeem_points}&validation_code=${coupon_details.validation_code}&mobile=${coupon_details.mobile_num}`;

    makeRedeemRequest(couponUrl, 'GET', null, res, req.body.store_id);


}

const redeemPoints = (req, res) => {
    const coupon_details = {
        validation_code: req.body.validation_code,
        redeem_points: req.body.redeem_points,
        mobile_num: req.body.mobile || null,
        email: req.email || null,
        external_id: req.external_id || null,
        store_id: req.body.store_id,
        order_id: req.body.order_id
    }
    let payload = {
        "root": {
            "redeem": {
                "points_redeemed": coupon_details.redeem_points,
                "transaction_number": coupon_details.order_id,
                "customer": {
                    "mobile": coupon_details.mobile_num || null,
                    "email": coupon_details.email || null,
                    "external_id": coupon_details.external_id || null
                },
                "validation_code": coupon_details.validation_code
            }
        }
    }

    let couponUrl = 'http://api.capillary.co.in/v1.1/points/redeem?format=json';

    makeRedeemRequest(couponUrl, 'POST', payload, res, coupon_details.store_id);



}

const makeRedeemRequest = (url, method, payload, res, store_id) => {
    const authQuery = `select user_name,password from m_store where store_id = ${store_id}`;
    if (!store_id) {
        res.send({
            status: 'Error',
            error: 'Unable to Process your request',
            data: 'Required Parameters in the payload are missing'
        });
        return;
    }
    db.query(authQuery).then((result) => {
        request({
            url: url,
            method: method,
            json: true,
            headers: {
                'Content-Type': 'application/json;charset=utf-8',
                'Authorization': 'Basic ' + new Buffer(result[0][0].user_name + ':' + result[0][0].password).toString('base64')
            },
            body: payload
        }, function (err, response, body) {
            if (err) {
                res.send({
                    status: 'Error',
                    error: err,
                    data: body
                });
            } else {
                if (response.status == 200) {
                    res.send({
                        status: 'SUCCESS',
                        error: false,
                        data: body
                    });
                } else {
                    res.send({
                        status: 'Error',
                        error: true,
                        data: body
                    });
                }
            }
        });

    });
}

const referFriend = (req, res) => {
    const details = req.body;
    const fieldType = details.fieldType;
    let referalPayload = details.fieldValue && details.fieldValue.length > 0 && details.fieldValue.map(function (value) {
        return {
            "type": `${fieldType}`,
            "referral": {
                "id": "",
                "name": "",
                "identifier": value,
                "invited_on": ""
            }
        }
    });
    let payload = {
        "root": {
            "customer": {
                "email": details.email,
                "referrals": {
                    "referral_type": referalPayload

                }
            }
        }
    }
    let couponUrl = ' http://api.capillary.co.in/v1.1/customer/referrals?format=json';

    makeRedeemRequest(couponUrl, 'POST', payload, res, details.store_id);
}
const getCustomerDetails = (customer_id, store_id) => {

    const authQuery = `select user_name,password from m_store where store_id = ${store_id}`;
    let capillaryQuery = 'http://api.capillary.co.in/v1.1/customer/get?format=json&external_id=';
    if (_.isArray(customer_id) && customer_id.length > 0) {
        customer_id.map((item, index) => {
            if (index == 0) {
                capillaryQuery += item;
            } else {
                capillaryQuery += ',' + item;
            }

        });
    } else {
        capillaryQuery += customer_id;
    }
    return db.query(authQuery).then((result) => {
        // console.log('Basic ' + new Buffer(result[0][0].user_name + ':' + result[0][0].password).toString('base64'));
        return rp({
            url: capillaryQuery,
            method: "GET",
            headers: {
                'Content-Type': 'application/json;charset=utf-8',
                'Authorization': 'Basic ' + new Buffer(result[0][0].user_name + ':' + result[0][0].password).toString('base64')
            },
        }).then((response) => {
            const responseBody = JSON.parse(response);
            const customerDetails = responseBody.response.customers.customer;
            // console.log('REHDHGHSZDG',customerDetails);
            return {
                ...customerDetails
            }
            // return customerDetails;
        });
    });
}

export default {
    capillaryOrderCreation,
    getLoyalityPoints,
    isCouponRedeemable,
    redeemCoupon,
    validateRedeemPoints,
    isPointsRedeemable,
    redeemPoints,
    makeRedeemRequest,
    referFriend,
    getCustomerDetails,
    triggerGiftVoucherEmails
}