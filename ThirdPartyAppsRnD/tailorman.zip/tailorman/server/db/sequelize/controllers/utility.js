import Models from '../models';
const db = Models.sequelize;
import moment from 'moment';
import numeral from 'numeral';
import _ from 'lodash';

const getProductRate = (sale, add_discount) => {
    /**
     * Getting the complete Tax Details
     */
    let completeTax = 0;
    if (sale.taxes && sale.taxes.length > 0) {
        sale.taxes.map((_tax_item) => {
            completeTax += _tax_item.percent;
        });
    }
    if (sale.shipping_taxes && sale.shipping_taxes.length > 0) {
        sale.shipping_taxes.map((_tax_item) => {
            completeTax += _tax_item.percent;
        });
    }
    let _mrp = parseFloat(sale.mrp);
    if (add_discount) {
        _mrp = discountedMRP(sale);
    }
    let productRateBeforeMrp = parseFloat(_mrp / (100 + completeTax) * 100);
    return parseFloat(productRateBeforeMrp.toFixed(2));
};
const discountedMRP = (sale) => {
    // if (sale.discount_value > 0) {
    //     if (sale.discount_type == UPCHARGE_UNIT_PERCENTAGE)
    //         value = (value - (parseFloat(value) * parseFloat(sale.discount_value) / 100)).toFixed(2);
    // }
    // return value;
    let mrp = sale.mrp;
    if (sale.discount_value > 0) {
        if(sale.discount_type == 2 ){
            mrp = (mrp - (parseFloat(mrp) * parseFloat(sale.discount_value) / 100)).toFixed(2);
        }else{
            mrp = (sale.mrp - sale.discount_value).toFixed(2);
        }
    }
    return mrp;
}
const toFixedData = (data) => {
    if (isNaN(data)) {
        return data;
    } else {
        return parseFloat(data).toFixed(2);
    }
}
const getTaxableValue = (sale) => {


    let total_rate = getProductRate(sale);
    //console.log('TOTAL RATEE',total_rate,sale);
    if (sale.upcharge && sale.upcharge.length > 0) {
        sale.upcharge.map(function (upcharge) {
            // console.log('UPCHARGESS', upcharge);
            total_rate += parseFloat(upcharge.rate);
            // console.log('RATEEEEEEEEEEE', total_rate);
        })
    }

    let taxable_value = (((total_rate) * (sale.qty)) - (sale.formatted_discount_value));
    taxable_value = parseFloat(taxable_value.toFixed(2));
    return taxable_value;
}

const inWords = (num) => {
    num = num && num.toFixed && num.toFixed();
    var a = ['', 'One ', 'Two ', 'Three ', 'Four ', 'Five ', 'Six ', 'Seven ', 'Eight ', 'Nine ', 'Ten ', 'Eleven ', 'Twelve ', 'Thirteen ', 'Fourteen ', 'Fifteen ', 'Sixteen ', 'Seventeen ', 'Eighteen ', 'Nineteen '];
    var b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

    if ((num = num.toString()).length > 9) return 'overflow';
    const n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return; var str = '';
    str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
    str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
    str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
    str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
    str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + ' Rupees only ' : '';
    return 'INR ' + str;
}
const getDiscount = (sale, value) => {
    if (sale.discount_value > 0) {
        if (sale.discount_type == UPCHARGE_UNIT_PERCENTAGE)
            value = (value - (parseFloat(value) * parseFloat(sale.discount_value) / 100)).toFixed(2);
    }
    return value;
}
const getOrderItemUpcharge = (order_item, order_details) => {
    if (order_item.upcharge && order_item.upcharge.length > 0) {
        order_item.upcharge.map((upcharge_item) => {
            if (upcharge_item.type != 'High Priority Delivery') {
                let _upcharge = upcharge_item.value;
                if (_upcharge && _upcharge.toFixed) {
                    _upcharge = _upcharge.toFixed(2);
                    if (upcharge_item.unit === 2) {
                        _upcharge = ((parseFloat(order_item.mrp) * parseFloat(_upcharge)) / 100).toFixed(2);
                    }
                    upcharge_item.upchargeRate = _upcharge;
                }
            } else {
                let _upcharge = upcharge_item.value
                if (_upcharge && _upcharge.toFixed) {
                    _upcharge = _upcharge.toFixed(2);
                    if (upcharge_item.unit === 2) {
                        _upcharge = ((parseFloat(order_item.mrp) * parseFloat(_upcharge)) / 100).toFixed(2);
                    }
                    upcharge_item.upchargeRate = _upcharge;
                }
            }
        });
    } else {
        order_item.upcharge = [];
    }
    return order_item;
}
export function getCalculatedData({ orderItems, orderDetails, paymentDetails = {} }) {

    let total_taxable_value = 0;
    let total_cgst_value = 0;
    let total_sgst_value = 0;
    let total_bill_amount = 0;
    let total_igst_value = 0;
    let tax_total_value = 0;

    orderItems.map(function (order_item, index) {
        if(_.isString(order_item.upcharge)){
            order_item.upcharge = JSON.parse(order_item.upcharge);
        }
        let completeTax = 0;
        if (order_item.taxes && order_item.taxes.length > 0) {
            order_item.taxes.map((_tax_item) => {
                completeTax += _tax_item.percent;
            });
            order_item.cgst_tax = ((order_item.taxes[0].value) * order_item.qty).toFixed(2);
            order_item.sgst_tax = ((order_item.taxes[1].value) * order_item.qty).toFixed(2);
            if (order_item.taxes[2]) {
                order_item.igst_tax = ((order_item.taxes[2].value) * order_item.qty).toFixed(2);
            }
        }

        if (order_item.shipping_taxes && order_item.shipping_taxes.length > 0) {
            order_item.shipping_taxes.map((_tax_item) => {
                completeTax += _tax_item.percent;
            });

            order_item.cgst_tax = ((order_item.shipping_taxes[0].value)).toFixed(2);
            order_item.sgst_tax = ((order_item.shipping_taxes[1].value)).toFixed(2);
            order_item.mrp = Number(toFixedData(parseFloat(order_item.shipping_charges)));
            order_item.bill_amount = Number(toFixedData(parseFloat(order_item.shipping_charges)));
            order_item.taxable_value = getProductRate(order_item);

            // if (order_item.taxes[2]) {
            //     order_item.igst_tax = ((order_item.taxes[2].value) * order_item.qty).toFixed(2);
            // }
        }

        if (order_item.upcharge && order_item.upcharge.length > 0) {
            order_item.upcharge.map((upcharge_item) => {

                upcharge_item.display_upcharge_name = upcharge_item.type;

                if (upcharge_item.unit == 1) {
                    upcharge_item.upchargeRate = upcharge_item.value;
                    upcharge_item.rate = (upcharge_item.value / (100 + completeTax) * 100).toFixed(2);
                } else if (upcharge_item.unit == 2) {
                    let _upcharge = upcharge_item.value.toFixed(2);
                    if (upcharge_item.type = 'Higher Size Upcharge') {
                        upcharge_item.display_upcharge_name = upcharge_item.display_upcharge_name + "-(" + upcharge_item.value + "%)";
                    }

                    _upcharge = ((parseFloat(order_item.mrp) * parseFloat(_upcharge)) / 100).toFixed(2);
                    upcharge_item.value = _upcharge;
                    upcharge_item.upchargeRate = _upcharge;
                    upcharge_item.rate = (_upcharge / (100 + completeTax) * 100).toFixed(2);
                }
            });

        }

        order_item.display_name = order_item.display_name;
        order_item.complete_tax_percent = completeTax;
        order_item.sno = (index + 1);
        order_item.rate = getProductRate(order_item);
        order_item.amount = numeral(parseFloat(getProductRate(order_item, true)) * order_item.qty).format('0,0.00');
        order_item.fit_on_date = (order_item.fit_on_date) ? moment(order_item.fit_on_date).format('YYYY-MM-DD') : '';
        order_item.delivery_date = (order_item.delivery_date) ? moment(order_item.delivery_date).format('YYYY-MM-DD') : '';
        order_item.customer_fit_on_date = (order_item.customer_fit_on_date) ? moment(order_item.customer_fit_on_date).format('YYYY-MM-DD') : '';
        order_item.customer_delivery_date = (order_item.customer_delivery_date) ? moment(order_item.customer_delivery_date).format('YYYY-MM-DD') : '';

        order_item.formatted_discount_value = '';
        if (order_item.discount_amount)
            order_item.formatted_discount_value = parseFloat((order_item.discount_amount / (1 + (order_item.complete_tax_percent / 100))).toFixed(2));
        // order_item = getOrderItemUpcharge(order_item, orderDetails);

        // order_item.rate = getProductRate(order_item);
        if (!order_item.taxable_value)
            order_item.taxable_value = getTaxableValue(order_item);
        total_taxable_value += order_item.taxable_value;
        total_cgst_value += (isNaN(parseFloat(order_item.cgst_tax)) ? 0 : parseFloat(order_item.cgst_tax));
        total_sgst_value += (isNaN(parseFloat(order_item.sgst_tax)) ? 0 : parseFloat(order_item.sgst_tax));
        total_igst_value += parseFloat(order_item.igst_tax);
        total_bill_amount += order_item.bill_amount;
        tax_total_value += (order_item.taxes && order_item.taxes.length > 0) ? (isNaN(parseFloat(order_item.taxable_value)) ? 0 : parseFloat(order_item.taxable_value)) : 0;
    });

    // orderDetails.total_bill_amount = total_bill_amount;
    orderDetails.amount_in_words = inWords(orderDetails.total_amount);

    orderDetails.order_date = (orderDetails.order_date) ? moment(orderDetails.order_date).format('YYYY-MM-DD') : '';

    orderDetails.total_taxable_value = total_taxable_value ? toFixedData(total_taxable_value) : null;

    orderDetails.total_cgst_value = total_cgst_value ? toFixedData(total_cgst_value) : null;
    orderDetails.total_sgst_value = total_sgst_value ? toFixedData(total_sgst_value) : null;

    orderDetails.total_igst_value = parseFloat(total_igst_value.toFixed(2));

    orderDetails.shipping_charges = orderDetails.shipping_charges ? parseInt(orderDetails.shipping_charges) : null;
    orderDetails.total_bill_amount = total_bill_amount ? parseFloat(total_bill_amount) : null;

    orderDetails.tax_total_value = tax_total_value ? toFixedData(tax_total_value) : null;

    var total_amount_payed = 0;

    for (var i = 0; i < paymentDetails.length; i++) {
        total_amount_payed += paymentDetails[i].amount;
    }
    orderDetails.total_amount_payed = total_amount_payed;
    orderDetails.receipt_amount_in_words = inWords(orderDetails.total_amount_payed);

    orderDetails.pending_amount = parseInt(orderDetails.total_bill_amount) - parseInt(orderDetails.total_amount_payed);


    return {
        orderDetails,
        orderItems,
        paymentDetails
    }
}

export function getCalculatedInvoiceData(in_order_id, type) {
    var invoiceData = {
        orderItems: [],
        orderDetails: {}
    };
    return db.query('select * from "GetOrderDetails"(:in_order_id) ', {
        raw: true,
        replacements: {
            in_order_id: in_order_id
        }
    }).then((result) => {
        invoiceData.orderDetails = result[0][0];
        return db.query('select * from "GetInvoiceNumber"(:in_order_id,:in_store_id)', {
            raw: true,
            replacements: {
                in_order_id: in_order_id,
                in_store_id: invoiceData.orderDetails.store_id
            }
        }).then((result2) => {
            invoiceData.orderDetails.invoice_number = result2[0][0].GetInvoiceNumber;
            return db.query('select * from "GetOrderItemListV2"(:in_order_id)', {
                raw: true,
                replacements: {
                    in_order_id: in_order_id
                }

            }).then((response) => {
                invoiceData.orderItems = response[0];
                if (result[0][0].shipping_charges && result[0][0].shipping_taxes && result[0][0].shipping_taxes.length > 0) {
                    //result[0][0].taxes = result[0][0].shipping_taxes;
                    result[0][0].hsn_code = response[0][0].hsn_code || '';
                    result[0][0].display_name = 'Delivery Charges/any other incidental charges';
                    result[0][0].qty = '';
                    result[0][0].upcharge = [];
                    invoiceData.orderItems.push(result[0][0]);
                }
                if (type == 'INVOICE') {
                    return getCalculatedData(invoiceData);
                } else if (type == 'RECEIPT') {
                    return db.query('select * from "GetReceiptNumber"(:in_order_id,:in_store_id)', {
                        raw: true,
                        replacements: {
                            in_order_id: in_order_id,
                            in_store_id: invoiceData.orderDetails.store_id
                        }
                    }).then((result3) => {
                        invoiceData.orderDetails.receipt_number = result3[0][0].GetReceiptNumber;
                        return db.query(`select cp.c_order_payment_id,cp.store_id,cp.order_id,cp.customer_id,cp.created,cp.amount,cp.reference,mp.code as payment_mode from c_order_payment cp LEFT JOIN m_payment_type mp ON cp.payment_mode = mp.payment_type_id where order_id =  ${in_order_id};`).then((records) => {
                            invoiceData.paymentDetails = records[0];
                            return getCalculatedData(invoiceData);
                        });
                    });
                }

            });
        });

    });

}
export function removeDuplicateHsnCodes(order_items) {
    let newArray = [];
    order_items.map((order_item) => {
        let componentFound = _.find(newArray, function (o) { return (o.hsn_code == order_item.hsn_code && o.complete_tax_percent == order_item.complete_tax_percent) });
        if (componentFound) {
            componentFound.taxable_value_ui += (isNaN(parseFloat(order_item.taxable_value)) ? 0 : parseFloat(order_item.taxable_value));
            componentFound.cgst_tax_ui += (isNaN(parseFloat(order_item.cgst_tax)) ? 0 : parseFloat(order_item.cgst_tax));
            componentFound.sgst_tax_ui += (isNaN(parseFloat(order_item.sgst_tax)) ? 0 : parseFloat(order_item.sgst_tax));
            componentFound.igst_tax_ui += (isNaN(parseFloat(order_item.igst_tax)) ? 0 : parseFloat(order_item.igst_tax));
        } else {
            newArray.push({
                ...order_item,
                taxable_value_ui: (isNaN(parseFloat(order_item.taxable_value)) ? 0 : parseFloat(order_item.taxable_value)),
                cgst_tax_ui: (isNaN(parseFloat(order_item.cgst_tax)) ? 0 : parseFloat(order_item.cgst_tax)),
                sgst_tax_ui: (isNaN(parseFloat(order_item.sgst_tax)) ? 0 : parseFloat(order_item.sgst_tax)),
                igst_tax_ui: (isNaN(parseFloat(order_item.igst_tax)) ? 0 : parseFloat(order_item.igst_tax))
            });
        }
    });
    return newArray;
}
export function getFormatedInvoice(response) {

    let order = response.orderDetails;
    let order_items = response.orderItems;
    var invoice_json = {
        title: "TAX INVOICE",
        company: {
            name: "Camden Apparel Solutions Pvt. Ltd",
            address: "Camden Apparel Solutions Pvt. Ltd., SURVEY NO.48/2 KUDLU VILLAGE, ANEKAL TALUK SARJAPURA HOBLI, BANGALORE DISTRICT, BBMP, BANGALORE-560068",
            contact: "Phone : 1800 3000 1575 / E-mail : care@tailorman.com",
            cin: "U18204KA2012PTC066352",
            range: "SINGASANDRA / A WING , KENDRIYASADAN",
            division: "KORAMANGALA / A WING , KENDRIYASADAN",
            excise: "AAFCC0250LEM001",
            commissionerate: "BANGALORE-I/PO Box - 540 QUEEN’S ROAD, BANGALORE",
            pan: "AAFCC0250L",
            gst: "29AAFCC0250L1ZO"
        },
        declaration: "We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct."
    };

    var headers = [

        {
            text: 'SI No.',
            "style": "productTableHeader"
        }, {
            text: 'Description of Goods',
            "style": "productTableHeader"
        }, {
            text: 'HSN No',
            "style": "productTableHeader"
        }, {
            text: 'GST',
            "style": "productTableHeader"
        }, {
            text: 'MRP',
            "style": "productTableHeader"
        }, {
            text: 'Rate (INR)',
            "style": "productTableHeader"
        }, {
            text: 'Qty',
            "style": "productTableHeader"
        }, {
            text: 'Disc',
            "style": "productTableHeader"
        }, {
            text: 'Taxable Value',
            "style": "productTableHeader"
        }, {
            text: 'CGST',
            "style": "productTableHeader"
        }, {
            text: 'SGST',
            "style": "productTableHeader"
        }, {
            text: 'IGST',
            "style": "productTableHeader"
        }, {
            text: 'Amount',
            "style": "productTableHeader"
        }
    ];

    var body = [];
    body.push(headers);

    for (var i = 0; i < order_items.length; i++) {
        //if (order_items.hasOwnProperty(key)) {
        var data = order_items[i];
        let item_qty = data.qty ? (data.qty + " pcs") : '';

        var row = [];
        row.push(i + 1);
        row.push(data.display_name);
        row.push(data.hsn_code || '');
        row.push(data.complete_tax_percent + "%" || '');
        row.push(data.mrp || '');
        row.push(toFixedData(data.rate) || '');
        row.push(item_qty);
        row.push(data.formatted_discount_value || '');
        row.push(toFixedData(data.taxable_value) || '');
        row.push(toFixedData(data.cgst_tax) || '');
        row.push(toFixedData(data.sgst_tax) || '');
        row.push(data.igst_tax || '');
        row.push(data.bill_amount || '');
        body.push(row);

        if (data.upcharge && data.upcharge.length > 0) {
            for (var key in data.upcharge) {
                if (data.upcharge.hasOwnProperty(key)) {
                    var data1 = data.upcharge[key];
                    var row = [];
                    row.push('');
                    row.push(data1.display_upcharge_name.toString());
                    row.push('');
                    row.push('');
                    row.push(data1.value.toString());
                    row.push(data1.rate.toString());
                    row.push('');
                    row.push('');
                    row.push('');
                    row.push('');
                    row.push('');
                    row.push('');
                    row.push('');
                    body.push(row);
                }
            }
        }
    }


    var row = [];
    row.push('');
    row.push('Total');
    row.push('');
    row.push('');
    row.push('');
    row.push('');
    row.push('');
    row.push('');
    row.push(order.total_taxable_value || "");
    row.push(order.total_cgst_value || "");
    row.push(order.total_sgst_value || "");
    row.push(order.total_igst_value || "");
    row.push(order.total_bill_amount || "");
    body.push(row);

    var headers1 = {
        fila_0: {
            col_1: {
                text: 'HSN/SAC',
                rowSpan: 2
            },
            col_2: {
                text: 'Taxable'
            },
            col_3: {
                text: 'CGST',
                colSpan: 2
            },
            col_4: {
                text: ''
            },
            col_5: {
                text: 'SGST',
                colSpan: 2
            },
            col_6: {
                text: ''
            },
            col_7: {
                text: 'IGST',
                colSpan: 2
            },
            col_8: {
                text: ''
            },
            col_9: {
                text: 'Total',
                rowSpan: 2
            }
        },
        fila_1: {
            col_1: {
                text: ''
            },
            col_2: {
                text: 'Value'
            },
            col_3: {
                text: 'Rate'
            },
            col_4: {
                text: 'Amount'
            },
            col_5: {
                text: 'Rate'
            },
            col_6: {
                text: 'Amount'
            },
            col_7: {
                text: 'Rate'
            },
            col_8: {
                text: 'Amount'
            },
            col_9: {
                text: 'Amount'
            }
        }
    }
    var body1 = [];
    for (var key in headers1) {
        if (headers1.hasOwnProperty(key)) {
            var header = headers1[key];
            var row1 = [];
            //   console.log(header);
            row1.push(header.col_1);
            row1.push(header.col_2);
            row1.push(header.col_3);
            row1.push(header.col_4);
            row1.push(header.col_5);
            row1.push(header.col_6);
            row1.push(header.col_7);
            row1.push(header.col_8);
            row1.push(header.col_9);
            body1.push(row1);
        }
    }
    //	console.log(body1);
    let total_tax_amount = 0;
    let unduplicateOrderItems = removeDuplicateHsnCodes(order_items);

    let total_shipping_taxes = (order.shipping_taxes && order.shipping_taxes.length > 0) ? toFixedData(parseFloat(order.shipping_taxes[0].value) + parseFloat(order.shipping_taxes[1].value)) : 0;



    unduplicateOrderItems.map(function (data, index) {

        if (data.taxes && data.taxes.length > 0) {
            //data.taxes.map(function(tax){
            let complete_tax_value = Number(toFixedData(parseFloat(data.cgst_tax_ui) + parseFloat(data.sgst_tax_ui)));

            var row = [];
            row.push(data.hsn_code);
            row.push(toFixedData(data.taxable_value_ui));
            if (data.igst_tax_ui) {
                row.push('0');
                row.push(toFixedData(data.cgst_tax_ui));
                row.push('0');
                row.push(toFixedData(data.sgst_tax_ui));
                row.push(toFixedData(data.complete_tax_percent));
                row.push(toFixedData(data.igst_tax_ui));
                row.push(toFixedData(data.igst_tax_ui));
            } else {
                row.push(data.complete_tax_percent / 2);
                row.push(toFixedData(data.cgst_tax_ui));
                row.push(data.complete_tax_percent / 2);
                row.push(toFixedData(data.sgst_tax_ui));
                row.push('');
                row.push('');
                row.push(complete_tax_value);
            }
            //row.push( data1.value.toString()  );
            body1.push(row);
            //})
        } else {
            if (index == 0 && order.shipping_taxes && order.shipping_taxes.length > 0) {
                var row1 = [];
                row1.push(order_items[0].hsn_code);
                row1.push(toFixedData(order.shipping_taxes[0].mrp_before_tax));
                row1.push(order.shipping_taxes[0].percent);
                row1.push(toFixedData(order.shipping_taxes[0].value));
                row1.push(order.shipping_taxes[1].percent);
                row1.push(toFixedData(order.shipping_taxes[1].value));
                row1.push('');
                row1.push('');
                row1.push(toFixedData(order.shipping_taxes[0].value + order.shipping_taxes[1].value));
                //row1.push( data1.value.toString()  );
                body1.push(row1);
            }
        }
        if (data.igst_tax_ui) {
            total_tax_amount += parseFloat(data.igst_tax_ui);
        } else {
            total_tax_amount += (parseFloat(data.cgst_tax_ui) + parseFloat(data.sgst_tax_ui));
        }


    });



    var row = [];
    row.push('Total');
    row.push(toFixedData(order.tax_total_value));
    row.push('');
    row.push(toFixedData(order.total_cgst_value));
    row.push('');
    row.push(toFixedData(order.total_sgst_value));
    row.push('');
    row.push(toFixedData(order.total_igst_value) || "");
    row.push(toFixedData(total_tax_amount));
    //row.push( data1.value.toString()  );
    body1.push(row);

    // for (var j=0;j<order_items.length;j++) {
    // 	//if (order_items.hasOwnProperty(key)) {

    // 		if (order_items[j].taxes && order_items[j].taxes.length > 0) {
    // 			for (var k=0;k<order_items[j].taxes.length;k++) {
    // 				//if (data.taxes.hasOwnProperty(key)) {
    // 					var data1 = order_items[j].taxes[k];
    // 					var row = [];
    // 					row.push(data1.name.toString());
    // 					row.push(data1.name.toString());
    // 					row.push('');
    // 					row.push('');
    // 					row.push(data1.name.toString());
    // 					row.push(data1.value.toString());
    // 					row.push(data1.value.toString());
    // 					row.push(data1.value.toString());
    // 					row.push(data1.value.toString());
    // 					//row.push( data1.value.toString()  );
    // 					body1.push(row);
    // 			//	}
    // 			}
    // 		}
    // 	//}
    // }

    var res_json = {
        pageSize: 'A4',
        pageOrientation: 'landscape',
        footer: {
            columns: [{
                text: 'You have allowed Tailorman to send you regular updates about Tailorman via sms and email',
                style: 'documentFooterLeft'
            }, {
                text: 'This is a computer generated invoice',
                style: 'documentFooterCenter'
            }, {
                text: 'E & O.E',
                style: 'documentFooterRight'
            }]
        },

        content: [{
            table: {
                // headers are automatically repeated if the table spans over multiple pages
                // you can declare how many rows should be treated as headers
                headerRows: 0,
                widths: ['*'],

                body: [
                    // Total
                    [{
                        text: invoice_json.title,
                        style: 'center'
                    }],
                    [{
                        text: invoice_json.company.name,
                        style: 'center'
                    }],
                    [{
                        text: order.store_address + '-' + order.state_code,
                        //style: 'redText'

                    }]
                ]
            }, // table
            // layout: 'lightHorizontalLines'
        },

        {
            table: {
                // headers are automatically repeated if the table spans over multiple pages
                // you can declare how many rows should be treated as headers
                headerRows: 1,
                widths: ['*', '*', '*'],

                body: [
                    // Table Header
                    [{
                        text: 'GST No.',
                        style: 'itemsHeader'
                    }, {
                        text: 'Invoice No.',
                        style: 'itemsHeader'
                    }, {
                        text: "Buyer's Order No.",
                        style: 'itemsHeader'
                    }],
                    // Items
                    // Item 1
                    [{
                        text: order.gst_code || "",
                        //style: 'itemNumber'
                    }, {
                        text: order.invoice_number || "",
                        //style: 'itemNumber'
                    }, {
                        text: order.order_id || "",
                        //style: 'itemNumber'
                    }],
                    // Item 2
                    [{
                        text: 'PAN No.',
                        style: 'itemsHeader'
                    }, {
                        text: 'Date & Time Of Issue Of Invoice',
                        style: 'itemsHeader'
                    }, {
                        text: "Payment Mode",
                        style: 'itemsHeader'
                    }],
                    // Items
                    // Item 1
                    [{
                        text: invoice_json.company.pan,
                        //style: 'itemNumber'
                    }, {
                        text: (moment().utcOffset() === 0) ? moment().utcOffset("+05:30").format('lll') : moment().format('lll'),
                        //	style: 'itemNumber'
                    }, {
                        text: order.payment_type,
                        //style: 'itemNumber'
                    }],
                    [{
                        text: 'Place of Supply : ' + order.city + ' - ' + order.state_code,
                        //style: 'redText'
                    }, {
                        text: 'Country of Supply : India',
                        //style: 'redText'
                    }, {
                        text: 'Whether GST is payable on Reverse Charge Basis  - N',
                        //style: 'redText'
                    }]
                    // END Items
                ]
            }, // table
            //  layout: 'lightHorizontalLines'
        }, {
            table: {
                // headers are automatically repeated if the table spans over multiple pages
                // you can declare how many rows should be treated as headers
                headerRows: 1,
                widths: ['*', '*'],

                body: [
                    [{
                        text: 'Buyer Name & Billing Address',
                        style: 'itemsHeader'
                    }, {
                        text: 'Buyer Name & Shipping Address',
                        style: 'itemsHeader'
                    }],
                    [{
                        text: ` ${order.customer_name} \n ${order.benficiary_mobile}  \n Billing Address : ${order.billing_address} - ${order.state_code}`,
                        style: ''
                    }, {
                        text: ` ${order.customer_name} \n ${order.benficiary_mobile} \n Shipping Address : ${order.delivery_address}`,
                        style: ''
                    }]
                ]
            },
        }, {
            table: {
                // headers are automatically repeated if the table spans over multiple pages
                // you can declare how many rows should be treated as headers
                headerRows: 1,
                widths: [20, '*', '*', 24, 45, 45, 23, 30, 45, 45, 45, 40, '*'],
                body: body


            },
        }, {
            table: {
                // headers are automatically repeated if the table spans over multiple pages
                // you can declare how many rows should be treated as headers
                headerRows: 1,
                widths: [162.5, '*'],

                body: [
                    [{
                        text: 'Amount In Words',
                        style: 'itemsHeader'
                    }, {
                        text: order.amount_in_words,
                        "margin": [0, 5, 0, 5]
                    }]
                ]
            },
        }, {
            table: {
                // headers are automatically repeated if the table spans over multiple pages
                // you can declare how many rows should be treated as headers
                headerRows: 2,
                widths: ['*', 45, 45, 45, 45, 45, 45, 45, 45],

                //  body: [
                //     [ 
                //       {
                //           text: 'HSN/SAC',
                //           style: 'itemsHeader'
                //       }, 
                //       {
                //           text: 'Taxable',
                //           style: ['itemsHeader','redText']
                //       },{
                //           text: 'CGST',
                //           style: ['itemsHeader','redText']
                //       }, 
                //       {
                //           text: 'SGST:',
                //           style: ['itemsHeader','redText']
                //       },{
                //           text: 'IGST',
                //           style: ['itemsHeader','redText']
                //       }, 
                //       {
                //           text: 'Total:',
                //           style: ['itemsHeader','redText']
                //       }
                //   ]
                // ]
                body: body1
            },
        }, {
            "table": {
                "headerRows": 0,
                "widths": [
                    "*"
                ],
                "body": [
                    [
                        {
                            "text": "For  Camden Apparel Solutions Pvt. Ltd",
                            "style": "itemsFooterSubTitle",
                            "margin": [20, 20, 0, 50]
                        }
                    ],
                    [
                        {
                            "text": "Authorised Signatory",
                            "style": "itemsFooterSubTitle"
                        }
                    ]
                ]
            },
            "layout": "noBorders"
        },
        {
            table: {
                // headers are automatically repeated if the table spans over multiple pages
                // you can declare how many rows should be treated as headers
                headerRows: 0,
                widths: ['*'],

                body: [
                    // Total
                    [{
                        text: 'Corporate Address: Camden Apparel Solutions Pvt. Ltd., Survey No.48/2 Kudlu Village, Anekal Taluk Sarjapura Hobli, Bangalore District, Bbmp, Bangalore-560068',
                        style: 'itemsFooterSubTitle'
                    }],
                    [{
                        text: 'CIN: U18204KA2012PTC066352 / Phone : 1800 3000 1575 / E-Mail : Care@Tailorman.com',
                        style: 'itemsFooterSubTitle'
                    }],
                    [{
                        text: 'Declaration : We declare that this invoice  shows the actual price  of the goods described and that all particulars are true and correct.',
                        style: 'itemsFooterTotalTitle'
                    }],
                ]
            }, // table
            layout: 'lightHorizontalLines'
        }
        ],
        styles: {
            "productTableHeader": {
                "bold": true,
                "fillColor": '#cccccc'
            },
            // Document Footer
            documentFooterLeft: {
                fontSize: 10,
                margin: [5, 5, 5, 5],
                alignment: 'left'
            },
            documentFooterCenter: {
                fontSize: 10,
                margin: [5, 5, 5, 5],
                alignment: 'center'
            },
            documentFooterRight: {
                fontSize: 10,
                margin: [5, 5, 5, 5],
                alignment: 'right'
            },

            itemsHeader: {
                margin: [0, 5, 0, 5],
                bold: true,
                "fillColor": '#cccccc'
            },
            // Item Title
            itemTitle: {
                bold: true,
            },
            itemSubTitle: {
                italics: true,
                fontSize: 11
            },
            // itemNumber: {
            //     margin: [0,5,0,5],
            //     alignment: 'left',
            // },
            itemTotal: {
                margin: [0, 5, 0, 5],
                bold: true,
                alignment: 'center',
            },

            // Items Footer (Subtotal, Total, Tax, etc)
            itemsFooterSubTitle: {
                margin: [0, 5, 0, 5],
                bold: true,
                alignment: 'right',
            },
            itemsFooterSubValue: {
                margin: [0, 5, 0, 5],
                bold: true,
                alignment: 'center',
            },
            itemsFooterTotalTitle: {
                margin: [0, 5, 0, 5],
                bold: true,
                alignment: 'right',
            },
            itemsFooterTotalValue: {
                margin: [0, 5, 0, 5],
                bold: true,
                alignment: 'center',
            },
            signaturePlaceholder: {
                margin: [0, 70, 0, 0],
            },
            signatureName: {
                bold: true,
                alignment: 'center',
            },
            signatureJobTitle: {
                italics: true,
                fontSize: 10,
                alignment: 'center',
            },
            notesTitle: {
                fontSize: 10,
                bold: true,
                margin: [0, 50, 0, 3],
            },
            notesText: {
                fontSize: 10
            },
            center: {
                alignment: 'center',
                "bold": true
            },
            redText: {
                color: 'red'
            },
            rightText: {
                alignment: 'right',
                margin: [10, 0, 0, 0]
            }
        },
        defaultStyle: {
            columnGap: 20,
        }

    };
    return res_json;
}
export function getInvoiceFormatedData(in_order_id) {
    return getCalculatedInvoiceData(in_order_id,'INVOICE').then((data) => {
        return {
            ...data,
            pdfMakeDoc: getFormatedInvoice(data)
        };
    });
}

export function getReceiptFormatedData(in_order_id) {

    return getCalculatedInvoiceData(in_order_id, 'RECEIPT').then((data) => {
        return {
            ...data,
            pdfMakeDoc: getFormatedReceipt(data)
        };
    });
}
export function getFormatedReceipt(response) {

    let order = response.orderDetails;
    let paymentDetails = response.paymentDetails;

    var invoice_json = {
        company: {
            name: "Camden Apparel Solutions Pvt. Ltd",
            address: "Camden Apparel Solutions Pvt. Ltd., SURVEY NO.48/2 KUDLU VILLAGE, ANEKAL TALUK SARJAPURA HOBLI, BANGALORE DISTRICT, BBMP, BANGALORE-560068",
            contact: "Phone : 1800 3000 1575 / E-mail : care@tailorman.com",
            cin: "U18204KA2012PTC066352",
            pan: "AAFCC0250L",
            gst: "29AAFCC0250L1ZO"
        },
        declaration: "We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct."
    };

    var body = [
        [
            {
                text: 'Particulars',
                style: 'itemsHeader',
                colSpan: 4,
                alignment: 'center'
            },
            {}, {}, {}
        ],
        [
            {
                text: 'Customer Name',
                style: 'itemsHeader',
                alignment: 'center'
            },
            {
                text: 'Customer ID',
                style: 'itemsHeader',
                alignment: 'center'
            },
            {
                text: 'Order Number',
                style: 'itemsHeader',
                alignment: 'center'
            },
            {
                text: 'Reference Invoice No.',
                style: 'itemsHeader',
                alignment: 'center'
            }
        ],
        [order.customer_name, order.customer_id, order.order_id, order.invoice_number]
    ];

    var headers1 = [
        {
            "text": "SI No.",
            "style": "productTableHeader"
        },
        {
            "text": "Payment Mode",
            "style": "productTableHeader"
        },
        {
            "text": "Ref",
            "style": "productTableHeader"
        },
        {
            "text": "Amount",
            "style": "productTableHeader"
        }
    ];

    var body1 = [];
    body1.push(headers1);


    for (var j = 0; j < paymentDetails.length; j++) {
        var row = [];
        row.push(j + 1);
        row.push(paymentDetails[j].payment_mode);
        row.push(paymentDetails[j].reference);
        row.push(paymentDetails[j].amount);
        body1.push(row);
    }

    var row1 = [];
    row1.push('Total');
    row1.push("");
    row1.push("");
    row1.push(order.total_amount_payed);
    body1.push(row1);


    var body2 = [
        [{ text: 'Summary of Amount Recceived against invoice no ' + order.invoice_number, style: 'itemsHeader', colSpan: 4, alignment: 'center' },
        {
            "text": "",
       },{
            "text": "",
       },{
            "text": "",
       }],
        [
            {
                "text": "Date",
                "style": "productTableHeader"
            },
            {
                "text": "Billed Amount",
                "style": "productTableHeader"
            },
            {
                "text": "Received Amount",
                "style": "productTableHeader"
            },
            {
                "text": "Payment Type",
                "style": "productTableHeader"
            }
        ]
    ];

    for (var k = 0; k < paymentDetails.length; k++) {
        var bill_amount;
        if (k == 0) {
            bill_amount = order.total_bill_amount || '';
        } else {
            bill_amount = "";
        }
        var row = [];
        row.push(moment(paymentDetails[k].created).format('YYYY-MM-DD'));
        row.push(bill_amount);
        row.push(paymentDetails[k].amount);
        row.push(paymentDetails[k].payment_mode);
        body2.push(row);
    }

    var row2 = [];
    row2.push('Pending Amount as on Date');
    row2.push("");
    row2.push(order.pending_amount || '');
    row2.push("");
    //row.push( data1.value.toString()  );
    body2.push(row2);

    var res_json = {
        pageSize: 'A4',
        pageOrientation: 'landscape',

        content: [{
            "table": {
                "headerRows": 0,
                "widths": [
                    "*"
                ],
                "body": [
                    [
                        {
                            "text": invoice_json.company.name,
                            "style": "headerCenter",
                            border: [false]
                        }
                    ],
                    [
                        {
                            "text": order.store_address,
                            "style": "headerMiddleCenter",
                            border: [false]
                        }
                    ],
                    [
                        {
                            "text": "State Name :  " + order.city + ", Code : " + order.state_code,
                            "style": "headerMiddleCenter",
                            border: [false]
                        }
                    ],
                    [
                        {
                            "text": "Receipt Voucher",
                            "style": "headerBottomCenter",
                            border: [false]
                        }
                    ]
                ],
            }
        }, {
            "table": {
                "headerRows": 1,
                "widths": [
                    450,
                    "*",
                    "*"
                ],
                "body": [
                    [
                        {
                            "text": "No.: " + order.receipt_number,
                            border: [false]
                        },
                        {
                            "text": 'Dated:',
                            border: [false]
                        },
                        {
                            "text": moment(order.order_date).format('YYYY-MM-DD'),
                            border: [false]
                        }
                    ]
                ],
            },
        }, {
            // style: "",
            table: {

                widths: [300, '*', '*', '*'],
                headerRows: 1,
                // keepWithHeaderRows: 1,
                body: body
            }
        },
        {
            // style: "tableExampleCenter",
            table: {

                widths: [300, '*', '*', '*'],
                headerRows: 1,
                // keepWithHeaderRows: 1,
                body: body1
            }
        },
        {

            "table": {
                "headerRows": 1,
                "widths": [
                    300,
                    "*"
                ],
                "body": [
                    [
                        {
                            "text": "Amount In Words",
                            "style": "itemsHeader"
                        },
                        {
                            "text": order.receipt_amount_in_words
                        }
                    ]
                ]
            }
        }, {
            // style: "tableExampleBottom",
            "table": {
                "headerRows": 1,
                "widths": [
                    300,
                    "*",
                    "*",
                    "*"
                ],
                body: body2
            }
        }, {
            "columns": [{
                "text": "PAN : " + invoice_json.company.pan,
                "width": 565

            }, {
                "text": "CIN : " + invoice_json.company.cin,

            }]
        },
        {
            "columns": [{
                "text": "GST : " + order.gst_code,
                "width": 440,
                // "style": "tableExample"

            }, {
                "text": invoice_json.company.contact,
                // "style": "tableExample"

            }]
        }, {
            "table": {
                "headerRows": 0,
                "widths": [
                    "*"
                ],
                "body": [
                    [
                        {
                            "text": "Corporate Address: Camden Apparel Solutions Pvt. Ltd., Survey No.48/2 Kudlu Village, Anekal Taluk Sarjapura Hobli, Bangalore District, Bbmp, Bangalore-560068",
                            "style": "itemsFooterSubTitle"
                        }
                    ],
                    [
                        {
                            "text": "Declaration : We declare that this invoice  shows the actual price  of the goods described and that all particulars are true and correct.",
                            "style": "itemsFooterCenterTitle"
                        }
                    ], [
                        {
                            "text": '*The document is computer generated and does not require signature*',
                            "style": 'itemsFooterCenterTitleRed'
                        }
                    ]
                ]
            },
            "layout": "noBorders"
        }
        ],
        styles: {
            "productTableHeader": {
                "bold": true,
                "fillColor": '#cccccc'
            },
            itemsFooterCenterTitle: {
                alignment: 'center',
                margin: [0, 5, 0, 5]
            },
            itemsFooterCenterTitleRed: {
                alignment: 'center',
                margin: [0, 5, 0, 5],
                color: 'red'
            },
            itemsFooterSubTitle: {
                margin: [0, 30, 0, 5],
                alignment: "center"
            },
            // Document Footer
            documentFooterLeft: {
                fontSize: 10,
                margin: [5, 5, 5, 5],
                alignment: 'left'
            },
            documentFooterCenter: {
                fontSize: 10,
                margin: [5, 5, 5, 5],
                alignment: 'center'
            },
            documentFooterRight: {
                fontSize: 10,
                margin: [5, 5, 5, 5],
                alignment: 'right'
            },

            itemsHeader: {
                margin: [0, 5, 0, 5],
                bold: true,
                "fillColor": '#cccccc'
            },
            // Item Title
            itemTitle: {
                bold: true,
            },
            itemSubTitle: {
                italics: true,
                fontSize: 11
            },
            // itemNumber: {
            //     margin: [0,5,0,5],
            //     alignment: 'left',
            // },
            itemTotal: {
                margin: [0, 5, 0, 5],
                bold: true,
                alignment: 'center',
            },


            itemsFooterSubValue: {
                margin: [0, 5, 0, 5],
                bold: true,
                alignment: 'center',
            },
            itemsFooterTotalTitle: {
                margin: [0, 5, 0, 5],
                bold: true,
                alignment: 'right',
            },
            itemsFooterTotalValue: {
                margin: [0, 5, 0, 5],
                bold: true,
                alignment: 'center',
            },
            signaturePlaceholder: {
                margin: [0, 70, 0, 0],
            },
            signatureName: {
                bold: true,
                alignment: 'center',
            },
            signatureJobTitle: {
                italics: true,
                fontSize: 10,
                alignment: 'center',
            },
            notesTitle: {
                fontSize: 10,
                bold: true,
                margin: [0, 50, 0, 3],
            },
            notesText: {
                fontSize: 10
            },
            center: {
                alignment: 'center',
                "bold": true
            },
            redText: {
                color: 'red'
            },
            rightText: {
                alignment: 'right',
                margin: [10, 0, 0, 0]
            },
            tableExampleCenter: {
                margin: [0, 5, 0, 0]
            },
            tableExampleBottom: {
                margin: [0, 35, 0, 15]
            },
            headerCenter: {
                alignment: 'center',
                margin: [0, 0, 0, 3],
                bold: true
            },
            headerMiddleCenter: {
                alignment: 'center',
                margin: [0, 0, 0, 3]
            },
            headerBottomCenter: {
                alignment: 'center',
                margin: [0, 0, 0, 30],
                bold: true
            },
        },
        defaultStyle: {
            columnGap: 20,
        }

    };

    return res_json;
};

export function getDiscountedTotal(sale) {
    let mrp = getUpChargedTotal(sale, sale.mrp);
    if (!sale.discount_type)
        sale.discount_type = 1;
    if (sale.discount_type && sale.discount) {
        switch (sale.discount_type) {
            case 1:
                mrp = Math.floor(parseFloat(mrp) - parseFloat(sale.discount / sale.qty));
                break;
            case 2:
                mrp = mrp - Math.floor((mrp * (sale.discount) / 100));
                break;
        }
    }
    return parseFloat(mrp).toFixed(2);
}
export function getUpChargedTotal(sale, mrp) {
   
    const totalUpCharge = sale.upcharge && sale.upcharge.reduce((_prev, _sale) => {
        if (_sale.type != 'High Priority Delivery') {
            if (_sale.unit == 1)
                return _prev + parseInt(_sale.value);
            else if (_sale.unit == 2)
                return _prev + Math.floor(sale.mrp * _sale.value / 100);
            else if (_sale.value)
                return _prev + parseInt(_sale.value);
        } else {
            return _prev;
        }
    }, 0);

    return ((parseFloat(mrp) + totalUpCharge)).toFixed(2);
}
export function updateOrderItemCalculation(order_item_details) {
  
    order_item_details.upcharge = JSON.parse(order_item_details.upcharge) || [];
    const discountedTotal = getDiscountedTotal(order_item_details);
    const delivery_upcharge = order_item_details.upcharge.reduce((prev, next) => {
        if (next.type == 'High Priority Delivery') {
            return prev + next.value;
        } else {
            return prev;
        }
    }, 0);
    let totalTax = 0;
    let completeTaxPercent = 0;
    order_item_details.taxes && order_item_details.taxes.map((tax) => {
        completeTaxPercent += tax.percent;
    });
    let _dicountedTotal = parseFloat(discountedTotal) + (parseFloat(delivery_upcharge));
    let _temptax = (_dicountedTotal / (100 + completeTaxPercent) * 100);
    order_item_details.taxes = order_item_details.taxes.map((tax) => {
        tax.value = ((parseFloat(tax.percent) / 100) * _temptax);
        tax.mrp_before_tax = parseFloat(_temptax);
        totalTax += tax.value;
        return tax;
    });
    const total_upcharge = order_item_details.upcharge ? order_item_details.upcharge.reduce((prev, next) => {
		if (next.type == 'High Priority Delivery') {
			return prev;
		}
		if (next.unit === 2) {
			return prev + Math.floor((order_item_details.mrp * next.value / 100));
		} else {
			return prev + next.value;
		}
    }, 0) : 0;
    order_item_details.upcharge_amount = total_upcharge;
    order_item_details.delivery_upcharge = delivery_upcharge;
    order_item_details.bill_amount = ((parseFloat(discountedTotal) + parseFloat(delivery_upcharge)) * order_item_details.qty);
    return order_item_details;
}