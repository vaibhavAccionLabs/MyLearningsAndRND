import Models from '../models';
const db = Models.sequelize;
import Promise from 'bluebird';
const RTW_INVENTORY_TABLE_NAME = 'm_category_rtw_inventory_measurment';
import moment from 'moment';
import fs from 'fs';
import _ from 'lodash';
import capillaryController from './capillary';


export function getPriorities(req, res) {
	db.query('select * from "GetPriorityList"()', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getPaymentTypes(req, res) {
	db.query('select * from "GetPaymenttypeList"()', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getTailors(req, res) {
	db.query('select * from "GetTailorList"()', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	})
}

export function getSalesmen(req, res) {
	db.query('select * from "GetSalesManList"()', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getFinishTypes(req, res) {
	db.query('select * from "GetProductFinishTypeList"()', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getStyles(req, res) {
	db.query('select * from "GetStyleList"()', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getItemTypes(req, res) {
	db.query('select * from "GetItemTypeList"()', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getMeasurementFields(req, res) {
	db.query('select * from "GetMeasurementTypeList"(:in_item_type_id, :in_measurement_source_id)', {
		raw: true,
		replacements: {
			in_item_type_id: req.query.item_type_id,
			in_measurement_source_id: req.query.measurement_type_id
		}
	}).then((result) => {
		return db.query('select * from "GetMeasurementMasterData"()').then((masterResult) => {
			return {
				fields: result[0],
				masterData: _.groupBy(masterResult[0], 'measurement_type_id')
			}
		});
	}).then((result) => {
		const fields = result.fields.map((field) => {
			if (field.category == 'Enumerated' && result.masterData[field.measurement_type_id]) {
				field.options = result.masterData[field.measurement_type_id];
			}
			return field;
		})
		res.send(fields);
	});
}

export function getFabricDesignFields(req, res) {
	db.query('select * from "GetFabricDesignParamsV3"(:in_item_type_id)', {
		raw: true,
		replacements: {
			in_item_type_id: req.query.item_type
		}
	}).then((result) => {
		if (result[0][0].GetFabricDesignParamsV3)
			res.send(result[0][0].GetFabricDesignParamsV3);
		else
			res.send([]);
	});
}

export function getMeasurementTypes(req, res) {
	db.query('select * from "GetMeasurementSourceList"()', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getCustomerSourceList(req, res) {
	db.query('select * from "GetSourceList"()', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getCustomerAddressList(req, res) {
	const customer_id = req.query.customer_id;
	db.query('select * from "GetCustomerAddressList"(:customer_id)', {
		raw: true,
		replacements: {
			customer_id: customer_id
		}
	}).then((result) => {
		res.send(result[0]);
	});

}

export function getWorkflows(req, res) {
	db.query('select * from "GetWorkflowList"()', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getOccasions(req, res) {
	db.query('select * from "GetOccationList"()', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getFabrics(req, res) {
	const item_type_id = req.query.item_type_id;
	db.query('select * from "GetFabricList"(:item_type_id)', {
		raw: true,
		replacements: {
			item_type_id: item_type_id
		}
	}).then((result) => {
		res.send(result[0]);
	});
}

export function searchFabrics(req, res) {
	const item_type_id = req.query.item_type_id;
	const product_sku = req.query.keyword;
	db.query('select * from "GetSKUDetails"(:in_item_type_id,:in_product_sku_code)', {
		raw: true,
		replacements: {
			in_item_type_id: item_type_id,
			in_product_sku_code: product_sku
		}
	}).then((result) => {
		let bundled_sku_list_Promise = [];
		if (result[0].length > 0) {
			result[0].map((item, index) => {
				var bundled_sku_list = item.bundled_sku_list ? item.bundled_sku_list.split(',') : null;
				var bundledSkuList = [];
				bundled_sku_list && bundled_sku_list.length > 0 && bundled_sku_list.map((value, index) => {
					var query = `SELECT * from "GetSKUDetails"('${value}')`;
					bundled_sku_list_Promise.push(db.query(query).then((data) => {
						bundledSkuList.push(data[0][0]);
						item.bundled_sku_list = bundledSkuList;
					}));
				});

			});
			if (bundled_sku_list_Promise && bundled_sku_list_Promise.length > 0) {
				Promise.all(bundled_sku_list_Promise).then((data) => {
					res.send(result[0]);
				});
			} else {
				res.send(result[0]);
			}
			// res.send(result[0]);
		}
	});
}

export function searchSaleFabrics(req, res) {
	const product_sku = req.query.keyword;
	db.query('select * from "GetSKUSaleDetails"(:in_product_sku_code)', {
		raw: true,
		replacements: {
			in_product_sku_code: product_sku
		}
	}).then((result) => {
		let bundled_sku_list_Promise = [];
		if (result[0].length > 0) {
			result[0].map((item, index) => {
				var bundled_sku_list = item.bundled_sku_list ? item.bundled_sku_list.split(',') : null;
				var bundledSkuList = [];
				bundled_sku_list && bundled_sku_list.length > 0 && bundled_sku_list.map((value, index) => {
					var query = `SELECT * from "GetSKUDetails"('${value}')`;
					bundled_sku_list_Promise.push(db.query(query).then((data) => {
						bundledSkuList.push(data[0][0]);
						item.bundled_sku_list = bundledSkuList;
					}));
				});

			});
			if (bundled_sku_list_Promise && bundled_sku_list_Promise.length > 0) {
				Promise.all(bundled_sku_list_Promise).then((data) => {
					res.send(result[0]);
				});
			} else {
				res.send(result[0]);
			}
			// res.send(result[0]);
		}
	});
}

export function getCustomerList(req, res) {
	const keyword = req.query.keyword || '';
	const store_id = req.query.store_id;
	db.query('select * from "GetCustomerList"(:in_param)', {
		raw: true,
		replacements: {
			in_param: keyword
		}
	}).then((result) => {
		let promiseArray = [];

		let customerId = [];
		promiseArray.push(result[0].length > 0 && result[0].map((item, index) => {
			customerId.push(item.customer_id);
		}));


		Promise.all(promiseArray).then(() => {
			if (customerId && customerId.length > 0) {

				capillaryController.getCustomerDetails(customerId, store_id).then((response) => {

					result[0].map((item) => {
						const current_slab_item = _.find(response, { external_id: item.customer_id.toString() });
						item.current_slab = current_slab_item ? current_slab_item.current_slab : '';
						item.loyalty_points = current_slab_item ? current_slab_item.loyalty_points : 0;
					});
					res.send(result[0]);
				});
			}else{
				res.send(result[0]);
			}
		});

	})
}

export function getWorkFlowStageList(req, res) {
	const user_id = req.body.user_id;
	const roles = req.body.roles;
	const workflow_id = req.body.workflow_id;
	if( !_.isArray(roles) ||  !user_id || !workflow_id ){
			
		res.status(500).json({
			success: false,
			message: "Required Parameters are missing"
		});
		return;	
	} 
	db.query('select * from "GetWorkFlowStageList"(' + user_id + ', ' + 'ARRAY[\'' + roles.join('\',\'') + '\'], ' + workflow_id + ')').then((result) => {
		res.send(result[0]);
	})
}
export function getWorkFlowList(req, res) {
	const keyword = req.query.keyword || '';
	db.query('select * from "GetWorkflowList"()').then((result) => {
		res.send(result[0]);
	});
}

export function getRTWList(req, res) {
	const store_id = req.query.store_id;
	const product_sku = req.query.keyword;
	const size = req.query.size;
	const fit = req.query.fit;
	const item_type_id = req.query.item_type_id;
	db.query('select * from "GetRTWSKUDetails"(:in_store_id,:in_product_sku_code,:in_size,:in_fit,:in_item_type_id)', {
		raw: true,
		replacements: {
			in_store_id: store_id,
			in_product_sku_code: product_sku,
			in_size: size,
			in_fit: fit,
			in_item_type_id: item_type_id
		}
	}).then((result) => {
		res.send(result[0]);
	});
}

export function fetchRTWStock(req, res) {
	const store_id = parseInt(req.query.store_id);
	const product_sku = req.query.keyword;
	const size = req.query.size;
	const fit = req.query.fit;
	const item_type_id = parseInt(req.query.item_type_id);
	db.query('select * from "GetRTWSKUStockDetails"(:in_store_id,:in_product_sku_code,:in_size,:in_fit,:in_item_type_id)', {
		raw: true,
		replacements: {
			in_store_id: store_id,
			in_product_sku_code: product_sku,
			in_size: size,
			in_fit: fit,
			in_item_type_id: item_type_id
		}
	}).then((result) => {
		res.send(result[0]);
	});
}
export function getRTWMeasurements(req, res) {
	const item_type_id = req.query.item_type;
	const store_id = req.query.store_id;
	db.query('select distinct * from m_category_rtw_inventory_measurment where item_type_id =' + item_type_id + ' and store_id =' + store_id).then((result) => {
		res.send(result[0]);
	});
}

export function getSizeList(req, res) {
	db.query('select distinct size as name from m_category_rtw_inventory_measurment where size is not null order by size').then((result) => {
		res.send(result[0]);
	});
}

export function getFitList(req, res) {
	db.query('select distinct fit as name from m_category_rtw_inventory_measurment where fit is not null').then((result) => {
		res.send(result[0]);
	});
}



export function transferInventory(req, res) {
	const formValues = req.body;
	const from_store_id = formValues.from_store_id;
	const to_store_id = formValues.to_store_id;
	const size = formValues.size;
	const fit = formValues.fit;
	const qty = formValues.qty;
	const description = formValues.description;
	const created_by = formValues.created_by;
	const fabric_id = formValues.fabric_id;
	const product_sku_code = formValues.product_sku_code;
	const item_type_id = formValues.item_type_id;
	formValues.user_id = req.user.user_id;


	db.query(`INSERT INTO rtw_inventory_transfer(from_store_id,to_store_id,size,fit,qty,description,fabric_id,created_by)values(${from_store_id},${to_store_id},'${size}','${fit}',${qty},'${description}',${created_by},${fabric_id})`).then((result) => {

		db.query(`Select distinct * from m_category_rtw_inventory_measurment where sku_code='${product_sku_code}' AND fit='${fit}' AND size='${size}' AND store_id=${to_store_id}`).then((results) => {
			var UpdateOrInsertQuery;
			if (results[0].length > 0) {
				UpdateOrInsertQuery = `Update m_category_rtw_inventory_measurment set inventory_count=inventory_count+${qty} where sku_code='${product_sku_code}' AND fit='${fit}' AND size='${size}' AND  item_type_id='${item_type_id}' AND store_id=${to_store_id}`;
			} else {
				UpdateOrInsertQuery = `INSERT INTO m_category_rtw_inventory_measurment(item_type_id,sku_code,fit,size,store_id,inventory_count) values('${item_type_id}','${product_sku_code}','${fit}','${size}',${to_store_id},${qty})`;
			}
			db.query(UpdateOrInsertQuery).then((incdata) => {
				db.query(`Update m_category_rtw_inventory_measurment set inventory_count=inventory_count-${qty} where sku_code='${product_sku_code}' AND fit='${fit}' AND size='${size}' AND store_id=${from_store_id} AND inventory_count>0 `).then((decdata) => {
					trackStockMovement(formValues);
					res.send({
						status: true
					});
				});

			});
		})

	}).catch((error) => {
		res.send({
			err: error
		});
	})
}

export function trackStockMovement(formValues) {
	//const formValues = req.body;
	console.log('FORMM VALUESSS', formValues);
	const from_store = formValues.from_store_id ? parseInt(formValues.from_store_id) : null;
	const to_store = formValues.to_store_id ? parseInt(formValues.to_store_id) : null;
	const size = formValues.size || null;
	const fit = formValues.fit || null;
	const qty = formValues.qty || null;
	const user_id = formValues.user_id || null;
	const product_sku_code = formValues.product_sku_code || null;
	const item_type_id = parseInt(formValues.item_type_id) || null;
	const type = formValues.type || null;
	const from_count_details = ('-' + qty) || null;
	const to_count_details = ('+' + qty) || null;

	const count_details = formValues.qty > 0 ? ('-' + formValues.qty) : ('+' + -formValues.qty);

	if (!fit || !size) {
		console.log('Size and Fit are Null or undefined');
		return false;
	}
	if (type == 'TRANSFER') {
		db.query(`INSERT INTO stock_movement_details(store_id,transferred_store_id,size,fit,count_details,product_sku,user_id,date,stock_movement_type,item_type_id)values(${from_store},${to_store},'${size}','${fit}','${from_count_details}','${product_sku_code}',${user_id},now(),'${type}',${item_type_id})`).then((result) => {

			console.log('Successfully inserted details');
		}).catch((error) => {
			console.log('Error', error);
		})
		db.query(`INSERT INTO stock_movement_details(store_id,transferred_store_id,size,fit,count_details,product_sku,user_id,date,stock_movement_type,item_type_id)values(${to_store},${from_store},'${size}','${fit}','${to_count_details}','${product_sku_code}',${user_id},now(),'${type}',${item_type_id})`).then((result) => {

			console.log('Successfully inserted details');
		}).catch((error) => {
			console.log('Error', error);
		})
	} else if (type == 'ORDER' || type == "DELETE ORDER") {
		db.query(`INSERT INTO stock_movement_details(store_id,order_item_id,size,fit,count_details,product_sku,user_id,date,stock_movement_type,item_type_id)values(${formValues.store_id},${formValues.record_id},'${formValues.size}','${formValues.fit}','${count_details}','${formValues.product_sku_code}',${user_id},now(),'${formValues.type}',${formValues.item_type_id})`).then((result) => {

			console.log('STOCKK MOVEMENT RESULTT', result);



		}).catch((error) => {
			console.log('Error', error);
		})
	}
}

export function getStoreInventory(req, res) {
	var store_id = req.query.store_id;
	db.query(`select m.address,it.descr,im.fit,im.fit,im.size,im.inventory_count,im.sku_code from m_category_rtw_inventory_measurment im LEFT JOIN m_item_type it ON it.item_type_id=im.item_type_id LEFT JOIN m_store m ON m.store_id=im.store_id where im.store_id=${store_id}`).then((result) => {
		res.send(result[0]);
	});
}
export function updateStoreInventory(req, res) {
	var formObj = req.body;
	var array = [];
	console.log("formObj", formObj.length, formObj[0]);

	//trackStockUploadMovement(formObj);
	if (formObj.length > 0) {
		formObj.map((item, index) => {
			array.push(item.sku_code);

			let selectQuery = `select * from  ${RTW_INVENTORY_TABLE_NAME} where sku_code='${item.sku_code}' and store_id=${item.store_id} and item_type_id=${item.item_type_id} and fit='${item.fit}' and size='${item.size}'`;

			let stockinsertQuery = `insert into stock_movement_details(store_id,product_sku,fit,size,stock_movement_type,date,count_details,item_type_id,user_id)values('${item.store_id}','${item.sku_code}','${item.fit}','${item.size}','UPLOAD',now(),'${item.count_details}','${item.item_type_id}','${item.user_id}')`;

			db.query(selectQuery).then((data) => {
				db.query(stockinsertQuery);
				if (data.length > 0) {
					console.log("data", data);
					let updateQuery = `update ${RTW_INVENTORY_TABLE_NAME} set inventory_count=inventory_count+${item.inventory_count} where sku_code='${item.sku_code}' and store_id=${item.store_id} and item_type_id=${item.item_type_id} and fit='${item.fit}' and size='${item.size}'`;
					console.log('updateQuery: ', updateQuery);


					return newUpdation(updateQuery, item.sku_code);
				} else {
					let insertQuery = `INSERT INTO ${RTW_INVENTORY_TABLE_NAME}(store_id, item_type_id, sku_code, fit, size, inventory_count) VALUES(${item.store_id},${item.item_type_id},'${item.sku_code}','${item.fit}','${item.size}','${item.inventory_count}')`;

					return newUpdation(insertQuery, item.sku_code);

					console.log('updateQuery: ', updateQuery);
				}



			});



		});

		res.send({
			success: true,
			error: false,
			data: array
		});
	} else {
		res.send({
			success: true,
			error: false,
			data: []
		});
	}


}

function newUpdation(updateQuery, field) {
	db.query(updateQuery)
		.then((result) => {
			// console.log('result inner: ', result[0]);
		})
		.catch((err) => {
			console.log('Failed to update m_fabric details:', field, err);
		});
}

export function inventorySheet(req, res) {
	const contype = req.headers['content-type'];
	const params = req.query;
	let content = `Params data : ${JSON.stringify(params)} \n Header:${JSON.stringify(req.headers)} `;
	fs.writeFile('inventory_data', content, function (err) {
		if (err) {
			return console.log(err);
		} else {
			let query = 'select m.address,it.descr,im.fit,im.fit,im.size,im.inventory_count,im.sku_code from m_category_rtw_inventory_measurment im LEFT JOIN m_item_type it ON it.item_type_id=im.item_type_id LEFT JOIN m_store m ON m.store_id=im.store_id';

			db.query(query).then((result) => {
				if (contype != 'application/xml') {
					var parsedJson = result[0];
					if (req.query.download) {
						res.xls('data.xlsx', getJsonParsedResponse(parsedJson));
					} else {
						res.send(parsedJson);
					}
				} else {
					var parsedXml = getXMLParsedResponse(result[0]);
					res.set('Content-Type', 'application/xml');
					res.send(xml(parsedXml, { declaration: true }));
				}
			});
		}

	})
}
function getJsonParsedResponse(result) {
	var formatedResponse = [];
	console.log("@@@", result[0])
	result.map((item, index) => {
		formatedResponse.push({
			"Address": item.address,
			"Description": item.descr,
			"SKU_Code": item.sku_code,
			"Fit": item.fit,
			"Size": item.size,
			"Invoice_count": item.inventory_count
		});
	})
	return formatedResponse;
}
function getXMLParsedResponse(result) {
	var formatedResponse = [];
	var records = [];
	result.map((item, index) => {
		var record = [];

		record = [{ "Address": item.address },
		{ "Description": item.descr },
		{ "SKU_Code": item.sku_code },
		{ "Bussiness_Date": item.business_dt },
		{ "Fit": item.fit },
		{ "Size": item.size },
		{ "Invoice_count": item.inventory_count }
		];
		records.push({
			record
		});
	})
	formatedResponse.push({
		records
	})
	return formatedResponse;
}
export function getPendingAmounts(req, res) {
	var store_id = req.query.store_id;
	if(!store_id){
		res.send([]);
		return;
	}
	db.query(`select bo.order_id,
             m.name,
             m.customer_id,
             sum(cop.amount) as amount,
             (select (array_to_json(array_agg(c_order_payment))) FROM  c_order_payment where store_id=${store_id} AND order_id = bo.order_id) as pending_amounts,
bo.total_amount from c_order_payment cop
 LEFT JOIN b_order bo ON bo.order_id =cop.order_id 
 LEFT JOIN m_customer m ON m.customer_id =bo.customer_id    
 where cop.store_id=${store_id} 
 AND bo.is_active = true
 GROUP by bo.order_id,m.name,m.customer_id,bo.total_amount`).then((result) => {
			res.send(result[0]);
		});

}


export function fetchStockDetails(req, res) {
	const values = req.body;
	console.log('TESTTT', values);
	const store_id = values.to_store_id;
	const product_sku = values.product_sku_code;
	const size = values.size;
	const fit = values.fit;
	const item_type_id = values.item_type_id;

	const query = `select * from stock_movement_details where store_id='${store_id}' and product_sku='${product_sku}' and size='${size}' and fit='${fit}' and item_type_id='${item_type_id}'`;
	db.query(query).then((result) => {
		// console.log('result inner: ', result[0]);
		res.send({
			success: true,
			data: result[0]
		});
	})
		.catch((err) => {
			res.send({
				error: err
			});
		});

	console.log('VALUESSSS', req.query, req.body);
}

export function getDeliveryLocations(req, res) {
	db.query('select * from "GetStoreLocations"()', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	});
}

export default {
	getPriorities,
	getPaymentTypes,
	getTailors,
	getStyles,
	getItemTypes,
	getMeasurementFields,
	getMeasurementTypes,
	getFabricDesignFields,
	getWorkflows,
	getFabrics,
	getCustomerList,
	getCustomerSourceList,
	getCustomerAddressList,
	getOccasions,
	getFinishTypes,
	getSalesmen,
	searchFabrics,
	searchSaleFabrics,
	getWorkFlowStageList,
	getWorkFlowList,
	getRTWList,
	getSizeList,
	getFitList,
	transferInventory,
	getRTWMeasurements,
	getStoreInventory,
	updateStoreInventory,
	inventorySheet,
	getPendingAmounts,
	trackStockMovement,
	fetchStockDetails,
	fetchRTWStock,
	getDeliveryLocations
}