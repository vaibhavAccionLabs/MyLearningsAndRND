'use strict';
import Models from '../models';
const db = Models.sequelize;
const Sequelize = Models.Sequelize;



export function getPendingWorkOrders(req, res) {
    const customer_id = req.body.customer_id;
    const store_id = req.body.store_id;
    
	db.query('select * from "GetPendingWorkOrders"(:in_customer_id,:in_store_id)', {
		raw: true,
		replacements: {
            in_customer_id: customer_id,
            in_store_id:store_id
		}
	}).then((result) => {
		res.send(result[0]);
	});
}




export default {
	getPendingWorkOrders
}