import users from './users';
import lists from './lists';
import orders from './orders';
import dashboard from './dashboard';
import capillary from './capillary';
import google_admin from './google-admin-actions';
import orderupdate from './orderupdate';
import dbdump from './dbdump';
export {
	users,
	lists,
	orders,
	dashboard,
	google_admin,
	capillary,
	orderupdate,
	dbdump
};

export default {
	users,
	lists,
	orders,
	dashboard,
	google_admin,
	capillary,
	orderupdate,
	dbdump
};