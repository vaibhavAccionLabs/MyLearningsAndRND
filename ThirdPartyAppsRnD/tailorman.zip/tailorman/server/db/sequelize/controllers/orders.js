import Models from '../models';
const db = Models.sequelize;
const Sequelize = Models.Sequelize;
import fs from 'fs';
import Promise from 'bluebird';
const readFile = Promise.promisify(fs.readFile);
import phantom from 'phantom';
import nodemailer from 'nodemailer';
import moment from 'moment';
import capillaryController from './capillary';
var express = require('express'),
	app = express();
// pdf = require('express-pdf');

import request from 'request';
import AWS from 'aws-sdk';
import uuid from 'uuid/v4';
import xml from 'xml';
import _ from 'lodash';
import {
	getCalculatedInvoiceData,
	getInvoiceFormatedData,
	updateOrderItemCalculation,
	getReceiptFormatedData
} from './utility';
import { AWSS3SecretKey, AWSS3SecretKeyWebsite } from '../../../config/secrets';
import {
	trackStockMovement
} from './lists';
import {
	Mandrill
} from 'mandrill-api';
import numeral from 'numeral';
import pdfMake from 'pdfmake';

var fonts = {
	Roboto: {
		normal: './fonts/Roboto-Regular.ttf',
		bold: './fonts/Roboto-Medium.ttf',
		italics: './fonts/Roboto-Italic.ttf',
		bolditalics: './fonts/Roboto-MediumItalic.ttf'
	}
};
var PdfPrinter = require('pdfmake/src/printer');
var printer = new PdfPrinter(fonts);
//Fabric design selected values json
const selectedFabricDesign = (fabrics) => {
	let styleObj = {};

	fabrics.map((item, index) => {
		styleObj[item.name] = {};

		item.Designs.map((type, i) => {
			if (type.selected === 0 || type.selected || type.text) {
				styleObj[item.name][type.name] = type.text || type.values[type.selected];
				if (styleObj[item.name][type.name] && styleObj[item.name][type.name].replace) {
					styleObj[item.name][type.name] = styleObj[item.name][type.name].replace(/'/g, "''");
				}
			}
		});

		if (_.isEmpty(styleObj[item.name])) {
			delete styleObj[item.name];
		}
	});

	return styleObj;
};

export function checkCustomer(req, res) {
	const _customer = req.body;
	db.query('select * from m_customer where email=:in_email OR mobile =:in_mobile', {
		raw: true,
		replacements: {
			in_mobile: _customer.mobile,
			in_email: _customer.email
		}
	}).then((result) => {
		if (result.length > 0 && result[0].length > 0) {
			res.status(500).json({
				success: false,
				message: "Email or mobile number already exists"
			});
		} else {
			saveCustomer(req, res);
		}
	});
}
export function saveCustomer(req, res) {
	const _customer = req.body;

	db.query('select * from "SaveCustomer"(:in_name, :in_gender, :in_dob, :in_mobile, :in_email, :in_height, :in_weight, :in_source_id, :in_comment,:in_referral_code)', {
		raw: true,
		replacements: {
			in_name: _customer.name,
			in_gender: (_customer.gender) ? _customer.gender[0].toUpperCase() : 'M',
			in_dob: _customer.dob || null,
			in_mobile: _customer.mobile,
			in_email: _customer.email,
			in_height: _customer.height ? parseFloat(_customer.height) : 0,
			in_weight: _customer.weight ? parseFloat(_customer.weight) : 0,
			in_source_id: _customer.source_id || 1,
			in_comment: _customer.comment || '',
			in_referral_code: _customer.referral_code || ''
		}
	}).then((result) => {
		//if(_customer.referral_code){
		capillaryController.capillaryOrderCreation(result[0][0].SaveCustomer, 'CUSTOMER', _customer.store_id);
		//}
		res.json({
			success: true,
			customer_id: result[0][0].SaveCustomer
		});

	})
		.catch(err => {
			res.status(500).json({
				success: false,
				err: err
			});
		});
}
export function updateCustomer(req, res) {
	const customer = req.body;
	db.query(`select * from m_customer where customer_id =${customer.customer_id}`).then((data) => {
		db.query('select * from "UpdateCustomer"(:in_customer_id, :in_name, :in_gender, :in_dob, :in_mobile, :in_email, :in_height, :in_weight, :in_source_id, :in_comment)', {
			raw: true,
			replacements: {
				in_customer_id: customer.customer_id || customer.id,
				in_name: customer.name,
				in_gender: (customer.gender) ? customer.gender[0].toUpperCase() : 'M',
				in_dob: customer.dob || null,
				in_mobile: customer.mobile || customer.phone,
				in_email: customer.email,
				in_height: customer.height ? parseFloat(customer.height) : 0,
				in_weight: customer.weight ? parseFloat(customer.weight) : 0,
				in_source_id: customer.source_id || 1,
				in_comment: customer.comment || ''
			}
		}).then((result) => {

			if (data[0] && ((data[0].email != customer.email) || (data[0].mobile != customer.mobile))) {
				capillaryController.capillaryOrderCreation(customer.customer_id, 'CUSTOMERUPDATE');

			}

			res.json({
				status: 'OK'
			});
		});
	});
}

export function saveDetails(req, res) {
	const _details = req.body;
	db.query('select * from "SaveOrder"( :in_customer_id, :in_order_type_id, :in_store_id, :in_user_id, :in_order_date, :in_priority_id, :in_payment_type_id, :in_Payment_details,:in_total_amount, :in_comment, :in_display_name, :in_billing_address, :in_delivery_address, :in_pin_number)', {
		raw: true,
		replacements: {
			in_customer_id: _details.customer_id,
			in_order_type_id: _details.order_type_id || 1,
			in_store_id: _details.store_id,
			in_priority_id: null,
			in_payment_type_id: _details.payment_type_id,
			in_Payment_details: _details.payment_details,
			in_user_id: _details.user_id,
			in_order_date: _details.order_date || null,
			in_total_amount: _details.total_amount,
			in_comment: _details.comment,
			in_display_name: _details.display_name,
			in_billing_address: _details.billing_address,
			in_delivery_address: _details.delivery_address,
			in_pin_number: _details.PIN || ''
		}
	}).then((result) => {
		res.json({
			order_id: result[0][0].SaveOrder
		});
	});
}

export function updateDetails(req, res) {
	const _details = req.body;
	db.query('select * from "UpdateOrderV2"(:in_order_id, :in_tailor_id, :in_customer_id, :in_order_type_id, :in_store_id, :in_user_id, :in_order_date, :in_occasion, :in_occation_date, :in_benificiary_name, :in_benificiary_mobile, :in_benificiary_email, :in_priority_id, :in_payment_type_id, :in_Payment_details,:in_total_amount, :in_comment, :in_display_name, :in_full_payment_flag, :in_billing_address, :in_delivery_address, :in_pin_number, :in_sales_man_id,:in_pindate,:in_redeemcoupon_json,:in_shipping_charges,:in_shipping_taxes,:in_approved_by)', {
		raw: true,
		replacements: {
			in_order_id: _details.order_id,
			in_tailor_id: _details.tailor_id || null,
			in_customer_id: _details.customer_id,
			in_order_type_id: _details.order_type_id || 1,
			in_benificiary_name: _details.benificiary_name || null,
			in_benificiary_mobile: _details.benificiary_mobile || null,
			in_benificiary_email: _details.benificiary_email || null,
			in_sales_man_id: _details.salesman_id || null,
			in_store_id: _details.store_id,
			in_priority_id: null,
			in_payment_type_id: _details.payment_type_id,
			in_Payment_details: _details.payment_details,
			in_user_id: _details.user_id,
			in_order_date: _details.order_date || null,
			in_occasion: _details.occasion || null,
			in_occation_date: _details.occasion_date || null,
			in_total_amount: _details.total_amount,
			in_comment: _details.comment || '',
			in_display_name: _details.display_name,
			in_full_payment_flag: _details.is_full_payment ? 'Y' : 'N',
			in_billing_address: _details.billing_address,
			in_delivery_address: _details.delivery_address,
			in_pin_number: _details.PIN || '0',
			in_pindate: _details.pindate || null,
			in_redeemcoupon_json: (_details.discounts) ? JSON.stringify(_details.discounts) : null,
			in_shipping_charges: _details.shipping_charges || null,
			in_shipping_taxes: (_details.shipping_taxes) ? JSON.stringify(_details.shipping_taxes) : null,
			in_approved_by: _details.approved_details || null
		}
	}).then((result) => {
		if (_details.discounts) {
			_details.discounts.map((_discount) => {
				if (_discount && !_discount.is_payment_mode) {
					if (_discount.type == "redeempoints") {
						capillaryController.capillaryOrderCreation(_details.order_id, "REDEEM");
					} else if (_discount.type == "coupon") {
						capillaryController.capillaryOrderCreation(_details.order_id, "COUPON");
					}
				}
			});
		}
		let promiseArray = [];
		let pending_amount_payload = _details.pending_amount || [];
		let pending_amount = _.filter(pending_amount_payload, (o) => {
			return !o.c_order_payment_id;
		});
		if (pending_amount && pending_amount.length > 0) {
			pending_amount.map((_disc) => {
				if (_disc.payment_mode == "11") {
					promiseArray.push(
						db.query(`INSERT INTO gift_transaction (gift_vocher_id,order_id,amount,created_by,created) VALUES(${_disc.gift_vocher_id},${_details.order_id},${parseInt(_disc.amount)},${_details.user_id},now())`)
					);
					promiseArray.push(
						db.query(`UPDATE gift_vocher SET balance_amount = balance_amount-${_disc.amount} WHERE gift_vocher_id=${_disc.gift_vocher_id}`)
					);
				}
				promiseArray.push(
					db.query(`INSERT INTO c_order_payment (order_id,store_id,payment_mode,reference,amount,created_by,created) values(${_details.order_id},${_details.store_id},'${_disc.payment_mode}','${_disc.reference}',${parseInt(_disc.amount)},${_details.user_id},now())`)
				);

			});
		}
		if (_details.loyality_tier_discount) {
			_details.loyality_tier_discount.map((_disc) => {
				promiseArray.push(db.query(`insert into capilary_charge_customer_trx(customer_id,order_id,fyearid,capilary_charge_rules_id,discount_amount) values(${_details.customer_id},${_details.order_id},'${_disc.fyearid}',${_disc.capilary_charge_rules_id},${_disc.discount})`));
			});
		}
		if (promiseArray.length > 0) {
			Promise.all(promiseArray).then(() => {
				res.json({ order_id: result[0][0].SaveOrder });
			});
		} else {
			res.json({ order_id: result[0][0].SaveOrder });
		}
	});
}
export function saveProfile(req, res) {
	const profile = req.body;
	db.query('select * from "SaveMeasurementProfile"(:in_customer_id, :in_item_type_id, :in_measurement_source_id, :in_profile_name, :in_comment)', {
		raw: true,
		replacements: {
			in_customer_id: profile.customer_id,
			in_item_type_id: profile.item_type_id,
			in_measurement_source_id: profile.measurement_source_id,
			in_profile_name: profile.name,
			in_comment: profile.comment
		}
	}).then((result) => {
		res.json({
			profile_id: result[0][0].SaveMeasurementProfile
		})
	});
}
export function saveStylingProfile(req, res) {
	const profile = req.body;


	const fabric_design = JSON.stringify(profile.fabric_design);
	console.log("STYLINGG PROFILEE", profile, fabric_design);

	db.query(`select * from "SaveStylingProfile"(${profile.customer_id},${profile.item_type_id},'${profile.name}',${profile.order_item_id},'${fabric_design}','${profile.comment}')`).then((result) => {
		console.log("STYLEEE RESULTT", result[0][0]);
		res.json({
			profile_id: result[0][0].SaveStylingProfile
		})
	})
}
export function updateProfile(req, res) {
	const profile = req.body;
	db.query('select * from "UpdateMeasurementProfile"(:in_profile_id, :in_profile_name, :in_comment)', {
		raw: true,
		replacements: {
			in_profile_id: profile.profile_id,
			in_profile_name: profile.profile_name || profile.name,
			in_comment: profile.comment
		}
	}).then((result) => {
		res.json({
			status: 'OK'
		});
	})
}

export function saveBulkMeasurement(req, res) {
	let done;

	const reqBody = req.body;

	const profileId = reqBody.profile_id;
	const measurements = reqBody.measurements;

	//After done with all save measurement
	//calls, it will be sending the response
	done = _.after(measurements.length, () => {
		return res.json({
			status: true
		});
	});

	measurements.map((item, index) => {
		db.query('select * from "SaveMeasurementProfileValues"(:in_profile_id, :in_measurement_type_id, :in_value,:in_descr,:in_delta_flag_value)', {
			raw: true,
			replacements: {
				in_profile_id: profileId,
				in_measurement_type_id: item.id,
				in_value: item.value || '0.00',
				in_descr: item.descr || null,
				in_delta_flag_value: item.delta_flag_value || false
			}
		}).then((result) => {
			done();
		}).catch(err => {
			console.log('Error in update measurement profile: ', err);
			done();
		});
	});
}
export function saveBulkImage(req, res) {
	let done;

	const reqBody = req.body;
	const profileId = reqBody.profile_id;
	const thumbnails = reqBody.thumbnails;


	//After done with all save measurement
	//calls, it will be sending the response
	done = _.after(thumbnails.length, () => {
		return res.json({
			status: true
		});
	});

	thumbnails.map((item, index) => {
		db.query('select * from "SaveProfileImage"(:in_profile_id, :in_image_id, :in_image)', {
			raw: true,
			replacements: {
				in_profile_id: profileId,
				in_image_id: parseInt(Math.random() * (10000 - 1) + 1),
				in_image: item
			}
		}).then((result) => {
			done();
		}).catch(err => {
			console.log('Error in update upload profile: ', err);
			done();
		});
	});
}

export function updateOrderProfileImage(req, res) {
	let done;

	const reqBody = req.body;
	const order_id = reqBody.order_id;
	const thumbnails = reqBody.thumbnails;
	const type = parseInt(reqBody.type);


	//After done with all save measurement
	//calls, it will be sending the response
	done = _.after(thumbnails.length, () => {
		return res.json({
			status: true
		});
	});

	thumbnails.map((item, index) => {
		db.query('select * from "SaveOrderImage"(:in_order_id, :in_image_id, :in_image)', {
			raw: true,
			replacements: {
				in_order_id: order_id,
				in_image_id: type || parseInt(Math.random() * (10000 - 1) + 1),
				in_image: item
			}
		}).then((result) => {
			done();
		}).catch(err => {
			console.log('Error in update upload profile: ', err);
			done();
		});
	});
}
export function saveMeasurement(req, res) {
	const measurement = req.body;

	db.query('select * from "SaveMeasurementProfileValues"(:in_profile_id, :in_measurement_type_id, :in_value,:in_descr,:delta_flag)', {
		raw: true,
		replacements: {
			in_profile_id: measurement.profile_id,
			in_measurement_type_id: measurement.type_id,
			in_value: measurement.value || '0.00',
			in_descr: measurement.descr || null,
			delta_flag: measurement.delta_flag || false
		}
	}).then((result) => {
		res.json({
			status: result[0][0].SaveMeasurementProfileValues
		})
	});
}

export function saveOrderItem(req, res) {
	const _sale = req.body;
	db.query('select * From "SaveOrderItem"(:in_order_id, :in_style_id, :in_workflow_id, :in_sku_id, :in_item_type_id, :in_mrp, :in_qty, :in_finish_type, :in_fit_on_date, :in_delivery_date, :in_comment, :in_profile_id, :in_priority_id, :in_display_name,:in_workflow_start_stage_id,:in_customer_fit_on_date,:in_customer_delivery_date,:in_upcharge,:in_taxes)', {
		raw: true,
		replacements: {
			in_order_id: _sale.order_id,
			in_workflow_id: _sale.workflow_id || 1,
			in_sku_id: _sale.style,
			in_item_type_id: _sale.item_type_id,
			in_mrp: _sale.mrp,
			in_qty: parseInt(_sale.qty),
			in_finish_type: _sale.finish_type_id || 0,
			in_fit_on_date: _sale.fiton_date || null,
			in_delivery_date: _sale.delivery_date || null,
			in_style_id: _sale.style || 0,
			in_comment: _sale.comment || '',
			in_profile_id: _sale.profile_id,
			in_priority_id: _sale.priority_id || 0,
			in_display_name: _sale.display_name,
			in_workflow_start_stage_id: _sale.workflow_stage_id || 1,
			in_customer_fit_on_date: _sale.customer_fit_on_date || null,
			in_customer_delivery_date: _sale.customer_delivery_date || null,
			in_upcharge: JSON.stringify(_sale.upcharges) || '[]',
			in_taxes: JSON.stringify(_sale.taxes) || '[]'
		}
	}).then((result) => {

		if (_sale.isMTM) {
			res.json({ order_item_id: result[0][0].SaveOrderItem });
		} else {
			const order_item_id = result[0][0].SaveOrderItem;
			const fabricmeasurement = JSON.stringify(_sale.fabric_measurement);
			db.query('select * from "SaveFabricMeasurement"(:in_order_item_id,:in_fabricmeasurement,:in_comment)', {
				raw: true,
				replacements: {
					in_order_item_id: order_item_id,
					in_fabricmeasurement: fabricmeasurement,
					in_comment: "storeops comment"
				}
			}).then((result) => {
				res.json({ order_item_id: order_item_id });



			});
		}

	});
}

export function saveAlteredOrderItem(req, res) {
	const _sale = req.body;
	db.query('select * from "SaveOrderItemAlteration"( :in_order_id, :in_order_item_id , :in_workflow_id , :in_sku_id, :in_item_type_id, :in_finish_type, :in_fit_on_date, :in_delivery_date, :in_comment, :in_profile_id, :in_display_name)', {
		raw: true,
		replacements: {
			in_order_id: _sale.order_id,
			in_order_item_id: _sale.order_item_id,
			in_workflow_id: _sale.workflow_id || 2,
			in_sku_id: _sale.style || 0,
			in_item_type_id: _sale.item_type_id,
			in_finish_type: _sale.finish_type_id || 0,
			in_fit_on_date: _sale.fiton_date || null,
			in_delivery_date: _sale.delivery_date || null,
			in_comment: _sale.comment || '',
			in_profile_id: _sale.profile_id,
			in_display_name: _sale.display_name || ''
		}
	}).then((result) => {
		res.send(result[0]);
	})
}

export function updateOrderItem(req, res) {

	const sale = req.body;
	/* ======== calculate bill amount =======*/

	//assume there is no delivery upcharge
	let has_delivery_upcharge = false;

	//Keep adding upcharge to total_upcharge, exclude delivery upcharge if available.
	const total_upcharge = sale.upcharges ? sale.upcharges.reduce((prev, next) => {
		//Check for delivery upcharge
		if (next.type == 'High Priority Delivery') {
			//if available assign the upcharge to has_delivery_upcharge
			has_delivery_upcharge = next;
			return prev;
		}

		//if upcharge.unit = 2, then this is percentage type upcharge, use upcharge.value as percentage value.
		if (next.unit === 2) {
			//The total upcharge needs to be rounded down so if upcharge is 614.6, it becomes 614.
			return prev + Math.floor((sale.mrp * next.value / 100));
		} else {
			return prev + next.value;
		}
	}, 0) : 0;


	//assume bill amount is the MRP, we will add upcharge and discount in the next step
	let bill_amount = sale.mrp + total_upcharge;

	//if the order item has a discount_value column
	if (sale.discount_value) {
		//if discount_type = 2, then this is percentage type discount, use the discount_value column as a percentage value
		if (sale.discount_type === 2) {
			//The total discount has to be floored (rounded down), so if the discount is 550.9 INR it becomes 550 INR.
			bill_amount = sale.mrp + total_upcharge - Math.floor((sale.mrp + total_upcharge) * sale.discount_value / 100);
			//else discount_value is a normal amount and simply add to the upcharged mrp.
		} else {
			bill_amount = sale.mrp + total_upcharge - (sale.discount_value / sale.qty);
		}
	}

	const discount_amount = ((sale.mrp + total_upcharge) - bill_amount) * sale.qty;
	//	const discount_amount = ((sale.mrp + total_upcharge) - bill_amount) ;


	//total bill amount will be the upcharged and discounted mrp times the order item quantity
	bill_amount = bill_amount * sale.qty;

	let delivery_upcharge = 0;
	//Finally add delivery upcharge if available.
	if (has_delivery_upcharge) {
		bill_amount += (has_delivery_upcharge.value * sale.qty);
		delivery_upcharge = (has_delivery_upcharge.value * sale.qty);
	}
	/* EO Calculate bill amount */
	db.query('select * from "UpdateOrderItem"(:in_order_id, :in_order_item_id, :in_style_id, :in_workflow_id, :in_sku_id, :in_item_type_id, :in_mrp, :in_qty, :in_finish_type, :in_fit_on_date, :in_delivery_date, :in_comment, :in_profile_id, :in_priority_id, :in_display_name, :in_upcharge, :in_taxes, :in_discount_type, :in_discount_value, :in_order_flag, :in_bill_amount, :in_upcharge_amount, :in_delivery_upcharge_amount, :in_discount_amount,:in_discount_comment,:in_workflow_start_stage_id,:in_customer_fit_on_date,:in_customer_delivery_date)', {
		raw: true,
		replacements: {
			in_order_id: sale.order_id,
			in_order_item_id: sale.order_item_id,
			in_style_id: sale.style,
			in_workflow_id: 1,
			in_sku_id: sale.style,
			in_item_type_id: sale.item_type_id,
			in_mrp: sale.mrp,
			in_qty: parseInt(sale.qty),
			in_finish_type: sale.finish_type_id || 0,
			in_fit_on_date: sale.fiton_date || null,
			in_delivery_date: sale.delivery_date || null,
			in_comment: sale.comment,
			in_profile_id: sale.profile_id,
			in_priority_id: sale.priority_id,
			in_display_name: sale.display_name,
			in_upcharge: JSON.stringify(sale.upcharges) || '[]',
			in_taxes: JSON.stringify(sale.taxes) || '[]',
			in_discount_type: sale.discount_type || 0,
			in_discount_value: sale.discount_value ? parseFloat(sale.discount_value) : 0.00,
			in_order_flag: sale.order_flag || 1,
			in_bill_amount: bill_amount,
			in_upcharge_amount: total_upcharge,
			in_delivery_upcharge_amount: delivery_upcharge,
			in_discount_amount: discount_amount,
			in_discount_comment: sale.discount_comment || "",
			in_workflow_start_stage_id: sale.workflow_stage_id || null,
			in_customer_fit_on_date: sale.customer_fit_on_date || null,
			in_customer_delivery_date: sale.customer_delivery_date || null
		}
	}).then((result) => {
		if (sale.isMTM) {
			res.json({
				status: result[0]
			});
		} else {
			if (sale.fabric_measurement) {
				const order_item_id = sale.order_item_id;
				const fabricmeasurement = JSON.stringify(sale.fabric_measurement);
				db.query('select * from "SaveFabricMeasurement"(:in_order_item_id,:in_fabricmeasurement,:in_comment)', {
					raw: true,
					replacements: {
						in_order_item_id: order_item_id,
						in_fabricmeasurement: fabricmeasurement,
						in_comment: "storeops comment"
					}
				}).then((result) => {
					res.json({
						status: result[0]
					});
				});
			} else {
				res.json({
					status: result[0]
				});
			}
		}

	});
}


//delete an image from aws
export function deleteAWSImage(req, res) {
	console.log("requesting Body is=======", req.body);

	AWS.config.region = AWSS3SecretKey.region;
	AWS.config.accessKeyId = AWSS3SecretKey.accessKeyID;
	AWS.config.secretAccessKey = AWSS3SecretKey.secretAccessKey;

	var bucketName = AWSS3SecretKey.bucketName;
	console.log("Bucket Name is =====", bucketName);
	//https://s3.ap-south-1.amazonaws.com/assets.web.tm/product/FY00733.jpg
	var bucketInstance = new AWS.S3();
	var reqBody = req.body;
	var fileName = reqBody.file.fileName;
	var productSku = reqBody.file.productSku;
	var checkRtw = reqBody.file.rtw;
	if (fileName.rtw) {
		fileName = fileName.filename
	}
	console.log("File Name:======", fileName);
	var params = {
		Bucket: bucketName,
		Key: fileName
	};
	bucketInstance.deleteObject(params, function (err, data) {
		if (data) {
			if (checkRtw && _.includes(fileName, 'RTWHR')) {
				db.query(`UPDATE m_fabric SET rtw_image_count = rtw_image_count - 1 WHERE sku_code = '${productSku}'`).then((result) => {
					console.log("result is ======", result);
					// update query result needed
				});
			}
			console.log("File deleted successfully");
			res.status(200).send({
				success: true,
				message: "File deleted successfully"
			});
		}
		else {
			res.status(500).send({
				success: false,
				message: "Check if you have sufficient permissions : " + err
			});
			console.log("Check if you have sufficient permissions : " + err);
		}
	});
}

export function getSignUrl(req, res) {

	AWS.config.region = AWSS3SecretKeyWebsite.region;
	AWS.config.accessKeyId = AWSS3SecretKeyWebsite.accessKeyID;
	AWS.config.secretAccessKey = AWSS3SecretKeyWebsite.secretAccessKey;

	var bucketName = AWSS3SecretKeyWebsite.bucketName;
	var s3bucket = new AWS.S3();
	var reqBody = req.body;

	var imagePath = reqBody.file.name;
	// let checkRtw = reqBody.file.checkRtw;
	// let productSku = reqBody.file.productSku;
	// console.log("request Body Is ====", reqBody.file);
	// console.log("IMAGE PATH IS", imagePath);

	var s3_params = {
		Bucket: bucketName,
		Key: imagePath,
		Expires: 60, // expire after 60 mins
		ContentType: reqBody.file.type,
		ACL: 'public-read',
	};

	s3bucket.getSignedUrl('putObject', s3_params, function (err, data) {
		if (err) {
			res.status(500).send({
				success: false,
				error: err,
				message: 'Failed to get the signed url!'
			});
			return;
		} else {
			var return_data = {
				requestUrl: data,
				imageUrl: 'https://s3.ap-south-1.amazonaws.com/' + bucketName + '/' + imagePath
			};
			// if(checkRtw && _.includes(imagePath, 'RTWHR')){
			// 	// extract sku
			// 		db.query(`UPDATE m_fabric SET rtw_image_count = rtw_image_count + 1 WHERE sku_code = '${productSku}'`).then((result) => {
			// 			console.log("result is ======", result);
			// 			// update query result needed
			// 		});
			// 	}

			res.status(200).send({
				data: return_data
			});
		}
	});
}

//To get the signed AWS URL
export function getSignedUrl(req, res) {
	if (!req.body.file) {
		res.json({
			success: false,
			message: 'No file found!'
		});
		return;
	}
	//Input parameters
	var reqBody = req.body;

	var file = reqBody.file;
	var pdfFormat = reqBody.pdfFormat;

	var fileType = file.type;
	var fileSize = file.size;
	var fileName = file.name;
	var orderId = file.order_id;

	var imagePath;
	if (pdfFormat) {
		if (fileType.match('application/pdf.*')) {
			imagePath = 'upload/' + orderId + '/' + `${orderId}.pdf`;
		} else {
			fileName = fileName.split('.').pop()
			imagePath = 'upload/' + orderId + '/' + `${orderId}.${fileName}`;
		}

		if (fileType.match('application/pdf.*') || fileType.match('image/*')) {
			//correct format
		} else {
			res.json({
				success: false,
				message: 'Uploaded format is incorrect!'
			});
			return;
		}
	} else {
		imagePath = 'upload/' + orderId + '/' + uuid() + fileName;
		if (fileType.match('image.*')) {
			//correct format
		} else {
			res.json({
				success: false,
				message: 'Uploaded format is incorrect!'
			});
			return;
		}
	}


	AWS.config.region = AWSS3SecretKey.region;
	AWS.config.accessKeyId = AWSS3SecretKey.accessKeyID;
	AWS.config.secretAccessKey = AWSS3SecretKey.secretAccessKey;

	var bucketName = AWSS3SecretKey.bucketName;
	var s3bucket = new AWS.S3();

	var s3_params = {
		Bucket: bucketName,
		Key: imagePath,
		Expires: 60, // expire after 60 mins
		ContentType: fileType,
		ACL: 'public-read',
	};

	s3bucket.getSignedUrl('putObject', s3_params, function (err, data) {
		if (err) {
			console.log(err);
			res.json({
				success: false,
				error: err,
				message: 'Failed to get the signed url!'
			});
			return;
		} else {
			console.log('data: data: ', data);
			console.log('bucketName: bucketName: ', bucketName);
			console.log('fileName: fileName: ', imagePath);

			var return_data = {
				requestUrl: data,
				imageUrl: 'https://s3.ap-south-1.amazonaws.com/' + bucketName + '/' + imagePath
			};
			res.json({
				success: true,
				data: return_data,
				message: 'Uploaded completed!'
			});
		}
	});
}

export function saveImage(req, res) {
	const order_id = parseInt(req.body.order_id);
	const dataURL = req.body.dataURL;
	const type = parseInt(req.body.type);
	db.query('select * from "SaveOrderImage"(:in_order_id, :in_image_id, :in_image)', {
		raw: true,
		replacements: {
			in_order_id: order_id,
			in_image_id: type || parseInt(Math.random() * (10000 - 1) + 1),
			in_image: dataURL
		}
	}).then((result) => {
		res.json({
			status: 'OK'
		});
	});
}

export function savePdf(req, res) {


	const order_id = parseInt(req.body.order_id);
	const dataURL = req.body.dataURL;
	const query = `update b_order set bespoke_url = '${dataURL}' where order_id = ${order_id}`;
	db.query(query).then((result) => {
		res.json({
			status: 'OK'
		});
	});
}

export function getImages(req, res) {
	const order_id = parseInt(req.query.order_id);
	db.query('select * from "GetImageList"(:in_order_id)', {
		raw: true,
		replacements: {
			in_order_id: order_id
		}
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getImagesOfType(req, res) {
	const order_id = parseInt(req.query.order_id);
	const image_id = parseInt(req.query.image_id);
	db.query('select * from "GetImageList"(:in_order_id) where "image_id" = :in_image_id', {
		raw: true,
		replacements: {
			in_order_id: order_id,
			in_image_id: image_id
		}
	}).then((result) => {
		res.send(result[0]);
	})
}
export function getProfileImage(req, res) {
	const profile_id = parseInt(req.query.profile_id);

	db.query('select image_id,image from b_order_image where profile_id = ' + profile_id).then((result) => {
		res.send(result[0]);
	})
}
export function saveFabricDesign(req, res) {
	const item_type_id = req.query.order_item_id;
	const profile_id = req.body.profile_id;
	const selectedStyles = selectedFabricDesign(req.body.fabric_design);

	console.log("FABRICC DESIGNN", JSON.stringify(req.body.fabric_design));
	db.query('select * from "SaveFabricDesign"(:in_order_item_id, :in_fabric_design, :in_selected_fabric_design, :in_comment,:in_profile_id)', {
		raw: true,
		replacements: {
			in_order_item_id: item_type_id,
			in_fabric_design: JSON.stringify(req.body.fabric_design),
			in_selected_fabric_design: JSON.stringify(selectedStyles),
			in_comment: req.body.comment || '',
			in_profile_id: profile_id || null
		}
	}).then((result) => {
		res.json({
			status: result[0][0].SaveFabricDesign
		});
	})
}

export function saveStylingProfileOrder(req, res) {
	const order_item_id = req.body.order_item_id;
	const profile_id = req.body.profile_id;

	const query = `update b_customer_style_profile set order_item_id = ${order_item_id} where profile_id = ${profile_id}`; ''

	db.query(query).then((result) => {
		res.json({
			status: 'OK'
		});
	})
}

export function getCustomerOrders(req, res) {
	const customer_id = req.query.customer_id;
	db.query('select * from "GetCustomerOrderList"(:in_customer_id)', {
		raw: true,
		replacements: {
			in_customer_id: customer_id
		}
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getOrderItems(req, res) {
	const order_id = req.query.order_id;
	if (!order_id) {
		res.status(500).json({
			success: false,
			message: "Required Parameters are missing"
		});
		return;
	}
	db.query('select * from "GetOrderItemListV2"(:in_order_id)', {
		raw: true,
		replacements: {
			in_order_id: order_id
		}
	}).then((result) => {
		res.send(result[0]);
	})
}

export function getOrderItemFabricDesign(req, res) {
	const order_item_id = req.query.order_item_id;
	db.query('select * from "GetOrderItemFabricDesign"(:in_order_item_id)', {
		raw: true,
		replacements: {
			in_order_item_id: order_item_id
		}
	}).then((result) => {
		res.send(result[0]);
	})
}
export function getOrderItemProfileStyling(req, res) {
	const order_item_id = req.query.order_item_id;
	const query = `select c.order_item_id,c.fabric_design,c.comment,s.profile_name from b_order_item_fabric_design c left join b_customer_style_profile s on c.order_item_id = s.order_item_id and c.order_item_id = ${order_item_id}`;
	console.log('Queryyy', query);
	db.query(query).then((result) => {
		res.send(result[0]);
	})
}


export function getProfiles(req, res) {
	const customer_id = req.query.customer_id;
	const item_type_id = req.query.item_type_id;
	if (!item_type_id || !customer_id) {
		res.status(500).json({
			success: false,
			message: "Required Parameters are missing"
		});
		return false;
	}
	db.query('select * from "GetMeasurementProfileList"(:in_customer_id, :in_item_type_id)', {
		raw: true,
		replacements: {
			in_customer_id: customer_id,
			in_item_type_id: item_type_id
		}
	}).then((result) => {
		res.send(result[0]);
	})
}
export function getStyleProfiles(req, res) {
	const customer_id = req.query.customer_id;
	const item_type_id = req.query.item_type_id;
	db.query('select * from "GetStylingProfileList"(:in_customer_id, :in_item_type_id)', {
		raw: true,
		replacements: {
			in_customer_id: customer_id,
			in_item_type_id: item_type_id
		}
	}).then((result) => {
		res.send(result[0]);
	})
}



export function getMeasurementProfileValues(req, res) {
	const profile_id = req.query.profile_id;
	const is_print = req.query.is_print;
	if (!profile_id) {
		res.status(500).json({
			success: false,
			message: "Required Parameters are missing"
		});
		return;
	}
	let query = 'select * from "GetMeasurementProfileValuesV2"(:in_profile_id)';
	if (is_print)
		query = 'select * from "GetMeasurementProfileValuesV2"(:in_profile_id, :in_wo_order)';
	db.query(query, {
		raw: true,
		replacements: {
			in_profile_id: profile_id,
			in_wo_order: 1
		}
	}).then((result) => {
		res.send(result[0]);
	});
}

export function getRTWMeasurementProfileValues(req, res) {
	const order_item_id = req.query.order_item_id;
	let query = 'select * from "GetOrderItemFabricMeasurement"(:order_item_id)';
	db.query(query, {
		raw: true,
		replacements: {
			order_item_id
		}
	}).then((result) => {
		res.send(result[0]);
	});
}

export function deleteOrderItem(req, res) {
	const values = req.body;
	const order_item_id = values.order_item_id;
	db.query('select * from "DeleteOrderItem"(:in_order_item_id)', {
		raw: true,
		replacements: {
			in_order_item_id: order_item_id
		}
	}).then((result) => {
		values.user_id = req.user.user_id;
		trackStockMovement(values);
		res.send(result[0]);
	})
}
export function updateMeasurementInventory(req, res) {
	const fabric_measurement = req.body;
	db.query("select * from m_category_rtw_inventory_measurment where sku_code=:in_product_sku and fit = :in_fit and size=:in_size and store_id =:in_store_id", {
		raw: true,
		replacements: {
			in_qty: parseInt(fabric_measurement.qty),
			in_product_sku: fabric_measurement.product_sku_code,
			in_fit: fabric_measurement.fit,
			in_size: fabric_measurement.size,
			in_length: fabric_measurement.length,
			in_store_id: parseInt(fabric_measurement.store_id)
		}
	}).then((m_category_rtw_inventory_measurment_data) => {
		if (m_category_rtw_inventory_measurment_data[0].length == 0) {
			db.query("insert into m_category_rtw_inventory_measurment (inventory_count,sku_code,fit,store_id,size) VALUES (-(:in_qty),:in_product_sku,:in_fit,:in_store_id,:in_size)", {
				raw: true,
				replacements: {
					in_qty: parseInt(fabric_measurement.qty),
					in_product_sku: fabric_measurement.product_sku_code,
					in_fit: fabric_measurement.fit,
					in_size: fabric_measurement.size,
					in_length: fabric_measurement.length,
					in_store_id: parseInt(fabric_measurement.store_id)
				}
			}).then((data) => {
				fabric_measurement.user_id = req.user.user_id;
				trackStockMovement(fabric_measurement);
				res.send(data[0]);
			});
		} else {
			db.query("Update m_category_rtw_inventory_measurment set inventory_count=inventory_count-(:in_qty) where sku_code=:in_product_sku and fit = :in_fit and size=:in_size and store_id =:in_store_id", {
				raw: true,
				replacements: {
					in_qty: parseInt(fabric_measurement.qty),
					in_product_sku: fabric_measurement.product_sku_code,
					in_fit: fabric_measurement.fit,
					in_size: fabric_measurement.size,
					in_length: fabric_measurement.length,
					in_store_id: parseInt(fabric_measurement.store_id)
				}
			}).then((data) => {
				fabric_measurement.user_id = req.user.user_id;
				trackStockMovement(fabric_measurement);
				res.send(data[0]);
			});
		}
	});

}


export function getTaxes(req, res) {
	const total = req.query.total;
	const sku_code = req.query.sku_code;
	// const has_discount = req.query.has_discount == 'true' ? true : false;
	const store_id = req.query.store_id;
	db.query(`select * from "GetTaxes"(${store_id},'${sku_code}')`).then((result) => {
		let taxesArray = result[0][0].GetTaxes;
		if (parseFloat(total) <= 1000) {
			taxesArray = taxesArray.map((item) => {
				if (item.percent == 12) {
					item.percent = 5;
				} else if (item.percent == 6) {
					item.percent = 2.5;
				}
				return item;
			});
		}
		res.send(taxesArray);
	});
}

export function getWorkOrders(req, res) {
	const stage_ids = req.body.stage_ids;
	const from_date = req.body.from_date;
	const to_date = req.body.to_date;
	const customer = req.body.customer;
	const customer_id = req.body.customer_id;
	const order_id = req.body.order_id;
	if (!_.isArray(stage_ids)) {
		res.status(500).json({
			success: false,
			message: "Required Parameters are missing"
		});
		return;
	}
	db.query('select * from "GetWorkOrderList"(' + 'ARRAY[' + stage_ids.join(',') + ']' + ', :in_start_date, :in_end_date, :in_customer_param,:in_order_id,:in_customer_id) where current_stage_id NOT IN (13, -1)', {
		raw: true,
		replacements: {
			in_customer_param: customer || '',
			in_start_date: from_date,
			in_end_date: to_date,
			in_order_id: order_id || null,
			in_customer_id: customer_id || null
		}
	}).then((result) => {
		res.send(result[0]);
	})
}

export function getWorkOrderStageList(req, res) {
	const order_item_id = req.body.order_item_id;
	const user_id = req.body.user_id;
	const roles = req.body.roles;
	const workflow_id = req.body.workflow_id;
	db.query('select * from "GetWorkFlowStageList"(' + user_id + ', ' + order_item_id + ' , ' + 'ARRAY[\'' + roles.join('\',\'') + '\'], ' + workflow_id + ')', {
		raw: true
	}).then((result) => {
		res.send(result[0]);
	});
}

export function saveWorkFlowStage(req, res) {
	const workflow_id = req.body.workflow_id;
	const workflow_stage_id = req.body.workflow_stage_id;
	const order_item_id = req.body.order_item_id;
	const profile_id = req.body.profile_id;
	const comment = req.body.comment;
	const user_id = req.body.user_id;
	db.query('select * from "SaveWorkFlowStage"(:in_workflow_id, :in_workflow_stage_id, :in_order_item_id, :in_profile_id, :in_comment, :in_user_id)', {
		raw: true,
		replacements: {
			in_workflow_id: workflow_id,
			in_workflow_stage_id: workflow_stage_id,
			in_order_item_id: order_item_id,
			in_profile_id: profile_id,
			in_comment: comment,
			in_user_id: user_id
		}
	}).then((result) => {
		res.send({
			status: true
		});
	}).catch((error) => {
		console.log(error);
		res.send({
			err: error
		});
	})
}

export function getOrderDetails(req, res) {
	const order_id = req.query.order_id;
	db.query('select * from "GetOrderDetails"(:in_order_id)', {
		raw: true,
		replacements: {
			in_order_id: order_id
		}
	}).then((result) => {
		res.send(result[0][0]);
	})
}

export function getCustomerDetails(req, res) {
	const customer_id = req.query.customer_id;
	db.query('select * from "GetCustomer"(:in_customer_id)', {
		raw: true,
		replacements: {
			in_customer_id: customer_id
		}
	}).then((result) => {
		res.send(result[0][0]);
	})
}

export function getOrderItemDetails(req, res) {
	const order_item_id = req.query.order_item_id;
	db.query('select * from "GetOrderItemDetails"(:in_order_item_id)', {
		raw: true,
		replacements: {
			in_order_item_id: order_item_id
		}
	}).then((result) => {
		res.send(result[0][0]);
	})
}

export function getWorkFlowOrderItemDetails(req, res) {
	const order_item_id = req.query.order_item_id;
	const workflow_stage_id = req.query.workflow_stage_id || 13;

	db.query('select * from "GetOrderItemDetails"(:in_order_item_id,:in_workflow_stage_id)', {
		raw: true,
		replacements: {
			in_order_item_id: order_item_id,
			in_workflow_stage_id: workflow_stage_id
		}
	}).then((result) => {
		res.send(result[0][0]);
	})
}

export function getOrderItemList(req, res) {
	const order_id = req.query.order_id;
	if (!order_id) {
		res.status(500).json({
			success: false,
			message: "Required Parameters are missing"
		});
		return;
	}
	db.query('select * from "GetOrderItemListV2"(:in_order_id)', {
		raw: true,
		replacements: {
			in_order_id: order_id
		}
	}).then((result) => {
		res.send(result[0]);
	});
}

function sendEmail(req, content, customer, attachment, order_id, res, store_email) {
	var email = (req.user) ? req.user.email : 'data@tailorman.com';
	if (customer && customer.is_customer) {
		email = customer.customer_email || 'data@tailorman.com';
	}
	var mandrill_client = new Mandrill('P8PB1qLj9O75t1TMPZ3VpA');
	const ENV = process.env.TAILORMAN_ENV;
	let to_email = [{
		email: email,
		name: customer.name,
		type: 'to'
	}];
	if (store_email) {
		to_email.push({
			email: store_email,
			name: customer.name,
			type: "bcc"
		});
	}


	//COMMENTING FOR THE FUTURE, WHEN WE CAN ACTUALLY SEND THE EMAILS TO CUSTOMERS
	// if (ENV == 'PRODUCTION' && customer && customer.email) {
	// 	to_email[0].type = 'bcc';
	// 	to_email.push({
	// 		email: customer.email,
	// 		name: customer.name,
	// 		type: 'to'
	// 	})
	// }

	if (ENV == 'PRODUCTION') {
		to_email[0].type = 'bcc';
		to_email.push({
			email: 'data@tailorman.com',
			name: 'PPD',
			type: 'to'
		})
	}

	const message = {
		html: content,
		text: '',
		subject: 'Tailorman Invoice Order No: ' + order_id,
		from_email: 'care@tailorman.com',
		from_name: 'Tailorman Invoice',
		to: to_email,
		attachments: attachment
	}
	mandrill_client.messages.send({
		"message": message,
		"async": false,
		"ip_pool": "Main Pool",
		"send_at": moment().subtract(2, 'days').format('YYYY-MM-DD HH:mm:ss')
	}, function (result) {
		console.log("Message sent: " + JSON.stringify(result));
		if (res) {
			res.send({
				success: true,
				data: result
			})
		}

	}, function (error) {
		console.log("Error:", error);
	});

}

export function testPhantom(req, res) {
	const customer_id = req.query.customer_id;
	const order_id = req.query.order_id;
	var _ph, _page, _outObj;
	const FILETYPE = '.pdf';
	capillaryController.capillaryOrderCreation(order_id, 'ORDER');
	db.query('select * from "GetCustomer"(:in_customer_id)', {
		raw: true,
		replacements: {
			in_customer_id: customer_id
		}
	}).then((result) => {
		const customer = result[0][0];
		return db.query('select * from "GetCustomerOrderList"(:in_customer_id)', {
			raw: true,
			replacements: {
				in_customer_id: customer_id
			}
		}).then((result) => {
			const order = _.find(result[0], {
				order_id: parseInt(order_id)
			});
			if (order)
				return customer;
			else
				return false;
		});
	}).then((result) => {
		const customer = result;
		if (result) {
			phantom.create().then(ph => {
				_ph = ph;
				return _ph.createPage();
			}).then(page => {
				_page = page;
				let url = '';
				switch (process.env.TAILORMAN_ENV) {
					case 'PRODUCTION':
						url = 'https://store.tailorman.com';
						break;
					case 'UAT':
						url = 'https://uat-store.tailorman.com';
						break;
					default:
						url = 'http://localhost:4000';
				}
				url += '/invoice/customer/' + customer_id + '/order/' + order_id;
				return _page.open(url);
			}).then(status => {
				setTimeout(() => {
					const filename = "./invoices/" + customer.name.split(" ").join("") + "_" + order_id + "_Invoice" + FILETYPE;
					_page.render(filename, {
						quality: 100
					}).then(() => {
						let content = "<p>Dear " + customer.name + ",</p>";
						content += "<p>Greetings from Tailorman!</p>";
						content += "<p>Your invoice copy is attached with this mail.</p>";
						content += "<p>Please feel free to contact us on 1800 3000 1575 or write us on <a href='mailto:care@tailorman.com'>care@tailorman.com</a> if you have any other queries. </p>";
						content += "<p>Kind regards, <br/> Team Tailorman</p>";
						const file = fs.readFileSync(filename).toString('base64');
						// sendEmail(req, content, customer, [{
						// 	name: customer.name.split(" ").join("") + " Invoice" + FILETYPE,
						// 	content: file,
						// 	type: 'application/pdf'
						// }], order_id,res);
						_page.close();
						_ph.exit();
						res.send('ok');
					})
				}, 15000);
			}).catch(e => console.log(e));
		}
	});
}


export function getPriorityUpcharge(req, res) {
	const item_type_id = req.query.item_type;
	const priority_id = req.query.priority_id;
	db.query('select * from "GetDeliveryUpcharge"(:in_item_type_id)', {
		raw: true,
		replacements: {
			in_item_type_id: item_type_id
		}
	}).then((result) => {
		res.send(result[0]);
	});
}


export function getWorkOrderMeasurementProfile(req, res) {
	const order_item_id = req.query.order_item_id;
	const type = req.query.type;
	let query;
	if (type == 'pattern') {
		query = 'select * from "GetPatternProfile"(:in_order_item_id)';
	} else if (type == 'FGQC') {
		query = 'select * from "GetFGQCProfile"(:in_order_item_id)';
	} else {
		res.send([]);
	}
	db.query(query, {
		raw: true,
		replacements: {
			in_order_item_id: order_item_id
		}
	}).then((result) => {
		res.send(result[0][0])
	});
}

export function getOrderHistory(req, res) {
	db.query('select * from "GetOrderItemHistory"()', {
		raw: true
	}).then((result) => {
		//res.send(result[0]);
		result[0].forEach(updateOrderHistory);
	})
}
export function getOrdersHistory(req, res) {
	const customer_id = req.query.customer_id;
	if (!customer_id) {
		res.status(500).json({
			success: false,
			message: "Email or mobile number already exists"
		});
		return;
	}
	db.query('select * from "GetCustomerOrderHistory"(:in_customer_id)', {
		raw: true,
		replacements: {
			in_customer_id: customer_id
		}
	}).then((result) => {
		res.send(result[0]);
	});
}
export function updateOrderHistory(sale) {
	/* ======== calculate bill amount =======*/
	if (sale.upcharge && _.isArray(sale.upcharge))
		sale.upcharges = sale.upcharge;
	//assume there is no delivery upcharge
	let has_delivery_upcharge = false;
	let total_upcharge = 0;
	//Keep adding upcharge to total_upcharge, exclude delivery upcharge if available.
	total_upcharge = sale.upcharges ? sale.upcharges.reduce((prev, next) => {
		//Check for delivery upcharge
		if (next.type == 'High Priority Delivery') {
			//if available assign the upcharge to has_delivery_upcharge
			has_delivery_upcharge = next;
			return prev;
		}

		//if upcharge.unit = 2, then this is percentage type upcharge, use upcharge.value as percentage value.
		if (next.unit === 2) {
			//The total upcharge needs to be rounded down so if upcharge is 614.6, it becomes 614.
			return prev + Math.floor((sale.mrp * next.value / 100));
		} else {
			return prev + next.value;
		}
	}, 0) : 0;


	//assume bill amount is the MRP, we will add upcharge and discount in the next step
	let bill_amount = sale.mrp + total_upcharge;

	//if the order item has a discount_value column
	if (sale.discount && sale.discount_type) {
		//if discount_type = 2, then this is percentage type discount, use the discount_value column as a percentage value
		if (sale.discount_type === 2) {
			//The total discount has to be floored (rounded down), so if the discount is 550.9 INR it becomes 550 INR.
			bill_amount = sale.mrp + total_upcharge - Math.floor((sale.mrp + total_upcharge) * sale.discount / 100);
			//else discount_value is a normal amount and simply add to the upcharged mrp.
		} else {
			bill_amount = sale.mrp + total_upcharge - sale.discount;
		}
	}


	const discount_amount = ((sale.mrp + total_upcharge) - bill_amount) * sale.qty;

	//total bill amount will be the upcharged and discounted mrp times the order item quantity
	bill_amount = bill_amount * sale.qty;

	let delivery_upcharge = 0;
	//Finally add delivery upcharge if available.
	if (has_delivery_upcharge) {
		bill_amount += (has_delivery_upcharge.value * sale.qty);
		delivery_upcharge = (has_delivery_upcharge.value * sale.qty);
	}

	/* EO Calculate bill amount */
	db.query('select * from "UpdateOrderItemHistory"(:in_order_item_id, :in_upcharge_amount, :in_delivery_upcharge_amount, :in_discount_amount, :in_bill_amount)', {
		raw: true,
		replacements: {
			in_order_item_id: sale.order_item_id,
			in_upcharge_amount: total_upcharge,
			in_delivery_upcharge_amount: delivery_upcharge,
			in_discount_amount: discount_amount,
			in_bill_amount: bill_amount
		}
	}).then((result) => {
		console.log(result[0]);
		console.log("updated", sale.order_item_id);
	});
}

export function getLatestItemTypeComment(req, res) {
	let params = req.query;

	let itemTypeId = params.item_type_id;
	let customerId = params.customer_id;

	let query = `select boi.comment from b_order_item boi LEFT JOIN b_order b ON boi.order_id=b.order_id where boi.item_type_id=${itemTypeId} and b.customer_id=${customerId} order by order_item_id DESC LIMIT 1`;

	db.query(query)
		.then((result) => {
			res.send({
				success: true,
				data: result && result[0] && result[0][0]
			});
		})
		.catch((err) => {
			res.status(500).json({
				success: false,
				error: err
			});
		});
}
function getJsonParsedResponse(result) {
	var formatedResponse = [];
	result.map((item, index) => {
		formatedResponse.push({
			"Receipt_number": item.rcpt_num,
			"Receipt_Date": item.rcpt_dt,
			"Bussiness_Date": item.business_dt,
			"Transaction_Time": item.rcpt_tm,
			"Invoice_amount": item.inv_amt,
			"Discount_amount": item.discount_amount,
			"VAT_Amount": item.tax_amt,
			"Service_Tax_Amount": item.service_tax,
			"ServiceChargeAmount": item.service_charge,
			"Net_sale": item.mrp,
			"Payment_Mode": item.payment_mode,
			"Transaction_status": item.transaction_status
		});
	})
	return formatedResponse;
}


function getXMLParsedResponse(result) {
	var formatedResponse = [];
	var records = [];
	result.map((item, index) => {
		var record = [];

		record = [{ "Receipt_number": item.rcpt_num },
		{ "Receipt_Date": item.rcpt_dt },
		{ "Bussiness_Date": item.business_dt },
		{ "Transaction_Time": item.rcpt_tm },
		{ "Invoice_amount": item.inv_amt },
		{ "Discount_amount": item.discount_amount },
		{ "VAT_Amount": item.tax_amt },
		{ "Service_Tax_Amount": item.service_tax },
		{ "ServiceChargeAmount": item.service_charge },
		{ "Net_sale": item.mrp },
		{ "Payment_Mode": item.payment_mode },
		{ "Transaction_status": item.transaction_status }];
		records.push({
			record
		});
	})
	formatedResponse.push({
		records
	})
	return formatedResponse;
}
export function storetransactions(req, res) {
	const contype = req.headers['content-type'];
	const params = req.query;
	let dateString = `./transactionlog/${moment().format('YYYYMMDDHHmmss')}`;
	let content = `Params data : ${JSON.stringify(params)} \n Header:${JSON.stringify(req.headers)} `;
	fs.writeFile(dateString, content, function (err) {
		if (err) {
			return console.log(err);
		} else {
			let query = 'select * from v_orders_store_7 ';
			if (params.to && params.from) {
				query = `${query} where rcpt_dt between '${params.from}' and '${params.to}'`
			}
			db.query(query).then((result) => {
				if (contype != 'application/xml') {
					var parsedJson = getJsonParsedResponse(result[0]);
					if (req.query.download) {
						res.xls('data.xlsx', parsedJson);
					} else {
						res.send(parsedJson);
					}
				} else {
					var parsedXml = getXMLParsedResponse(result[0]);
					res.set('Content-Type', 'application/xml');
					res.send(xml(parsedXml, { declaration: true }));
				}
			});
		}

	})
}

export function getOrderItemOnlineFabricDetails(req, res) {
	const order_item_id = req.query.order_item_id;
	// const has_discount = req.query.has_discount == 'true' ? true : false;
	// const store_id = req.query.store_id;
	db.query(`select * from b_order_item_fabric_design where order_item_id=${order_item_id}`).then((result) => {

		res.send(result[0]);
	});
}
export function getOrderItemOnlineMeasurements(req, res) {
	const order_item_id = req.query.order_item_id;
	// const has_discount = req.query.has_discount == 'true' ? true : false;
	// const store_id = req.query.store_id;
	db.query(`select * from b_order_item_fabric_measurement where order_item_id=${order_item_id}`).then((result) => {

		res.send(result[0]);
	});
}
export function getOrderItemOnlineStyleBucketDetails(req, res) {
	const order_item_id = req.query.order_item_id;
	db.query(`select its.style from item_type_style its LEFT JOIN b_order_item boi ON boi.style_code = its.code where boi.order_item_id=${order_item_id}`).then((result) => {

		res.send(result[0]);
	});
}

export function updateCustomerAddressType(req, res) {
	console.log('REQQ BODYY', req.body);
	const address_type = req.body.value[0];
	const customer_address_id = req.body.customer_address_id;

	db.query(`update m_customer_addresses set address_type = '${address_type}' where m_customer_addresses_id = ${customer_address_id}`).then((result) => {

		res.send(result[0]);
	});
}

export function stockUpdate(req, res) {
	let values = '(';
	let notExistProducts = [];

	const reqBody = req.body;

	const quantity = reqBody.value;
	const productCode = reqBody.supplier_product_code;
	const isWebApplicablility = reqBody.isWebApplicablility;

	let updateSetter = `in_stock_qty=${quantity}`;

	let verifyQuery = 'select supplier_product_code from m_fabric where supplier_product_code IN ';

	productCode.map((item) => {
		values += `'${item}',`;
	});

	values = values.slice(0, -1).concat(")");

	verifyQuery += values;

	db.query(verifyQuery)
		.then((result) => {
			if (productCode.length != result[0].length) {
				productCode.map((item) => {
					if (!_.find(result[0], { supplier_product_code: item })) {
						notExistProducts.push(item);
					}
				});
			}

			updateSetter = (quantity != 1) ? updateSetter : updateSetter.concat(`,isavailableforweb=${isWebApplicablility}`);

			const updateQuery = `update m_fabric set ${updateSetter} where supplier_product_code IN ${values}`;

			return db.query(updateQuery)
				.then((value) => {
					return res.send({
						success: true,
						not_exist: notExistProducts
					});
				})
				.catch((err) => {
					return res.status(500).json({ success: false, error: err });
				});
		})
		.catch((err) => {
			return res.status(500).json({ success: false, error: err });
		});
}
export function sendGiftVocherEmail(order_id, user_email) {
	db.query(`select total_amount,mu.email AS user_email,mu.fname AS user_name,mc.email AS customer_email,mc.name AS customer_name,ms.email AS store_email from b_order bo LEFT JOIN m_user mu ON bo.user_id = mu.user_id LEFT JOIN m_customer mc ON mc.customer_id = bo.customer_id LEFT JOIN m_store ms ON ms.store_id = bo.store_id where bo.order_id = ${order_id}`).then((data) => {
		if (data[0] && data[0].length > 0) {
			var response = data[0][0];
			// const mandrill_client = new Mandrill('P8PB1qLj9O75t1TMPZ3VpA');
			let to_email = [{
				email: user_email,//Store Ops Punching Person
				name: response.user_name,
				type: 'to'
			}];
			const ENV = process.env.TAILORMAN_ENV;
			if (ENV == "PRODUCTION") {
				to_email[0].type = "bcc";
				to_email.push({
					email: "data@tailorman.com",
					name: "PPD",
					type: "to"
				});
			}
			to_email.push({
				email: response.customer_email,
				name: response.customer_name,
				type: "bcc"
			});
			if (response.store_email) {
				to_email.push({
					email: response.store_email,
					name: 'TM Store User',
					type: "bcc"
				});
			}
			const mandrill_client_gift_email = new Mandrill('P8PB1qLj9O75t1TMPZ3VpA');
			const message = {
				text: `Gift Card Purchased
				Total Amount - ${response.total_amount} 
				Gift Order_id : ${order_id}`,
				subject: 'Gift Card Purchase',
				from_email: 'care@tailorman.com',
				from_name: 'Tailorman Care',
				to: to_email,
				"inline_css": true,
				"merge": true,
				"auto_text": true,
				"merge_language": "handlebars",
				"global_merge_vars": [
					{
						"name": "products",
						"content": response
					}
				]
			};
			mandrill_client_gift_email.messages.send({
				"message": message,
				"async": false,
				"ip_pool": "Main Pool",
				"send_at": moment().subtract(2, 'days').format('YYYY-MM-DD HH:mm:ss')
			});
		}

	}).catch((err) => {
		console.log('Error Unable to Send the Gift Vocher Email', err);
	});
}
export function proceedGiftVoucherEmail(order_obj) {
	const mandrill_client = new Mandrill('P8PB1qLj9O75t1TMPZ3VpA');
	let to_email = [{
		email: order_obj.recepient_email,
		name: order_obj.recepient_name,
		type: 'to'
	}];
	const message = {
		text: order_obj.coupon_code,
		subject: 'Gift Card Details',
		from_email: 'care@tailorman.com',
		from_name: 'Tailorman Care',
		to: to_email,
		"inline_css": true,
		"merge": true,
		"auto_text": true,
		"merge_language": "handlebars",
		"global_merge_vars": [
			{
				"name": "products",
				"content": order_obj
			}
		]
	}
	mandrill_client.messages.send({
		"message": message,
		"async": false,
		"ip_pool": "Main Pool",
		"send_at": moment().subtract(2, 'days').format('YYYY-MM-DD HH:mm:ss')
	}, function () {
		db.query(`update gift_vocher SET last_email_sent =:recipient_email where gift_vocher_id = :in_gift_vocher_id`, {
			raw: true,
			replacements: {
				in_gift_vocher_id: order_obj.gift_vocher_id,
				recipient_email: order_obj.recepient_email
			}
		});
	});
}
export function proceedAbondanedCartEmail(order_obj) {
	const mandrill_client = new Mandrill('P8PB1qLj9O75t1TMPZ3VpA');
	let to_email = [{
		email: order_obj.email,
		name: order_obj.name,
		type: 'to'
	}];
	const message = {
		text: '',
		subject: 'Abandoned cart',
		from_email: 'care@tailorman.com',
		from_name: 'Tailorman Care',
		to: to_email,
		"inline_css": true,
		"merge": true,
		"auto_text": true,
		"merge_language": "handlebars",
		"global_merge_vars": [
			{
				"name": "products",
				"content": order_obj.order_items_list
			}
		]
	}
	mandrill_client.messages.sendTemplate({
		"template_name": "abandoned cart final",
		"template_content": [
			{
				"name": "Items Waiting on Your Cart",
				"content": "Items Waiting on your Cart"
			}
		],
		"message": message,
		"async": false,
		"ip_pool": "Main Pool",
		"send_at": moment().subtract(2, 'days').format('YYYY-MM-DD HH:mm:ss')
	}, function (result) {

		db.query('update b_order SET abon_mail_status = true where order_id = :in_order_id', {
			raw: true,
			replacements: {
				in_order_id: order_obj.order_id
			}
		});
	}, function (error) {

	});
}
export function proceedPIEmail(order_id, res, req) {
	const ENV = process.env.TAILORMAN_ENV;
	var user_email = (req.user) ? req.user.email : 'data@tailorman.com';
	if (!order_id) {
		res.send({
			success: false,
			error: 'Required Parameters are missing in the payload'
		});
		return false;
	}
	getCalculatedInvoiceData(order_id, "INVOICE").then((respone) => {
		if (!respone.orderDetails.customer_email) {
			console.log('PI Email Failure Due to Missing CustomerEmail - ', order_id);
			res.send({
				success: false,
				error: 'Unable to send the PI email since the email Id is Missing for the customer'
			});
			return false;
		}

		const mandrill_client = new Mandrill('P8PB1qLj9O75t1TMPZ3VpA');
		let to_email = [{
			// email : user_email,
			email: respone.orderDetails.customer_email,
			name: respone.orderDetails.customer_name,
			type: 'to'
		}];
		if (ENV == "PRODUCTION") {
			to_email[0].type = "bcc";
			to_email.push({
				email: "data@tailorman.com",
				name: "PPD",
				type: "to"
			});
		}
		to_email.push({
			email: user_email,
			name: respone.orderDetails.customer_name,
			type: "bcc"
		});
		if (respone.orderDetails.store_email) {
			to_email.push({
				email: respone.orderDetails.store_email,
				name: respone.orderDetails.customer_name,
				type: "bcc"
			});
		}
		// res.send({
		// 	to_email
		// });
		// return;
		const half_amount = respone.orderDetails.half_amount || 0;
		const message = {
			text: '',
			subject: 'Thank you for shopping',
			from_email: 'care@tailorman.com',
			from_name: 'Tailorman Care',
			to: to_email,
			"inline_css": true,
			"merge": true,
			"auto_text": true,
			"merge_language": "handlebars",
			"global_merge_vars": [
				{
					"name": "ordNumber",
					"content": respone.orderDetails.order_id
				},
				{
					"name": "ordPlacedOn",
					"content": respone.orderDetails.order_date
				},
				{
					"name": "products",
					"content": respone.orderItems
				},
				{
					"name": "totalAmount",
					"content": respone.orderDetails.total_bill_amount
				},
				{
					"name": "totalAmountInWords",
					"content": respone.orderDetails.amount_in_words
				}, {
					"name": "amountPayed",
					"content": respone.orderDetails.half_amount
				}, {
					"name": "balanceAmount",
					"content": (respone.orderDetails.total_bill_amount - respone.orderDetails.half_amount)
				}, {
					"name": "PaymentPending",
					"content": ((respone.orderDetails.full_payment_flag == "Y" || half_amount == 0) ? false : true)
				}
			],
			"merge_vars": [
				{
					"rcpt": "recipient@example.com",
					"vars": [
						{
							"name": "ordNumber",
							"content": "478366238"
						}
					]
				}
			]
		}
		mandrill_client.messages.sendTemplate({
			"template_name": "Thank you for shopping",
			"template_content": [
				{
					"name": "Thank you for shopping",
					"content": "Thank you for shopping"
				}
			],
			"message": message,
			"async": false,
			"ip_pool": "Main Pool",
			"send_at": moment().subtract(2, 'days').format('YYYY-MM-DD HH:mm:ss')
		}, function (result) {

			db.query('update b_order SET pi_email_status = true where order_id = :in_order_id', {
				raw: true,
				replacements: {
					in_order_id: order_id
				}
			}).then(() => {
				res.send({
					success: true
				});
			});
		}, function (error) {
			res.send({
				success: false,
				error: error
			});
		});
		// res.send({
		// 	data: respone
		// });
	});
}
export function sendPiEmail(req, res) {
	const order_id = req.query.order_id;
	const duplicate = req.query.duplicate || false;
	if (order_id) {
		if (duplicate) {
			proceedPIEmail(order_id, res, req);
		} else {
			db.query('select pi_email_status from b_order where order_id = :in_order_id', {
				raw: true,
				replacements: {
					in_order_id: order_id
				}
			}).then((respone) => {
				if (respone[0] && respone[0][0] && respone[0][0].pi_email_status) {
					res.status(500).json({
						success: false,
						error: 'PI Email already Sent'
					});
				} else {
					proceedPIEmail(order_id, res, req);
				}
			})
		}
	} else {
		return res.status(500).json({ success: false, error: 'Order Id is missing' });
	}
}

export function getInvoiceDetails(req, res) {

	const order_id = req.query.order_id;
	const download = req.query.download || false;
	var customer = req.query.customer || false;
	if (!download) {
		capillaryController.capillaryOrderCreation(order_id, 'ORDER');
	}
	getInvoiceFormatedData(order_id).then((data) => {
		const filename = "./invoices/" + data.orderDetails.customer_name.split(" ").join("") + "_" + data.orderDetails.order_id + "_Invoice.pdf";
		var pdfDoc = printer.createPdfKitDocument(data.pdfMakeDoc);
		let writeStream = fs.createWriteStream(filename);
		pdfDoc.pipe(writeStream);
		pdfDoc.end();
		writeStream.on('finish', function () {
			const file = fs.readFileSync(filename);
			if (download) {
				res.contentType("application/pdf");
				res.send(file);
			} else {

				var customer_obj = {
					is_customer: customer,
					customer_email: data.orderDetails.customer_email,
					name: data.orderDetails.customer_name
				};
				var store_email = data.orderDetails.store_email;
				let content = "<p>Dear " + data.orderDetails.customer_name + ",</p>";
				content += "<p>Greetings from Tailorman!</p>";
				content += "<p>Your invoice copy is attached with this mail.</p>";
				content += "<p>Please feel free to contact us on 1800 3000 1575 or write us on <a href='mailto:care@tailorman.com'>care@tailorman.com</a> if you have any other queries. </p>";
				content += "<p>Kind regards, <br/> Team Tailorman</p>";

				sendEmail(req, content, customer_obj, [{
					name: data.orderDetails.customer_name.split(" ").join("") + " Invoice.pdf",
					content: file.toString('base64'),
					type: 'application/pdf'
				}], order_id, res, store_email);
			}
		});
	});
}

export function getReceiptDetails(req, res) {

	const order_id = req.query.order_id;
	var customer = req.query.customer || false;
	const download = req.query.download || false;

	getReceiptFormatedData(order_id).then((data) => {
		// res.send({
		// 	order : data,
		// 	data : data.pdfMakeDoc
		// });
		// return;
		const filename = "./receipts/" + data.orderDetails.customer_name.split(" ").join("") + "_" + data.orderDetails.order_id + "_Receipt.pdf";
		var pdfDoc = printer.createPdfKitDocument(data.pdfMakeDoc);
		let writeStream = fs.createWriteStream(filename);
		pdfDoc.pipe(writeStream);
		pdfDoc.end();
		writeStream.on('finish', function () {
			const file = fs.readFileSync(filename);
			if (download) {
				res.contentType("application/pdf");
				res.send(file);
			} else {

				var customer_obj = {
					is_customer: customer,
					customer_email: data.orderDetails.customer_email,
					name: data.orderDetails.customer_name
				};
				var store_email = data.orderDetails.store_email;
				let content = "<p>Dear " + data.orderDetails.customer_name + ",</p>";
				content += "<p>Greetings from Tailorman!</p>";
				content += "<p>Your receipt copy is attached with this mail.</p>";
				content += "<p>Please feel free to contact us on 1800 3000 1575 or write us on <a href='mailto:care@tailorman.com'>care@tailorman.com</a> if you have any other queries. </p>";
				content += "<p>Kind regards, <br/> Team Tailorman</p>";
				const file = fs.readFileSync(filename).toString('base64');
				sendEmail(req, content, customer_obj, [{
					name: data.orderDetails.customer_name.split(" ").join("") + " Receipt.pdf",
					content: fs.readFileSync(filename).toString('base64'),
					type: 'application/pdf'
				}], order_id, res, store_email);
			}
		});
	});
}

const insertCustomerAddress = (req, res) => {
	const formValues = req.body;


	const in_customer_id = formValues.customer_id || req.query.customer_id;
	const address = formValues.addressText.replace(/'/g, "''");
	const address_type = formValues.address_type;
	const m_customer_addresses_id = formValues.m_customer_addresses_id;

	db.query(`select * from "InsertCustomerAddress"(${in_customer_id},'${address}','${address_type}',${m_customer_addresses_id})`).then((result) => {
		res.send({
			status: 'success',
			message: 'Added Cart Adress successfully'
		})
	}).catch(err => {
		console.log(err);
		res.send({
			status: 'failure',
			error: err,
			message: 'Failed to update'
		})
	});
};



export function updateUpcharge(req, res) {
	const formValues = req.body;
	const order_item_id = formValues.order_item_id;
	const order_id = formValues.order_id;
	const upcharge = JSON.stringify(formValues.upcharge) || '[]';
	if (!order_item_id || !order_id) {
		res.status(500).json({
			success: false,
			error: 'Missing Order Item ID Details'
		});
		return;
	}
	db.query(`select o.order_id,o.international_shipping_charges,(select (array_to_json(array_agg(b_order_item))) FROM b_order_item where b_order_item.order_id = o.order_id) as order_items  from b_order o where o.order_id = ${order_id}`).then((result) => {
		if (result[0].length > 0) {
			let order_details = result[0][0];
			let order_item_details = order_details.order_items;
			let total_amount = 0;
			order_item_details = order_item_details && order_item_details.map((_order_item) => {
				if (_order_item.order_item_id == order_item_id) {
					_order_item.upcharge = upcharge;
					_order_item = updateOrderItemCalculation(_order_item);
					total_amount += parseFloat(_order_item.bill_amount);
					return _order_item;
				}
				total_amount += parseFloat(_order_item.bill_amount);
				return _order_item;
			});
			order_details.international_shipping_charges = parseFloat(order_details.international_shipping_charges) || 0;
			order_details.total_amount = (total_amount + order_details.international_shipping_charges);
			let promiseArray = [];
			promiseArray.push(db.query(`update b_order SET total_amount = ${order_details.total_amount} where order_id = ${order_details.order_id}`));
			order_item_details && order_item_details.map((_order_item) => {
				promiseArray.push(db.query(`update b_order_item SET upcharge = '${JSON.stringify(_order_item.upcharge)}',taxes = '${JSON.stringify(_order_item.taxes)}', bill_amount = ${_order_item.bill_amount} , upcharge_amount = ${_order_item.upcharge_amount} where order_item_id = ${_order_item.order_item_id}`));
			});
			Promise.all(promiseArray).then(() => {
				res.json({
					success: true,
					message: 'Updated the Details SuccessFully'
				});
			});

		} else {
			res.status(500).json({
				success: false,
				error: 'Could Not Find the Order Details in the DB'
			});
		}
	}).catch(err => {
		// console.log(err);
		res.send({
			status: 'failure',
			error: err,
			message: 'Failed to Fetch the Details'
		})
	});
};
export function getItemTypeDropDownList(req, res) {
	const item_type_id = req.query.item_type_id;
	var url = "select item_type_style_dropdownlist_id,button_sku as id,button_sku as name, button_type,descr,supplier_product_code,upcharge,item_type_id,is_lining,lining_width from item_type_style_dropdownlist where item_type_id is null";
	if (item_type_id) {
		url = `select item_type_style_dropdownlist_id,button_sku as id,button_sku as name, button_type,descr,supplier_product_code,upcharge,item_type_id,is_lining from item_type_style_dropdownlist where item_type_id=${item_type_id}`;
	}
	// const has_discount = req.query.has_discount == 'true' ? true : false;
	// const store_id = req.query.store_id;
	db.query(url).then((result) => {
		res.send(result[0]);
	});
}
const updateDefaultCustomerAddress = (req, res) => {
	const formValues = req.body;
	if (!formValues.address_type || !formValues.m_customer_addresses_id || !formValues.m_customer_id) {
		res.status(500).json({ success: false, error: 'Missing Details' });
		return;
	}
	db.query(`update m_customer_addresses set default_address = false where m_customer_id = '${formValues.m_customer_id}' AND address_type = '${formValues.address_type}'`)
		.then((result) => {
			db.query(`update m_customer_addresses set default_address = true where m_customer_addresses_id = ${formValues.m_customer_addresses_id} AND address_type = '${formValues.address_type}'`).then(() => {
				res.send({
					status: true,
					data: formValues
				});
			}).catch(err => {
				res.status(500).json({ success: false, error: 'Failed to Update in DB' });
			});
		}).catch(err => {
			res.status(500).json({ success: false, error: 'Failed to Update in DB' });
		});
};

export function calculateOrderItemUpcharges(orderItem, upcharge_type) {
	var totalOrderItemUpcharge = 0;
	orderItem.upcharges.map((item, index) => {
		if (item.type != 'High Priority Delivery') {
			if ((item.unit == 1) && (item.upcharge_type == upcharge_type))
				totalOrderItemUpcharge = totalOrderItemUpcharge + parseInt(item.value);
			else if ((item.unit == 2) && (item.upcharge_type == upcharge_type))
				totalOrderItemUpcharge = totalOrderItemUpcharge + Math.floor(sale.mrp * item.value / 100);
			else if (item.value)
				totalOrderItemUpcharge = totalOrderItemUpcharge + parseInt(item.value);
		} else {
			totalOrderItemUpcharge = totalOrderItemUpcharge;
		}
	});

	return totalOrderItemUpcharge;

}
export function calculateUpcharges(sales, upcharge_type) {
	var totalUpchargeAmount = 0;
	sales.map((orderItem, index) => {
		totalUpchargeAmount = totalUpchargeAmount + calculateOrderItemUpcharges(orderItem, upcharge_type);

	});

	return totalUpchargeAmount;

}
export function calculateMeasurementUpcharges(sales, upcharge_type) {
	var totalOrderItemUpcharge = 0;
	var measurementUpchargeArray = [];
	sales.map((sale, index) => {
		if (sale.profile && sale.profile.measurements && sale.profile.measurements.length > 0) {

			console.log("upcharges.concat(_.compact(_.map(sale.profile.measurements, 'upcharge')));", _.compact(_.map(sale.profile.measurements, 'upcharge')));
			measurementUpchargeArray = _.compact(_.map(sale.profile.measurements, 'upcharge'));

			measurementUpchargeArray.map((item, index) => {
				if (item.type != 'High Priority Delivery') {
					if (item.unit == 1)
						totalOrderItemUpcharge = totalOrderItemUpcharge + parseInt(item.value);
					else if (item.unit == 2) {
						console.log("upcharge", Math.floor(sale.mrp * item.value / 100), item.value);
						totalOrderItemUpcharge = totalOrderItemUpcharge + Math.floor(sale.mrp * item.value / 100);
					}
					else if (item.value)
						totalOrderItemUpcharge = totalOrderItemUpcharge + parseInt(item.value);
				} else {
					totalOrderItemUpcharge = totalOrderItemUpcharge;
				}
			});
		}

	});


	return totalOrderItemUpcharge;

}
export function getLoyalityTierTransaction(req, res) {
	let params = req.query;
	let customerId = params.customer_id;
	if (!customerId) {
		res.status(500).json({
			success: false,
			error: 'Customer Details Missing Could Not Fetch the transactions'
		});
		return;
	}
	const transaction_query = `SELECT  
	ROW_NUMBER () OVER (ORDER BY ccct.capilary_charge_customer_trx_id) as sc_no,
	ccct.order_id as order_number,
	bo.order_date as order_date,
	ccct.discount_amount as discount_amount,
	cc.name as discount_type,
	ct.name as discount_tier
	from capilary_charge_customer_trx ccct 
	left join b_order bo on bo.order_id = ccct.order_id
	left join capilary_charge_rules ccr on ccr.capilary_charge_rules_id = ccct.capilary_charge_rules_id
	left join capilary_charges cc on cc.capilary_charges_id = ccr.capilary_charges_id
	left join capilary_tiers ct on ct.capilary_tiers_id = ccr.capilary_tiers_id
	where ccct.fyearid = "GetFYear"(now()::date) and ccct.customer_id = ${customerId};`;
	db.query(transaction_query).then((result) => {
		res.send({
			status: true,
			data: result[0]
		})
	}).catch(() => {
		res.status(500).json({
			success: false,
			error: 'unable to process the request'
		});
	});

}
export function getLoyalityTierDiscount(req, res) {

	const reqbody = req.body;
	const customer_id = reqbody.customer_id;
	const order_id = reqbody.order_id;
	const store_id = reqbody.store_id;
	if (!customer_id || !order_id || !store_id) {
		res.status(500).json({ success: false, error: 'Details Missing Could Not able to fetch the discounts' });
		return;
	}
	capillaryController.getCustomerDetails(customer_id, store_id).then((data) => {
		if (!data[0].current_slab) {
			res.status(500).json({ success: false, error: 'Current Slab Details Missing in the Capillary' });
			return true;
		}

		/**
	 * making the capillary Request and Getting the customer Details
	 * To Do make Tier Dyanimic Assuming the current Tier as GOLD
	 */
		/**
		 * Getting all the Tier Rules along with the discount feature
		 */
		const Discounts_Query = `select "GetFYear"(now()::date) as fyearid,ccr.capilary_charge_rules_id,cpt.code,cc.name,cc.code as charge_code,ccct.discount as discount_amount,ccct.order_id,ccr.min_amount,ccr.max_amount,ccr.max_orders,ccr.discount_type,ccct.order_count from capilary_charge_rules as ccr
	left join capilary_tiers cpt on cpt.capilary_tiers_id = ccr.capilary_tiers_id
    left join capilary_charges cc on cc.capilary_charges_id = ccr.capilary_charges_id
	 left join ( 
		 select 
			capilary_charge_rules_id,
			array_to_string(array_agg(order_id), ',') as order_id, 
			count(order_id) as order_count,
			sum(discount_amount) as discount from capilary_charge_customer_trx where fyearid =  "GetFYear"(now()::date) and customer_id = ${customer_id}
			group by capilary_charge_rules_id ) 
			as ccct on ccr.capilary_charge_rules_id = ccct.capilary_charge_rules_id where cpt.code = '${data[0].current_slab}';`;
		return db.query(Discounts_Query).then((result) => {
			if (result[0].length > 0) {
				let discountApplied = false;
				let applicableDiscounts = [];
				result[0].map((data) => {
					if (data.order_id && data.order_id.indexOf(order_id) != -1) {
						discountApplied = true;
					}
					let discount_amount = data.discount_amount || 0;
					if (data.max_amount == 0 || data.max_amount > discount_amount) {
						let order_count = data.order_count || 0;
						if (data.discount_type == "MULTIPLE" && data.max_orders > order_count) {
							let min_amount = data.min_amount || 0;
							if (min_amount == 0 || reqbody.totalOrderAmount >= data.min_amount) {
								applicableDiscounts.push(data);
							}
						}
						if (data.discount_type == "SINGLE" && order_count == 0) {
							let min_amount = data.min_amount || 0;
							if (min_amount == 0 || reqbody.totalOrderAmount >= data.min_amount) {
								applicableDiscounts.push(data);
							}
						}
					}
				});
				if ((discountApplied) || (applicableDiscounts && applicableDiscounts.length == 0)) {
					res.send({
						success: true,
						message: 'No Discounts applicable for the current Customer'
					});
				} else {
					/**
					 * We are sending all the applicable discounts to the Requested User.
					 */
					applicableDiscounts.map((discount) => {
						let discount_amount = discount.discount_amount || 0;
						if (discount.max_amount == 0 && discount_amount == 0) {
							discount.discount = reqbody[discount.charge_code];
						} else if (discount.max_amount != 0) {
							let discount_applicable = (discount.max_amount - discount_amount);
							if (discount_applicable <= reqbody[discount.charge_code]) {
								discount.discount = discount_applicable;
							} else {
								discount.discount = reqbody[discount.charge_code];
							}
						}
					});
					res.send({
						success: true,
						data: applicableDiscounts,
						message: 'Successfully received all the applicable Discounts'
					});
				}
			} else {
				res.send({
					success: true,
					message: 'No Discounts applicable for the current Customer'
				});
			}
			return true;
		});
	}).catch(() => {
		res.send({
			success: true,
			message: 'Request Failed please contact support for more Details on this'
		});
	});
}

// export function getLoyalityTierDiscount(req, res) {
// 	const current_tier = req.body.current_tier;
// 	const order_id = req.body.order_id;
// 	const customer_id =req.body.customer_id;
// 	const discount_type =req.body.discount_type;
// 	const sales = req.body.sales;
// 	console.log("sales",sales);

// 	const styling_upcharge =calculateUpcharges(sales,"order_styling");
// 	const measurement_upcharge =calculateMeasurementUpcharges(sales);
// 	debugger;
// 		console.log("upcharges@@@@@",styling_upcharge,measurement_upcharge);
// 	db.query(`select * from capilary_charge_customer_trx cct LEFT JOIN capilary_charge_rules ccr ON ccr.capilary_charge_rules_id =cct.capilary_charge_rules_id where cct.order_id=${order_id}`).then((result) => {
// 		console.log("result@@@@@",result);

// 		if(result[0].length >0){
// 			var resultArray = result[0];
// 			var applyMeasurement = true, applyStyling = true;
// 			resultArray.map((item,index)=>{
//                 if(item.name =='Order Measurements'){
// 					applyMeasurement = false;
// 				}
// 				if(item.name =='Order Styling'){
// 					applyStyling = false;
// 				}
// 			});
// 			if(applyMeasurement){
// 				db.query(`select  count(*) from capilary_charge_customer_trx  cct LEFT JOIN capilary_charge_rules ccr ON ccr.capilary_charge_rules_id =cct.capilary_charge_rules_id where cct.customer_id=${customer_id} and ccr.name='Order Measurements'`).then((existingMeasurementTrx)=>{
// 					var measurementTrxCount = existingMeasurementTrx[0][0].count;

// 					db.query(`select ccr.max_orders,ct.fyearid from capilary_charge_rules ccr LEFT JOIN capilary_tiers ct ON ct.capilary_tiers_id =ccr.capilary_tiers_id LEFT JOIN capilary_charges cc ON cc.capilary_charges_id = ccr.capilary_charges_id where ccr.name='Order Measurements' and ct.name ='GOLD'`).then((availableMeasurementResult)=>{
// 					   var availableMeasurement =availableMeasurementResult[0][0].max_orders;
// 						  if(availableMeasurement && availableMeasurement >measurementTrxCount){
// 							var disCountObj ={
// 								measurement_discount: measurement_upcharge,
// 							    styling_discount: resultArray[0].discount_amount
// 							}

// 							 res.send([disCountObj])
// 						  }else{
// 							 res.send(result[0]);  
// 						  }

// 					})

// 				})
// 			}else if(applyStyling){
// 			  db.query(`select  sum(discount_amount) from capilary_charge_customer_trx  cct LEFT JOIN capilary_charge_rules ccr ON ccr.capilary_charge_rules_id =cct.capilary_charge_rules_id where cct.customer_id=${customer_id} and ccr.name='Order Styling'`).then((existingStylingTrx)=>{
// 			   var existingStylingDiscount = result2[0][0].sum || 0;
// 			    db.query(`select ccr.name,ccr.capilary_charge_rules_id,ccr.min_amount,ccr.max_amount,ccr.max_orders,ct.fyearid from capilary_charge_rules ccr LEFT JOIN capilary_tiers ct ON ct.capilary_tiers_id =ccr.capilary_tiers_id LEFT JOIN capilary_charges cc ON cc.capilary_charges_id = ccr.capilary_charges_id where ccr.name='${discount_type}' and ct.name ='GOLD'`).then((avaiableStylingDiscount) => {
// 				    var max_amount=avaiableStylingDiscount[0][0].max_amount;
// 				  var min_amount =avaiableStylingDiscount[0][0].min_amount;
// 				  var applyDiscount = 0;  
// 				 if(discount_amount>0){
// 					 avaiableStylingDiscount[0][0].max_amount = max_amount-discount_amount;
// 					 if(min_amount>avaiableStylingDiscount[0][0].max_amount){
// 						 avaiableStylingDiscount[0][0].min_amount =avaiableStylingDiscount[0][0].max_amount; 
// 					 }
// 				 }
// 				   if(styling_upcharge>0 && avaiableStylingDiscount[0][0].max_amount>0){
// 					if(styling_upcharge>=avaiableStylingDiscount[0][0].min_amount){
// 							applyDiscount = avaiableStylingDiscount[0][0].min_amount;
// 							if(styling_upcharge>= avaiableStylingDiscount[0][0].max_amount){
// 							applyDiscount = avaiableStylingDiscount[0][0].max_amount; 
// 							}else if((styling_upcharge < avaiableStylingDiscount[0][0].max_amount) && (styling_upcharge >avaiableStylingDiscount[0][0].min_amount) ){
// 							applyDiscount =styling_upcharge;
// 							}
// 					}
// 				   }
// 				   var disCountObj ={
// 							measurement_discount: measurement_upcharge,
// 							styling_discount:applyDiscount
// 						}

// 				   res.send([disCountObj])


// 				});


// 			  });

// 			}else{
// 			   res.send(result[0]);
// 			}
// 		}else{
// 			db.query(`select  sum(discount_amount) from capilary_charge_customer_trx  cct LEFT JOIN capilary_charge_rules ccr ON ccr.capilary_charge_rules_id =cct.capilary_charge_rules_id where cct.customer_id=${customer_id} and ccr.name='Order Styling'`).then((result2) => {

// 			var discount_amount = result2[0][0].sum || 0;
// 			console.log("discount_amount",discount_amount);

//           db.query(`select ccr.name,ccr.capilary_charge_rules_id,ccr.min_amount,ccr.max_amount,ccr.max_orders,ct.fyearid from capilary_charge_rules ccr LEFT JOIN capilary_tiers ct ON ct.capilary_tiers_id =ccr.capilary_tiers_id LEFT JOIN capilary_charges cc ON cc.capilary_charges_id = ccr.capilary_charges_id where ccr.name='${discount_type}' and ct.name ='GOLD'` ).then((avaiableStylingDiscount) => {
// 			  			console.log("avaiableStylingDiscount",avaiableStylingDiscount);

// 				 var max_amount=avaiableStylingDiscount[0][0].max_amount;
// 				  var min_amount =avaiableStylingDiscount[0][0].min_amount;
// 				  var discountObj={};
// 				  var applyDiscount =0;	  
// 				 if(discount_amount>0){
// 					 avaiableStylingDiscount[0][0].max_amount = max_amount-discount_amount;
// 					 if(min_amount>avaiableStylingDiscount[0][0].max_amount){
// 						 avaiableStylingDiscount[0][0].min_amount =avaiableStylingDiscount[0][0].max_amount; 
// 					 }
// 				 }

// 			   	if(styling_upcharge>0 && avaiableStylingDiscount[0][0].max_amount>0){
// 					if(styling_upcharge>=avaiableStylingDiscount[0][0].min_amount){
// 							applyDiscount = avaiableStylingDiscount[0][0].min_amount;
// 							if(styling_upcharge>= avaiableStylingDiscount[0][0].max_amount){
// 							applyDiscount = avaiableStylingDiscount[0][0].max_amount; 
// 							}else if((styling_upcharge < avaiableStylingDiscount[0][0].max_amount) && (styling_upcharge >avaiableStylingDiscount[0][0].min_amount) ){
// 							applyDiscount =styling_upcharge;
// 							}
// 					}
// 				   }
// 				   var disCountObj ={
// 							styling_discount:applyDiscount
// 						}

// 			    	db.query(`select  count(*) from capilary_charge_customer_trx  cct LEFT JOIN capilary_charge_rules ccr ON ccr.capilary_charge_rules_id =cct.capilary_charge_rules_id where cct.customer_id=${customer_id} and ccr.name='Order Measurements'`).then((existingMeasurementTrx)=>{
// 					var measurementTrxCount = existingMeasurementTrx[0][0].count;

// 					db.query(`select ccr.max_orders,ct.fyearid from capilary_charge_rules ccr LEFT JOIN capilary_tiers ct ON ct.capilary_tiers_id =ccr.capilary_tiers_id LEFT JOIN capilary_charges cc ON cc.capilary_charges_id = ccr.capilary_charges_id where ccr.name='Order Measurements' and ct.name ='GOLD'`).then((availableMeasurementResult)=>{
// 					   var availableMeasurement =availableMeasurementResult[0][0].max_orders;
// 						  if(availableMeasurement && availableMeasurement >measurementTrxCount){

// 								disCountObj.measurement_discount= measurement_upcharge;

// 							 res.send([disCountObj])
// 						  }else{
// 							  disCountObj.measurement_discount =0;
// 							 res.send([disCountObj]);  
// 						  }

// 					});

// 				});


// 		});
// 		});
// 		}

// 	});
// }

// export function updatePendingAmount(req, res) {
// 	const _details = req.body;
// 	const pending_amount = _details.pending_amount;
// 	if (pending_amount) {
// 		let promiseArray = [];
// 		pending_amount.map((_disc) => {
// 			promiseArray.push(db.query(`insert into c_order_payment (order_id,store_id,payment_mode,reference,amount,created_by,created) values(${_details.order_id},${_details.store_id},'${_disc.payment_mode}','${_disc.reference}',${parseInt(_disc.amount)},${_details.user_id},now())`));
// 		});

// 		Promise.all(promiseArray).then(() => {
// 			res.json({ order_id: _details.order_id });
// 		});

// 	}
// }

export function updateStorePendingAmount(req, res) {
	const _details = req.body;
	let pending_amount = _details.pending_amount || [];
	pending_amount = _.filter(pending_amount, (o) => {
		return !o.c_order_payment_id;
	});
	if (pending_amount) {
		let promiseArray = [];
		pending_amount.map((_disc) => {
			promiseArray.push(db.query(`insert into c_order_payment (order_id,store_id,payment_mode,reference,amount,created_by,created) values(${_details.order_id},${_details.store_id},'${_disc.payment_mode}','${_disc.reference}',${parseInt(_disc.amount)},${req.user.user_id},now())`));
		});
		Promise.all(promiseArray).then(() => {
			res.json({ order_id: _details.order_id });
		});

	}
}
export function updatePendingOrderDetails(req, res) {
	console.log('REQQ BODYY', req.body);
	const formValues = req.body;
	const order_id = formValues.order_id;

	const occation_date = formValues.occasion_date ? moment(formValues.occasion_date).format('YYYY-MM-DD') : null;
	const benificiary_name = formValues.benificiary_name;
	const benificiary_email = formValues.benificiary_email;
	const benificiary_phone = formValues.benificiary_phone;
	const tailor_id = formValues.tailor_id;
	const salesman_id = formValues.salesman_id;
	const occasion = formValues.occasion;
	const delivery_location_id = formValues.delivery_location_id;
	const fiton_location_id = formValues.fiton_location_id;

	let query;

	if (occation_date) {
		query = `update b_order set occation_date = '${occation_date}',benficiary_name='${benificiary_name}',benficiary_mobile='${benificiary_phone}',benificiary_email='${benificiary_email}',tailor_id='${tailor_id}',sales_man_id='${salesman_id}',occasion='${occasion}',delivery_location_id='${delivery_location_id}',fiton_location_id='${fiton_location_id}' where order_id = '${order_id}'`;
	} else {
		query = `update b_order set occation_date = null,benficiary_name='${benificiary_name}',benficiary_mobile='${benificiary_phone}',benificiary_email='${benificiary_email}',tailor_id='${tailor_id}',sales_man_id='${salesman_id}',occasion='${occasion}',delivery_location_id='${delivery_location_id}',fiton_location_id='${fiton_location_id}' where order_id = '${order_id}'`;
	}

	db.query(query).then((result) => {

		res.send(result[0]);
	});
}


export function fetchOrderDetails(req, res) {
	const order_id = req.body.order_id;
	db.query('select * from "GetPendingOrderDetails"(:in_order_id)', {
		raw: true,
		replacements: {
			in_order_id: order_id
		}
	}).then(function (result) {
		res.send(result[0][0]);
	});

}
export function getOrderDump(req, res) {
	const params = req.query;

	let query = 'select * from v_orders';
	if (params.store_id) {
		query = `${query} v join m_store s on s.store_id=${params.store_id} and v.store=s.address`
	}
	if (params.to && params.from) {
		query = `${query} where order_date between '${params.from}' and '${params.to}'`

	}

	db.query(query).then((result) => {
		if (req.query.download) {
			res.xls('data.xlsx', result[0]);
		} else {
			res.send(result[0]);
		}

	});
}
export function sendPIInvoiceEmail(req, res) {
	const order_id = req.query.order_id;
	const duplicate = req.query.duplicate || false;
	if (order_id) {
		if (duplicate) {
			proceedInvoicePIMail(order_id, res, req);
		} else {
			db.query('select pi_email_status from b_order where order_id = :in_order_id', {
				raw: true,
				replacements: {
					in_order_id: order_id
				}
			}).then((respone) => {
				if (respone[0] && respone[0][0] && respone[0][0].pi_email_status) {
					res.status(500).json({
						success: false,
						error: 'Invoice and PI Email Already Sent'
					});
				} else {
					proceedInvoicePIMail(order_id, res, req);
				}
			})
		}
	} else {
		return res.status(500).json({ success: false, error: 'Order Id is missing' });
	}
}

export function proceedInvoicePIMail(order_id, res, req) {
	const ENV = process.env.TAILORMAN_ENV;
	var user_email = (req.user) ? req.user.email : 'data@tailorman.com';
	getInvoiceFormatedData(order_id).then((respone) => {

		const mandrill_client = new Mandrill('P8PB1qLj9O75t1TMPZ3VpA');
		let to_email = [];
		if (respone.orderDetails && respone.orderDetails.customer_email) {
			to_email.push({
				email: respone.orderDetails.customer_email,
				name: respone.orderDetails.customer_name,
				type: 'to'
			});
		}
		if (ENV == "PRODUCTION") {
			to_email[0].type = "bcc";
			to_email.push({
				email: "data@tailorman.com",
				name: "PPD",
				type: "to"
			});
		}
		if (user_email) {
			to_email.push({
				email: user_email,
				name: respone.orderDetails.customer_name,
				type: "bcc"
			});
		}
		if (respone.orderDetails.store_email) {
			to_email.push({
				email: respone.orderDetails.store_email,
				name: respone.orderDetails.customer_name,
				type: "bcc"
			});
		}
		const half_amount = respone.orderDetails.half_amount || 0;
		const message = {
			text: '',
			subject: `Thank you for Shopping - Tailorman Order No - ${respone.orderDetails.order_id}`,
			from_email: 'care@tailorman.com',
			from_name: 'Tailorman Care',
			to: to_email,
			"inline_css": true,
			"merge": true,
			"auto_text": true,
			"merge_language": "handlebars",
			"global_merge_vars": [
				{
					"name": "ordNumber",
					"content": respone.orderDetails.order_id
				},
				{
					"name": "ordPlacedOn",
					"content": respone.orderDetails.order_date
				},
				{
					"name": "products",
					"content": respone.orderItems
				},
				{
					"name": "totalAmount",
					"content": respone.orderDetails.total_bill_amount
				},
				{
					"name": "totalAmountInWords",
					"content": respone.orderDetails.amount_in_words
				}, {
					"name": "amountPayed",
					"content": respone.orderDetails.half_amount
				}, {
					"name": "balanceAmount",
					"content": (respone.orderDetails.total_bill_amount - respone.orderDetails.half_amount)
				}, {
					"name": "PaymentPending",
					"content": ((respone.orderDetails.full_payment_flag == "Y" || half_amount == 0) ? false : true)
				}
			],
			"merge_vars": [
				{
					"rcpt": "recipient@example.com",
					"vars": [
						{
							"name": "ordNumber",
							"content": "478366238"
						}
					]
				}
			]
		}
		// ----
		const order_id = req.query.order_id;
		const download = req.query.download || false;
		var customer = req.query.customer || false;
		if (!download) {
			capillaryController.capillaryOrderCreation(order_id, 'ORDER');
		}
		// getInvoiceFormatedData(order_id).then((data) => {
		let customerName = respone.orderDetails.customer_name.split(" ").join("");
		customerName = customerName.replace(/\//g, "");
		const filename = "./invoices/" + customerName + "_" + respone.orderDetails.order_id + "_Invoice.pdf";
		var pdfDoc = printer.createPdfKitDocument(respone.pdfMakeDoc);
		let writeStream = fs.createWriteStream(filename);
		pdfDoc.pipe(writeStream);
		pdfDoc.end();
		writeStream.on('finish', function () {
			const file = fs.readFileSync(filename);
			message.attachments = [{
				name: respone.orderDetails.customer_name.split(" ").join("") + " Invoice.pdf",
				content: file.toString('base64'),
				type: 'application/pdf'
			}];
			mandrill_client.messages.sendTemplate({
				"template_name": "Thank you for shopping",
				"template_content": [
					{
						"name": "Thank you for shopping",
						"content": "Thank you for shopping"
					}
				],
				"message": message,
				"async": false,
				"ip_pool": "Main Pool",
				"send_at": moment().subtract(2, 'days').format('YYYY-MM-DD HH:mm:ss')
			}, function (result) {

				db.query('update b_order SET pi_email_status = true where order_id = :in_order_id', {
					raw: true,
					replacements: {
						in_order_id: order_id
					}
				}).then(() => {
					res.send({
						success: true
					});
				});
			}, function (error) {
				res.send({
					success: false,
					error: error
				});
			});
			// sendEmail(req, content, customer_obj, , order_id, res, store_email);
		});
		// });
		// });

		// res.send({
		// 	data: respone
		// });
	});
}


export function updateMeasurementProfile(req, res) {
	console.log('REQQ BODYY', req.body);
	const formValues = req.body;

	db.query('select * from "UpdateOrderItemMeasurementProfile"(:in_order_id, :in_order_item_id, :in_workflow_id,:in_comment,:in_profile_id,:in_workflow_start_stage_id)', {
		raw: true,
		replacements: {
			in_order_id: formValues.order_id,
			in_order_item_id: formValues.order_item_id,
			in_workflow_id: formValues.workflow_id,
			in_comment: formValues.comment,
			in_profile_id: formValues.profile_id,
			in_workflow_start_stage_id: formValues.workflow_start_stage_id
		}
	}).then((result) => {

		res.send(result[0]);
	});
}

export function updateThreedmetadata(req, res) {
	let threedmetadata = req.body.threedmeta;
	let fabricid = req.body.fabric_id;

	db.query('update m_fabric set threedmeta  = :threedmetadata where fabric_id = :fabric_id ', {
		replacements: {
			threedmetadata: threedmetadata || null,
			fabric_id: fabricid
		}
	}).then(function (result) {
		res.send('sucess');
	});
}
export function saveGiftOrder(req, res) {
	var giftCardObj = req.body;
	var user_email = (req.user) ? req.user.email : 'data@tailorman.com';
	var giftcard = giftCardObj.giftcard;

	db.transaction({ autocommit: false }).then(function (t) {
		var promisesArray = [];

		var insertGiftQuery = `INSERT INTO b_order(customer_id,store_id,total_amount,user_id) VALUES (${giftCardObj.customer_id},${giftCardObj.store_id},${giftCardObj.total_amount},${req.user.user_id}) RETURNING order_id`;
		return db
			.query(insertGiftQuery, { transaction: t, plain: true })
			.then(orderdata => {
				var order_id = orderdata.order_id;
				// giftCardObj.order_id = order_id;
				giftcard.map((item, key) => {
					promisesArray.push(insertGiftCard(giftCardObj, item, t, order_id));
				});
				return Promise.all(promisesArray)
					.then(data => {
						t.commit().then(() => {
							sendGiftVocherEmail(order_id, user_email);
						}).catch(err => {
							console.log("errrr", err);
						});

						//triggerGiftVocher();
						res.send({
							msg: "gift cards created"
						});
					})
					.catch(err => {
						console.log("errrr", err);
					});
			})
			.catch(err => {
				console.log("errrr", err);
			});
	});
}

function insertGiftCard(giftCardObj, giftCard, t, order_id) {
	return new Promise(function (resolve) {
		var insertGiftOrderLineQuery = `INSERT INTO b_order_item(order_id,mrp,qty,bill_amount) VALUES (${order_id},${giftCard.amount}, ${giftCard.quantity},${giftCard.amount}) RETURNING order_item_id `;

		return db
			.query(insertGiftOrderLineQuery, { transaction: t, plain: true })
			.then(innerdata => {
				var order_item_id = innerdata.order_item_id;
				let giftVochers = [];
				let noOfGiftVocher = parseInt(giftCard.quantity);
				let giftValue = parseInt(giftCard.amount);
				for (var i = 0; i < noOfGiftVocher; i++) {
					var innerArray = `INSERT INTO gift_vocher ( b_order_item_id,recepient_name,recepient_email,delivery_date,amount,coupon_code,created_date,message,from_name,from_email,balance_amount,last_email_sent) VALUES(${order_item_id},'${giftCard.recipientname[i]}','${giftCard.recipientemail[i]}','${giftCard.deliverydate}',${giftValue},'${uuid()}',now(),'${giftCard.custommsg}','${giftCard.customername}','${giftCard.customeremail}',${giftValue},null)`;
					giftVochers.push(
						db.query(innerArray, { transaction: t, plain: true })
					);
				}
				return Promise.all(giftVochers)
					.then(data => {
						resolve();
					})
					.catch(err => {
						console.log("errrr", err);
					});
			})
			.catch(err => {
				console.log("errrr", err);
			});
	});
}
export function validateGiftVocher(req, res) {
	var giftVocherObj = req.body;
	var selectQuery = `SELECT balance_amount, to_char( ( delivery_date + interval ' 6 months'), 'YYYY/MM/DD') AS "delivery_date",gift_vocher_id FROM gift_vocher WHERE coupon_code ='${giftVocherObj.gift_vocher}' AND (delivery_date + interval ' 6 months')::date>=( now() AT TIME ZONE 'IST' )::date AND recepient_email =(SELECT email FROM m_customer WHERE customer_id=${giftVocherObj.customer_id})`;
	db.query(selectQuery, { plain: true }).then((data) => {
		if (data && data.balance_amount > 0) {
			res.send({
				msg: "Gift Vocher is valid",
				isredeemable: true,
				gift_amount: data.balance_amount,
				delivery_date: data.delivery_date,
				gift_vocher_id: data.gift_vocher_id
			});
		} else {
			res.send({
				msg: "Gift Vocher is invalid.",
				isredeemable: false
			});
		}

	});
}
export function getGiftVochersList(req, res) {
	var giftSearchObj = req.body;
	var selectQuery = `select * from "GetGiftVochersList"('${giftSearchObj.start_date}','${giftSearchObj.end_date}',${giftSearchObj.store_id},${giftSearchObj.customer_id})`;
	db.query(selectQuery).then((data) => {
		res.send({
			data: data[0] || []
		});

	});
}

export function getGiftTransactions(req, res) {
	var giftVocherObj = req.body;
	var selectQuery = `select * from gift_transaction where gift_vocher_id =${giftVocherObj.gift_vocher_id}`;

	db.query(selectQuery).then((data) => {
		res.send({
			data: data[0] || []
		});

	});
}

export function saveCustomerEmail(req, res) {
	var order_id = req.query.order_id || false;
	var user_email = req.query.email || false;
	if(user_email){
	sendGiftVocherEmail(order_id, user_email);
	}
   
}
export default {
	saveCustomer,
	updateCustomer,
	saveDetails,
	saveOrderItem,
	saveMeasurement,
	saveFabricDesign,
	saveImage,
	saveProfile,
	saveStylingProfile,
	updateProfile,
	updateUpcharge,
	getCustomerOrders,
	getOrderItemFabricDesign,
	saveStylingProfileOrder,
	getOrderItems,
	getProfiles,
	getStyleProfiles,
	updateDetails,
	updateOrderItem,
	deleteOrderItem,
	getImages,
	getTaxes,
	getWorkOrders,
	getMeasurementProfileValues,
	getOrderDetails,
	getCustomerDetails,
	getOrderItemDetails,
	getWorkOrderStageList,
	saveWorkFlowStage,
	getOrderItemList,
	testPhantom,
	getImagesOfType,
	saveAlteredOrderItem,
	getPriorityUpcharge,
	getWorkOrderMeasurementProfile,
	getOrderHistory,
	getSignedUrl,
	getSignUrl,
	deleteAWSImage,
	checkCustomer,
	getLatestItemTypeComment,
	storetransactions,
	saveBulkMeasurement,
	getOrderItemOnlineMeasurements,
	getOrderItemOnlineFabricDetails,
	getOrderItemOnlineStyleBucketDetails,
	stockUpdate,
	getRTWMeasurementProfileValues,
	updateMeasurementInventory,
	getWorkFlowOrderItemDetails,
	getOrderItemProfileStyling,
	saveBulkImage,
	getProfileImage,
	updateOrderProfileImage,
	updateCustomerAddressType,
	insertCustomerAddress,
	savePdf,
	sendPiEmail,
	getInvoiceDetails,
	getItemTypeDropDownList,
	updateDefaultCustomerAddress,
	getLoyalityTierDiscount,
	getLoyalityTierTransaction,
	updatePendingOrderDetails,
	fetchOrderDetails,
	getOrderDump,
	getReceiptDetails,
	// updatePendingAmount,
	updateStorePendingAmount,
	getOrdersHistory,
	sendPIInvoiceEmail,
	updateMeasurementProfile,
	proceedAbondanedCartEmail,
	// getAWSAllFiles,
	// rearrangeAWSFiles,
	updateThreedmetadata,
	saveGiftOrder,
	validateGiftVocher,
	proceedGiftVoucherEmail,
	getGiftVochersList,
	getGiftTransactions,
	saveCustomerEmail
}