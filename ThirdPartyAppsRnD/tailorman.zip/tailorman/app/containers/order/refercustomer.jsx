import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';

import classNames from 'classnames/bind';
import styles from 'css/components/order/customer';
import ReactDOM from 'react-dom';

import { connect } from 'react-redux';

import MultiInputField from '../../components/MultiInputField';

import { referFriend } from '../../actions/customer';

import back from 'images/back-arrow.png';
const cx = classNames.bind(styles);
import { updateMessage } from 'actions/order';
import { ERROR_CONDITION, SUCCESS_CONDITION } from 'types';


class ReferCustomer extends Component {
    constructor(props) {
        super(props);
        this.onEmailClick = this.onEmailClick.bind(this);
        this.onMobileClick = this.onMobileClick.bind(this);
        this.onSaveClick = this.onSaveClick.bind(this);
        this.onEmailKeyDown = this.onEmailKeyDown.bind(this);
        this.onMobileKeyDown = this.onMobileKeyDown.bind(this);
        this.updateChips = this.updateChips.bind(this);
        this.deleteChip = this.deleteChip.bind(this);
        this.onFocusLeave = this.onFocusLeave.bind(this);
        this.state = {
            chips:[],
            chips_email:[],
            chips_mobile:[],
            email:false,
            mobile:true,
            inputValue:true,
            errorMsgs:[]
        }
    }


    onEmailClick() {
        if(this.state.email){
        this.setState({
            chips_email:[],
            chips_mobile:[],
            mobile:true,
            email:false,
           errorMsgs:[]
            
        });
    }
    }

    onMobileClick(){
       
       this.setState({
        chips_mobile:[],
        chips_email:[],
           mobile:false,
           email:true,
           errorMsgs:[]
           
       });
    
    }

    onFocusLeave(event){
        let chips;
        if(!this.state.email){
            chips = this.state.chips_email;
        }else{
            chips=this.state.chips_mobile;
        }
        this.updateChips(event,chips);
          this.setState({
              inputValue:true
          });
    }
    onSaveClick(){
       
        let referField;
        let self = this;
        if(!this.state.email)
            referField = 'email'
        else
            referField = 'mobile'
        let fieldValue = this.state.chips;

        let details = {
            fieldType:referField,
            fieldValue:fieldValue,
            email:this.props.customer.email,
            store_id:this.props.stores.selected.store_id

        }
        let validate=true;
        const { dispatch } = this.props;
        if(fieldValue && fieldValue.length > 0){

            fieldValue.map(function(value){
               
               let re = /\S+@\S+\.\S+/;
               let validEmail = re.test(value);

               if(!validEmail){
                   validate = false;
               }
            })
           if(validate || referField == 'mobile'){
            
            dispatch(referFriend(details)).then(function(messageArray){
               
                this.setState({
                 errorMsgs:messageArray,
                 chips_mobile:[],
                 chips_email:[],
                 chips:[]

             });
            
            }.bind(this));
            
        }else{
            dispatch(updateMessage('ERROR_CONDITION', 'Please Enter Valid Email Address'));
        }
           
        }
    }

    onEmailKeyDown(event) {
      
        let keyPressed = event.which;
        let chips = this.state.chips_email;
    
        if (keyPressed === 13) {
          event.preventDefault();
          this.updateChips(event,chips);
          this.setState({
              inputValue:true
          });
        } else if (keyPressed === 8) {
          
    
          if (!event.target.value && chips.length) {
            this.deleteChip(chips[chips.length - 1]);
          }
        }
      }

      onMobileKeyDown(event) {
        let keyPressed = event.which;
        let chips = this.state.chips_mobile;
    
        if (keyPressed === 13) {
          event.preventDefault();
          this.updateChips(event,chips);
          this.setState({
              inputValue:true
          });
        } else if (keyPressed === 8) {
          
    
          if (!event.target.value && chips.length) {
            this.deleteChip(chips[chips.length - 1]);
          }
        }
      }

      updateChips(event,chips) {
         
        if (!this.props.max || 
           chips.length < this.props.max) { 
          let value = event.target.value;
    
          if (!value) return;
    
          let chip = value.trim().toLowerCase();

          
    
          if (chip && chips.indexOf(chip) < 0) {
             
              chips.push(chip);
            this.setState({
              chips
            });
          }
        }
        //event.target.value = '';
      }
    
      deleteChip(chip) {
        let index = this.state.chips.indexOf(chip);

        let chips = this.state.chips;
        
        if (index >= 0) {
            
            chips.splice(index,1);
          this.setState({
            chips
          });
        }
      }
    render() {
        let errorMsgs="";

        errorMsgs = this.state.errorMsgs && this.state.errorMsgs.length>0 && this.state.errorMsgs.map(function(msg,index){
            let errorClassName;
            errorClassName = (msg.success=="true") ? 'refer-success-cls' : 'refer-error-cls';
            return <li key={index} className="refer-label-cls"><label className={errorClassName}>{msg.msg}</label></li>
        });

        return (
            <div className={cx('container')}>
                <Link to="/order/customer" className={cx('back')} ><img src={back} /></Link>
                <h1>Refer Friend</h1>
                <div className={cx('refer-cls')}>Channel</div>
                <div className={cx('referbtn-cls' ,{new:this.state.email==false})} onClick={this.onEmailClick} >
                    <img className={cx('email-btn-cls')} src="https://www.iotforall.com/wp-content/uploads/2017/07/emailicon.png" />
                </div>
                <div className={cx('referbtn-cls',{new:this.state.mobile==false})} onClick={this.onMobileClick}>
                    <img className={cx('phone-btn-cls')} src="http://icons.iconarchive.com/icons/paomedia/small-n-flat/1024/device-mobile-phone-icon.png" />
                </div>
                <div className={cx('multifield-cls')} ref="email" hidden={this.state.email}>
                    <MultiInputField labelName='Email Addresses' onKeyDown={this.onEmailKeyDown} chips={this.state.chips_email} isValue={this.state.inputValue} type='textarea' onFocusLeave={this.onFocusLeave}/>
                </div>
                <div className={cx('multifield-cls')} ref="mobile" hidden={this.state.mobile}>
                    <MultiInputField labelName='Mobile Numbers' onKeyDown={this.onMobileKeyDown} ref="multi_input" chips={this.state.chips_mobile} isValue={this.state.inputValue} type='number' onFocusLeave={this.onFocusLeave}/>
                </div>
                {( this.state.email ? "Note : Please Add the county extension code Ex: 91XXXXXXXXXX " : "")}
                {errorMsgs}
                <div className="refer-btn-cls">
                    <button className={cx('action', 'refer')} onClick={this.onSaveClick}>Save</button>
                    <Link to="/order/customer" ><button className={cx('action', 'refer')} onClick={this.onSaveClick}>Cancel</button></Link>

                </div>
            </div>
        );
    }
}

ReferCustomer.propTypes = {
    customer: PropTypes.object,
    stores: PropTypes.object
};


function mapStateToProps({ customer,stores }) {
    return {
        customer,
        stores
    };
}

// Connects React component to the redux store
// It does not modify the component class passed to it
// Instead, it returns a new, connected component class, for you to use.
export default connect(mapStateToProps)(ReferCustomer);
