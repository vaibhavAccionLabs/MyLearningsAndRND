import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';
import classNames from 'classnames/bind';
import styles from 'css/components/order/history';
import {
	push
} from 'react-router-redux';
import { fetchList } from '../../actions/list';
import _ from 'lodash';
import {
	populateOrders,
	setActiveKey,
	reSendPIEmail
} from '../../actions/history';
import { connect } from 'react-redux';
import ReactDOM from 'react-dom';
import Collapse, { Panel } from 'rc-collapse';
import back from 'images/back-arrow.png';
import moment from 'moment';

const cx = classNames.bind(styles);

class OrderHistory extends Component {
	constructor(props) {
		super(props);
		this.accordion = true;
		this.renderAccordion = this.renderAccordion.bind(this);
		this.toggleAccordion = this.toggleAccordion.bind(this);
		this.getOrderItemDiv = this.getOrderItemDiv.bind(this);
		this.resendPIEmail = this.resendPIEmail.bind(this);
	}
	resendPIEmail(order_id){
		
		this.props.dispatch(reSendPIEmail(order_id));
		window.scrollTo(0, 0);
	}
	componentDidMount() {
		this.props.dispatch(populateOrders(this.props.customer.customer_id));
	}
	getHeaderName(order){
		let order_date = order.order_date && moment(order.order_date).format('YYYY-MM-DD');
		let order_name = order.display_name || [order.order_id, moment(order.modified_time).format('LL')].join('--');
		if(order_date){
			return `${order.order_id} ${order_date} ${order_name}`;
		}else{
			return order_name;
		}
	}
	renderAccordion() {
		const self = this;
		if (this.props.history.orders && this.props.history.orders.length > 0) {
			return this.props.history.orders.map((order, index) => {
				return (
					<Panel header={self.getHeaderName(order)} key={index} >
						{self.getOrderItemDiv(order.sale_items)}
						{/* <div>
						<button 
							style={{
							    backgroundColor: 'black',
								color: 'white',
								border: '1px solid black',
								padding: '5px 15px',
								margin: '20px auto'
							}}
							onClick={this.resendInvoiceEmail}
							>RE-SEND INVOICE EMAIL</button>
						</div> */}
						{
							(order.sale_items && order.sale_items.length >= 0) ? (<button style={{
							    backgroundColor: 'black',
								color: 'white',
								border: '1px solid black',
								padding: '5px 15px',
								margin: '20px auto'
							}}
							onClick={()=>{this.resendPIEmail(order.order_id)}}
							>RE-SEND PI AND INVOICE EMAIL </button>) : ''
						}
					</Panel>
				)
			});
		} else {
			return null;
		}

	}

	getOrderItemDiv(sales) {
		
		if (sales && sales.length >= 0) {
			return sales.map((sale, index) => {
				return (
					<div key={index}>
						<span>{sale.display_name}</span>
					</div>
				);
			})
		} else {
			return <div>No Sale Items</div>	
		}
	}

	toggleAccordion(activeKey) {
		this.props.dispatch(setActiveKey(activeKey));
	}

	render() {
		return (
			<div className={cx('container')}>
				<div className={cx('header-note')}>
					<span className={cx('header-label')}>Customer:   </span>
					<span className={cx('header-content')}>{this.props.customer.name}</span>
				</div>
				<h1>History</h1>
				<Link to="/reset" className={cx('review')}>
					Logout
				</Link>
				<Link to="/customer/actions" className={cx('back')} ><img src={back} /></Link>
				<div className={cx('form-container')}>
					<Collapse
						accordion={this.accordion}
						onChange={this.toggleAccordion}
						activeKey={this.props.history.accordionKey}
						>
						{this.renderAccordion()}
					</Collapse>
				</div>
			</div>
		);
	}
}

OrderHistory.propTypes = {
	history: PropTypes.object,
	user: PropTypes.object,
	customer: PropTypes.object,
};


function mapStateToProps({history, user, customer}) {
	return {
		history,
		user,
		customer
	};
}

// Connects React component to the redux store
// It does not modify the component class passed to it
// Instead, it returns a new, connected component class, for you to use.
export default connect(mapStateToProps)(OrderHistory);