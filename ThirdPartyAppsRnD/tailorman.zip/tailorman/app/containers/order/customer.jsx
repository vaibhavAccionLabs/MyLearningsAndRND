import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';

import classNames from 'classnames/bind';
import styles from 'css/components/order/customer';
import ReactDOM from 'react-dom';
import NumberForm from '../../components/NumberForm';
import { connect } from 'react-redux';
import MultipleChoice from '../../components/MultipleChoice';
// import PopupCmp from '../../components/PopupCmp';
import SelectForm from '../../components/SelectForm';
import {
	updateCustomerGender,
	updateCustomerIsNew,
	updateCustomerPincode,
	updateCustomerPhone,
	updateCustomer,
	updateCustomerSource,
	updateAddressType,
	cartAddressInsert,
	updateMessage,
	loadLoyalityPoints,
	loadLoyalityDiscontTransaction
} from '../../actions/order';
import { toggleAddressListItemMenu, setDefaultDeliveryAddress, setDefaultBillingAddress } from '../../actions/customer';
import { fetchList } from '../../actions/list';
import moment from 'moment';
import back from 'images/back-arrow.png';
const cx = classNames.bind(styles);
import Popup from 'react-popup';
//import { data } from './CountriesData';
import ants from 'images/ants.png';
import ReactTable from "react-table";
import "react-table/react-table.css";

class OrderCustomer extends Component {
	constructor(props) {
		super(props);
		this.saveNumberFieldValue = this.saveNumberFieldValue.bind(this);
		this.saveMultiChoiceFieldValue = this.saveMultiChoiceFieldValue.bind(this);
		this.saveValues = this.saveValues.bind(this);
		this.formatDate = this.formatDate.bind(this);
		this.saveSelectFormValue = this.saveSelectFormValue.bind(this);
		this.extractPincode = this.extractPincode.bind(this);
		this.fetchAddressList = this.fetchAddressList.bind(this);
		this.saveAddressType = this.saveAddressType.bind(this);
		this.renderMenu = this.renderMenu.bind(this);
		this.toggleMenu = this.toggleMenu.bind(this);
		this.closeMenu = this.closeMenu.bind(this);
		this.editAddress = this.editAddress.bind(this);
		this.getTransactionHistory = this.getTransactionHistory.bind(this);
		//this.setSelectedCountry = this.setSelectedCountry.bind(this);
		//this.setSelectedState = this.setSelectedState.bind(this);
		this.state = {
			country: null,
			state: null,
			addressText: null,
			mode: "ADD",
			address_type: null,
			m_customer_addresses_id: null
		}
	}
	extractPincode(address) {
		if (address) {
			var lastToken = address.trim().split(" ").slice(-1)[0].trim();
			var _address = address.trim().split(" ").slice(0, -1).join(" ");
			if (parseInt(lastToken) > 99999) {
				return {
					pincode: lastToken,
					address: _address
				}
			} else {
				return {
					address: address,
					pincode: ''
				}
			}
		} else {
			return {
				address: address,
				pincode: ''
			};
		}

	}

	componentDidMount() {
		this.props.dispatch(fetchList('customer_source'));
		this.props.dispatch(fetchList('customer_address', { customer_id: this.props.customer.customer_id }));
		this.props.dispatch(loadLoyalityPoints(this.props.stores.selected.store_id, this.props.customer.customer_id));
		this.props.dispatch(loadLoyalityDiscontTransaction(this.props.customer.customer_id));
	}
	formatDate(date) {
		if (date) {
			return moment(date).format('YYYY-MM-DD');
		} else
			return '';

	}
	saveNumberFieldValue(value, field) {
		if (field == 'pincode') {
			this.props.dispatch(updateCustomerPincode(value));
		} else if (field == 'phone') {
			this.props.dispatch(updateCustomerPhone(value))
		}
	}
	saveMultiChoiceFieldValue(value, field, isMultiple) {
		switch (field) {
			case 'gender':
				this.props.dispatch(updateCustomerGender(value));
			case 'new_customer':
				this.props.dispatch(updateCustomerIsNew(value));
		}
	}
	saveSelectFormValue(selected, type) {
		if (type == 'customer_sources') {
			this.props.dispatch(updateCustomerSource(selected.value));
		}
	}

	saveValues() {
		var _that = this;
		const formValues = {
			email: ReactDOM.findDOMNode(_that.refs.email).value,
			name: ReactDOM.findDOMNode(_that.refs.name).value,
			//address: ReactDOM.findDOMNode(_that.refs.address).value,
			phone: _that.props.customer.phone,
			gender: _that.props.customer.gender,
			dob: ReactDOM.findDOMNode(_that.refs.dob).value,
			height: ReactDOM.findDOMNode(_that.refs.height).value,
			weight: ReactDOM.findDOMNode(_that.refs.weight).value,
			source_id: _that.props.customer.source_id,
			comment: ReactDOM.findDOMNode(_that.refs.comment).value,
			customer_id: _that.props.customer.customer_id
		}
		this.props.dispatch(updateCustomer(formValues));
	}

	// setSelectedCountry(address){
	// 	let countriesData = data.countries;
	// 	let country = _.find(countriesData,{name:address.name}).code;
	// 	this.setState({
	// 		country
	// 	});
	// }

	// setSelectedState(address){
	// 	let statesData = data.states;
	// 	let state = _.find(statesData,{name:address.name}).key;
	// 	this.setState({
	// 		state
	// 	});
	// }

	addressChange(e, data) {
		var self = this;
		const addValue = e.currentTarget.value;
		self.setState({
			addressText: addValue
		}, () => {
			Popup.close();
			self.showPopUp(this.state.mode);
		})

	}

	addAddress() {
		let { addressText } = this.state;

		const customer_id = this.props.customer.customer_id;
		const address_type = this.state.address_type;
		const m_customer_addresses_id = this.state.m_customer_addresses_id;
		if (address_type && addressText) {
			const values = {
				addressText,
				address_type,
				customer_id,
				m_customer_addresses_id
			}
			this.props.dispatch(cartAddressInsert(values));
		} else {
			this.props.dispatch(updateMessage('ERROR_CONDITION', 'Please enter address value and address type'));
			window.scrollTo(0, 0);
		}

	}

	onAddAddressClick() {
		let self = this;
		self.setState({
			addressText: null,
			address_type: null,
			mode: "ADD",
			m_customer_addresses_id: null
		}, () => {
			self.showPopUp("ADD");
		});

	}

	showPopUp(btnText) {
		let self = this;

		let contentElement = (
			<div className={cx('form-container')}>
				<div className={cx('input-group')}>
					<label htmlFor="add_address">{btnText} Shipping/Billing Address</label>
					<input type="text" id="add_address" onChange={this.addressChange.bind(this)} value={self.state.addressText} />
				</div>
				<div>
					<MultipleChoice isMultiple={false} options={['Delivery', 'Shipping']} rel="addressType" save={self.saveAddressType} selected={self.state.address_type} />
				</div>
			</div>
		);
		let popUp = Popup.create({
			title: `${btnText} Address`,
			content: contentElement,
			buttons: {
				left: [{
					text: 'CANCEL',
					action: function () {
						self.setState({
							addressText: null,
							address_type: null,
							m_customer_addresses_id: null
						});
						Popup.close();

					}
				}],
				right: [{
					text: btnText,
					action: function () {
						//Popup.close();
						self.addAddress();
						self.setState({
							addressText: null,
							address_type: null,
							m_customer_addresses_id: null
						});
						Popup.close();
					}
				}]
			}
		});
		return Popup;
	}

	saveAddressType(value) {

		this.setState({
			address_type: value[0]
		});
		Popup.close();
		this.showPopUp(this.state.mode);
	}

	renderMenu(address) {
		const self = this;
		if (this.props.customer.selectedWorkOrderItem == address.m_customer_addresses_id && this.props.customer.isListItemMenuOpen) {

			return (
				<div className={cx('ants-menu')}>
					<a onClick={this.setDefaultAddress.bind(this, address)}>Set as Default</a>
					<a onClick={this.editAddress.bind(this, address)}>Edit</a>
					{/* <FileCapture accept="application/pdf/*" workOrderMenu={true} addImage={this.addImage} /> */}
				</div>
			)
		} else {
			return null;
		}
	}

	setDefaultAddress(address) {
		// if(address.address_type == "Delivery"){
		this.props.dispatch(setDefaultDeliveryAddress(address));
		// }else if(address.address_type == "Shipping"){
		// this.props.dispatch(setDefaultBillingAddress(address));
		// }
	}
	editAddress(address) {
		var self = this;
		self.setState({
			addressText: address.address,
			mode: "Update",
			address_type: address.address_type,
			m_customer_addresses_id: address.m_customer_addresses_id
		}, () => {
			self.showPopUp("Update");
		});

	}

	toggleMenu(m_customer_addresses_id, e) {
		this.props.dispatch(toggleAddressListItemMenu(!this.props.customer.isListItemMenuOpen, m_customer_addresses_id));
	}
	closeMenu() {
		this.props.dispatch(toggleAddressListItemMenu(!this.props.customer.isListItemMenuOpen, this.props.customer.workorder.selectedWorkOrderItem));
	}


	fetchAddressList() {

		let addressList;
		let { lists: { customer_addresses } } = this.props;
		let btnElement = <button className={cx('addaddress')} onClick={this.onAddAddressClick.bind(this)}>Add Address</button>;

		if (customer_addresses && customer_addresses.length > 0) {
			const addressElements = customer_addresses.map((address, index) => {
				let defaultAddressColumn = address.default_address ? "defaultColumn" : "";
				return <div className={cx('workorder', defaultAddressColumn)} key={index}>
					{/* <div className={cx({
                        'medium': true
                    })}>{address.m_customer_addresses_id}</div> */}
					<div className={cx({
						'x_large': true
					})}>{address.address}</div>
					<div className={cx({
						'x_large': true
					})}>{address.address_type}</div>



					<div onClick={this.toggleMenu.bind(this, address.m_customer_addresses_id)} className={cx({ 'toggleMenu': true, 'up': (index > customer_addresses.length / 2) })}><img src={ants} />{this.renderMenu(address)}</div>
				</div>
			});
			return (
				<div>
					<div>
						{btnElement}
					</div>
					<div className={cx('workorders')}>

						<div className={cx('workorder')}>
							{/* <div className={cx({
                            'head': true,
                            'medium': true
                        })} >Address ID</div> */}
							<div className={cx({
								'head': true,
								'x_large': true
							})} >Address</div>
							<div className={cx({
								'head': true,
								'x_large': true
							})} >Address Type</div>



						</div>
						{addressElements}
					</div>

				</div>
			)
		} else {
			return (
				<div>
					{btnElement}
					<h3> No Addresses are Available </h3>
				</div>
			)
		}

	}
	getTransactionHistory() {
		if (this.props.customer.loyalitytransactionsloading) {
			return (
				<div>
					Transactions Loading Please wait...
				</div>
			)
		}
		let transactions = this.props.customer.loyalitytransactions || [];
		if (transactions.length == 0) {
			return (
				<div>
					No Transactions Available In the current Financial Year
				</div>
			);
		}
		return (
			<div
				style={{
					position: 'relative',
					width: '100%'
				}} >
				<ReactTable
					data={transactions}
					columns={[
						{
							accessor: "sc_no",
							Header: "S No"
						}, {
							Header: "Order Date",
							accessor: "order_date",
							Cell: props => <span className='number'>{props.value ? moment(props.value).format('YYYY-MM-DD') : props.value}</span> 
						},
						{
							Header: "Order Number",
							accessor: "order_number"
						},
						{
							Header: 'Discount Amount',
							accessor: "discount_amount"
						}, {
							Header: 'Discount Type',
							accessor: "discount_type"
						},{
							Header: 'Tier',
							accessor: "discount_tier"
						}
					]}
					defaultPageSize={5}
					className="-striped -highlight"
				/>
			</ div>
		);
	}
	render() {
		let customerAddresses = this.fetchAddressList();
		return (
			<div className={cx('container')}>
				<Link to="/order" className={cx('review')}>
					Review
				</Link>
				<Link to="/order" className={cx('back')} ><img src={back} /></Link>
				<h1>Customer Details</h1>
				<div className={cx('form-container')}>
					<div className={cx('input-group')}>
						<label htmlFor="name">Name</label>
						<input type="text" id="name" ref="name" defaultValue={this.props.customer.name} />
					</div>

					<div className={cx('input-group')}>
						<label htmlFor="email">Email</label>
						<input type="email" id="email" ref="email" defaultValue={this.props.customer.email} disabled/>
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="dob">Date of Birth</label>
						<input type="date" id="dob" ref="dob" defaultValue={this.formatDate(this.props.customer.dob)} />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="phone">Phone</label>
						<NumberForm type="phone" rel="phone" save={this.saveNumberFieldValue} default={this.props.customer.phone} disabled={true} />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="name">Loyality Points</label>
						<input type="text" value={this.props.order.details.loyality_points} disabled />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="name">Current Loyality Tier</label>
						<input type="text" value={this.props.order.details.current_tier} disabled />
					</div>
					{/* <div className={cx('input-group')}>
						<label htmlFor="address">Address</label>
						<textarea id="address" ref="address" defaultValue={this.props.customer.address} ></textarea>
					</div> */}

					<div className={cx('input-group')}>
						<label htmlFor="gender">Gender</label>
						<MultipleChoice isMultiple={false} options={['male', 'female']} selected={this.props.customer.gender} rel="gender" save={this.saveMultiChoiceFieldValue} />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="height">Height (in Inches)</label>
						<input type="text" ref="height" defaultValue={this.props.customer.height} />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="height">Weight (in kg)</label>
						<input type="number" ref="weight" defaultValue={this.props.customer.weight} />
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="customer_sources">Source</label>
						<SelectForm type="customer_sources" rel="customer_sources" options={this.props.lists.customerSources} value={this.props.customer.source_id} save={this.saveSelectFormValue} />
					</div>
					<div>
						{customerAddresses}
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="comments">Comments</label>
						<textarea id="comment" ref="comment" defaultValue={this.props.customer.comment} ></textarea>
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="Transactions">Current Financial Year Transactions</label>
						{this.getTransactionHistory()}
					</div>
					
					<div className={cx('save-btn')}><button onClick={this.saveValues} className={cx('action', 'primary')}>Save</button></div>
					 <Link to="/order/customer/refer" className={cx('action', 'primary')} >Refer Friend</Link> 
					
				</div>
			</div>
		);
	}
}

OrderCustomer.propTypes = {
	order: PropTypes.object,
	users: PropTypes.object,
	customer: PropTypes.object,
	lists: PropTypes.object
};


function mapStateToProps({ order, customer, user, lists, stores }) {
	return {
		order,
		customer,
		user,
		lists,
		stores
	};
}

// Connects React component to the redux store
// It does not modify the component class passed to it
// Instead, it returns a new, connected component class, for you to use.
export default connect(mapStateToProps)(OrderCustomer);
