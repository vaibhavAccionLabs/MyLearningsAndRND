import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';
import classNames from 'classnames/bind';
import styles from 'css/components/workorder';
import {
    push
} from 'react-router-redux';
import SelectForm from 'components/SelectForm';
import MultipleChoice from 'components/MultipleChoice';
import _ from 'lodash';
 import { fetchList } from '../../actions/list';
 import {
    getWorkflowStages,
    setActiveKey,
    getWorkOrders,
    selectWorkOrder,
    sortWorkOrders,
    toggleWorkOrderListItemMenu,
    updateWorkOrderItemStage,
    selectWorkflow as _selectWorkflow,
    saveQueryFields
} from '../../actions/workorder';
import {
    updateMessage
} from '../../actions/order';
import { connect } from 'react-redux';
import ReactDOM from 'react-dom';
import back from 'images/back-arrow.png';
import Collapse, { Panel } from 'rc-collapse';
import print from 'images/print.png';
import ants from 'images/ants.png';
import moment from 'moment';
import FileCapture from 'components/FileCapture';
import {saveImageAWS} from 'actions/order';
import {
	getPendingWorkOrders
} from '../../actions/orderupdate';
import * as types from 'types';
const cx = classNames.bind(styles);

class OrderStyleUpdate extends Component {
    constructor(props) {
        super(props);
       
        this.renderWorkOrders = this.renderWorkOrders.bind(this);
        this.renderMenu = this.renderMenu.bind(this);
        this.toggleMenu = this.toggleMenu.bind(this);
        this.updateStage = this.updateStage.bind(this);
        this.renderBespoke = this.renderBespoke.bind(this);
        this.addImage = this.addImage.bind(this);
        this.closeMenu = this.closeMenu.bind(this);
        this.renderCheckList =this.renderCheckList.bind(this);
    }
    closeMenu(){
        this.toggleMenu(this.props.workorder.selectedWorkflow);
    }
    componentDidMount() {
        this.props.dispatch(getPendingWorkOrders(this.props.customer.customer_id,this.props.stores.selected.store_id));
    }
    updateStage(workorder, stage, e) {
        
        this.props.dispatch(updateWorkOrderItemStage(workorder, workorder, '', this.props.user.user.user_id, 1));
        this.props.dispatch(getWorkOrders.apply(this, this.props.workorder.query));
      //  this.props.dispatch(getPendingWorkOrders(this.props.customer.customer_id,this.props.stores.selected.store_id));
        this.props.dispatch(updateMessage('UPDATE_GENERAL_MESSAGE', 'Order Item\'s Stage updated'));
        e.preventDefault();
        e.stopPropagation();
    }
    renderBespoke(){

        const order_item = _.find(this.props.orderupdate.updatestyleorder,{order_item_id:this.props.workorder.selectedWorkOrderItem});
        const order_id = order_item ? order_item.order_id : null;
        if(order_item && order_item.bespoke_url){
            var downloadFileName = order_item.bespoke_url.split("/");
                downloadFileName = downloadFileName[downloadFileName.length-1] || "test.pdf";

            return <a target="_blank" href={order_item.bespoke_url} download={downloadFileName}>Download Bespoke</a>;
        }
        else{
            return <div className = {"custom-file-capture"}> <FileCapture workOrderMenu={true} addImage={this.addImage} className="custom-file-input" closeMenu={this.closeMenu} /></div>;
        }

    }
    addImage(file) {
         const order_item = _.find(this.props.orderupdate.updatestyleorder,{order_item_id:this.props.workorder.selectedWorkOrderItem});
         const order_id = order_item ? order_item.order_id : null;
         this.props.dispatch(saveImageAWS(file, order_id, types.IMAGE_TYPE_MEASUREMENT,true));
     }
    renderMenu(workorder) {
        const self = this;
        if (this.props.workorder.selectedWorkOrderItem == workorder.order_item_id && this.props.workorder.isListItemMenuOpen) {
            
            workorder.stage_id = 1;
            // const stageChanges = this.props.workorder.stageList.map((stage, index) => {
            //     return (
            //         <a key={index} onClick={self.updateStage.bind(this, workorder, stage)}>{"Set as " + stage.code}</a>
            //     )
            // });
            // let printWrap =(<Link to={"/workorder/order/" + workorder.order_id + "/item/" + workorder.order_item_id + "/profile/" + workorder.profile_id + "/print"}>View & Print</Link>);
            // if(workorder.store == "Online Store"){
            //     printWrap =<Link to={"/workorder/ordernew/" + workorder.order_id + "/item/" + workorder.order_item_id + "/profile/" + workorder.profile_id + "/print"}>View & Print</Link>  
             //}
            return (
                <div className={cx('ants-menu')}>
                   
                    <Link to={"/order/update/" + workorder.order_item_id + "/measurements/default"}>Update Measurements</Link>
                    <Link to={"/order/update/" + workorder.order_item_id + "/style"}>Update Styles</Link>
                    <Link to={"/order/update/"  + workorder.order_id + "/details"}>Update Order Details</Link>
                    {this.renderBespoke()}
                    <div className={cx('confirm-order-cls')}  onClick={this.updateStage.bind(this, workorder, workorder)}>Set as Confirmed</div>
                </div>
            )
        } else {
            return null;
        }
    }
    
    toggleMenu(order_item_id, e) {
        if(e && e.target && e.target.type == "file"){
            console.log('File Change request');
        }else{
            this.props.dispatch(toggleWorkOrderListItemMenu(!this.props.workorder.isListItemMenuOpen, order_item_id, this.props.user.user, this.props.workorder.selectedWorkflow));
        }
    }
    renderCheckList(workorder){
        return (
                <ul className={cx("button-group radius")}>
                    <li><span className={cx(`small button ${(workorder.profile_id != -1 )?"success": "failure"} `)}>Measure</span></li>
                    <li><span className={cx(`small button ${(workorder.style_id)?"success": "failure"}`)}>Styles</span></li>
                    <li><span className={cx(`small button ${(workorder.image)?"success": "failure"}`)}>Photo upload</span></li>
                    <li><span className={cx(`small button ${(workorder.bespoke_url)?"success": "failure"}`)}>Bespoke</span></li>
               </ul>
            )
    }

    renderWorkOrders() {
        
        const self = this;
        if (this.props.orderupdate.updatestyleorder && this.props.orderupdate.updatestyleorder.length > 0) {
            const workordersElements = this.props.orderupdate.updatestyleorder.map((workorder, index) => {
                return <div className={cx('workorder extra-cls')} key={index}>
                    <div className={cx({
                        'sorted': this.props.workorder.sortedBy == 'order_item_id',
                        'small': true
                    })}>{workorder.order_item_id}</div>
                    <div className={cx({
                        'sorted': this.props.workorder.sortedBy == 'customer_name',
                        'medium': true
                    })}>{workorder.customer_name}</div>
                    <div className={cx({
                        'sorted': this.props.workorder.sortedBy == 'order_id',
                        'small': true
                    })}>{workorder.order_id}</div>
                    <div className={cx({
                        'sorted': this.props.workorder.sortedBy == 'order_date',
                        'medium': true
                    })}>{moment(workorder.order_date).format('L')}</div>
                    <div className={cx({
                        'sorted': this.props.workorder.sortedBy == 'product_sku',
                        'medium': true
                    })}>{workorder.product_sku}</div>
                    <div className={cx({
                        'sorted': this.props.workorder.sortedBy == 'mrp',
                        'small': true
                    })}>{workorder.mrp}</div>
                    <div className={cx({
                        'sorted': this.props.workorder.sortedBy == 'qty',
                        'small': true
                    })}>{workorder.qty}</div>
                    <div className={cx({
                        'sorted': this.props.workorder.sortedBy == 'priority',
                        'medium': true
                    })}>{workorder.priority}</div>
                    <div className={cx({
                        'sorted': this.props.workorder.sortedBy == 'cusomer_id',
                        'medium': true
                    })}>{workorder.cusomer_id}</div>
                    <div className={cx({
                        'sorted': this.props.workorder.sortedBy == 'current_status',
                        'medium': true
                    })}>{workorder.current_status}</div>
                    <div className={cx({
                        'sorted': this.props.workorder.sortedBy == 'store',
                        'large': true
                    })}>{workorder.store}</div>
                    <div className={cx({
                        'sorted': this.props.workorder.sortedBy == 'store',
                        'extralarge': true
                    })}>{this.renderCheckList(workorder)}</div>


                    <div onClick={this.toggleMenu.bind(this, workorder.order_item_id)} className={cx({ 'toggleMenu': true, 'up': (index > this.props.orderupdate.updatestyleorder / 2) })}><img src={ants} />{this.renderMenu(workorder)}</div> 
                </div>
            });
         
            return (
                <div className={cx('workorders')}>
              
                    <div className={cx('workorder')}>
                        <div className={cx({
                            'sorted': this.props.workorder.sortedBy == 'order_item_id',
                            'desc': this.props.workorder.sortOrder == 'desc',
                            'asc': this.props.workorder.sortOrder == 'asc',
                            'head': true,
                            'small': true
                        })} >Item</div>
                        <div className={cx({
                            'sorted': this.props.workorder.sortedBy == 'customer_name',
                            'desc': this.props.workorder.sortOrder == 'desc',
                            'asc': this.props.workorder.sortOrder == 'asc',
                            'head': true,
                            'medium': true
                        })} >Customer</div>
                        <div className={cx({
                            'sorted': this.props.workorder.sortedBy == 'order_id',
                            'desc': this.props.workorder.sortOrder == 'desc',
                            'asc': this.props.workorder.sortOrder == 'asc',
                            'head': true,
                            'small': true
                        })} >Order</div>
                        <div className={cx({
                            'sorted': this.props.workorder.sortedBy == 'order_date',
                            'desc': this.props.workorder.sortOrder == 'desc',
                            'asc': this.props.workorder.sortOrder == 'asc',
                            'head': true,
                            'medium': true
                        })} >Order Date</div>
                        <div className={cx({
                            'sorted': this.props.workorder.sortedBy == 'product_sku',
                            'desc': this.props.workorder.sortOrder == 'desc',
                            'asc': this.props.workorder.sortOrder == 'asc',
                            'head': true,
                            'medium': true
                        })} >SKU</div>
                        <div className={cx({
                            'sorted': this.props.workorder.sortedBy == 'mrp',
                            'desc': this.props.workorder.sortOrder == 'desc',
                            'asc': this.props.workorder.sortOrder == 'asc',
                            'head': true,
                            'small': true
                        })} >MRP</div>
                        <div className={cx({
                            'sorted': this.props.workorder.sortedBy == 'qty',
                            'desc': this.props.workorder.sortOrder == 'desc',
                            'asc': this.props.workorder.sortOrder == 'asc',
                            'head': true,
                            'small': true
                        })} >QTY</div>
                        <div className={cx({
                            'sorted': this.props.workorder.sortedBy == 'priority',
                            'desc': this.props.workorder.sortOrder == 'desc',
                            'asc': this.props.workorder.sortOrder == 'asc',
                            'head': true,
                            'medium': true
                        })} >Priority</div>
                        <div className={cx({
                            'sorted': this.props.workorder.sortedBy == 'cusomer_id',
                            'desc': this.props.workorder.sortOrder == 'desc',
                            'asc': this.props.workorder.sortOrder == 'asc',
                            'head': true,
                            'medium': true
                        })} >Customer ID</div>
                        <div className={cx({
                            'sorted': this.props.workorder.sortedBy == 'current_status',
                            'desc': this.props.workorder.sortOrder == 'desc',
                            'asc': this.props.workorder.sortOrder == 'asc',
                            'head': true,
                            'medium': true
                        })} >Status</div>
                        <div className={cx({
                            'sorted': this.props.workorder.sortedBy == 'store',
                            'desc': this.props.workorder.sortOrder == 'desc',
                            'asc': this.props.workorder.sortOrder == 'asc',
                            'head': true,
                            'large': true
                        })} >Store</div>
                        <div className={cx({
                            'sorted': this.props.workorder.sortedBy == 'store',
                            'desc': this.props.workorder.sortOrder == 'desc',
                            'asc': this.props.workorder.sortOrder == 'asc',
                            'head': true,
                            'extralarge': true
                        })} >CheckList</div>


                    </div>
                    {workordersElements}
                </div>
            )
        } else {
            return (
                <h3> No pending items available </h3>
            )
        }
    }

    render() {
        let workordersearch = (
            <div>
                
                <div className={cx('input-group')}>
                    
                    <label htmlFor="workflowStage">Order Status</label>
                    <MultipleChoice
                        isMultiple={true}
                        options={_.map(this.props.workorder.workflowStages, 'name')} selected={['']} rel='stage' save={this.selectWorkflowStage} />

                    {
                        //<SelectForm type="workflowStage" rel="workflowStage" options={this.props.workorder.workflowStages} value={this.props.workorder.stage_id} save={this.selectWorkflowStage} />
                    }
                </div>
                <div className={cx('input-group')}>
                    <label htmlFor="customer">Customer</label>
                    <input type="text" ref="customer" />
                </div>
                <div className={cx('input-group')}>
                    <label htmlFor="customer">Customer Id</label>
                    <input type="number" ref="customerId" />
                </div>
                <div className={cx('input-group')}>
                    <label htmlFor="customer">Order Id</label>
                    <input type="number" ref="orderId" />
                </div>
                <div className={cx('input-group')}>
                    <label htmlFor="from_date">From Date</label>
                    <input type="date" ref="from_date" />
                </div>
                <div className={cx('input-group')}>
                    <label htmlFor="to_date">To Date</label>
                    <input type="date" ref="to_date" />
                </div>

                <button className={cx('action')} onClick={this.search}>Search</button>
            </div>
        );
        if (this.props.workorder.selectedWorkflow === -1) {
            workordersearch = null;
        }
        return (
            <div className={cx('container', 'big')}>
                 <Link to="/customer/actions" className={cx('back')} ><img src={back} /></Link>
                            {this.renderWorkOrders()}
                        
            </div>
        );
    }
}

OrderStyleUpdate.propTypes = {
    workorder: PropTypes.object,
    user: PropTypes.object,
    lists: PropTypes.object,
    history: PropTypes.object,
    orderupdate:PropTypes.object,
    stores:PropTypes.object,
    order:PropTypes.object
};


function mapStateToProps({ workorder, user, customer, lists, history,orderupdate,stores,order}) {
    return {
        workorder,
        user,
        customer,
        lists,
        history,
        orderupdate,
        stores,
        order
    };
}

export default connect(mapStateToProps)(OrderStyleUpdate);