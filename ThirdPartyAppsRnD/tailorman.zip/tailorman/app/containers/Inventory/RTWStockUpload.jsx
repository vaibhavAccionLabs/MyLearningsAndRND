import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';

import classNames from 'classnames/bind';
import json2csv from 'json2csv';
import styles from 'css/components/order/details';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import { updatePriorityType, updatePaymentType, updateTailor, updateOrderDetails, updateBenificiaryPhone, updateOccasion, updateSalesman, updateMessage } from '../../actions/order';
import { fetchList, searchRTW, fetchSizeList, fetchFitList, transferInventory, fetchItemTypeList, updateRTWInventory } from '../../actions/list';
import { fetchStoresList } from '../../actions/users';
import NumberForm from '../../components/NumberForm';
import SelectForm from '../../components/SelectForm';
import back from 'images/back-arrow.png';
const STOCK_UPDATE_TEMPLATE_DOWNLOAD_FILE_NAME = 'store_inventory.csv';

//Custom components
import FileCapture from 'components/FileCapture';
import ReactTable from "react-table";
import "react-table/react-table.css";

const cx = classNames.bind(styles);

class RTWStockUpload extends Component {
    constructor(props) {
        super(props);
        this.state = {
            store_id: '',
            fileUploaded: null,
        }
        this.onSelectStoreType = this.onSelectStoreType.bind(this);
        this.onCheckSelect = this.onCheckSelect.bind(this);
        this.renderWorkOrders = this.renderWorkOrders.bind(this);
        this.fileCapture = this.fileCapture.bind(this);
        this.uploadCSVtoDB = this.uploadCSVtoDB.bind(this);
        this.getInventoryCSVFile = this.getInventoryCSVFile.bind(this);
    }

    onSelectStoreType(valObj, type) {
        this.setState({
            store_id: valObj.value
        });
    }

    onCheckSelect() {
        this.props.dispatch(fetchList('store_type', { store_id: this.state.store_id }));

    }
    fileCapture(file, data) {

        if (file && data) {
            let obj = [];

            let headers = [];
            let records = [];

            const splitData = data.split("\n");

            const { updateStockAction } = this.props;
            const { selectedValue, isWebApplicablility } = this.state;

            //To remove the double quote
            const doubleQuoteRemoval = (extra, value) => {
                if (extra && value[3] === '"') {
                    value = value.substr(4);
                } else if (value[0] === '"') {
                    value = value.substr(1);
                } else {
                    //do nothing
                }

                if (value[value.length - 1] === '"') {
                    value = value.substr(0, value.length - 1);
                }

                return value;
            }

            splitData.map((item, index) => {
                let values = item.split(",");

                values.map((value, type) => {
                    if (value) {
                        //let bool = (index === 0 && type === 0) ? true : false;

                        //value = doubleQuoteRemoval(bool, value);

                        if (index === 0) {
                            // obj[value] = [];
                            value = value.replace(/"/g, "");
                            headers.push(value);
                        } else {
                            // obj[headers[type]] && obj[headers[type]].push(value);
                            if (!obj[index - 1]) {
                                obj[index - 1] = {}
                            }

                            obj[index - 1][headers[type]] = value;
                        }
                    }
                });
            });

            if (obj) {
                var newObj = JSON.stringify(obj).replace(/(?:\\[rn]|[\r\n]+)+/g, "");

                //  this.props.dispatch(updateRTWInventory(JSON.parse(newObj)));
                this.setState({
                    fileUploaded: JSON.parse(newObj)
                });
            } else {
                this.setState({
                    fileUploaded: null
                });
            }
        } else {
            this.props.errorNotification(CSV_FORMAT_ERROR_MESSAGE, 'error');
        }
    }
    uploadCSVtoDB() {

        this.state.fileUploaded && this.state.fileUploaded.length > 0 && this.state.fileUploaded.map((record, index) => {
            record.count_details = (record.inventory_count > 0) ? '+' + record.inventory_count : (record.inventory_count < 0) ? '-' + -record.inventory_count : null;
            record.user_id = this.props.user.user.user_id;
        });
        if (this.state.fileUploaded) {
            this.props.dispatch(updateRTWInventory(this.state.fileUploaded));
        }
        window.scrollTo(0, 0);
    }
    renderWorkOrders() {

        const self = this;
        if (this.props.lists.store_inventory && this.props.lists.store_inventory.length > 0) {

            return (<div
                style={{
                    position: 'relative',
                    width: '100%'
                }}
            >
                <ReactTable
                    data={this.props.lists.store_inventory}
                    columns={[
                        {
                            accessor: "address",
                            Header: "Store Address"
                        }, {
                            Header: "SKU Code",
                            accessor: "sku_code"
                        },
                        {
                            Header: "Size",
                            accessor: "size"
                        },
                        {
                            Header: 'Inventory Count',
                            accessor: "inventory_count"
                        }, {
                            Header: 'Item Type Description',
                            accessor: "descr"
                        }
                    ]}
                    defaultPageSize={10}
                    className="-striped -highlight"
                />
            </div>);

            const workordersElements = this.props.lists.store_inventory.map((store_inventory, index) => {
                return <div className={cx('workorder')} key={index}>
                    <div className={cx({
                        'large': true
                    })}>{store_inventory.address}</div>
                    <div className={cx({
                        'medium': true
                    })}>{store_inventory.sku_code}</div>
                    <div className={cx({
                        'medium': true
                    })}>{store_inventory.size}</div>
                    <div className={cx({
                        'medium': true
                    })}>{store_inventory.fit}</div>
                    <div className={cx({
                        'medium': true
                    })}>{store_inventory.inventory_count}</div>
                    <div className={cx({
                        'medium': true
                    })}>{store_inventory.descr}</div>
                </div>

            });

            return (
                <div className={cx('workorders')}>

                    <div className={cx('workorder')}>
                        <div className={cx({
                            'head': true,
                            'large': true
                        })} >Store</div>
                        <div className={cx({
                            'head': true,
                            'medium': true
                        })} >Size</div>
                        <div className={cx({
                            'head': true,
                            'medium': true
                        })} >Fit</div>

                        <div className={cx({
                            'head': true,
                            'medium': true
                        })} >Inventory Count</div>
                        <div className={cx({
                            'head': true,
                            'medium': true
                        })} >Description</div>


                    </div>
                    {workordersElements}
                </div>
            )
        } else {
            return (
                <h3> No pending items available </h3>
            )
        }
    }
    generateCSV(store_inventory) {
        var fields = ['address', 'fit', 'size', 'inventory_count', 'descr', 'sku_code'];

        try {
            var result = json2csv({ data: store_inventory, fields: fields });
            console.log(result);
        } catch (err) {
            // Errors are thrown for bad options, or if the data is empty and no fields are provided.
            // Be sure to provide fields if it is possible that your data array will be empty.
            console.error(err);
        }
        return result;
    }
    getInventoryCSVFile() {
        this.props.dispatch(fetchList('store_inventory'));
    }
    render() {
        let csvDataHref = 'data:text/csv;charset=utf-8,';

        var store_list = this.props.stores.list;
        var csvData = this.generateCSV(this.props.lists.store_inventory);
        csvDataHref += csvData;
        var store_list_array = [];
        store_list.map((item, index) => {
            item.id = item.store_id;
            item.name = item.address;
            store_list_array.push(item);
        })
        return <div className={cx("container")}>

            <div className={cx("container")}>
                <div className={cx("container half")}>
                    <div className={cx("input-group")}>
                        <label htmlFor="store_type" className="required">
                            Store
                    </label>
                        <SelectForm type="store_type" rel="store_type" options={store_list_array} value={this.state.store_id} save={this.onSelectStoreType} />
                        <button className={cx("action", "primary")} onClick={this.onCheckSelect}>
                            Show Inventory Result
                    </button>
                    </div>
                    <div className={"download-wrapper csv-button"}>
                        <a className={"download-anchor"} download={STOCK_UPDATE_TEMPLATE_DOWNLOAD_FILE_NAME} target="_blank" href={csvDataHref}>
                            Export to CSV
                    </a>
                    </div>
                    <a className={cx("action", "primary", "action-button")} download={"RTWInventory.xlsx"} target="_blank" href={"/list/inventory/sheet?download=true"} >Export all to CSV
                </a>

                </div>
                <div className={cx("container half")}>
                    <div className={"input-group upload-invoice-label"}>
                        <label htmlFor="stockUpdate">
                            Upload CSV file for inventory update
                    <em className={"mandatory"}>*</em>
                        </label>
                        <FileCapture
                            fileType={"csv"}
                            accept={".csv"}
                            uploadFileDetails={this.fileCapture}
                            value={this.state.fileUploaded}
                            emptyFileUploaded={() => this.setState(
                                { fileUploaded: null }
                            )} />
                        <button className={cx("action", "primary", "action-button")} onClick={this.uploadCSVtoDB}>Upload CSV
                    </button>

                    </div>
                </div>


            </div>

            {this.renderWorkOrders()}
        </div>;
    }
}


RTWStockUpload.propTypes = {
    user: PropTypes.object,
    stores: PropTypes.object
};


function mapStateToProps({ user, stores, lists }) {
    return {
        stores,
        user,
        lists
    };
}

export default connect(mapStateToProps)(RTWStockUpload);