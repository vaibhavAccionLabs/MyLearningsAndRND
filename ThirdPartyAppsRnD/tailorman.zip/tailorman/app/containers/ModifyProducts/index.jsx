import React, { Component } from 'react';
import { connect } from 'react-redux';
import classNames from 'classnames/bind';
import styles from 'css/main';

import SearchList from '../../components/SearchList';
import UpdateImage from '../../components/UpdateImage';
import ImageUploader from '../../components/ImageUploader';

import {
  selectedProduct,
  deleteAWSCloudImage,
  getImageUploadSignUrl,
  updatertwimagecount,
  saveImageAWS,
  cleardeleteProducts,
  deleteProducts,
  previewimage,
  clearuploadedProducts,
  uploadedProducts,
  updateThreedmetadata,
  removeSelectedProduct
} from '../../actions/products';

import { fetchList, clearList } from '../../actions/list';
import _ from 'lodash';

//@class
const cx = classNames.bind(styles);
const buttonActiveStyle = {
  marginRight: '10px',
  float: 'none'
};
const buttonInActiveStyle = {
  marginRight: '10px',
  float: 'none',
  backgroundColor: '#fff',
  color: '#000'
};
const disabledButtonStyle = {
  float: 'none',
  backgroundColor: '#bbbaba',
  color: ' #484444',
  border: '#bbbaba',
  cursor: 'initial'
};
class ModifyProducts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showProduct: false,
      showWarning: false,
      neverShowWarning: false,
      disable: true,
      switchRtwTabs: 'rtw_product',
      threedmeta: '',
      threedmetamsg: '',
      rtwwarningmessage: ''
    };
    //this.toggleAccordion = this.toggleAccordion.bind(this);
    this.searchProduct = this.searchProduct.bind(this);
    this.renderProductList = this.renderProductList.bind(this);
    this.selectProduct = this.selectProduct.bind(this);
    this.saveImageHandler = this.saveImageHandler.bind(this);
    this.deleteImageHandler = this.deleteImageHandler.bind(this);
    this.onFileSelectHandler = this.onFileSelectHandler.bind(this);
    this.donotShowHandler = this.donotShowHandler.bind(this);
    this.renderProductUploader = this.renderProductUploader.bind(this);
    this.onThreedMetaChange = this.onThreedMetaChange.bind(this);

    this.onDrag = this.onDrag.bind(this);
  }
  searchProduct(keyword) {
    if (keyword.length === 0) {
      this.props.dispatch(clearList('sale_fabric'));
    } else {
      this.props.dispatch(fetchList('sale_fabric', { keyword: keyword }));
    }
  }

  onDrag(newSortedArray) {
    console.log('New Sorted Array After Rearrange ===', newSortedArray);
    //debugger;
  }

  previewImage(imgData, type) {
    //debugger;
    let { dispatch } = this.props;
    var reader = new FileReader();
    reader.onload = function(e) {
      //console.log("THE IMAGE PATH ==== ", e.target.result);
      // dispatch the action to load the image in the image array..
      dispatch(previewimage(type, e.target.result));
      // for testing log in fix dom
      //  document.getElementById("image").src = e.target.result;
    };
    // read the image file as a data URL.
    reader.readAsDataURL(imgData);
  }

  onFileSelectHandler(data) {
    //debugger;
    const fabricImages = [
      {
        item_type_id: 12,
        folderPath: 'product/RTW/Shirts/',
        folderHrPath: 'product/RTWHR/Shirts/',
        name: 'shirts',
        count: 6
      },
      {
        item_type_id: 13,
        folderPath: 'product/RTW/Bundy/',
        folderHrPath: 'product/RTWHR/Bundy/',
        name: 'bundy',
        count: 4
      },
      {
        item_type_id: 15,
        folderPath: 'product/RTW/Jackets/',
        folderHrPath: 'product/RTWHR/Jackets/',
        name: 'jacket',
        count: 5
      },
      {
        item_type_id: 27,
        folderPath: 'product/RTW/Shorts/',
        folderHrPath: 'product/RTWHR/Shorts/',
        name: 'shorts',
        count: 5
      },
      {
        item_type_id: 14,
        folderPath: 'product/RTW/Trousers/',
        folderHrPath: 'product/RTWHR/Trousers/',
        name: 'Trouser',
        count: 5
      },
      {
        item_type_id: 28,
        folderPath: 'product/RTW/Waistcoat/',
        folderHrPath: 'product/RTWHR/Waistcoat/',
        name: 'waistcoat',
        count: 4
      }
    ];
    const AWSBUCKETNAME = 'u-tm-so-img';
    const AWSINITIALURL = `https://s3.ap-south-1.amazonaws.com/${AWSBUCKETNAME}/`;

    let { dispatch } = this.props;
    let { selectedProduct } = this.props.modifyproducts;
    let { showProduct, switchRtwTabs } = this.state;
    var imageObject = _.find(fabricImages, {
      item_type_id: selectedProduct.item_type_id
    });

    if (data.name != '') {
      if (selectedProduct.mtm_flag === 'N') {
        if (switchRtwTabs === 'rtw_product') {
          if (_.isArray(selectedProduct.imageUrl)) {
            let lenOfRtwImage = selectedProduct.imageUrl.length;
            let imgPath =
              AWSINITIALURL +
              imageObject.folderPath +
              selectedProduct.product_sku_code +
              '/' +
              selectedProduct.product_sku_code +
              '.jpg';
            let filePathName = this.extractImagePath(imgPath);
            data.customPathName = this.updateRtwImageName(
              filePathName,
              lenOfRtwImage
            );
            this.previewImage(data, 'rtw');
            //this.rtwImageUpload.reset();
          }
        } else if (switchRtwTabs === 'rtw_product_hr') {
          if (_.isArray(selectedProduct.high_res_image_url)) {
            let lenOfRtwhrImage = selectedProduct.high_res_image_url.length;
            let imgPath =
              AWSINITIALURL +
              imageObject.folderHrPath +
              selectedProduct.product_sku_code +
              '/' +
              selectedProduct.product_sku_code +
              '.jpg';
            let filePathName = this.extractImagePath(imgPath);
            data.customPathName = this.updateRtwImageName(
              filePathName,
              lenOfRtwhrImage
            );
            this.previewImage(data, 'rtwhr');
            //this.rtwImageUpload.reset();
          }
        } else {
          let imgPath =
            AWSINITIALURL +
            imageObject.folderPath +
            selectedProduct.product_sku_code +
            '/' +
            selectedProduct.product_sku_code +
            '.jpg';
          data.customPathName = this.extractImagePath(imgPath);
          this.previewImage(data, 'rtwdefault');
        }
      } else {
        if (_.isArray(selectedProduct.image_url_path)) {
          //let imgPath = (showProduct)?selectedProduct.image_url_path[1] : selectedProduct.image_url_path[0];
          let imgPath = showProduct
            ? AWSINITIALURL +
              'product/' +
              selectedProduct.product_sku_code +
              '.jpg'
            : AWSINITIALURL +
              'product/' +
              selectedProduct.fabric_sku_code +
              '.jpg';
          if (showProduct) {
            this.previewImage(data, 'product');
          } else {
            this.previewImage(data, 'fabric');
          }
          data.customPathName = this.extractImagePath(imgPath);
        }
      }

      //console.log("FILE DATA IS", data)
      dispatch(uploadedProducts(data));
      this.setState({
        showWarning: true
      });
    }
  }

  donotShowHandler() {
    //debugger;
    if (this.check.checked) {
      this.setState({
        neverShowWarning: true
      });
    }
  }

  extractImagePath(imageUrl) {
    let customFileName = '';
    for (let i = 0; i < 4; i++) {
      customFileName = imageUrl.substring(imageUrl.indexOf('/') + 1);
      imageUrl = customFileName;
    }
    return customFileName;
  }
  isJsonValid(str) {
    if (_.isEmpty(str)) {
      return true;
    }
    try {
      JSON.parse(str);
    } catch (e) {
      return false;
    }
    return true;
  }
  saveImageHandler() {
    //debugger;
    let { dispatch } = this.props;
    let {
      selectedProduct,
      deletedProduct,
      uploadedProduct
    } = this.props.modifyproducts;
    let productSku = selectedProduct.product_sku_code;
    let threedmeta = this.state.threedmeta;
    let threedmetaValid = this.isJsonValid(threedmeta);
    if (!threedmetaValid) {
      this.setState({
        threedmetamsg: 'Please enter valid JSON format'
      });
      return;
    }
    if (selectedProduct.mtm_flag === 'N') {
      if (deletedProduct && deletedProduct.length > 0) {
        if (
          selectedProduct.imageUrl.length !=
          selectedProduct.high_res_image_url.length
        ) {
          this.setState({
            rtwwarningmessage:
              'Product and Product High Resolution Image Count Are Different You are not allowed to save.'
          });
        } else {
          //dispatch(deleteAWSCloudImage(deletedProduct, true, productSku));
          //dispatch(cleardeleteProducts());
          this.setState({
            rtwwarningmessage: ''
          });
        }
      }
      if (uploadedProduct && uploadedProduct.length > 0) {
        if (
          selectedProduct.imageUrl.length !=
          selectedProduct.high_res_image_url.length
        ) {
          //alert("RTW_Product AND RTW_PRODUCT_HIGH_RES are not having same count");
          this.setState({
            rtwwarningmessage:
              'Product and Product High Resolution Image Count Are Different You are not allowed to save.'
          });
        } else {
          dispatch(saveImageAWS(uploadedProduct, true, productSku));
          dispatch(clearuploadedProducts());
          this.setState({
            rtwwarningmessage: ''
          });
        }
      }
      //this.rtwImageUpload.reset();
    } else {
      let threeDObject = false;
      if (threedmetaValid)
        threeDObject = {
          fabric_id: selectedProduct.fabric_id,
          threedmeta: threedmeta
        };
      dispatch(saveImageAWS(uploadedProduct, false, false, threeDObject));
      // }
      this.imageUpload.reset();
      // dispatch(cleardeleteProducts());
      dispatch(clearuploadedProducts());
      // }
      // if (deletedProduct && deletedProduct.length > 0) {
      // 	dispatch(deleteAWSCloudImage(deletedProduct, false));
      // }
      if (uploadedProduct && uploadedProduct.length > 0) {
        dispatch(saveImageAWS(uploadedProduct, false));
      }
      //this.imageUpload.reset();
      this.setState({
        neverShowWarning: false
      });
      // dispatch(cleardeleteProducts());
      dispatch(clearuploadedProducts());
    }
  }

  updateRtwImageName(customFileName, count) {
    //debugger;
    let image_count = parseInt(count) + 1;
    //console.log("IMAGE COUNT IS=========  ", image_count);
    let newFileName = '';
    var rest = customFileName.substring(0, customFileName.lastIndexOf('.') + 0);
    var fileextension = customFileName.substring(
      customFileName.lastIndexOf('.') + 1
    );
    newFileName = rest + '_' + image_count + '.' + fileextension;
    return newFileName;
  }

  deleteImageHandler(data) {
    debugger;
    // pop image out from the array ....
    var filename = this.extractImagePath(data);
    this.props.dispatch(deleteProducts(filename));
  }

  renderProductList(product) {
    return (
      <div>
        <span className={cx('select-main-label')}>
          Product Name : {product.name}
        </span>
        <span className={cx('select-main-label')}>
          Product Type: {product.item_type_name}
        </span>
        <span className={cx('select-main-label')}>
          Product Sku: {product.product_sku_code}
        </span>
        <span className={cx('select-main-label')}>
          Fabric Sku: {product.fabric_sku_code}
        </span>
        <span className={cx('select-main-label')}>
          Available For Web: {'' + product.isavailableforweb}
        </span>
      </div>
    );
  }

  selectProduct(id) {
    let {
      lists: { sale_fabrics },
      dispatch
    } = this.props;
    const product = _.find(sale_fabrics, { fabric_id: parseInt(id) });
    this.setState({
      showProduct: false
    });
    dispatch(selectedProduct(product));
    dispatch(cleardeleteProducts());
    dispatch(clearuploadedProducts());
  }

  selectOption(option) {
    debugger;
    let delimg = false;
    let { deletedProduct, selectedProduct } = this.props.modifyproducts;

    if (selectedProduct.mtm_flag == 'N') {
      if (option === 'rtw_product') {
        this.setState({
          switchRtwTabs: 'rtw_product'
        });
        //this.rtwImageUpload.reset();
      } else if (option === 'rtw_product_hr') {
        this.setState({
          switchRtwTabs: 'rtw_product_hr'
        });
        //this.rtwImageUpload.reset();
      } else if (option === 'rtw_default') {
        this.setState({
          switchRtwTabs: 'rtw_default'
        });
        //this.rtwImageUpload.reset();
      }
    } else {
      if (option === 'product') {
        this.setState({
          showProduct: true
        });
      } else {
        this.setState({
          showProduct: false
        });
      }
      //	this.imageUpload.reset();
    }
  }
  onThreedMetaChange(e) {
    this.setState({
      threedmeta: e.target.value,
      threedmetamsg: ''
    });
  }
  componentWillReceiveProps(nextProps) {
    if (
      nextProps.modifyproducts.selectedProduct !=
      this.props.modifyproducts.selectedProduct
    ) {
      let stringobj = JSON.stringify(
        nextProps.modifyproducts.selectedProduct.threedmeta
      );
      this.setState({
        threedmeta: stringobj == 'null' ? '' : stringobj,
        threedmetamsg: ''
      });
    }
  }
  renderThreedMetadata() {
    let { threedmeta, threedmetamsg } = this.state;

    return (
      <div style={{ marginTop: '20px', marginBottom: '20px' }}>
        <label htmlFor="threedMeta">Product 3D Meta Information</label>
        <textarea
          className="threedMeta"
          value={threedmeta}
          onChange={e => {
            this.onThreedMetaChange(e);
          }}
        />
        <div style={{ color: 'red' }}>{threedmetamsg}</div>
      </div>
    );
  }
  renderMTMUploader() {
    let {
      showProduct,
      neverShowWarning,
      showWarning,
      switchRtwTabs
    } = this.state;
    let {
      selectedProduct,
      deletedProduct,
      uploadedProduct
    } = this.props.modifyproducts;
    let meta = JSON.stringify(
      this.props.modifyproducts.selectedProduct.threedmeta
    );
    let threedmetachanged =
      (meta == 'null' ? '' : meta) != this.state.threedmeta ? true : false;
    let disabled =
      deletedProduct.length == 0 && uploadedProduct.length == 0 ? true : false;
    if (threedmetachanged) {
      disabled = false;
    }
    return (
      <div>
        {this.renderThreedMetadata()}
        <div className={'toggle-button-container'}>
          <div className={'divider'} />
          <button
            className={'action primary'}
            onClick={this.selectOption.bind(this, 'fabric')}
            style={!showProduct ? buttonActiveStyle : buttonInActiveStyle}
          >
            Fabric
          </button>
          <button
            className={'action primary'}
            onClick={this.selectOption.bind(this, 'product')}
            style={showProduct ? buttonActiveStyle : buttonInActiveStyle}
          >
            Product
          </button>
        </div>
        <div className={'image-box-container'}>
          <div className={'image-container clearfix'}>
            {
              <UpdateImage
                showProduct={showProduct}
                deleteImage={this.deleteImageHandler}
                productsDeleted={deletedProduct}
                reset={false}
                singleUpload={true}
                onChange={this.onFileSelectHandler}
                title={
                  showProduct
                    ? 'Upload New Product Image'
                    : 'Upload New Fabric Image'
                }
                imgPath={
                  showProduct
                    ? selectedProduct.image_url_path[1]
                    : selectedProduct.image_url_path[0]
                }
              />
            }
          </div>

          {/*<div className={"image-upload-container"}>*/}
          {/*Image Uploader*/}
          {/*<ImageUploader
						ref={(ref) => { this.imageUpload = ref }}
						onChange={this.onFileSelectHandler}
					title={(showProduct) ? "Upload New Product Image" : "Upload New Fabric Image"} />*/}
          {/* {(!neverShowWarning && showWarning) ? <div className={"ImageUploader-WarningMessage"}>
						<span className={'message-popup'}>This will Replace the orignal image</span>
						<br />
						<span><input ref={(ref) => { this.check = ref }} type="checkbox" onClick={this.donotShowHandler} /> Do Show This Message again</span>
					</div> : ""} */}
          {/*</div>*/}
        </div>
        <div className={'save-button-container'}>
          <div className={'divider'} />
          <button
            className={'action primary'}
            onClick={this.saveImageHandler}
            style={disabled ? disabledButtonStyle : { float: 'none' }}
            disabled={disabled}
          >
            Save
          </button>
        </div>
      </div>
    );
  }
  renderRTWUploader() {
    debugger;
    //return (<div>Under Development</div>);
    let { switchRtwTabs, rtwwarningmessage } = this.state;
    let {
      selectedProduct,
      deletedProduct,
      uploadedProduct
    } = this.props.modifyproducts;
    let switchRes = 'imageUrl';
    if (switchRtwTabs === 'rtw_product_hr') {
      switchRes = 'high_res_image_url';
    } else if (switchRtwTabs === 'rtw_default') {
      switchRes = 'image_url_path';
    }
    return (
      <div className={cx('input-group')}>
        <div className={'toggle-button-container'}>
          <button
            className={'action primary'}
            onClick={this.selectOption.bind(this, 'rtw_product')}
            style={
              switchRtwTabs === 'rtw_product'
                ? buttonActiveStyle
                : buttonInActiveStyle
            }
          >
            Product
          </button>
          <button
            className={'action primary'}
            onClick={this.selectOption.bind(this, 'rtw_product_hr')}
            style={
              switchRtwTabs === 'rtw_product_hr'
                ? buttonActiveStyle
                : buttonInActiveStyle
            }
          >
            Product High Resolution
          </button>
          <button
            className={'action primary'}
            onClick={this.selectOption.bind(this, 'rtw_default')}
            style={
              switchRtwTabs === 'rtw_default'
                ? buttonActiveStyle
                : buttonInActiveStyle
            }
          >
            Default Product Image
          </button>
        </div>

        <div className={'image-container rtw'}>
          <div className={'display-all-rtw-images clearfix'}>
            {
              <UpdateImage
                deleteImage={this.deleteImageHandler}
                title={'Upload New Image'}
                reset={true}
                onChange={this.onFileSelectHandler}
                imgPath={selectedProduct[switchRes]}
                productsDeleted={deletedProduct}
                onDrag={this.onDrag}
              />
            }
          </div>
          {/*<div className={'imageUploader-container rtw'}>
					<ImageUploader
						title={"Upload New Image"}
						ref={(ref) => { this.rtwImageUpload = ref }}
						onChange={this.onFileSelectHandler}
					/>
					</div>*/}
          <div style={{ clear: 'both' }} />
          <div className={'save-button-container rtw'}>
            <div className={'divider'} />
            <div className="rtw-warning">{rtwwarningmessage}</div>
            <button
              className={'action primary'}
              onClick={this.saveImageHandler}
              style={
                deletedProduct.length == 0 && uploadedProduct.length == 0
                  ? disabledButtonStyle
                  : { float: 'none' }
              }
              disabled={
                deletedProduct.length == 0 && uploadedProduct.length == 0
                  ? true
                  : false
              }
            >
              Save
            </button>
          </div>
        </div>
      </div>
    );
  }
  renderProductUploader() {
    let { selectedProduct } = this.props.modifyproducts;

    if (_.isEmpty(selectedProduct)) {
      return (
        <div className={'no-content'}>
          Select A Product Which You Want to Update
        </div>
      );
    }
    return (
      <div className={'image-modifier'}>
        {/* <div className={'product-info'}>
					<div className={'product-info-heading'}><h3>Product Info:</h3></div>
					<div className={'product-info-box'}>Product Name : {selectedProduct.name}</div>
					<div className={'product-info-box'}>Fabric Code : {selectedProduct.fabric_sku_code} </div>
					<div className={'product-info-box'}>Supplier Product Code : {selectedProduct.product_sku_code}</div>
					<div className={'product-info-box'}>Item Type Name : {selectedProduct.item_type_name}</div>
				</div> */}
        {selectedProduct.mtm_flag === 'Y'
          ? this.renderMTMUploader()
          : this.renderRTWUploader()}
      </div>
    );
  }
  render() {
    return (
      <div className={'container'}>
        <h1>Update Fabric Details</h1>
        <div className={cx('input-group')} style={{ display: 'flex' }}>
          <SearchList
            search={this.searchProduct}
            select={this.selectProduct}
            results={this.props.lists.sale_fabrics}
            renderItem={this.renderProductList}
            placeholder="search for product"
          />
          {this.renderProductUploader()}
        </div>
      </div>
    );
  }
}

function mapStateToProps({ lists, modifyproducts }) {
  return {
    lists,
    modifyproducts
  };
}

export default connect(mapStateToProps)(ModifyProducts);
