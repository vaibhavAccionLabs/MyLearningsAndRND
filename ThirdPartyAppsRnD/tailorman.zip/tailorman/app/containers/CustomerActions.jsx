import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';
import { Link } from 'react-router';
import classNames from 'classnames/bind';
import { connect } from 'react-redux';
import styles from 'css/components/customeractions';
import { fetchList } from 'actions/list';
import { selectOrder } from 'actions/order';
import SelectForm from 'components/SelectForm';
const cx = classNames.bind(styles);
import back from 'images/back-arrow.png';
import _ from 'lodash';
import * as types from 'types';
import {
    push
} from 'react-router-redux';
import {resetGiftCards} from 'actions/giftcard'

class CustomerActions extends Component {
    constructor(props) {
        super(props);
        this.selectOrder = this.selectOrder.bind(this);
        this.getEditOrderElement = this.getEditOrderElement.bind(this);
        this.onNewOrderClick =this.onNewOrderClick.bind(this);
    }
    componentDidMount() {
        this.props.dispatch(fetchList('orders', { customer_id: this.props.customer.customer_id }));
    }

    onNewOrderClick(){
           this.props.dispatch({
            type: types.CLEAR_ORDER_DATA
        })

        this.props.dispatch(push('/order'));
    }

    selectOrder(selectedOrder, type) {
       
        if (type == 'order') {
            var _order = _.find(this.props.lists.orders, { order_id: selectedOrder.value });
            _order.is_full_payment = (_order.full_payment_flag=="Y")?true:false;            
            this.props.dispatch(selectOrder(_order, true));
        }
    }
    getOrderAlteration() {
        // if (this.props.user.user.isPPD) {
            return (
                <Link to="/order/alteration" className={cx('option')} >
                    Order Alteration
                </Link>
            );
        // }
    }
    getEditOrderOptions(){
        if(this.props.user.user.isPPD){
            return this.props.lists.orders; 
        }else{
            let activeOrders = _.filter(this.props.lists.orders, ['w_o_print_status',false]);
            return activeOrders;
        }
    }
    getEditOrderElement() {
        // if (this.props.user.user.isPPD) {
            return (
                <div className={cx('input-group')}>
                    <label htmlFor="select_order">Edit Order</label>
                    <SelectForm type="order" rel="order" options={this.getEditOrderOptions()} save={this.selectOrder} />
                </div>
            );
        // }
    }
    getGiftCardElement(){
        return (
                <Link to="/giftcard/list" className={cx('option')} onClick={()=>{this.props.dispatch(resetGiftCards())}}>
                   New Gift Card
                </Link>
            );
    }
    


    render() {
        return (
            <div className={cx('container', 'customer-actions')}>
                <div className={cx('header-note')}>
                    <span className={cx('header-label')}>Customer:   </span>
                    <span className={cx('header-content')}>{this.props.customer.name}</span>
                </div>

                <h1>Orders</h1>
                <Link to="/customer" className={cx('back')} ><img src={back} /></Link>

                <div className={cx('form-container')}>
                    <a className={cx('option')} onClick={this.onNewOrderClick} >
                        New Order
                      </a>
                     {this.getGiftCardElement()}  
                    {this.getOrderAlteration()}
                    {this.getEditOrderElement()}
                    <Link to="/order/history" className={cx('option')}>
                        Order History
				    </Link>
                    <Link to="/order/updatemeasurement" className={cx('option')}>
                        Update Order Pending Details
				</Link>
                    <Link to="/order/newmeasurements" className={cx('option')}>
                        Add Measurements
				</Link>
                </div>
            </div>
        );
    }
}

CustomerActions.propTypes = {
    user: PropTypes.object,
    customer: PropTypes.object,
    lists: PropTypes.object
};


function mapStateToProps({ lists, customer, user }) {
    return {
        customer,
        user,
        lists
    };
}

// Connects React component to the redux store
// It does not modify the component class passed to it
// Instead, it returns a new, connected component class, for you to use.
export default connect(mapStateToProps)(CustomerActions);
