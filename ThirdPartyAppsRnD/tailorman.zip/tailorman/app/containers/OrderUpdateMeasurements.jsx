import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';
import classNames from 'classnames/bind';
import styles from 'css/components/workorder';
import ImageViewer from './ImageViewer';
import {
	push
} from 'react-router-redux';
import { fetchList, clearList } from '../actions/list';
import _ from 'lodash';
import MeasurementsForm from 'components/MeasurementsForm';
import {
	getWorkOrderPendingDetails,
	updateWorkOrderItemStage,
	getWorkOrders,
	updateProfile,
	updateWorkOrderIsNewMeasurement,
	updateWorkOrderMeasurementProfileId,
	updatedProfileInOrderItemLevel
} from 'actions/workorder';
import {
	updateMessage,
	saveProfile,
	saveImageAWS
} from 'actions/order';
import { connect } from 'react-redux';
import ReactDOM from 'react-dom';
import back from 'images/back-arrow.png';
import Slider from 'react-slick';
import MultipleChoice from 'components/MultipleChoice';
import SelectForm from 'components/SelectForm';


import * as types from 'types';

const cx = classNames.bind(styles);

class OrderUpdateMeasurements extends Component {
	constructor(props) {
		super(props);
		this.closeForm = this.closeForm.bind(this);
		this.loadFields = this.loadFields.bind(this);
		this.saveMeasurements = this.saveMeasurements.bind(this);
		this.showMessage = this.showMessage.bind(this);
		this.renderCarousel = this.renderCarousel.bind(this);
		this.handleViewerClose = this.handleViewerClose.bind(this);
		this.onImageButtonClick = this.onImageButtonClick.bind(this);
		//this.afterChange = this.afterChange.bind(this);
		this.saveImageAWS = this.saveImageAWS.bind(this);
		this.toggleUpchargeMeasurement =this.toggleUpchargeMeasurement.bind(this);
		this.saveSelectFormValues =this.saveSelectFormValues.bind(this);
		this.saveExistingProfile =this.saveExistingProfile.bind(this);
		this.state = {
			images: [],
			activeImageIndex: 0,
			imageViewer: false
		}
	}
	saveImageAWS(file){
		 const workorder = _.find(this.props.orderupdate.updatestyleorder, { order_item_id: parseInt(this.props.params.order_item_id) });
         this.props.dispatch(saveImageAWS(file, workorder.order_id, types.IMAGE_TYPE_MEASUREMENT));

    }
	handleViewerClose() {
		this.setState({
			imageViewer: false
		});
	}
	onImageButtonClick(index) {
		this.setState({
			//images: this.props.workorder.selected.images,
			activeImageIndex: index,
			imageViewer: true
		});
	}
	// afterChange(activeIndex) {
	// 	this.state = {
	// 		activeImageIndex: activeIndex,
	// 	}
	// }
	toggleUpchargeMeasurement(value) {
        if (value[0] == 'yes') {
			value = true;
				 this.props.dispatch(updateWorkOrderMeasurementProfileId(-1, 'profile_id'));
        } else {
            value = false;
        }
 this.props.dispatch(updateWorkOrderIsNewMeasurement(value, 'is_new_measurements'));
	}
saveSelectFormValues(value){
	

	 this.props.dispatch(updateWorkOrderMeasurementProfileId(value.value, 'profile_id'));

}
	saveExistingProfile(){

	   var selectedWorkOrderItem = this.props.workorder.selected.order_item;
		var profileId = this.props.workorder.profile_id;
		var data={
			order_id:selectedWorkOrderItem.order_id,
			order_item_id:selectedWorkOrderItem.order_item_id,
			workflow_id:selectedWorkOrderItem.workflow_id,
			comment:selectedWorkOrderItem.comment,
			profile_id:profileId,
			workflow_start_stage_id:13
		}
	   if(profileId>0){
	   this.props.dispatch(updatedProfileInOrderItemLevel(data));
	   	this.props.dispatch(push('/order/updatemeasurement'));
	   }
		
	}
	
	componentDidMount() {
		

             const workorder = _.find(this.props.orderupdate.updatestyleorder, { order_item_id: parseInt(this.props.params.order_item_id) });
            //  this.props.workorder.selected.order_item = workorder;
            //  this.props.workorder.selected.order_item.profile = {};
            //  this.props.workorder.selected.order_item.profile.profile_id =  workorder.profile_id;
            //  this.props.workorder.selected.order_item.profile_id =  workorder.profile_id;
             this.props.dispatch(fetchList('measurement_type'));
		// this.props.dispatch(getWorkOrderMeasurementDetails(workorder.order_id, workorder.order_item_id, workorder.profile_id, this.props.params.type));
		this.props.dispatch(getWorkOrderPendingDetails(workorder.order_id, workorder.order_item_id, workorder.profile_id, this.props.params.type,false,workorder.cusomer_id));
		this.props.dispatch(fetchList('profile', { item_type_id:workorder.item_type_id , customer_id: workorder.cusomer_id }));
	}

	saveMeasurements(value, updateFields) {
		if (value.profile) {
			
	
			const workorder = _.find(this.props.orderupdate.updatestyleorder, { order_item_id: parseInt(this.props.params.order_item_id) });
			value.profile.customer_id = this.props.customer.customer_id;
			value.profile.item_type_id = workorder.item_type_id;
			if (this.props.params.type == 'default') {
				if (parseInt(this.props.params.order_item_id) === parseInt(this.props.workorder.selected.order_item.order_item_id)) {
					if (parseInt(this.props.workorder.selected.order_item.profile_id) === parseInt(value.profile.profile_id)) {
						value.profile.profile_id = 0;
					}
				}
			}
			saveProfile(value.profile, value.measurements).then(function (profile_id) {
				workorder.profile_id = profile_id;
				const stage = _.find(this.props.workorder.stageList, { stage_id: workorder.current_stage_id });
                workorder.stage_id = [13];
                workorder.profile = this.props.workorder.selected.order_item.profile;
                this.props.workorder.selected.order_item.comment = value.profile.comment;
             //   this.props.workorder.selected.order_item.profile = value.profile;
             //   this.props.workorder.selected.order_item.profile_id = value.profile.profile_id;
				if (this.props.params.type == 'default') {
					updateWorkOrderItemStage(workorder, workorder, value.profile.comment, this.props.user.user.user_id, workorder.current_stage_id).then((status) => {
                        // this.props.dispatch(getWorkOrders.apply(this, this.props.workorder.query));
						// this.props.dispatch(getWorkOrders(13,null,null,null,this.props.customer.customer_id,workorder.order_id));
						this.props.dispatch(push('/order/updatemeasurement'));
						this.props.dispatch(updateMessage('UPDATE_GENERAL_MESSAGE', 'Measurements Updated'));
					});
				} else {
                    // this.props.dispatch(getWorkOrders.apply(this, this.props.workorder.query));
					// this.props.dispatch(getWorkOrders(13,null,null,null,this.props.customer.customer_id,workorder.order_id));
					this.props.dispatch(push('/order/updatemeasurement'));
					this.props.dispatch(updateMessage('UPDATE_GENERAL_MESSAGE', 'Measurements Updated'));
				}
			}.bind(this));
		}
		if (updateFields) {
           
            
			this.props.dispatch(updateProfile());
		}
	}

	showMessage(type, value) {
		this.props.dispatch(updateMessage(type, value));
	}

	loadFields(measurement_type_id, clear) {
		if (this.props.params.type == 'default')
			this.props.dispatch(fetchList('measurement_field', { item_type_id: this.props.workorder.selected.order_item.item_type_id, measurement_type_id: measurement_type_id, clear: clear }));
		else {
			if (!clear) {
				this.props.dispatch({
					type: types.FETCH_LIST_MEASUREMENT_FIELDS,
					measurement_fields: this.props.workorder.selected.order_item.profile.measurements.map((field) => {
						return {
							code: field.code,
							category: null,
							measurement_type_id: field.id
						}
					})
				});
			} else {
				this.props.dispatch({
					type: types.FETCH_LIST_MEASUREMENT_FIELDS,
					measurement_fields: []
				})
			}
		}

	}

	closeForm() {
		this.props.dispatch(push('/order/updatemeasurement'));
	}

	renderCarousel() {

		let imageList = this.props.workorder.selected.images;
		if (imageList && imageList.length > 0) {
			// var settings = {
			// 	dots: true,
			// 	infinite: false,
			// 	speed: 500,
			// 	slidesToShow: 1,
			// 	slidesToScroll: 1,
			// 	adaptiveHeight: true
			// };
			return (
				/*<div className={'viewer-wrap'} >
					<div className={cx('react-viewer-icon', 'viewer-button', 'viewer-fullscreen')}
						onClick={this.onImageButtonClick}>SHOW</div>
					<Slider afterChange={this.afterChange} {...settings }>
						{
							this.props.workorder.selected.images.map((image, index) => {
								return (
									<div className={cx('image-container')} key={index}>
										<img src={image} />
									</div>)
							})
						}
					</Slider>
				</div> */

				<div className={'img-list'}>
                {imageList.map((item, index) => {
                  return (
                    <div key={index.toString()} className="img-item">
                      <img src={item} onClick={() => { this.onImageButtonClick(index) }}/>
                    </div>
                  );
                })}
              </div>
			)
		} else {
			return (
				<h3> No Images Found</h3>
			)
		}
	}

	getMeasurementType(is_new_measurements,profiles,profile_id){
	 
		if(is_new_measurements==false){
           return(<span style={{width:'100%'}}><div className={cx('input-group')}>
							<label htmlFor="profiles">Profiles</label>
							<SelectForm type="profiles" rel="profile_id" options={profiles} value={profile_id} save={this.saveSelectFormValues} />
						</div>
						<button onClick={this.saveExistingProfile} style={{float: "none"}}className={cx('action', 'primary')}>Save Profile</button>
				 </span>)
		}else{
			return(<MeasurementsForm
								lists={this.props.lists}
								item_type_id={this.props.workorder.selected.order_item.item_type_id}
								loadFields={this.loadFields}
								close={this.closeForm}
								save={this.saveMeasurements}
								addImage={this.saveImageAWS}
								is_source_disabled={(this.props.params.type == 'default') ? false : true}
								profile={this.props.workorder.selected.order_item.profile}
								message={this.showMessage}
								is_source_disabled={(this.props.params.type == 'default') ? false : true} />);
		}


	}
	getIsNewMeasurement(){
		
		var {selected,is_new_measurements,profile_id} =this.props.workorder;
		// if(selected && selected.order_item && selected.order_item.profile_id != -1){
			// is_new_measurements = true;
		// }
		return is_new_measurements;
	}
	render() {
		var {profile_id} =this.props.workorder;
		let is_new_measurements = this.getIsNewMeasurement();
		var profiles =this.props.lists.profiles;
		if (this.props.workorder.selected.order_item) {
			return ( 
				<div>
					<div className={cx('half', 'add-measure-scroll')}>
						<div className={cx('container')}>
							<h1>Update Measurements</h1>
							{/* { ( this.props.workorder.selected.order_item.profile_id == -1 ) ?  */}
							{(<div className={cx('input-group')}>
								<label htmlFor="is_upcharge_measurements">Is New/Update Measurement</label>
								<MultipleChoice isMultiple={false} options={['yes', 'no']} selected={(is_new_measurements === false) ? 'no' : 'yes'} rel="is_upcharge_measurements" save={this.toggleUpchargeMeasurement} />
							</div>)}
							{/* : "" } */}
							<Link to="/order/updatemeasurement" className={cx('back')} ><img src={back} /></Link>
							 {this.getMeasurementType(is_new_measurements,profiles,profile_id)}
						</div>
					</div>
					<div className={cx('half', 'stick-right', 'slick-wrapper', 'add-measure-scroll')}>
						<h1>Images </h1>
						<ImageViewer 
							visible={this.state.imageViewer} 
							onClose={this.handleViewerClose} 
							images={this.props.workorder.selected && this.props.workorder.selected.images || []} 
							activeIndex={this.state.activeImageIndex}
							onMaskClick={this.handleViewerClose}  />
						{this.renderCarousel()}
					</div>
				</div>
			);
		} else {
			return null;
		}

	}
}

OrderUpdateMeasurements.propTypes = {
	workorder: PropTypes.object,
	user: PropTypes.object,
	lists: PropTypes.object,
    orderupdate: PropTypes.object,
    customer: PropTypes.object
};


function mapStateToProps({ workorder, user, customer, lists,orderupdate }) {
	return {
		workorder,
		user,
		customer,
		lists,
		orderupdate
	};
}

export default connect(mapStateToProps)(OrderUpdateMeasurements);