import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';
import classNames from 'classnames/bind';
import { connect } from 'react-redux';
import styles from 'css/components/customer';
import NumberForm from '../components/NumberForm';
import SelectForm from '../components/SelectForm';
import SearchList from '../components/SearchList';
import { selectCustomer, saveCustomerPhone, updatePendingAmountDetails } from '../actions/customer';
import { fetchList, clearList } from '../actions/list';
import { setActiveKey } from '../actions/history';
import { Link } from 'react-router';
import back from 'images/back-arrow.png';
import Collapse, { Panel } from 'rc-collapse';
import ants from 'images/ants.png';
import ReactTable from "react-table";
import "react-table/react-table.css";
import OrderPendingPaymentDetails from 'components/OrderPendingPaymentDetails';



import _ from 'lodash';
const cx = classNames.bind(styles);

class Customer extends Component {
	constructor(props) {
		super(props);
		this.selectCustomer = this.selectCustomer.bind(this);
		this.saveCustomerPhone = this.saveCustomerPhone.bind(this);
		this.searchCustomers = this.searchCustomers.bind(this);
		this.selectNewCustomer = this.selectNewCustomer.bind(this);
		this.accordion = true;
		this.toggleAccordion = this.toggleAccordion.bind(this);
		this.renderCustomerListItem = this.renderCustomerListItem.bind(this);
		this.getPendingAmountDetails = this.getPendingAmountDetails.bind(this);
		this.toggleMenu = this.toggleMenu.bind(this);
		this.onAddPaymentClick = this.onAddPaymentClick.bind(this);
		this.updateDetails = this.updateDetails.bind(this);
		this.state = {
			record: {},
			popup_status: false
		}
	}
	componentDidMount() {
		this.props.dispatch(fetchList('store_pending_amounts', this.props.stores.selected));
		this.props.dispatch(fetchList('payment_type'));
	}
	toggleMenu(record) {
		this.setState({
			record: record,
			popup_status: true
		});
	}
	updateDetails(type, pending_amount) {
		let { record } = this.state;
		var data = {
			pending_amount: pending_amount,
			order_id: record.order_id,
			user_id: record.user_id || "",
			customer_id: record.customer_id,
			store_id: this.props.stores.selected.store_id
		}
		this.props.dispatch(updatePendingAmountDetails(data))
	}
	searchCustomers(keyword) {
		if (keyword.length === 0) {
			this.props.dispatch(clearList('customer'));
		} else {
			this.props.dispatch(fetchList('customer', { keyword: keyword,store_id:this.props.stores.selected.store_id }));
		}
	}
	saveCustomerPhone(value) {
		this.props.dispatch(saveCustomerPhone(value));
	}
	selectCustomer(value) {
		var self = this;
		var _customer = _.find(this.props.lists.customers, { customer_id: parseInt(value) });
		this.props.dispatch(selectCustomer(_customer));

	}
	selectNewCustomer() {
		var self = this;
		var _customer = {
			name: ReactDOM.findDOMNode(self.refs.name).value,
			email: ReactDOM.findDOMNode(self.refs.email).value,
			phone: self.props.customer.phone,
			store_id: self.props.stores.selected.store_id,
			referral_code: ReactDOM.findDOMNode(self.refs.referral_code).value
		}
		this.props.dispatch(selectCustomer(_customer, true));
	}
	toggleAccordion(activeKey) {
		this.props.dispatch(setActiveKey(activeKey));
	}
	renderCustomerListItem(customer) {
		return (
			<div>
				<span className={cx('select-main-label')}>{customer.name}</span>
				<span className={cx('select-email')}>Customer ID: {customer.id}</span>
				<span className={cx('select-email')}>{customer.email}</span>
				<span className={cx('select-phone')}>{customer.phone}</span>
				<span className={cx('select-phone')}>Current Tier : {customer.current_slab}</span>
				<span className={cx('select-phone')}>Loyality Points : {customer.loyalty_points}</span>
				<span className={cx('select-phone')}>Total Order Amount : {customer.total_order_amount}</span>
			</div>
		)
	}
	getPendingAmountDetails() {
		var store_pending_amounts_o = this.props.lists.store_pending_amounts;
		var pendingAmountsEl = "";
		
		var store_pending_amounts = _.filter(store_pending_amounts_o,(o)=>{
			return o.total_amount - o.amount
		});

		if (store_pending_amounts && store_pending_amounts.length > 0) {

			return (
				<div
					style={{
						position: 'relative',
						width: '100%'
					}}
				>
					<ReactTable
						data={store_pending_amounts}
						columns={[
							{
								Header: "Order",
								accessor: "order_id",
								//  Cell: this.renderEditable
							},
							{
								Header: "Customer",
								accessor: "name",
								//  Cell: this.renderEditable
							}, {
								Header: "Amount Paid",
								accessor: "amount",
								//  Cell: this.renderEditable
							},
							{
								Header: "Pending Amount",
								id: "full",
								accessor: d => {
									return d.total_amount - d.amount
								},
								// Cell: this.renderEditable
							}, {
								Header: "Actual Total Amount",
								accessor: "total_amount",
								// Cell: this.renderEditable
							}, {
								Header: "Payment",
								accessor: "order_id",
								// Cell: this.renderEditable
								Cell: row => {
									return (<button
										onClick={this.toggleMenu.bind(this, row.original)}
										>
										{/* <img src={ants} /> */}
										Make Payment
									</button>
									)
								}
							}
						]}
						defaultPageSize={10}
						className="-striped -highlight"
					/>
				</div>)
		}
	}
	onAddPaymentClick() {
		this.setState({
			popup_status: !this.state.popup_status
		});
	}

	render() {
		let { popup_status, record: { total_amount, pending_amounts } } = this.state;
		return (
			<div className={cx('container')}>
				<OrderPendingPaymentDetails
					onAddPendingAmount={this.updateDetails}
					openPaymentPopup={popup_status}
					pending_amount={pending_amounts || []}
					total_amount={total_amount}
					onAddPaymentClick={this.onAddPaymentClick}
					payment_types={this.props.lists.payment_types} />
				<h1>Customer</h1>
				<Link to="/stores" className={cx('back')} ><img src={back} /></Link>
				<Collapse
					accordion={this.accordion}
					onChange={this.toggleAccordion}
					activeKey={this.props.history.accordionKey}
				>
					<Panel header="Existing Customers" >
						<div className={cx('form-container')}>
							<h3>Select Customer</h3>
							<div className={cx('input-group')}>
								<label htmlFor="select_customer">Select Existing Customer</label>
								<SearchList
									search={this.searchCustomers}
									select={this.selectCustomer}
									results={this.props.lists.customers}
									renderItem={this.renderCustomerListItem}
									placeholder="search for email, phone or name" />
							</div>
						</div>
					</Panel>
					<Panel header="New Customer">
						<div className={cx('form-container')}>
							<h3>New Customer</h3>
							<div className={cx('input-group')}>
								<label htmlFor="name">Name</label>
								<input type="text" ref="name" />
							</div>
							<div className={cx('input-group')}>
								<label htmlFor="email">Email</label>
								<input type="email" ref="email" />
							</div>
							<div className={cx('input-group')}>
								<label htmlFor="phone">Phone</label>
								<NumberForm type="phone" ref="phone" save={this.saveCustomerPhone} />
							</div>
							<div className={cx('input-group')}>
								<label htmlFor="referral_code">Referral Code</label>
								<input type="text" ref="referral_code" />
							</div>
							<button onClick={this.selectNewCustomer} className={cx('action', 'primary')}>Save</button>
						</div>
					</Panel>
					<Panel header="Pending Amount details" >
						<div className={cx('form-container')}>
							<h3>Pending Amount details</h3>
							{this.getPendingAmountDetails()}
						</div>
					</Panel>

				</Collapse>
			</div>
		);
	}
}

Customer.propTypes = {
	user: PropTypes.object,
	customer: PropTypes.object,
	lists: PropTypes.object,
	history: PropTypes.object,
	stores: PropTypes.object
};
function mapStateToProps({ customer, user, lists, history, stores }) {
	return {
		customer,
		lists,
		user,
		history,
		stores
	};
}

export default connect(mapStateToProps)(Customer);