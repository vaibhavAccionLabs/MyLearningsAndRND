import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';
import back from 'images/back-arrow.png';
import styles from 'css/components/giftcarddetails';
import classNames from 'classnames/bind';
import { Link } from 'react-router';
import {
    push
} from 'react-router-redux';
import { connect } from 'react-redux';

import { giftCardPayment } from 'actions/giftcard';

const cx = classNames.bind(styles);


class GiftPayment extends Component {
    constructor(props) {
        super(props);
    }

    renderCards() {
        let giftcards = this.props.giftcard && this.props.giftcard.giftcards
        return giftcards && giftcards.map((item, index) => {
            return (<li key={index}><div><span className={cx('label')}>GiftCard {index + 1}</span></div>
                <div><span className={cx('label')}>Base Mrp</span><span className={cx('value')}>{item.amount}</span></div>
                <div><span className={cx('label')}>Quantity</span><span className={cx('value')}>{item.quantity}</span></div>
                <div><span className={cx('label')}>Sub Total</span><span className={cx('value')}>{item.quantity * item.amount}</span></div>
                <div>
                    <span className={cx('label')}>Recipient Email :</span><span className={cx('value')}>{item.recipientemail.join(' , ')}</span>
                </div>
            </li>)
        })

    }

    getTotalAmount() {
        let giftcards = this.props.giftcard && this.props.giftcard.giftcards
        let totaAmount = 0;
        giftcards && giftcards.map((item, index) => {
            totaAmount += item.quantity * item.amount
        })
        return totaAmount
    }
    onProceedToPayment() {
        let { customer, giftcard, stores } = this.props

        let giftcarddetails = {
            giftcard: giftcard.giftcards,
            customer_id: customer.customer_id,
            store_id: stores.selected.store_id,
            total_amount : this.getTotalAmount()
        }

        if (giftcard.giftcards) {
            this.props.dispatch(giftCardPayment(giftcarddetails));
            //console.log("giftCard",JSON.stringify(giftcarddetails))
        }
    }

    render() {
        return (
            <div className={cx('container')}>
                <Link to="/giftcard/list" className={cx('back')} ><img src={back} /></Link>
                <h1>Payment</h1>
                <div className={cx('header-note')}>
                    <span className={cx('header-label')}>Customer:   </span>
                    <span className={cx('header-content')}>{this.props.customer.name}</span>
                </div>
                <div className={cx('form-container')}>
                    <ul className={cx('cart')}>
                        {this.renderCards()}
                    </ul>

                    <ul className={cx('cart')}>
                        <div className="discount_amount total">
                            <span htmlFor="total_amount" style={{ "word-spacing": "2px" }}>Total Amount</span>
                            <span className='amount'>{this.getTotalAmount()}</span>
                        </div>
                    </ul>
                    <button className={cx('submit', 'action', 'primary')} onClick={() => { this.onProceedToPayment() }}>Proceed Payment</button>
                </div>

            </div>
        );
    }
}


function mapStateToProps({ customer, giftcard, stores }) {
    return {
        customer,
        giftcard,
        stores

    };
}

export default connect(mapStateToProps)(GiftPayment);