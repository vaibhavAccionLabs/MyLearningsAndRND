import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';
import back from 'images/back-arrow.png';
import styles from 'css/components/giftcarddetails';
import classNames from 'classnames/bind';
import { Link } from 'react-router';
import {
    push
} from 'react-router-redux';
import {connect} from 'react-redux'
import {deleteGiftcard} from 'actions/giftcard';
import {updateMessage} from 'actions/order'


const cx = classNames.bind(styles);


class GiftCardsList extends Component {
    constructor(props) {
        super(props);
        this.renderGiftCards = this.renderGiftCards.bind(this)
        this.deleteGiftCard = this.deleteGiftCard.bind(this)
    } 

    deleteGiftCard(id){
        this.props.dispatch(deleteGiftcard(id))
        this.props.dispatch(updateMessage('INSERT_GIFT_CARD_SUCCESS',"The gift card deleted successfully."))
    }
   

   renderGiftCards(giftcards){
   	   
            if(!_.isEmpty(giftcards)){
            	return giftcards.map((item,index)=>{
   	            	return <div key={index} className={cx('sale-item')}>
                            <div className={cx('display')}><span>GiftCard {index+1}</span></div>
                            <Link className={cx('action', 'small')} to={"/giftcard/details/"+item.id}>Edit</Link>
                            <button className={cx('action', 'small', 'primary')} onClick={()=>{this.deleteGiftCard(item.id)}}>Delete</button>
                           </div>
   	              })
            } else{
            	return <div className={cx('sale-item')}>No Gift Cards Available</div>
            }
   	        
   }
    render() {
    	let giftcards=this.props.giftcard && this.props.giftcard.giftcards
        return (
           <div className={cx('container')}>
                <Link to="/customer/actions" className={cx('back')} ><img src={back} /></Link>
                <h1>Gift Cards</h1>
                <div className={cx('header-note')}>
					<span className={cx('header-label')}>Customer:   </span>
					<span className={cx('header-content')}>{this.props.customer.name}</span>
				</div>
                <div className={cx('form-container')}>
                    {this.renderGiftCards(giftcards)}
                    <Link className={cx('action', 'primary')} to={"/giftcard/details/new"}>Add Gift</Link>
                    { !_.isEmpty(giftcards) ? <Link className={cx('action', 'primary')} to={"/giftcard/payment"}>Checkout</Link> : ''}
                </div>

            </div>
        );
    }
}

GiftCardsList.propTypes = {
 
};

function mapStateToProps({ customer,giftcard}) {
    return {
        customer,
        giftcard
       
    };
}

export default connect(mapStateToProps)(GiftCardsList);
