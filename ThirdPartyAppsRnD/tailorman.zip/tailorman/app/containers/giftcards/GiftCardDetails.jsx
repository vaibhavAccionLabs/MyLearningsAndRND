import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';
import back from 'images/back-arrow.png';
import styles from 'css/components/giftcarddetails';
import classNames from 'classnames/bind';
import { Link } from 'react-router';
import {
    push
} from 'react-router-redux';
import { connect } from 'react-redux'
import { insertGiftcard } from 'actions/giftcard';
import { updateMessage } from 'actions/order'
import moment from 'moment';
import MultipleChoice from 'components/MultipleChoice';
import MultiInputField from '../../components/MultiInputField';

const cx = classNames.bind(styles);
const gift_amounts = ['2500','5000','7500','10000','Other Amount'];

class GiftCardDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            gifts: [],
            gifts_email: [],
            gifts_name: [],
            gift_amount : null,
            gift_other_amount : false
        }
        this.onEmailKeyDown = this.onEmailKeyDown.bind(this);
        this.updategifts = this.updategifts.bind(this);
        this.deleteChip = this.deleteChip.bind(this);
        this.onNameFocusLeave = this.onNameFocusLeave.bind(this);
        this.onEmailFocusLeave = this.onEmailFocusLeave.bind(this);
        this.onNameKeyDown = this.onNameKeyDown.bind(this);
        this.toggleAmountSelection = this.toggleAmountSelection.bind(this);
        this.handleGiftCardAmountChange = this.handleGiftCardAmountChange.bind(this);
    }
    
    checkEmailvalidation(emails) {
        let emailRegex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        let bool = true;

        if (_.isArray(emails)) {
            bool && emails.map((mail) => {
                bool = emailRegex.test(mail);
            })
        } else {
            bool = emailRegex.test(emails);
        }
        if (!bool) {
            this.props.dispatch(updateMessage('INSERT_GIFT_CARD_FAILURE', "Please enter the valid email id's only"))
            window.scrollTo(0, 0);
        }
        return bool;
    }

    checkWithQty(gift) {
        if ((gift.quantity == gift.recipientemail.length) && gift.quantity == gift.recipientname.length) {
            return true
        } else {
            this.props.dispatch(updateMessage('INSERT_GIFT_CARD_FAILURE', "The quantity is must be equal to no'of recipientemail's and recipient persons."))
            window.scrollTo(0, 0);
            return false
        }
    }
    checkDatevalidation(date) {
        let validdate = moment().add(3, 'months').format('YYYY-MM-DD')
        let curentdate = moment().format('YYYY-MM-DD')
        if (date >= curentdate && date <= validdate) {
            return true;
        } else {
            this.props.dispatch(updateMessage('INSERT_GIFT_CARD_FAILURE', "Please select tha delivary date in between current and next three months only"))
            window.scrollTo(0, 0);
            return false;
        }
    }
    componentDidMount() {
        let giftArray = this.props.giftcard && this.props.giftcard.giftcards;
        let paramid = this.props.params.gift_id;
        let giftobject = _.clone(_.find(giftArray, { id: parseInt(paramid) }));
        giftobject && this.setState({
            gifts_email: _.clone(giftobject.recipientemail) || [],
            gifts_name: _.clone(giftobject.recipientname) || [],
            gifts: [],
            gift_amount : giftobject.amount,
            gift_other_amount : gift_amounts.indexOf(giftobject.amount) == -1 ? true : false
        })
    }
    
    onSaveClick(giftobject) {
        let formstatus = true;
        let id = giftobject.id || null
        let giftcardobj = {
            amount: this.state.gift_amount,
            quantity: ReactDOM.findDOMNode(this.refs.quantity).value,
            recipientname: this.state.gifts_name,
            recipientemail: this.state.gifts_email,
            deliverydate: ReactDOM.findDOMNode(this.refs.deliverydate).value,
            custommsg: ReactDOM.findDOMNode(this.refs.custommsg).value,
            customername: ReactDOM.findDOMNode(this.refs.customername).value,
            customeremail: ReactDOM.findDOMNode(this.refs.customeremail).value,
        }
        _.mapKeys(giftcardobj, (value, key) => {
            if (!value) {
                formstatus = false;
            } else {
                if ((_.isArray(value)) && (_.isEmpty(value))) {
                    formstatus = false
                }
            }
        });
        if(giftcardobj.amount < 1000){
            this.props.dispatch(updateMessage('INSERT_GIFT_CARD_FAILURE', "Amount should be greater than 1000"))
            window.scrollTo(0, 0);
            return;
        }
        if (!formstatus) {
            this.props.dispatch(updateMessage('INSERT_GIFT_CARD_FAILURE', "Please fill all the mandatory fields"))
            window.scrollTo(0, 0);
            return;
        }
        formstatus = formstatus && this.checkEmailvalidation(this.state.gifts_email);
        formstatus = formstatus && this.checkDatevalidation(giftcardobj.deliverydate)
        formstatus = formstatus && this.checkEmailvalidation(giftcardobj.customeremail);

        formstatus = formstatus && this.checkWithQty(giftcardobj)

        if (formstatus) {
            giftcardobj.id = id;
            this.props.dispatch(insertGiftcard(giftcardobj));
            this.props.dispatch(updateMessage('INSERT_GIFT_CARD_SUCCESS', "The gift card is successfully" + `${(id != null) ? " updtaed." : " added."}`));
            this.props.dispatch(push('/giftcard/list'))
        } else {
            console.log("Please fill all manadatory fields")
        }
    }

    onEmailFocusLeave(event) {
        this.updategifts(event, this.state.gifts_email);
    }
    onNameFocusLeave(event) {
        this.updategifts(event, this.state.gifts_name);
    }
    onEmailKeyDown(event, type) {
        let keyPressed = event.which;
        let gifts = this.state.gifts_email;

        if (keyPressed === 13) {
            event.preventDefault();
            this.updategifts(event, gifts);
        } else if (keyPressed === 8) {
            if (!event.target.value && gifts.length) {
                this.deleteChip(gifts[gifts.length - 1]);
            }
        }
    }

    onNameKeyDown(event, type) {
        let keyPressed = event.which;
        let gifts = this.state.gifts_name;
        if (keyPressed === 13) {
            event.preventDefault();
            this.updategifts(event, gifts);
        } else if (keyPressed === 8) {

            if (!event.target.value && gifts.length) {
                this.deleteChip(gifts[gifts.length - 1]);
            }
        }
    }
    updategifts(event, gifts) {

        let value = event.target.value;

        if (!value) return;

        let chip = value.trim().toLowerCase();

        if (chip && gifts.indexOf(chip) < 0) {

            gifts.push(chip);
            this.setState({
                gifts
            });
        }
        console.log("update", gifts)

    }
    handleGiftCardAmountChange(cmp){
        this.setState({
            gift_amount : cmp.target.value
        });
        
    }
    toggleAmountSelection(value){
        let gift_amount = this.state.gift_amount;
        let gift_other_amount = false;
        if(value && value[0] != "Other Amount"){
            gift_amount = value[0];
        }else if(value[0] == "Other Amount"){
            gift_other_amount = true;
        } 
        this.setState({
            gift_amount : gift_amount,
            gift_other_amount
        })
    }
    deleteChip(chip) {
        let index = this.state.gifts.indexOf(chip);

        let gifts = this.state.gifts;

        if (index >= 0) {
            gifts.splice(index, 1);
            this.setState({
                gifts
            });
        }
        console.log("delete", gifts)
    }
    render() {
        let giftArray = this.props.giftcard && this.props.giftcard.giftcards
        let paramid = this.props.params.gift_id
        let giftobject = _.find(giftArray, { id: parseInt(paramid) }) || {}
        let { gift_other_amount,gift_amount} = this.state;

        return (
            <div className={cx('container')}>
                <Link to="/giftcard/list" className={cx('back')} ><img src={back} /></Link>
                <h1>New Gift Card Details</h1>
                <div className={cx('form-container')}>
                    <div className={cx('input-group')}>
                        <label htmlFor="amount">Amount <em className={cx('mandatory')}>*</em></label>
                        <MultipleChoice isMultiple={false} options={gift_amounts} selected={gift_other_amount ? 'Other Amount' : gift_amount } save={this.toggleAmountSelection} />
                        { ( gift_other_amount && (<input type="number" id="amount" ref="amount" value = {gift_amount} onChange={this.handleGiftCardAmountChange} />) ) }
                    </div>

                    <div className={cx('input-group')}>
                        <label htmlFor="quantity">Qty <em className={cx('mandatory')}>*</em></label>
                        <input type="number" id="quantity" ref="quantity" defaultValue={giftobject.quantity || ''} />
                    </div>

                    <div className={cx('input-group')}>
                        <label htmlFor="recipname">Recipient Name <em className={cx('mandatory')}>*</em></label>
                        <MultiInputField
                            labelName=''
                            type='text'
                            onKeyDown={this.onNameKeyDown}
                            chips={this.state.gifts_name}
                            isValue={true}
                            onFocusLeave={this.onNameFocusLeave}
                            onDeletechip={this.deleteChip}

                        />

                        {/*                        <input type="text" id="recipname" ref="recipname" defaultValue={giftobject.recipientname || ''}/>
*/}                    </div>

                    <div className={cx('input-group')}>
                        <label htmlFor="recipemail">Recipient Email <em className={cx('mandatory')}>*</em></label>
                        <MultiInputField labelName='' type='email'
                            onKeyDown={this.onEmailKeyDown}
                            chips={this.state.gifts_email}
                            isValue={true}
                            onFocusLeave={this.onEmailFocusLeave}
                            onDeletechip={this.deleteChip}
                        />

                        {/*                        <input type="email" id="recipemail" ref="recipemail" defaultValue={giftobject.recipientemail && giftobject.recipientemail.join(',') || ''}/>
*/}                    </div>

                    <div className={cx('input-group')}>
                        <label htmlFor="deliverydate">Delivery Date <em className={cx('mandatory')}>*</em></label>
                        <input type="date" id="deliverydate" ref="deliverydate" defaultValue={giftobject.deliverydate || ''} />
                    </div>

                    <div className={cx('input-group')}>
                        <label htmlFor="custommsg">Custom Message <em className={cx('mandatory')}>*</em></label>
                        <textarea id="custommsg" ref="custommsg" defaultValue={giftobject.custommsg || ''} />
                    </div>
                    <div className={cx('input-group')}>
                        <h4 htmlFor="custommsg">Who is it from?</h4>

                        <label htmlFor="customername">Cutomer Name<em className={cx('mandatory')}>*</em></label>
                        <input type="email" id="customername" ref="customername" defaultValue={giftobject.customername || this.props.customer.name} />

                        <label htmlFor="customeremail">Customer Email <em className={cx('mandatory')}>*</em></label>
                        <input type="email" id="customeremail" ref="customeremail" defaultValue={giftobject.customeremail || this.props.customer.email} />

                    </div>
                    <div className={cx('divider')}></div>
                    <button onClick={() => { this.onSaveClick(giftobject) }} className={cx('action', 'primary')}>Save</button>

                </div>
            </div>
        );
    }
}

GiftCardDetails.propTypes = {

};

function mapStateToProps({ customer, giftcard }) {
    return {
        customer,
        giftcard

    };
}

export default connect(mapStateToProps)(GiftCardDetails);

