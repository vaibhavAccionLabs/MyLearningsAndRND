import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';
import classNames from 'classnames/bind';
import styles from 'css/components/workorder';
import {
	push
} from 'react-router-redux';
import { fetchList, clearList } from '../actions/list';
import _ from 'lodash';
import StylesForm from 'components/StylesForm';
import {
	getWorkOrderDetails,
	saveFabricDesign,
	getWorkOrderStyles,
	getItemTypeDropDown,
	getStyleLiningDropDown
} from 'actions/workorder';
import {
	updateMessage,
	saveUpcharges
} from 'actions/order';
import { connect } from 'react-redux';
import ReactDOM from 'react-dom';
import back from 'images/back-arrow.png';
import { setActiveKey } from '../actions/history';

const cx = classNames.bind(styles);

class WorkOrderStyles extends Component {
	constructor(props) {
		super(props);
		this.closeForm = this.closeForm.bind(this);
		this.loadFields = this.loadFields.bind(this);
		this.saveFabricDesign = this.saveFabricDesign.bind(this);
		this.toggleAccordion = this.toggleAccordion.bind(this);
	}
	toggleAccordion(activeKey) {
		this.props.dispatch(setActiveKey(activeKey));
	}

	componentDidMount() {
		const workorder = _.find(this.props.workorder.workorders, { order_item_id: parseInt(this.props.params.order_item_id) });
		this.props.dispatch(getWorkOrderStyles(workorder.order_item_id,workorder.item_type_id));
		this.props.dispatch(getItemTypeDropDown(workorder.item_type_id));
		this.props.dispatch(getStyleLiningDropDown());

	}

	saveFabricDesign(fabric_design, comment, upCharges, isFinal) {
		let { workorder: { selected: { order_item: { order_item_id,order_id,upcharge } } }, dispatch } = this.props;
		let profile_id;
		if(this.props.workorder.selected.order_item.design){
			profile_id = this.props.workorder.selected.order_item.design.profile_id;
		}
		if(isFinal){
			let new_style_Upcharges = this.refs.styleform && this.refs.styleform.getUpchargeObject();
			dispatch(saveUpcharges(order_id,order_item_id,new_style_Upcharges,upcharge));

		}
		dispatch(saveFabricDesign(order_item_id, fabric_design, comment, isFinal,profile_id));
		dispatch(updateMessage('UPDATE_GENERAL_MESSAGE', 'Fabric Style Updated'));
	}

	loadFields() {
		this.props.dispatch(fetchList('fabric_design_field', { item_type_id: this.props.workorder.selected.order_item.item_type_id }));
	}

	closeForm() {
		this.props.dispatch(push('/workorder'));
	}
	getFabricDesign(){
		let fabric_design = this.props.workorder.selected.order_item.design.fabric_design;
		if(fabric_design && fabric_design.length > 0 && fabric_design[0] && fabric_design[0].items){
			return [];
		}
		return fabric_design || [];
	}
	render() {
		if (this.props.workorder.selected.order_item) {
			let style_profile;
			if(this.props.workorder.selected.order_item.design){
				style_profile = {
					name:this.props.workorder.selected.order_item.design.profile_name,
					comment:this.props.workorder.selected.order_item.design.comment
				};
			}
			let fabric_design = this.getFabricDesign();
			return (
				<div className={cx('container', 'big')}>
					<h1>Update Styles </h1>
					<Link to="/workorder" className={cx('back')} ><img src={back} /></Link>
					<StylesForm
						lists={this.props.lists}
						ref="styleform"
						save={this.saveFabricDesign}
						close={this.closeForm}
						loadFields={this.loadFields}
						fabricDesign={fabric_design}
						comment={this.props.workorder.selected.order_item.design.comment}
						toggleAccordion={this.toggleAccordion}
						activeKey={this.props.history.accordionKey} 
						profile={style_profile}
						item_type_style_dropdown ={this.props.workorder.item_type_style_dropdown}
						item_style_lining_dropdown ={this.props.workorder.item_style_lining_dropdown}
						isUpdate={true}/>
				</div>
			);
		} else {
			return null;
		}
	}
}

WorkOrderStyles.propTypes = {
	workorder: PropTypes.object,
	user: PropTypes.object,
	lists: PropTypes.object,
	history: PropTypes.object
};


function mapStateToProps({ workorder, user, customer, lists, history }) {
	return {
		workorder,
		user,
		customer,
		lists,
		history
	};
}

// Connects React component to the redux store
// It does not modify the component class passed to it
// Instead, it returns a new, connected component class, for you to use.
export default connect(mapStateToProps)(WorkOrderStyles);