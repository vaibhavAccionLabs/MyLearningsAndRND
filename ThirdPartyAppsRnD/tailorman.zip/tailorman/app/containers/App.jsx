import React, { Component, PropTypes } from 'react';
import Navigation from 'containers/Navigation';
import Message from 'containers/Message';
import classNames from 'classnames/bind';
import styles from 'css/main';
import { connect } from 'react-redux';
import Popup from 'react-popup';
import 'css/react-popup'; 
import {checkLoginStatus} from 'actions/users'; 

const cx = classNames.bind(styles);


/*
 * React-router's <Router> component renders <Route>'s
 * and replaces `this.props.children` with the proper React Component.
 *
 * Please refer to `routes.jsx` for the route config.
 *
 * A better explanation of react-router is available here:
 * https://github.com/rackt/react-router/blob/latest/docs/Introduction.md
 */
class App extends Component {
	constructor(props) {
		super(props);
	}
	componentDidMount(){
		this.props.dispatch(checkLoginStatus());
	}
	render() {
		let {children} = this.props;
		return (
			<div className={cx('app')}>
				<Popup />
				<Navigation />
				<span className={cx('version')}>v4.0</span>
				<Message />
				{children}
			</div>
		)
	}
}
// const App = ({ children }) => {
// 	return (
// 		<div className={cx('app')}>
// 			<Popup />
// 			<Navigation />
// 			<span className={cx('version')}>v4.0</span>
// 			<Message />
// 			{children}
// 		</div>
// 	);
// };

App.propTypes = {
	children: PropTypes.object
};
export default connect()(App);