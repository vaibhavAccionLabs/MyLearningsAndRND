import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';

import classNames from 'classnames/bind';
import styles from 'css/components/order/details';
import ReactDOM from 'react-dom';
import { connect } from 'react-redux';
import {
    updateTailor,
    updateBenificiaryPhone,
    updateOccasion,
    updateSalesman,
    updatePendingOrderDetails,
    fetchOrderDetails,
    updateBenificiaryName,
    updateBenificiaryEmail,
    updateOccasionDate,
    updateMessage,
    updateDeliveryLocation,
    updateFitonLocation
} from '../actions/order';

import { fetchList, fetchCustomerAddress } from '../actions/list';
import NumberForm from '../components/NumberForm';
import SelectForm from '../components/SelectForm';
import back from 'images/back-arrow.png';
import moment from 'moment';

const cx = classNames.bind(styles);

class OrderUpdateDetails extends Component {
    constructor(props) {
        super(props);
        this.saveValues = this.saveValues.bind(this);
        this.saveSelectFormValue = this.saveSelectFormValue.bind(this);
        this.saveNumberFieldValue = this.saveNumberFieldValue.bind(this);
        //this.getSelected = this.getSelected.bind(this);
        this.getOccasionID = this.getOccasionID.bind(this);

        this.state = {
            delivery_address: null,
            billing_address: null
        }
    }

    componentDidMount() {

        if (this.props.lists) {
            if (this.props.lists.payment_types && this.props.lists.payment_types.length === 0)
                this.props.dispatch(fetchList('payment_type'));
            if (this.props.lists.tailors && this.props.lists.tailors.length === 0)
                this.props.dispatch(fetchList('tailor'));
            if (this.props.lists.occasions && this.props.lists.occasions.length === 0)
                this.props.dispatch(fetchList('occasion'));
            if (this.props.lists.salesmen && this.props.lists.salesmen.length === 0)
                this.props.dispatch(fetchList('salesman'));
            if (this.props.lists.delivery_locations && this.props.lists.delivery_locations.length === 0 )
                this.props.dispatch(fetchList('delivery_location'));
        }
        this.props.dispatch(fetchOrderDetails(this.props.params.order_id));

        window.scrollTo(0, 0)
    }

    onNameChange() {

        this.props.dispatch(updateBenificiaryName(this.refs.benificiary_name.value));
    }

    onEmailChange() {
        this.props.dispatch(updateBenificiaryEmail(this.refs.benificiary_email.value));
    }

    onDateChange() {
        this.props.dispatch(updateOccasionDate(this.refs.occasion_date.value));
    }

    saveValues() {

        const _that = this;
        if(_that.props.order.details.tailor_id >= 0 && _that.props.order.details.salesman_id >=0 ){

            let delivery_location_id = _that.props.order.details.delivery_location_id;
           if(delivery_location_id ==0){
              delivery_location_id = _that.props.order.details.store_id;
           }

        const formValues = {
            //From fields in this component

            occasion_date: ReactDOM.findDOMNode(_that.refs.occasion_date).value || null,
            benificiary_name: ReactDOM.findDOMNode(_that.refs.benificiary_name).value,
            benificiary_email: ReactDOM.findDOMNode(_that.refs.benificiary_email).value,

            //From props
            benificiary_phone: _that.props.order.details.benificiary_phone,
            occasion: _that.props.order.details.occasion,
            tailor_id: _that.props.order.details.tailor_id,
            salesman_id: _that.props.order.details.salesman_id,
            delivery_location_id: delivery_location_id,
            fiton_location_id: _that.props.order.details.fiton_location_id,
            customer_id: _that.props.customer.customer_id,
            order_id: _that.props.params.order_id
        }

        this.props.dispatch(updatePendingOrderDetails(formValues));
    }else{
        this.props.dispatch(updateMessage('MEARSUREMENT_FORM_VALIDATION', 'Salesman and Tailor are mandatory'));
			window.scrollTo(0, 0)
    }

    }
    saveSelectFormValue(selected, type) {

        switch (type) {
            case 'payment_type':
                this.props.dispatch(updatePaymentType(selected.value));
                break;
            case 'tailor':
                this.props.dispatch(updateTailor(selected.value));
                break;
            case 'occasion':
                const occasion = _.find(this.props.lists.occasions, { id: parseInt(selected.value) }).name;
                this.props.dispatch(updateOccasion(occasion));
                break;
            case 'salesman_id':
                this.props.dispatch(updateSalesman(selected.value));
                break;
            case 'delivery_address':

                this.props.dispatch(updateDeliveryAddress(selected.value));
                break;
            case 'billing_address':
                this.props.dispatch(updateBillingAddress(selected.value));
                break;
            case 'delivery_location':
                this.props.dispatch(updateDeliveryLocation(selected.value));
                break;
            case 'fiton_location':
                this.props.dispatch(updateFitonLocation(selected.value));
                break;

        }
    }


    saveNumberFieldValue(value, type) {
        switch (type) {
            case 'benificiary_phone':
                this.props.dispatch(updateBenificiaryPhone(value));
        }
    }

    getOccasionID() {
        if (this.props.order.details.occasion&&this.props.order.details.occasion.length > 0) {
            const occasion = _.find(this.props.lists.occasions, { name: this.props.order.details.occasion });
            if (occasion && occasion.id)
                return occasion.id;
            else
                return -1;
        }
        else {
            return -1;
        }
    }
    render() {
           let delivery_location_id = this.props.order.details.delivery_location_id;
           if(delivery_location_id ==0){
              delivery_location_id = this.props.order.details.store_id;
           }
        return (
            <div className={cx('container')}>
                <Link to="/order/updatemeasurement" className={cx('back')} ><img src={back} /></Link>
                <h1>Update Order Details</h1>
                <div className={cx('form-container')}>

                    <div className={cx('input-group')}>
                        <label htmlFor="occasion">Occasion</label>
                        <SelectForm type="occasion" rel="occasion" options={this.props.lists.occasions} value={this.getOccasionID()} save={this.saveSelectFormValue} />
                    </div>
                    <div className={cx('input-group')}>
                        <label htmlFor="occasion_date">Occasion Date</label>
                        <input type="date" id="occasion_date" ref="occasion_date" rel="occasion_date" value={moment(this.props.order.details.occasion_date).format('YYYY-MM-DD')} onChange={this.onDateChange.bind(this)} />
                    </div>
                    <div className={cx('input-group')}>
                        <label htmlFor="benificiary_name``">Benificiary Name</label>
                        <input type="text" id="benificiary_name" ref="benificiary_name" rel="benificiary_name" value={this.props.order.details.benificiary_name} onChange={this.onNameChange.bind(this)} />
                    </div>
                    <div className={cx('input-group')}>
                        <label htmlFor="benificiary_email">Benificiary Email</label>
                        <input type="email" id="benificiary_email" ref="benificiary_email" rel="benificiary_email" value={this.props.order.details.benificiary_email} onChange={this.onEmailChange.bind(this)} />
                    </div>
                    <div className={cx('input-group')}>
                        <label htmlFor="benificiary_phone">Benificiary Phone</label>
                        <NumberForm type="phone" rel="benificiary_phone" save={this.saveNumberFieldValue} default={this.props.order.details.benificiary_phone} />
                    </div>

                    <div className={cx('input-group')}>
                        <label htmlFor="delivery_location">Delivery Location <em className={cx('mandatory')}>*</em> </label>
                        <SelectForm type="delivery_location" rel="delivery_location" options={this.props.lists.delivery_locations} value={delivery_location_id} save={this.saveSelectFormValue} />
                    </div>
                    <div className={cx('input-group')}>
                        <label htmlFor="fiton_location">Fiton location <em className={cx('mandatory')}>*</em> </label>
                        <SelectForm type="fiton_location" rel="fiton_location" options={this.props.lists.delivery_locations} value={this.props.order.details.fiton_location_id} save={this.saveSelectFormValue} />
                    </div>
                    <div className={cx('input-group')}>
                        <label htmlFor="tailor">Tailor <em className={cx('mandatory')}>*</em> </label>
                        <SelectForm type="tailor" rel="tailor" options={this.props.lists.tailors} value={this.props.order.details.tailor_id} save={this.saveSelectFormValue} />
                    </div>
                    <div className={cx('input-group')}>
                        <label htmlFor="tailor">Salesman <em className={cx('mandatory')}>*</em> </label>
                        <SelectForm type="salesman_id" rel="salesman_id" options={this.props.lists.salesmen} value={this.props.order.details.salesman_id} save={this.saveSelectFormValue} />
                    </div>

                    <div className={cx('divider')}></div>
                    <button onClick={this.saveValues} className={cx('action', 'primary')}>Save</button>
                </div>
            </div>
        );
    }
}


OrderUpdateDetails.propTypes = {
    order: PropTypes.object,
    lists: PropTypes.object,
    user: PropTypes.object,
    stores: PropTypes.object,
    customer: PropTypes.object
};


function mapStateToProps({ order, lists, user, stores, customer }) {
    return {
        order,
        lists,
        user,
        stores,
        customer
    };
}

export default connect(mapStateToProps)(OrderUpdateDetails);