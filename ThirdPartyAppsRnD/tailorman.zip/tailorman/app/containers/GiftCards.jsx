import React, { Component } from 'react';
const cx = classNames.bind(styles);
import classNames from 'classnames/bind';
import styles from 'css/components/workorder';
import back from 'images/back-arrow.png';
import { Link } from 'react-router';
import Collapse, { Panel } from 'rc-collapse';
import Select from 'react-select';
import { connect } from 'react-redux';
import ReactDOM from 'react-dom';
import { push } from 'react-router-redux';
import { fetchGiftCardsList } from '../actions/giftcard'
import moment from 'moment';
import { fetchStoresList } from '../actions/users';


class GiftCards extends Component {

    constructor(props) {
        super(props);
        this.state = {
            store_Id: '',
            accordionKey: ['0']
        }
        this.onhandleStoreChange = this.onhandleStoreChange.bind(this);
        this.onSearchClick = this.onSearchClick.bind(this);
        this.onGiftRowClick = this.onGiftRowClick.bind(this);
        this.toggleAccordian = this.toggleAccordian.bind(this);
    }

    onSearchClick() {
        let customerId = ReactDOM.findDOMNode(this.refs.customerId).value || null;
        let store_Id = this.state.store_Id.value || null
        let from_date = ReactDOM.findDOMNode(this.refs.from_date).value || null;
        let to_date = ReactDOM.findDOMNode(this.refs.to_date).value || null;

        this.props.dispatch(fetchGiftCardsList(customerId, store_Id, from_date, to_date))
        this.setState({
            accordionKey: ['0', '1']
        })
    }
    onhandleStoreChange(selectedOption) {
        this.setState({
            store_Id: selectedOption
        })
    }
    onGiftRowClick(Gift_id) {
        this.props.dispatch(push(`/gifttransactions/${Gift_id}`))
    }
    renderGiftsSerachFields(stores) {
        let storeOptions = []
        stores && stores.list.map((item, index) => {
            let obj = {
                value: item.store_id, label: item.address
            }
            return storeOptions.push(obj)
        })
        return (
            <div>
                <div className={cx('input-group')}>
                    <label htmlFor="customerId">Customer Id</label>
                    <input type="number" ref="customerId" />
                </div>
                <div className={cx('input-group')}>
                    <label htmlFor="storeId">Stores</label>
                    <Select
                        className='store-selection'
                        name="form-field-name"
                        value={this.state.store_Id}
                        onChange={this.onhandleStoreChange}
                        options={
                            storeOptions
                        }
                    />
                </div>
                <div className={cx('input-group')}>
                    <label htmlFor="from_date"  >From Date</label>
                    <input type="date" ref="from_date" defaultValue={moment().subtract(7, 'days').format('YYYY-MM-DD')} />
                </div>
                <div className={cx('input-group')}>
                    <label htmlFor="to_date">To Date</label>
                    <input type="date" ref="to_date" defaultValue={moment().format('YYYY-MM-DD')} />
                    <button className={cx('action')} onClick={this.onSearchClick}>Search</button>
                </div>

            </div>

        )
    }
    componentDidMount(){
        this.props.dispatch(fetchStoresList(["All"])); 
    }
    toggleAccordian(key) {
        this.setState({
            accordionKey: key
        })
    }

    getGiftCards() {
        let giftsList = this.props.giftcard && this.props.giftcard.giftCardsList || []
        let giftElements = (
            giftsList.map((item, index) => {
                return <div className={cx('workorder')} key={index} onClick={() => { this.onGiftRowClick(item.gift_vocher_id) }}>

                    <div className={cx({
                        'medium': true
                    })}>{item.gift_vocher_id}</div>
                    <div className={cx({
                        'medium': true
                    })}>{item.customer_name}</div>

                    <div className={cx({
                        'medium': true
                    })}>{item.recepient_name}</div>

                    {/* <div className={cx({
                        'large': true
                    })}>{item.recepient_email}</div> */}
                    <div className={cx({
                        'large': true
                    })}>{item.amount}</div>
                    <div className={cx({
                        'large': true
                    })}>{moment(item.delivery_date).format('YYYY-MM-DD')}</div>
                    <div className={cx({
                        'large': true
                    })}>{item.store_address}</div>
                </div>
            })

        )
        return (
            <div className={cx('workorders')}>
                {giftsList.length > 0 ? <div> <div className={cx('workorder')}>
                    <div className={cx({
                        'head': true,
                        'medium': true
                    })}>Gift Vocher Id</div>
                    <div className={cx({
                        'head': true,
                        'medium': true
                    })}>Customer Name</div>
                    <div className={cx({
                        'head': true,
                        'medium': true
                    })}>Recepient Name</div>

                    {/* <div className={cx({
                        'head': true,
                        'large': true
                    })}>Recepient Email</div> */}
                    <div className={cx({
                        'head': true,
                        'large': true
                    })}>Amount</div>
                    <div className={cx({
                        'head': true,
                        'large': true
                    })}>Delivery Date</div>
                    <div className={cx({
                        'head': true,
                        'large': true
                    })}>Store Address</div>
                </div>
                    {giftElements}</div> : <div>No items are found for the search result</div>}
            </div>

        )
    }
    render() {
        let { stores, giftcard } = this.props;
        return (
            <div className={cx('container', 'big')}>
                <h1>Gift Cards</h1>
                <Link to="/landing" className={cx('back')} ><img src={back} /></Link>
                <div className={cx('form-container', 'big')}>
                    <Collapse
                        accordion={false}
                        activeKey={this.state.accordionKey}
                        onChange={(key) => { this.toggleAccordian(key) }}

                    >
                        <Panel header="Search Gift Cards" >
                            {this.renderGiftsSerachFields(stores)}
                        </Panel>
                        <Panel header="Gift Cards">
                            {this.getGiftCards()}
                        </Panel>
                    </Collapse>
                </div>

            </div>

        );
    }
}

function mapStateToProps({ stores, giftcard }) {
    return {
        stores,
        giftcard 
    };
}

export default connect(mapStateToProps)(GiftCards);