import * as types from 'types';
import {
	combineReducers
} from 'redux';
import _ from 'lodash';

import { fabricDesignDependency } from 'util';

const workorder = (
	state = {
		workflowStages: [],
		accordionKey: ['0'],
		orderItems: [],
		workorders: [],
		workflows: [],
		selectedWorkflow: -1,
		stage_id: -1,
		sortedBy: 'order_item_id',
		sortOrder: 'desc',
		selected: {},
		isListItemMenuOpen: false,
		stageList: [],
		selectedWorkOrderItem: false,
		query: [],
		item_type_style_dropdown:[],
		item_style_lining_dropdown:[],
		is_new_measurements:false,
		profile_id:-1

	},
	action
) => {
	switch (action.type) {
		case types.TOGGLE_WORKORDER_LIST_ITEM_MENU:
			return { ...state, isListItemMenuOpen: action.isOpen }
		case types.SELECT_WORK_ORDER_ITEM:
			return { ...state, selectedWorkOrderItem: action.order_item_id }
		case types.SELECT_WORKFLOW:
			return { ...state, selectedWorkflow: action.workflow }
		case types.TOGGLE_WORKORDER_ACCORDION:
			const _accordion = state.accordionKey;
			return {
				...state,
				accordionKey: action.key
			}
		case types.WORKORDER_SAVE_QUERY_FIELDS:
			return { ...state, query: action.query }
		case types.UPDATE_WORK_ORDER_ITEM_FABRIC_DESIGN:
			const selected = state.selected;
			selected.order_item.design.comment = action.comment;
			selected.order_item.design.fabric_design = fabricDesignDependency(action.fabric_design);

			return { ...state, selected: selected };
		case types.POPULATE_WORKFLOW_STAGE_LIST:
			return {
				...state,
				workflowStages: action.workflowStages
			}
		case types.POPULATE_APPLICABLE_STAGE_LIST:
			return {
				...state,
				stageList: action.stageList
			}
		case types.POPULATE_WORK_ORDERS:
			return {
				...state,
				workorders: action.workorders
			}
		case types.FETCH_LIST_WORKFLOW:
			return { ...state, workflows: action.workflows }
		case types.POPULATE_WORK_ORDER_ITEM_DETAILS:
			return {
				...state,
				workOrderItem :_.cloneDeep(action.details.order),
				workOrderItemSales : _.cloneDeep(action.details.sales)
			}
		case types.POPULATE_ORDER_ITEM_DETAILS:
			var is_new_measurements = false;
			if(action.details && action.details.order_item && action.details.order_item.profile_id != -1 ){
				is_new_measurements = true;
			}
			return {
				...state,
				profile_id : -1,
				is_new_measurements,
				selected: _.cloneDeep(action.details)
			}
		case types.UPDATE_WORK_ORDERS_MEASUREMENT_IMAGES:
		    if((state.selected && state.selected.images)&& (state.selected.order_item.order_id ==action.orderId )){
			  var newState = _.cloneDeep(state);
				newState.selected.images.push(action.imageDataURL);
					
				return newState;
						
			}else{
		   return state
			}
		case types.WORKORDER_UPDATE_MEASUREMENTS:
			return {
				...state,
				selected: _.cloneDeep(state.selected)
			}
		case types.SELECT_WORK_ORDER_STAGE:
			return {
				...state,
				stage_id: action.stage_id
			}
		case types.SORT_WORK_ORDERS:
			if (state.sortedBy == action.sortedBy && state.sortOrder == 'asc')
				return { ...state, workorders: _.reverse(state.workorders), sortedBy: action.sortedBy, sortOrder: 'desc' }
			else
				return { ...state, workorders: _.sortBy(state.workorders, [action.sortedBy]), sortedBy: action.sortedBy, sortOrder: 'asc' }
		case types.WORK_ORDER_UPDATE_SALE_ITEM_ENTRY :
			let new_state_Selected = _.cloneDeep(state.workOrderItem);
			new_state_Selected[action.payload.field] = action.payload.value;
			return {
				...state,
				workOrderItem : new_state_Selected
			};
		case types.UPDATE_WORK_ORDERS_BESPOKE_VALUE :
			let newStateWorkOrders = _.cloneDeep(state.workorders);
			newStateWorkOrders = newStateWorkOrders && newStateWorkOrders.map((_workOrder)=>{
				if(_workOrder.order_id ==  action.orderId ){
					_workOrder.bespoke_url = action.imageDataURL;
				}
				return _workOrder;
			});
			return { 
				...state,
				workorders : newStateWorkOrders
			};
		case types.FETCH_LIST_ITEM_TYPE_STYLE_DROPDOWN:
		    return { 
				...state,
				item_type_style_dropdown : action.item_type_style_dropdown
			};
		case types.FETCH_LIST_ITEM_STYLE_LINING_DROPDOWN:
		   return { 
				...state,
				item_style_lining_dropdown : action.item_style_lining_dropdown
			};
		case types.IS_NEW_MEASUREMENTS:
		     return {
				...state,
				is_new_measurements: action.value
			}
		case types.MEASUREMENT_PROFILE_ID:
		     return {
				...state,
				profile_id: action.value
			}
		default:
			return state;
	}
};

export default workorder;