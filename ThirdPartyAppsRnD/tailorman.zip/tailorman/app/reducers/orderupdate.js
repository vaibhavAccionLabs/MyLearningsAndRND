import * as types from 'types';
import _ from 'lodash';

const orderupdate = (
	state = {
		updatestyleorder: []
	},
	action
) => {

	switch (action.type) {

		case types.UPDATE_STYLE_ORDERS:
			return {
				...state,
				updatestyleorder: action.updatestyleorders
			}
		case types.UPDATE_WORK_ORDERS_BESPOKE_VALUE:

			let newStateWorkOrders = _.cloneDeep(state.updatestyleorder);
			newStateWorkOrders = newStateWorkOrders && newStateWorkOrders.map((_workOrder) => {
				if (_workOrder.order_id == action.orderId) {
					_workOrder.bespoke_url = action.imageDataURL;
				}
				return _workOrder;
			});
			return {
				...state,
				updatestyleorder: newStateWorkOrders
			};
		default:
			return state;
	}
};
export default orderupdate;