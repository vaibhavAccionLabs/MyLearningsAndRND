import * as types from 'types';

import _ from 'lodash';

const modifyproducts = (
	state = {
		selectedProduct: {},
		deletedProduct: [],
		uploadedProduct: []
	},
	action
) => {
	console.log(action.type);
	//debugger;
	switch (action.type) {
		case types.SELECTED_PPRODUCT:
			return {
				...state,
				selectedProduct: action.product
			}
		break;
		case types.DELETE_PPRODUCT_LIST:
		 let getstate = {...state};
		 if(getstate.deletedProduct && getstate.deletedProduct.indexOf(action.product) === -1){
			 let updatedArr = getstate.deletedProduct.concat(action.product);
			return {
				...state,
				deletedProduct: updatedArr
			}
		}
		break;
		case types.UPLOAD_PRODUCT_LIST:
		let getUploadedProduct = {...state};
		if(getUploadedProduct.uploadedProduct && !_.find(getUploadedProduct.uploadedProduct, {'customPathName':action.product.customPathName})){
			let updatedArr = getUploadedProduct.uploadedProduct.concat(action.product);
			return {
				...state,
				uploadedProduct:updatedArr
			}
		}
		break;
		case types.CLEAR_DELETE_PPRODUCT_LIST:
		return {
			...state,
			deletedProduct: []
		}
		break;
		case types.CLEAR_UPLOAD_PRODUCT_LIST:
		return {
			...state,
			uploadedProduct: []
		}
		break;
		case types.UPDATE_RTW_IMAGE_COUNT:
		//here update the value of selected product : --- 
		 let getselecedProduct = {...state};
		 if(getselecedProduct.selectedProduct.rtw_image_count){
			getselecedProduct.selectedProduct.rtw_image_count = getselecedProduct.selectedProduct.rtw_image_count + action.count
		 }
		return {
			...state,
			selectedProduct:getselecedProduct.selectedProduct
		}
		break;
		case types.PREVIEW_RTW_IMAGE:
		let getSelectedProductWithNewImage = {...state};
		if(action.updateType == "rtw"){
			if(getSelectedProductWithNewImage.selectedProduct.imageUrl){
				getSelectedProductWithNewImage.selectedProduct.imageUrl = getSelectedProductWithNewImage.selectedProduct.imageUrl.concat(action.imgData);
			}
		}else if(action.updateType == "rtwhr"){
			if(getSelectedProductWithNewImage.selectedProduct.high_res_image_url){
				getSelectedProductWithNewImage.selectedProduct.high_res_image_url = getSelectedProductWithNewImage.selectedProduct.high_res_image_url.concat(action.imgData);
			}
		}else if(action.updateType == "rtwdefault"){
			if(getSelectedProductWithNewImage.selectedProduct.high_res_image_url){
				getSelectedProductWithNewImage.selectedProduct.image_url_path = action.imgData;
			}
		}else if(action.updateType == "product"){
			if(getSelectedProductWithNewImage.selectedProduct.image_url_path){
				getSelectedProductWithNewImage.selectedProduct.image_url_path[1] = action.imgData;
			}
		}else if(action.updateType == "fabric"){
			if(getSelectedProductWithNewImage.selectedProduct.image_url_path){
				getSelectedProductWithNewImage.selectedProduct.image_url_path[0] = action.imgData;
			}
		}
		return {
			...state,
			selectedProduct:getSelectedProductWithNewImage.selectedProduct
		}
		break;
		default:
			return state;
	}
}

export default modifyproducts;