import * as types from 'types';


let initialState={
  id:0,
  giftcards:[],
  giftCardDetails:{},
  giftTransactions:[],
  giftCardsList:[]

}


export default function giftcard(state = initialState, action) {
  switch (action.type) {
    case types.INSERT_GIFT_CARD:
             let giftarray = state.giftcards
             let idx = _.findIndex(giftarray,{id:action.giftobj.id})
             if(idx == -1){
                let id= state.id+1;
                action.giftobj.id = id;
                giftarray.push(action.giftobj)

             }else{
               giftarray[idx] = action.giftobj
             }
           return {...state,
              giftcards:giftarray,
              id: state.id+1,
            };
    case types.DELETE_GIFT_CARD:
          let index = _.remove(state.giftcards,{id:action.id});
          return{
            ...state,
          }
    case types.RESET_GIFT_CARDS:
          return{
             ...state,
              id:0,
              giftcards:[],

          }
    case types.GIFT_CUPON_DETAILS:
          return{
            ...state,
            giftCardDetails: _.clone(action.cupon_details),
          }
    case types.GET_GIFT_COUPONES_LIST:
          return{
            ...state,
            giftCardsList:action.giftcards
          }
    case types.GET_GIFT_TRANASACTIONS:
          return{
            ...state,
            giftTransactions:action.transactions
          }
    
    default:
      return state;
  }
 
}