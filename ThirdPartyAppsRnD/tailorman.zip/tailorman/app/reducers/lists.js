import * as types from 'types';



function getFormatedFabrics(state, action) {
	let product_inventory = state.product_inventory;
	let fabrics = [];
	let selectionObj = action.selectedValues;
	if (!selectionObj.isMTM) {
		action.fabrics = action.fabrics.map((loopItem) => {
			let selectedData = _.find(product_inventory, { 'size': selectionObj.product_size, 'fit': selectionObj.product_fit, 'sku_code': loopItem.product_sku_code })
			loopItem.quantity = (selectedData && selectedData.inventory_count) || 0;
			return loopItem;
		});
	}

	return action.fabrics;

}

function getFormatedSaleFabrics(state, action) {
	let product_inventory = state.product_inventory;
	let fabrics = [];
	// if(!selectionObj.isMTM){
	action.sale_fabrics = action.sale_fabrics && action.sale_fabrics.map((loopItem) => {
		let selectedData = _.find({ 'sku_code': loopItem.product_sku_code })
		loopItem.quantity = (selectedData && selectedData.inventory_count) || 0;
		return loopItem;
	});
	// }

	return action.sale_fabrics;

}


const lists = (
	state = {
		priorities: [],
		payment_types: [],
		finish_types: [],
		tailors: [],
		salesmen: [],
		measurement_types: [],
		item_types: [],
		styles: [],
		customers: [],
		fabrics: [],
		measurement_fields: [],
		fabric_design_fields: [],
		customerSources: [],
		occasions: [],
		rtwsku: [],
		rtwsku_size: [],
		rtwsku_fit: [],
		product_sizes: [],
		product_fits: [],
		product_lengths: [],
		product_inventory: [],
		store_inventory: [],
		sale_fabrics: [],
		accordionKey: ['0'],
		details: null,
		customer_addresses: [],
		rtwsku_stock: [],
		rtw_stock_details:[],
		rtw_records:[],
		store_pending_amounts:[],
		delivery_locations:[],
		searchProducts:[]
	},
	action
) => {
	console.log(action.type);
	switch (action.type) {

		case types.FETCH_LIST_PRIORITIES:
			return {
				...state,
				priorities: action.priorities
			}
		case types.FETCH_LIST_PAYMENT_TYPES:
			return {
				...state,
				payment_types: action.payment_types
			}
		case types.FETCH_LIST_FINISH_TYPES:
			return {
				...state,
				finish_types: action.finish_types
			}
		case types.FETCH_LIST_TAILORS:
			return {
				...state,
				tailors: action.tailors
			}
		case types.FETCH_LIST_SALESMEN:
			return {
				...state,
				salesmen: action.salesmen
			}
		case types.FETCH_LIST_STYLES:
			return {
				...state,
				styles: action.styles
			}
		case types.FETCH_LIST_MEASUREMENT_TYPES:
			return {
				...state,
				measurement_types: action.measurement_types
			}
		case types.FETCH_LIST_MEASUREMENT_FIELDS:
			return {
				...state,
				measurement_fields: action.measurement_fields
			}
		case types.CLEAR_LIST_MEASUREMENT_FIELDS:
			return {
				...state,
				measurement_fields: []
			}
		case types.FETCH_LIST_FABRIC_DESIGN_FIELDS:
			return {
				...state,
				fabric_design_fields: action.fabric_design_fields
			}
		case types.FETCH_LIST_ITEM_TYPES:
			return {
				...state,
				item_types: action.item_types
			}
		case types.FETCH_LIST_FABRICS:
			let formatedFabrics = getFormatedFabrics(state, action);
			return {
				...state,
				fabrics: formatedFabrics
			}
		case types.FETCH_LIST_SALE_FABRICS:
			let formatedSaleFabrics = getFormatedSaleFabrics(state, action);
			return {
				...state,
				sale_fabrics: formatedSaleFabrics
			}
		case types.CLEAR_LIST_FABRICS:
			return {
				...state,
				fabrics: []
			};
		case types.CLEAR_LIST_SALE_FABRICS:
			return {
				...state,
				sale_fabrics: []
			};
		case types.FETCH_LIST_CUSTOMERS:
			return {
				...state,
				customers: action.customers
			}
		case types.CLEAR_LIST_CUSTOMERS:
			return { ...state, customers: [] };
		case types.FETCH_LIST_CAMERAS:
			return {
				...state,
				cameras: action.cameras
			}
		case types.FETCH_LIST_CUSTOMER_SOURCES:
			return {
				...state,
				customerSources: action.customerSources
			}
		case types.PRODUCTS_LIST:
			return {
				...state,
				searchProducts: action.products
			}
		case types.CLEAR_LIST_SEARCHPRODUCTS:
			return { ...state, searchProducts: [] };
		case types.FETCH_CUSTOMER_PROFILE_LIST:
			return {
				...state,
				profiles: action.profiles
			}
		case types.FETCH_CUSTOMER_STYLE_PROFILE_LIST:
			return {
				...state,
				style_profiles: action.style_profiles
			}
		case types.FETCH_CUSTOMER_ORDER_LIST:
			return {
				...state,
				orders: action.orders
			}
		case types.CLEAR_ORDER_DATA:
			return {
				...state,
				orders: {}
			}

		case types.FETCH_LIST_OCCASIONS:
			return {
				...state,
				occasions: action.occasions
			}
		case types.FETCH_RTW_SKU:
			return {
				...state,
				rtwsku: action.rtwsku
			}
		case types.FETCH_RTW_SKU_STOCK:
			return {
				...state,
				rtwsku_stock: action.rtwsku_stock
			}
		case types.FETCH_RTW_STOCK_DETAILS:
		return {
			...state,
			rtw_stock_details: action.stock_details
		}
		case types.FETCH_RTW_RECORDS:
		return {
			...state,
			rtw_records: action.rtw_records
		}
		case types.FETCH_RTW_SIZE:
			return {
				...state,
				rtwsku_size: action.rtwsku_size
			}
		case types.FETCH_RTW_FIT:
			return {
				...state,
				rtwsku_fit: action.rtwsku_fit
			}
		case types.FETCH_PRODUCT_SIZE:
			return {
				...state,
				product_sizes: action.product_sizes,
				product_fits: action.product_fits,
				product_lengths: action.product_lengths,
				product_inventory: action.product_inventory
			}
		case types.TOGGLE_ACCORDION_ORDER:
			return {
				...state,
				accordionKey: [action.key]
			};
		case types.FETCH_STORE_INVENTORY_DETAILS:
			return {
				...state,
				store_inventory: action.store_inventory
			};
		case types.SELECT_SALE_FABRIC:
			return {
				...state,
				details: action.fabric
			};
		case types.FETCH_CUSTOMER_ADDRESSES:
			return {
				...state,
				customer_addresses: action.customer_addresses

			};
		case types.STORE_WISE_FETCH_PENDING_AMOUNTS:
			return {...state,
				store_pending_amounts:action.store_pending_amounts

			};
		case types.FETCH_LIST_DELIVERY_ADDRESSES:
		  return {...state,
				delivery_locations:action.delivery_locations

			};
			
		default:
			return state;
	}
}

export default lists;