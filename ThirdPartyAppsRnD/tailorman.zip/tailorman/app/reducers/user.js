import * as types from 'types';
import {
	combineReducers
} from 'redux';

const isLogin = (
	state = true,
	action
) => {
	switch (action.type) {
		case types.TOGGLE_LOGIN_MODE:
			return !state;
		default:
			return state;
	}
};

const message = (
	state = '',
	action
) => {
	switch (action.type) {
		case types.TOGGLE_LOGIN_MODE:
		case types.MANUAL_LOGIN_USER:
		case types.SIGNUP_USER:
		case types.LOGOUT_USER:
		case types.LOGIN_SUCCESS_USER:
		case types.SIGNUP_SUCCESS_USER:
			return '';
		case types.LOGIN_ERROR_USER:
		case types.SIGNUP_ERROR_USER:
			return action.message;
		default:
			return state;
	}
};

const isWaiting = (
	state = false,
	action
) => {
	switch (action.type) {
		case types.MANUAL_LOGIN_USER:
		case types.SIGNUP_USER:
		case types.LOGOUT_USER:
			return true;
		case types.LOGIN_SUCCESS_USER:
		case types.SIGNUP_SUCCESS_USER:
		case types.LOGOUT_SUCCESS_USER:
		case types.LOGIN_ERROR_USER:
		case types.SIGNUP_ERROR_USER:
		case types.LOGOUT_ERROR_USER:
			return false;
		default:
			return state;
	}
};

const authenticated = (
	state = false,
	action
) => {
	switch (action.type) {
		case types.LOGIN_SUCCESS_USER:
		case types.SIGNUP_SUCCESS_USER:
		case types.LOGOUT_ERROR_USER:
			return true;
		case types.LOGIN_ERROR_USER:
		case types.SIGNUP_ERROR_USER:
		case types.LOGOUT_SUCCESS_USER:
			return false;
		case types.LOAD_USER_DETAILS_SUCCESS : 
			return action.data.authenticated
		default:
			return state;
	}
};
const user = (
	state = {
		isPPD : false
	},
	action
) => {
	switch (action.type) {
		case types.LOGIN_SUCCESS_USER:
			return action.user;
		case types.LOAD_USER_DETAILS:
			return {
				...state,
				isLoading : true
			}
		case types.LOAD_USER_DETAILS_SUCCESS : 
			let isPPD = false;
			let userData = action.data.user;
			let userWorkFlows = userData && userData.roles && userData.roles.workflow || [];
			if(userWorkFlows.indexOf('PPD') != -1){
				isPPD = true;
			}
			return {
				...state,
				isLoading : false,
				isPPD,
				...userData
			}
		default:
			return state;
	}
}
const menu = (
	state = false,
	action
) => {
	switch (action.type) {
		case types.TOGGLE_HAMBURGER_MENU:
			return action.status;
		default:
			return state;
	}
}
const userReducer = combineReducers({
	isLogin,
	isWaiting,
	authenticated,
	message,
	user,
	menu
});

export default userReducer;