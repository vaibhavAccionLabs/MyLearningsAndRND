import * as types from 'types';
import {
	polyfill
} from 'es6-promise';
import request from 'axios';
import moment from 'moment';
import {
	push
} from 'react-router-redux';

function fetchAPI(url, method = 'get', data = null) {
	return request[method](url, data).then(response => {
		if (response.status == 200)
			return response.data;
		else
			console.log("Could not fetch API", url);
	}).catch(err => {
		console.log(err);
	});
}
export function updateMessage(type, message) {
	return {
		type,
		message
	}
}


function postAPI(url, method = 'post', data) {
	return request[method](url, data).then(response => {
		if (response.status == 200)
			return response.data;
		else
			console.log("Could not fetch API", url);
	}).catch(err => {
		console.log(err);
	});
}

function fetchMeasurementFieldList(item_type_id, measurement_type_id) {
	return dispatch => {
		fetchAPI('/list/measurementField?item_type_id=' + item_type_id + "&measurement_type_id=" + measurement_type_id).then(response => {
			dispatch({
				type: types.FETCH_LIST_MEASUREMENT_FIELDS,
				measurement_fields: response
			})
		});
	}
}

function fetchFabricDesignFieldList(item_type_id) {
	return dispatch => {
		fetchAPI('/list/fabricDesignField?item_type=' + item_type_id).then(response => {
			dispatch({
				type: types.FETCH_LIST_FABRIC_DESIGN_FIELDS,
				fabric_design_fields: response
			})
		})
	}
}

function fetchMeasurementTypeList() {
	return dispatch => {
		fetchAPI('/list/measurementType').then(response => {
			const measurement_types = response.map((measurement_type) => {
				return {
					id: measurement_type.source_id,
					name: measurement_type.descr
				}
			})
			dispatch({
				type: types.FETCH_LIST_MEASUREMENT_TYPES,
				measurement_types: measurement_types
			})
		})
	}
}

export function fetchItemTypeList() {
	return dispatch => {
		fetchAPI('/list/itemType').then(response => {
			const item_types = response.map((item_type) => {
				item_type.id = item_type.item_type_id;
				item_type.name=item_type.descr;
				item_type.isMTM = (item_type.mtm_flag == 'Y') ? true : false;
				return item_type;
			});
			dispatch({
				type: types.FETCH_LIST_ITEM_TYPES,
				item_types
			})
		})
	}
}

function fetchStyles() {
	return dispatch => {
		fetchAPI('/list/style').then(response => {
			const styles = response.map((style) => {
				return {
					name: style.code,
					id: style.style_id
				}
			});
			dispatch({
				type: types.FETCH_LIST_STYLES,
				styles
			})
		})
	}
}

function fetchPriorityList() {
	return dispatch => {
		fetchAPI('/list/priority').then(response => {
			const priorities = response.map((priority) => {
				return {
					id: priority.priority_id,
					code: priority.code,
					name: priority.descr,
					delivery_upcharge: priority.delivery_upcharge
				}
			});
			dispatch({
				type: types.FETCH_LIST_PRIORITIES,
				priorities
			})
		});
	};
}

function fetchPaymentTypeList() {
	return dispatch => {
		fetchAPI('/list/paymentType').then(response => {
			const payment_types = response.map((payment_type) => {
				return {
					id: payment_type.payment_type_id,
					code: payment_type.code,
					name: payment_type.descr
				}
			});
			dispatch({
				type: types.FETCH_LIST_PAYMENT_TYPES,
				payment_types
			});
		});
	};
}

function fetchFinishTypeList(data) {
	var item_type_id, index;
     if(data){
		 item_type_id= data.item_type_id;
		  index =data.id;
	 }
	return dispatch => {
		fetchAPI('/list/finishType').then(response => {
			const finish_types = response.map((finish_type) => {
				return {
					id: finish_type.finish_type_id,
					name: finish_type.descr,
					code: finish_type.code
				}
			});
			dispatch({
				type: types.FETCH_LIST_FINISH_TYPES,
				finish_types
			})
			if(item_type_id == 1){
               	var selectedRecord = _.findIndex(finish_types,{code:"Direct Finish"})
			   var finish_type_value = finish_types[selectedRecord] && finish_types[selectedRecord].id; 
			   	dispatch( {
		           type: types.ORDER_SALES_UPDATE_SALE_ITEM_ENTRY,
					payload: {
						value:finish_type_value,
						field:"finish_type_id",
						index
					}
			  });
			}
			
		
		})
	}
}

function fetchRTWMeasurements(data) {
	return dispatch => {
		fetchAPI('/list/rtwmeasurements?item_type=' + data.item_type_id+'&store_id='+data.store_id).then(response => {
			let product_sizes = [];
			let product_fits = [];
			let product_lengths = [];

			response.map((product_size) => {
				product_sizes.push({
					id: product_size.size,
					name: product_size.size
				});
				product_fits.push({
					id: product_size.fit,
					name: product_size.fit
				});
				product_lengths.push({
					id: product_size.length,
					name: product_size.length		
				});

			});
			product_sizes = _.uniqBy(product_sizes,'id');
			product_fits = _.uniqBy(product_fits,'id');
			product_lengths = _.uniqBy(product_lengths,'id');

			dispatch({
				type: types.FETCH_PRODUCT_SIZE,
				product_sizes,
				product_fits,
				product_lengths,
				product_inventory:response

			})
		})
	}
}

function fetchStoreWiseInventoryCount(data) {
	return dispatch => {
		fetchAPI('/list/store/inventory/count?store_id='+data.store_id).then(response => {
		

			dispatch({
				type: types.FETCH_STORE_INVENTORY_DETAILS,
				store_inventory:response

			})
		})
	}
}


function fetchTailors() {
	return dispatch => {
		fetchAPI('/list/tailor').then(response => {
			const tailors = response.map((tailor) => {
				return {
					id: tailor.tailor_id,
					mobile: tailor.mobile,
					name: tailor.tailor_name
				}
			})
			dispatch({
				type: types.FETCH_LIST_TAILORS,
				tailors
			});
		});
	};
}

function fetchSalesMen() {
	return dispatch => {
		fetchAPI('/list/salesman').then(response => {
			const salesmen = response.map((salesman) => {
				return {
					id: salesman.sales_man_id,
					name: salesman.sales_man_name
				}
			});
			dispatch({
				type: types.FETCH_LIST_SALESMEN,
				salesmen
			});
		})
	}
}

function fetchCustomerList(keyword,store_id) {
	return dispatch => {
		fetchAPI('/list/customer?keyword=' + keyword + '&store_id=' + store_id).then(response => {
			const customers = response.map((customer) => {
				customer.id = customer.customer_id;
				customer.phone = customer.mobile;
				customer.gender = customer.gender == 'M' ? 'male' : 'female';
				customer.email = customer.email;
				customer.display_name = customer.email + " " + customer.name + " " + customer.phone;
				return customer;
			});
			dispatch({
				type: types.FETCH_LIST_CUSTOMERS,
				customers
			})
		})
	}
}

function clearCustomerList() {
	return {
		type: types.CLEAR_LIST_CUSTOMERS
	};
}

function fetchFabricList(item_type_id, keyword,data) {
	return dispatch => {
		fetchAPI('/list/fabric?item_type_id=' + item_type_id + "&keyword=" + keyword).then(response => {
			const fabrics = response.map((fabric) => {
				fabric.id = fabric.fabric_id;
				fabric.sku = {
					id: fabric.fabric_id,
					name: fabric.product_sku_code
				};
				return fabric;
			})
			dispatch({
				type: types.FETCH_LIST_FABRICS,
				fabrics,
				selectedValues:data
			});
		})
	}
}


function fetchCameras() {
	return dispatch => {
		navigator.mediaDevices.enumerateDevices()
			.then((devices) => {
				var cameras = devices.filter(device => {
					return device.kind === 'videoinput'
				});
				dispatch({
					type: types.FETCH_LIST_CAMERAS,
					cameras
				})
			});
	}
}

function fetchCustomerSourceList() {
	return dispatch => {
		fetchAPI('/list/customerSource').then(response => {
			const customerSources = response.map((source) => {
				return {
					id: source.source_id,
					code: source.code,
					name: source.descr
				}
			})
			dispatch({
				type: types.FETCH_LIST_CUSTOMER_SOURCES,
				customerSources
			})
		})
	}
}

export function fetchCustomerAddress(customer_id){
	return dispatch => {
		fetchAPI('/list/customerAddresses?customer_id=' + customer_id).then(response => {
			dispatch({
				type: types.FETCH_CUSTOMER_ADDRESSES,
				customer_addresses: response
			});
		})
	}
}

function fetchOccasions() {
	return dispatch => {
		fetchAPI('/list/occasion').then(response => {
			const occasions = response.map((occasion) => {
				return {
					id: occasion.occation_id,
					name: occasion.descr
				}
			});
			dispatch({
				type: types.FETCH_LIST_OCCASIONS,
				occasions
			})
		});

	}
}

function fetchProfiles(item_type_id, customer_id) {
	return dispatch => {
		fetchAPI('/profiles?item_type_id=' + item_type_id + "&customer_id=" + customer_id).then(response => {
			const profiles = response.map((profile) => {
				return {
					id: profile.profile_id,
					name: profile.created_date ? `${profile.profile_name} - ${moment(profile.created_date).format('DDMMYYYY')}` : profile.profile_name,
					measurement_source_id: profile.measurement_source_id,
					comment: profile.comment,
					profile_id: profile.profile_id
				}
			});
			dispatch({
				type: types.FETCH_CUSTOMER_PROFILE_LIST,
				profiles
			})
		})
	}
}
function fetchStyleProfiles(item_type_id, customer_id) {
	return dispatch => {
		fetchAPI('/style/profiles?item_type_id=' + item_type_id + "&customer_id=" + customer_id).then(response => {
			const style_profiles = response.map((profile) => {
				return {
					id: profile.profile_id,
					// name: profile.in_profile_name ,
					name : profile.created_date ? `${profile.in_profile_name} - ${moment(profile.created_date).format('DDMMYYYY')}` : profile.in_profile_name,
					fabric_design: profile.fabric_design,
					comment: profile.comments,
					profile_id: profile.profile_id,
					upcharge:profile.upcharge
					//modified:false
				}
			});
			dispatch({
				type: types.FETCH_CUSTOMER_STYLE_PROFILE_LIST,
				style_profiles
			})
		})
	}
}

function fetchOrders(customer_id) {
	return dispatch => {
		fetchAPI('/orders?customer_id=' + customer_id).then(response => {
			var customerOrders = response.map((order) => {
				order.id = order.order_id;
				order.name = [order.order_id, order.display_name].join(' -- ');
				order.order_date = moment(order.order_date).format('YYYY-MM-DD');
				//TODO: Fix these typos in the procs
				order.occasion_date = order.occation_date ? moment(order.occation_date).format('YYYY-MM-DD') : '';
				order.benificiary_phone = order.benficiary_mobile;
				order.benificiary_name = order.benficiary_name;
				order.salesman_id = order.sales_man_id;
				return order;
			});
			dispatch({
				type: types.FETCH_CUSTOMER_ORDER_LIST,
				orders: customerOrders
			})
		})
	}
}

function fetchWorkflows() {
	return dispatch => {
		fetchAPI('/list/workflow').then(response => {
			dispatch({
				type: types.FETCH_LIST_WORKFLOW,
				workflows: response
			});
		});
	}
}

export function fetchSaleFabricList(keyword,data){
	return dispatch => {
		fetchAPI('/list/sale/fabric?keyword=' + keyword).then(response => {
			const sale_fabrics = response.map((fabric) => {
				fabric.id = fabric.fabric_id;
				fabric.sku = {
					id: fabric.fabric_id,
					name: fabric.product_sku_code
				};
				return fabric;
			})
			dispatch({
				type: types.FETCH_LIST_SALE_FABRICS,
				sale_fabrics,
				selectedValues:data
			});
		})
	}

}




export function fetchList(type, data = null) {
	return dispatch => {
		switch (type) {
			case 'priority':
				dispatch(fetchPriorityList());
				break;
			case 'payment_type':
				dispatch(fetchPaymentTypeList());
				break;
			case 'finish_type':
				dispatch(fetchFinishTypeList(data));
				break;
			case 'tailor':
				dispatch(fetchTailors());
				break;
			case 'salesman':
				dispatch(fetchSalesMen());
				break;
			case 'style':
				dispatch(fetchStyles());
				break;
			case 'item_type':
				dispatch(fetchItemTypeList());
				break;
			case 'measurement_type':
				dispatch(fetchMeasurementTypeList());
				break;
			case 'measurement_field':
				if (!data.clear)
					dispatch(fetchMeasurementFieldList(data.item_type_id, data.measurement_type_id));
				else
					dispatch({
						type: types.CLEAR_LIST_MEASUREMENT_FIELDS
					})
				break;
			case 'fabric_design_field':
				dispatch(fetchFabricDesignFieldList(data.item_type_id));
				break;
			case 'fabric':
				dispatch(fetchFabricList(data.item_type_id, data.keyword,data));
				break;
			case 'sale_fabric':
				dispatch(fetchSaleFabricList(data.keyword,data));
				break;
			case 'customer':
				dispatch(fetchCustomerList(data.keyword,data.store_id));
				break;
			case 'cameras':
				dispatch(fetchCameras());
				break;
			case 'customer_source':
				dispatch(fetchCustomerSourceList());
				break;
			case 'profile':
				dispatch(fetchProfiles(data.item_type_id, data.customer_id));
				break;
			case 'style_profile':
				dispatch(fetchStyleProfiles(data.item_type_id, data.customer_id));
				break;	
			case 'orders':
				dispatch(fetchOrders(data.customer_id));
				break;
			case 'occasion':
				dispatch(fetchOccasions());
				break;
			case 'workflow':
				dispatch(fetchWorkflows());
				break;
			case 'rtwmeasurements':
				dispatch(fetchRTWMeasurements(data));
				break;
			case 'store_type':
				dispatch(fetchStoreWiseInventoryCount(data));
				break;
			case 'store_inventory':
			    dispatch(fetchAllInventoryData(data));
				break;
			case 'customer_address':
				dispatch(fetchCustomerAddress(data.customer_id));
				break;
			case 'store_pending_amounts':
			    dispatch(fetchPendingAmounts(data));
				break;
			case 'delivery_location':
			  dispatch(fetchDeliveryLocation(data));
				break;
		}
	}

}

export function clearList(type) {
	return dispatch => {
		switch (type) {
			case 'customer':
				dispatch(clearCustomerList());
				break;
			case 'fabric':
				dispatch({
					type: types.CLEAR_LIST_FABRICS
				});
				break;
			case 'sale_fabric':
				dispatch({
					type: types.CLEAR_LIST_SALE_FABRICS
				});
				break;
			case 'measurement_field':
				dispatch({
					type: types.CLEAR_LIST_MEASUREMENT_FIELDS
				});
			case 'product':
				return {
					type: types.CLEAR_LIST_SEARCHPRODUCTS
				}
			default:
				break;
		}
	}
}
export function searchRTW(store_id,keyword,size,fit,itemTypeId) {
	return dispatch => {
		fetchAPI('/list/searchRTW?keyword='+keyword+'&store_id='+store_id+'&size='+size+'&fit='+fit+'&item_type_id='+itemTypeId).then(response => {
			
			const rtwsku = response.map((rtwsku) => {
				return {
					fabric_id:rtwsku.fabric_id,
					id: rtwsku.fabric_sku_code,
					name: rtwsku.name,
					product_sku_code:rtwsku.product_sku_code,
					inventory_count:rtwsku.inventory_count,
					mrp:rtwsku.mrp,
					size:rtwsku.size,
					fit:rtwsku.fit,
					item_type_id:rtwsku.item_type_id
				}
			});
			dispatch({
				type: types.FETCH_RTW_SKU,
				rtwsku
			});
		})
	}
}

export function searchRTWStock(store_id,keyword,size,fit,itemTypeId) {
	return dispatch => {
		fetchAPI('/list/searchRTWStock?keyword='+keyword+'&store_id='+store_id+'&size='+size+'&fit='+fit+'&item_type_id='+itemTypeId).then(response => {
	
			
			const rtwsku_stock = response.map((rtwsku) => {
				return {
					fabric_id:rtwsku.fabric_id,
					id: rtwsku.fabric_sku_code,
					name: rtwsku.name,
					product_sku_code:rtwsku.product_sku_code,
					inventory_count:rtwsku.inventory_count,
					mrp:rtwsku.mrp,
					size:rtwsku.size,
					fit:rtwsku.fit,
					item_type_id:rtwsku.item_type_id
				}
			});
			
			dispatch({
				type: types.FETCH_RTW_SKU_STOCK,
				rtwsku_stock
			});
		})
	}
}



export function fetchSizeList(){
	return dispatch => {
		fetchAPI('/list/fetchSize').then(response=>{
			const rtwsku_size = response.map((rtwsku_size) => {
				return {
					name:rtwsku_size.name
				}
			});
			dispatch({
				type: types.FETCH_RTW_SIZE,
				rtwsku_size
			});
		});
	}
}

export function fetchFitList(){
	return dispatch => {
		fetchAPI('/list/fetchFit').then(response=>{
			const rtwsku_fit = response.map((rtwsku_fit) => {
				return {
					name:rtwsku_fit.name
				}
			});
			dispatch({
				type: types.FETCH_RTW_FIT,
				rtwsku_fit
			});
		});
	}
}



export function updateRTWInventory(formValues){
	return dispatch => {
		postAPI('/list/inventory/update','post',formValues).then(response=>{
			dispatch(updateMessage('INVENTORY_UPLOADED_SUCCESS', 'Inventory uploaded successfully!'));

			console.log("Successfully inserted details");
		});
	}
}
export function fetchAllInventoryData(){
	return dispatch => {
		fetchAPI('/list/inventory/sheet?download=true','get',"").then(response=>{

			console.log("Successfully get inventory details");
		});
	}
}

export function fetchStockDetails(values){

	return dispatch => {
		postAPI('/list/inventory/stockdetails','post',values).then(response=>{
			const stock_details = response.data;
			dispatch({
				type: types.FETCH_RTW_STOCK_DETAILS,
				stock_details
			});
		});
	}
}

export function transferInventory(formValues){
	return dispatch => {
		postAPI('/list/inventoryTransfer','post',formValues).then(response=>{

			console.log("Successfully inserted details");
		});
	}
}
export function setActiveKey(key) {
	return {
		type: types.TOGGLE_ACCORDION_ORDER,
		key
	}
}

export function selectSaleFabric(fabric, redirect,index) {
	return dispatch => {
		dispatch({
			type: types.SELECT_SALE_FABRIC,
			fabric
		});
		if (redirect)
			dispatch(push("/order/sales/"+index+"/type/" + fabric.item_type_id));
	}
}
function fetchPendingAmounts(data) {
    return dispatch => {
        fetchAPI('/pending/amounts?store_id='+data.store_id).then(response => {
            

            dispatch({
                type: types.STORE_WISE_FETCH_PENDING_AMOUNTS,
                store_pending_amounts:response

            })
        })
    }

}
function fetchDeliveryLocation(data) {
    return dispatch => {
        fetchAPI('/delivery/locations').then(response => {
            var responseData =[];
           response.map((item)=>{
            responseData.push({
				id:item.store_id,
				name: item.name
			})
		   })
		    responseData.push({
				id:"courier",
				name:"courier"
			})
            dispatch({
                type: types.FETCH_LIST_DELIVERY_ADDRESSES,
				delivery_locations:responseData

            })
        })
    }

}


