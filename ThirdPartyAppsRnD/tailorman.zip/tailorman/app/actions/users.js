import {
	polyfill
} from 'es6-promise';
import request from 'axios';
import {
	push
} from 'react-router-redux';

import * as types from 'types';

polyfill();

const getMessage = res => res.response && res.response.data && res.response.data.message;
/*
 * Utility function to make AJAX requests using isomorphic fetch.
 * You can also use jquery's $.ajax({}) if you do not want to use the
 * /fetch API.
 * @param Object Data you wish to pass to the server
 * @param String HTTP method, e.g. post, get, put, delete
 * @param String endpoint - defaults to /login
 * @return Promise
 */
function makeUserRequest(method, data, api = '/login') {
	return request[method](api, data);
}



// Log In Action Creators
export function beginLogin() {
	return {
		type: types.MANUAL_LOGIN_USER
	};
}

export function loginSuccess(response) {
	return {
		type: types.LOGIN_SUCCESS_USER,
		message: response.message,
		user: response.user
	};
}

function fetchStoresSucces(stores) {
	return {
		type: types.FETCH_STORES_SUCCESS,
		stores
	}
}

export function loginError(message) {
	return {
		type: types.LOGIN_ERROR_USER,
		message
	};
}

// Sign Up Action Creators
export function signUpError(message) {
	return {
		type: types.SIGNUP_ERROR_USER,
		message
	};
}

export function beginSignUp() {
	return {
		type: types.SIGNUP_USER
	};
}

export function signUpSuccess(message) {
	return {
		type: types.SIGNUP_SUCCESS_USER,
		message
	};
}

export function logout() {
	makeUserRequest('post', null, '/logout');
}
// Log Out Action Creators
export function beginLogout() {
	return {
		type: types.LOGOUT_USER
	};
}

export function logoutSuccess() {
	return {
		type: types.LOGOUT_SUCCESS_USER
	};
}

export function logoutError() {
	return {
		type: types.LOGOUT_ERROR_USER
	};
}

export function toggleLoginMode() {
	return {
		type: types.TOGGLE_LOGIN_MODE
	};
}

export function selectStore(store) {
	return dispatch => {
		dispatch({
			type: types.USER_SELECT_STORE,
			store
		});
		dispatch(push('/customer'));
	}
}

export function fetchStoresList(stores) {
	return dispatch => {
		return makeUserRequest('post', stores, '/user/stores')
			.then(response => {
				if (response.status === 200) {
					dispatch(fetchStoresSucces(response.data));
					//dispatch(push('/order'));
				} else {
					console.log("Could not fetch stores");
				}
			}).catch(err => {
				console.log(err);
			});
	};
}

// export function fetchOrderHistory() {
// 	return dispatch => {
// 		return makeUserRequest('get', null, '/orders/items/history')
// 			.then(response => {
// 				if (response.status === 200)
// 					console.log(response.data);
// 			})
// 	}
// }

export function checkLoginStatus(){
	return dispatch => {
		dispatch({
			type : types.LOAD_USER_DETAILS
		});
		return makeUserRequest('get', null, '/userdetails')
			.then(response => {
				if (response.status === 200) {
					let data = response.data;
					dispatch({
						type : types.LOAD_USER_DETAILS_SUCCESS,
						data
					});
					if(!data.authenticated){
						dispatch(push('/login'));
					}else if (window.location.pathname == "/login"){
						dispatch(push('/landing'));
					}
				} else {
					console.log("Could not fetch User Details");
				}
			}).catch(err => {
				console.log(err);
			});
	};
	
} 

//CHECK_LOGIN_STATUS
export function manualLogin(data) {
	return dispatch => {
		dispatch(beginLogin());

		return makeUserRequest('post', data, '/login')
			.then(response => {
				if (response.status === 200) {
					dispatch(loginSuccess(response.data));
					dispatch(push('/stores'));
				} else {
					dispatch(loginError('Oops! Something went wrong!'));
				}
			})
			.catch(err => {
				dispatch(loginError(getMessage(err)));
			});
	};
}