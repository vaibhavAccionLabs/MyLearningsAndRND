import * as types from 'types';
import {
	polyfill
} from 'es6-promise';
import {
	push
} from 'react-router-redux';
import request from 'axios';
import moment from 'moment';
import _ from 'lodash';
polyfill();


function makeRequest(method, data, api) {
	return request[method](api, data);
}
export function getPendingWorkOrders(customer_id,store_id) {
	return dispatch => {
		makeRequest('post', {customer_id:customer_id,store_id:store_id}, '/orderstyleupdate').then((response) => {
			if (response.status === 200) {
				const updatestyleorders = response.data;
				dispatch({
					type: types.UPDATE_STYLE_ORDERS,
					updatestyleorders: updatestyleorders
				})
			}
		}).catch((error) => {
			console.log("Error fetching work orders", error);
		})
	}
}

