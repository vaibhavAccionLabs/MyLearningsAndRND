import * as types from 'types';
import {
	polyfill
} from 'es6-promise';
import {
	push
} from 'react-router-redux';
import request from 'axios';
import { updateMessage } from './order';
import {fetchList} from './list';
polyfill();

function makeRequest(method, data, api) {
	return request[method](api, data);
}

function updateCustomerValues(customer) {
	return {
		type: types.ORDER_CUSTOMER_UPDATE,
		customer
	}
}


export function selectCustomer(customer) {
	return dispatch => {
		if (customer.customer_id > 0) {
			dispatch(updateCustomerValues(customer));
			dispatch({
			type: types.CLEAR_ORDER_DATA
		})
		dispatch(push('/customer/actions'));
		} else {
			const _customer = {
				mobile: customer.phone,
				name: customer.name,
				source_id: 1,
				email: customer.email,
				store_id:customer.store_id,
				referral_code:customer.referral_code
			}
			makeRequest('post', _customer, '/order/checkcustomer')
				.then((response) => {
					if (response.status === 200) {
						customer.customer_id = response.data.customer_id;
						dispatch({
							type: types.CLEAR_ORDER_DATA
						});
						dispatch(updateCustomerValues(customer));
						dispatch(push('/customer/actions'));
					} else {
						console.log("Something went wrong with the request", err);
					}
				})
				.catch(error => {
					console.log("Something went wrong with the request", error);
					dispatch(updateMessage('ALREADY_EXIST_CONDITION', 'Customer already exist!'))
				});
		}
		

	}
}

export function saveCustomerPhone(phone) {
	return {
		type: types.ORDER_CUSTOMER_UPDATE_PHONE,
		phone
	}
}

export function toggleAddressListItemMenu(isOpen, m_customer_addresses_id) {
	return dispatch => {
		dispatch({
			type: types.TOGGLE_ADDRESS_LIST,
			isOpen,
			m_customer_addresses_id
		});
		// dispatch({
		// 	type: types.SELECT_ADDRESS_LIST,
		// 	m_customer_addresses_id
		// })
		
	}
}

export function setDefaultDeliveryAddress(address){
	return dispatch => {
		makeRequest('post', {
			address_type : address.address_type,
			m_customer_addresses_id : address.m_customer_addresses_id,
			m_customer_id : address.m_customer_id
		}, '/updatecustomerdefaultaddress')
		.then((response) => {
			dispatch(fetchList('customer_address',{customer_id:address.m_customer_id}));
			dispatch(updateMessage('UPDATE_GENERAL_MESSAGE', 'Default Delivery Address has been updated!'));
			window.scrollTo(0, 0);
		})
		.catch(error => {
			dispatch(updateMessage('ALREADY_EXIST_CONDITION', 'Default Delivery Address cannot be updated!'));
			window.scrollTo(0, 0);
		});

}
}

// export function setDefaultBillingAddress(address){


	// 	return dispatch => {
// 		// dispatch({
// 		// 	type: types.SET_DEFAULT_BILLING_ADDRESS,
// 		// 	address
// 		// });
// 		dispatch(updateMessage('UPDATE_GENERAL_MESSAGE', 'Default Billing Address has been updated!'));
// 		window.scrollTo(0, 0);
// }
// }
export function referFriend(_details){
	return dispatch => {
			
			return makeRequest('post', _details, '/customer/referfriend')
				.then((response) => {
					
					if(response.data && response.data.data && response.status == 200){
						if(response.data.data.response.customers && response.data.data.response.customers.customer && response.data.data.response.customers.customer.length >0){
							let msgArray=[];
							let isError = '';
							let customer = response.data.data.response.customers.customer;
							if(customer[0].referrals && customer[0].referrals.referral_type && customer[0].referrals.referral_type.length > 0){
								let referalMail = "";
								let referalMsg = "";
								
								let referalFields = customer[0].referrals.referral_type[0].referral;
								if(referalFields && referalFields.length>0){
									referalFields.map(function(referal){
										 referalMail = referal.identifier;
										 referalMsg = referal.status.message;
										 msgArray.push({
											 success:referal.status.success,
											 msg:referal.identifier+" - "+referal.status.message
										 })
										 //msgArray+= referal.identifier+" - "+referal.status.message+",";
										 
									});
								}
							
							}else{

							}
							return msgArray;
							
							
						}
					}
					
				})
				.catch(error => {
					dispatch(updateMessage('IMAGE_UPLOADED_FAILURE',error.message));
				});


	}
}

export function updatePendingAmountDetails(data){
	return dispatch => {
		makeRequest('post', data, '/update/pending/amount')
		.then((response) => {
		//	dispatch(fetchList('customer_address',{customer_id:address.m_customer_id}));
		//	dispatch(updateMessage('UPDATE_GENERAL_MESSAGE', 'Default Delivery Address has been updated!'));
			window.scrollTo(0, 0);
		})
		.catch(error => {
			//dispatch(updateMessage('ALREADY_EXIST_CONDITION', 'Default Delivery Address cannot be updated!'));
			window.scrollTo(0, 0);
		});

}
}
