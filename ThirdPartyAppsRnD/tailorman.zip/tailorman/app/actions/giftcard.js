import * as types from 'types';
import request from 'axios';
import {
    push
} from 'react-router-redux';

function makeRequest(method, data, api) {
	return request[method](api, data);
}

export function insertGiftcard(giftobj){
	return {
		type:types.INSERT_GIFT_CARD,
		giftobj:giftobj
	}
}

export function deleteGiftcard(id){
	return{
		type:types.DELETE_GIFT_CARD,
		id:id
	}
}

export function resetGiftCards(){
	return{
		type : types.RESET_GIFT_CARDS
	}
}

function giftCuponDetails(cupon_details){
	return {
		type: types.GIFT_CUPON_DETAILS,
		cupon_details

	}
}

function getGiftCardsList(giftcards){
	return{
		type : types.GET_GIFT_COUPONES_LIST,
		giftcards
	}
}

function getGiftTransactions(transactions){
    return{
		type : types.GET_GIFT_TRANASACTIONS,
		transactions
	}
}
export  function vlidateGiftCupon(gift_vocher,customer_id){
	    let voucherDetails={
	    	gift_vocher,
	    	customer_id
	    }
    return (dispatch) => {
		return makeRequest('post',voucherDetails,'/order/validatevocher').then(response => {
			/*let cupon_details={
				gift_vocher:gift_vocher,
				isredeemable:true,
				validitydate:"05-7-2018",
				giftAmount:2500,
				msg:'Entered Cupon is valid you can redeem now.'
			}*/
		console.log("voucher",response.data)
		return	dispatch(giftCuponDetails(response.data));

		});
	}
}

export function redeemGiftCupon(redeem_amount,cupon_details){
	
	return (dispatch,cupon_details) => {
		//return makeRequest('post').then(response => {
			/*let is_redeem_sucess=true;
			let cupon=cupon_details
		
			if(is_redeem_sucess){
           cupon.isredeemable =false,
           cupon.redeem_amount=redeem_amount
           cupon.is_redeem_sucess=is_redeem_sucess
           
            }*/
		return	dispatch(giftCuponDetails({}));

		//});
		}
}

export function giftCardPayment(giftcard) {
	return dispatch => {
		return makeRequest('post', giftcard, '/order/savegiftorder').then(response => {
			dispatch(push('/landing'))
			//dispatch(fetchCustomerAddress(profile.customer_id));
		});
	}
}

export function fetchGiftCardsList(customerId,store_Id,from_date,to_date){
	let giftSearchObj = {
			start_date:from_date||null,
			end_date:to_date||null,
			store_id:store_Id || null,
			customer_id:customerId||null
	}
	return dispatch => {
		return makeRequest('post', giftSearchObj, '/gifts/searchlist').then(response => {
			dispatch(getGiftCardsList(response.data.data));

		});
	}
}

export function fetchGiftTransactions(voucher_id){
    let giftcard = {gift_vocher_id:voucher_id}
   return dispatch => {
		return makeRequest('post', giftcard, '/gifts/transactions').then(response => {
			dispatch(getGiftTransactions(response.data.data));

		});
	}

}