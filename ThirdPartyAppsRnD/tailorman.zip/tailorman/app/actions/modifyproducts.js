import * as types from 'types';
import request from 'axios';
import _ from 'lodash';

function makeRequest(method, data, api) {
	return request[method](api, data);
}

export function updateMessage(type, message) {
	return {
		type,
		message
	}
}

export function previewimage(updateType,imgData){
//	debugger;
// console.log("UPDATE TYPE", updateType);
// console.log("IMAGE DATA", imgData);
	return {
		type: types.PREVIEW_RTW_IMAGE,
		updateType,
		imgData
	}
}

export function deleteProducts(product) {
	//debugger;
	return {
        type: types.DELETE_PPRODUCT_LIST,
        product
	};
}

export function uploadedProducts(product){
	debugger;
	return {
		type: types.UPLOAD_PRODUCT_LIST,
		product                  
	}
}

export function cleardeleteProducts() {
	return {
        type: types.CLEAR_DELETE_PPRODUCT_LIST,
	};
}

export function clearuploadedProducts() {
	return {
        type: types.CLEAR_UPLOAD_PRODUCT_LIST,
	};
}

export function updatertwimagecount(count){
	return {
		type: types.UPDATE_RTW_IMAGE_COUNT,
		count
	};
}

//To get the s3 signed url
export function deleteAWSCloudImage(fileName, rtw, productSku) {
	//debugger;
	
	//return dispatch => { 
		if(_.isArray(fileName)){
			fileName.map((imgfile) => {
				console.log('Requested fileName to delete: ', imgfile);
				//var fileName = imgfile + ".jpg";
				// if(imgfile.indexOf("RTW") !== -1){
				// 	imgfile = {
				// 		filename:imgfile,
				// 		rtw:true,
				// 		productSku:productSku
				// 	};
				// }

				let fileObj = {
					fileName : imgfile,
					rtw :rtw, 
					productSku: productSku
				};

			return	makeRequest('post', {
				   file: fileObj
			   }, '/s3/image/delete')
			   .then((response) => {
				  console.log("IMAGED DELETED RESPONSE===", response);
				  //dispatch(updateMessage(types.IMAGE_DELETED_SUCCESS, 'Image deleted successFully'));
			   })
			   .catch((error) => {
				   console.log('Error in deleting the image from aws',error);
			   });
			});
		}
		//dispatch(cleardeleteProducts());
	//}
}

export function getImageUploadSignUrl(filedata, customFileName, rtw, productSku){
	//debugger;
	console.log("Request file obj : ", filedata);
	let fileName = filedata.name;
	let fileExtension = (fileName.substring(fileName.lastIndexOf(".")+1));
	let file = {
		name:customFileName,
		//name: customFileName+'.'+fileExtension,
		size :filedata.size,
		//path:'product/'
		checkRtw: rtw,
		productSku: productSku
	};
	return makeRequest('post', {
			file: file
		}, '/s3/signedurl')
		.then((response) => {
		console.log("Response is", response);
		 if(response.status == 200){
			let data = response.data;
			return data;
		}
		}).catch((error) => {
			console.log('Error generating the signed Url ==== ',error);
		});
}


//To upload into AWS s3 image using signed url
	export function uploadImagetoAWS(file, customFileName, signed_request, response_url) {
		//debugger;
		var options = {
			headers: {
				'Content-Type': file.type
			}
		};
			request
			.put(signed_request, file, options)
					.then((data) => {
						console.log("NEW IMAGE PATH IS",data);
						//dispatch(updateMessage(types.IMAGE_UPDATED_SUCCESS, 'Image updated successFully'));
					})
					.catch((error) => {
						console.log(err);
					});		
		}


	export function saveImageAWS(files, rtw, productSku) {
		//debugger;
		if(_.isArray(files)){
			files.map((file)=>{
				let fileObj = file;
				let customFileName = file.customPathName;
					getImageUploadSignUrl(fileObj, customFileName, rtw, productSku).then(data => {
							return uploadImagetoAWS(fileObj, customFileName, data.data.requestUrl, data.data.imageUrl);
						}).catch((error)=>{
							console.log("Can not upload the file", error);
						});
			});
		}
	}

	export function selectedProduct(product) {
		return {
			type: types.SELECTED_PPRODUCT,
			product
		};
	}