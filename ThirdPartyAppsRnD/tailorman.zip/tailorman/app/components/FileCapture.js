import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';

//Binding styles
import styles from 'css/components/filecapture';
import classNames from 'classnames/bind';
const cx = classNames.bind(styles);

//@class
export default class FileCapture extends Component {
	constructor(props) {
		super(props);

		this.fileCapture = this.fileCapture.bind(this);
	}


	fileCapture(e) {
		const { fileType, uploadFileDetails, emptyFileUploaded } = this.props;

		const target = e && e.target;

		let file = target.files;

		if (file && file.length > 0) {
			file = file[0];
			// if(fileType && !file.type.match(fileType)) {
			// uploadFileDetails();
			// } else {
			if (this.props.workOrderMenu) {
				this.props.addImage(file);
			} else {
				let reader = new FileReader();
				reader.onload = result => {
					uploadFileDetails(file, result['target']['result']);
				};
				reader.readAsBinaryString(file);
			}

			if (this.props.closeMenu) {
				this.props.closeMenu();
			}
		} else {
			emptyFileUploaded && emptyFileUploaded();
		}
	}
	reset() {
		let uploadInput = ReactDOM.findDOMNode(this.refs.uploadFileStock);
		uploadInput.value = '';
	}
	render() {
		let { accept, reset } = this.props;

		accept = accept || 'image/*,.pdf';
		let fileClassName = this.props.className ? this.props.className : null;

		return (
			<div className={cx('upload-wrapper')}>
				<input
					type="file"
					accept={accept}
					ref={'uploadFileStock'}
					onChange={this.fileCapture}
					className={fileClassName}
					title=" " />
			</div>

		);
	}
}

FileCapture.propTypes = {
	accept: PropTypes.string,
	fileType: PropTypes.string,
	uploadFileDetails: PropTypes.func,
	emptyFileUploaded: PropTypes.func
};