import React, { Component, PropTypes } from 'react';
import classNames from 'classnames/bind';
import styles from 'css/components/measurementForm';
import IncrementField from './IncrementField';
import MultipleChoice from './MultipleChoice';
import ReactDOM from 'react-dom';
import SelectForm from './SelectForm';
import Select from 'react-select';
import ImageCapture from 'components/ImageCapture';
import _ from 'lodash';
const cx = classNames.bind(styles);
import Popup from 'react-popup';
import { UPCHARGE_UNIT_VALUE, UPCHARGE_UNIT_PERCENTAGE } from 'types';
import { ValidationObj } from './MeasurementValidation';

const mandatoryFields = ["CUSTOMER IS WEARING", "MASTER SUGGESTED", "CUSTOMER FINAL FIT PREFERENCE", "CUSTOMER IS WEARING (BODY OVER)", "CUSTOMER IS WEARING (ARMHOLE)", "MASTER SUGGESTED (BODY OVER)", "MASTER SUGGESTED (ARMHOLE)", "FINAL FIT PREFERENCE (ARMHOLE)", "FINAL FIT PREFERENCE (BODY OVER)"];

export default class MeasurementsForm extends Component {
	constructor(props) {
		super(props);
		this.saveMeasurementType = this.saveMeasurementType.bind(this);
		this.save = this.save.bind(this);
		this.validate = this.validate.bind(this);
		this.measurement_type = 0;
		this.saveMeasurement = this.saveMeasurement.bind(this);
		this.getMeasurementFormFields = this.getMeasurementFormFields.bind(this);
		this.onDeltaChange = this.onDeltaChange.bind(this);
		this.profile = this.props.profile || {
			profile: {
				comment: '',
				name: '',
				item_type_id: 0,
				measurement_source_id: -1,
				profile_id: -1
			}
		}
		this.state = {
			validationArray: [],
			checked:false
		};
	}
	componentWillMount() {
		this.props.loadFields(0, true);
		if (this.props.profile && this.props.profile.measurement_source_id) {
			this.props.loadFields(this.props.profile.measurement_source_id);
			if (this.props.profile.measurements && this.props.profile.measurements.length > 0) {
				this.measurements = [];
				this.measurementDescr = [];
				const values = _.map(this.props.profile.measurements, 'value');
				const ids = _.map(this.props.profile.measurements, 'id');
				ids.forEach((id, index) => {
					this.measurements[id] = values[index];
					if (this.props.profile.values && this.props.profile.values[index]) {
						this.measurementDescr[id] = this.props.profile.values[index].descr;
					}
				});
			} else {
				this.measurements = [];
				this.measurementDescr = [];
			}
		}
	}

	onDeltaChange(arg,e){
		
       const field = _.find(this.props.lists.measurement_fields, { measurement_type_id: arg.measurement_type_id });

       if(this.refs.delta_check.checked) {
		   field.delta_flag_value = true;
		   this.setState('checked',true);
       } else {
		   field.delta_flag_value = false;
		   this.setState('checked',false);
       }
   }


	saveMeasurementType(selected, type) {
		this.profile.measurement_source_id = selected.value;
		this.props.loadFields(selected.value);
	}

	saveMeasurement(value, rel) {
		let descr = null;
		if (_.isArray(value)) {
			const field = _.find(this.props.lists.measurement_fields, { measurement_type_id: parseInt(rel) });
			const option = _.find(field.options, { descr: value[0] });
			if (option) {
				value = option.value;
				descr = option.descr;
			}
		}
		this.measurements[rel] = parseFloat(value);

		this.measurementDescr[rel] = descr;

		this.props.save(this.measurements, true, descr);
	}

	getMeasurementUpcharge(measurement) {
		if (measurement.upcharge_value > 0) {
			return {
				display: "Upcharge: " + measurement.upcharge_value + ' INR if >' + measurement.upcharge_limit,
				value: measurement.upcharge_value,
				type: UPCHARGE_UNIT_VALUE
			}
		}
		else if (measurement.upcharge_persentage > 0) {
			return {
				display: "Upcharge: " + measurement.upcharge_persentage + "% on MRP if >" + measurement.upcharge_limit,
				value: measurement.upcharge_persentage,
				type: UPCHARGE_UNIT_PERCENTAGE
			}
		} else {
			return {
				display: "No Upcharge",
				value: 0,
				type: -1
			}
		}
	}
	isMandatory(fieldName) {
		fieldName = fieldName && fieldName.toUpperCase();
		const mandatory = mandatoryFields.indexOf(fieldName);
		if (mandatory >= 0) {
			return <em className={cx('mandatory')}>*</em>;
		}
		return '';
	}
	getMeasurementFormFields() {
		const self = this;
		const { validationArray } = this.state;
		
		if (!self.measurements) {
			self.measurements = [];
		}
		if (!self.measurementDescr) {
			self.measurementDescr = [];
		}
		if (this.props.lists.measurement_fields && this.props.lists.measurement_fields.length > 0) {
			return this.props.lists.measurement_fields.map((measurement, index) => {
				  let fieldName = measurement && measurement.code.toUpperCase();
				if(measurement.upcharge_value > 0 || measurement.upcharge_persentage > 0 || !this.props.displayUpcharge || mandatoryFields.indexOf(fieldName)>=0 ){
				var _default = self.measurements[measurement.measurement_type_id];
				const measurement_upcharge = self.getMeasurementUpcharge(measurement);
				let deltaMeasCmp = self.props.profile && self.props.profile.values && _.find(self.props.profile.values,{measurement_type_id:measurement.measurement_type_id});
				let deltaFlagValue = deltaMeasCmp ? deltaMeasCmp.delta_flag_value : null;
				
				if(deltaFlagValue == true){
					this.state.checked = true;
				}
                const delta_flag_cmp = (measurement.delta_flag) ? <div className={cx('deltadiv')}><span>Delta</span><span><input type="checkbox" ref="delta_check" type="checkbox" onChange={() =>this.onDeltaChange(measurement)} checked={this.state.checked}/></span></div> : '';

				if (measurement.category != "Enumerated" || !measurement.options) {
					_default = (_default) ? _default.toString() : '0.000';
					return (
						<div className={cx('input-group')} key={measurement.measurement_type_id}>
							<label htmlFor={"measurement-" + measurement.measurement_type_id}>{measurement.code}{this.isMandatory(measurement.code)}</label>
							<IncrementField default={_default.toString()} step="0.125" save={self.saveMeasurement} rel={measurement.measurement_type_id.toString()} />

							<span className={cx({
								'foot-note': true,
								'green': measurement_upcharge.value > 0
							})}>{measurement_upcharge.display}</span>
							
							{delta_flag_cmp}
							<label className={cx('label_mandatory')} >{validationArray[measurement.measurement_type_id]}</label>
							
						</div>
					);
				} else {
					const _selectedField = _.find(measurement.options, { value: parseFloat(_default) });
					let selected;
					if (_selectedField)
						selected = [_selectedField.descr];
					return (
						<div className={cx('input-group')} key={measurement.measurement_type_id}>
							<label htmlFor={"measurement-" + measurement.measurement_type_id}>{measurement.code}{this.isMandatory(measurement.code)}</label>
							<MultipleChoice isMultiple={false} rel={measurement.measurement_type_id.toString()} save={self.saveMeasurement} selected={selected} options={_.map(measurement.options, 'descr')} />
							<span className={cx({
								'foot-note': true,
								'green': measurement_upcharge.value > 0
							})}>{measurement_upcharge.display}</span>
							
						</div>
					);
				}
			  }
			});
		}
	}

	getMeasurementValues() {
		var _that = this;
		return this.props.lists.measurement_fields && this.props.lists.measurement_fields.map((measurement) => {
			var _ref = "measurement-" + measurement.measurement_type_id;
			var upcharge = undefined;
			if (measurement.upcharge_limit > 0 && parseFloat(_that.measurements[measurement.measurement_type_id]) >= parseFloat(measurement.upcharge_limit)) {
				const _upc = _that.getMeasurementUpcharge(measurement);
				upcharge = {
					value: _upc.value,
					type: "Higher Size Upcharge",
					unit: _upc.type
				}
			}
			return {
				id: measurement.measurement_type_id,
				value: _that.measurements[measurement.measurement_type_id],
				upcharge: upcharge,
				code: measurement.code,
				descr: _that.measurementDescr[measurement.measurement_type_id],
				code:measurement.code,
				delta_flag:measurement.delta_flag?measurement.delta_flag:false,
                delta_flag_value:measurement.delta_flag_value ? measurement.delta_flag_value : false
			}
		});
	}
	getValidationMeasurement_type_id(validation_obj) {

		let measurementFields = this.props.lists.measurement_fields;
		let active_measurement_field = [];
		if (validation_obj.measurement_type_combination) {
			validation_obj.measurement_type_combination.map((item) => {
				if (_.find(measurementFields, { measurement_type_id: item })) {
					active_measurement_field.push(item);
				}
			});
		} else if (validation_obj.measurement_type_id) {
			if (_.find(measurementFields, { measurement_type_id: validation_obj.measurement_type_id })) {
				active_measurement_field.push(validation_obj.measurement_type_id);
			}
		}
		return active_measurement_field;
	}
	validateHeightWeight(validationMessages = []) {
		let measurement_fields = this.props.lists.measurement_fields;
		let height_obj = _.find(measurement_fields, { code: "HEIGHT" });
		let weight_obj = _.find(measurement_fields, { code: "WEIGHT" });
		let measurementValues = this.measurements;
		if (!height_obj || !weight_obj) {
			return validationMessages;
		}
		let height_value = measurementValues[height_obj.measurement_type_id];
		let weight_value = measurementValues[weight_obj.measurement_type_id];
		if (!height_value || !weight_value) {
			// if (!height_value) {
			// 	validationMessages[height_obj.measurement_type_id] = "Field is Mandatory";
			// }
			// if (!weight_value) {
			// 	validationMessages[weight_obj.measurement_type_id] = "Field is Mandatory";
			// }
			return validationMessages;
		}
		let heightValidations = _.filter(ValidationObj, function (o) {
			if (o.validation_type == 'WEIGHT_HEIGHT') {

				if (o.height == height_value && o.weight == weight_value) {
					return true;
				}
				if ((_.isObject(o.height) && (height_value >= o.height.min && height_value <= o.height.max)) && (_.isObject(o.weight) && (weight_value >= o.weight.min && weight_value <= o.weight.max))) {
					return true;
				}
			}
		});
		heightValidations && heightValidations.map((validation_cmp) => {
			validation_cmp.validations && validation_cmp.validations.map((validation_item) => {

				let availble_measurement_id_array = this.getValidationMeasurement_type_id(validation_item);
				if (availble_measurement_id_array.length >= 0) {
					availble_measurement_id_array.map((availble_measurement_id) => {
						let orignal_value = measurementValues[availble_measurement_id];
						if (!orignal_value) {
							validationMessages[availble_measurement_id] = "Value is Invalid";
						}
						if (_.isObject(validation_item.value)) {
							if (!(orignal_value >= validation_item.value.min && orignal_value <= validation_item.value.max)) {
								validationMessages[availble_measurement_id] = `Value should be In between ${validation_item.value.min} and ${validation_item.value.max}`;
							}
						} else if (orignal_value != validation_item.value) {
							validationMessages[availble_measurement_id] = `Value should be Equal to ${validation_item.value}`;
						}
					});
				}

			});
		});
		return validationMessages;
	}
	validateMinMax(validationMessages = []) {
		let measurement_fields = this.props.lists.measurement_fields;
		let measurementValues = this.measurements;
		let minMaxValidations = _.filter(ValidationObj, function (o) {
			if (o.validation_type == 'MIN_MAX') {
				return true;
			}
		});
		minMaxValidations && minMaxValidations.map((validation_cmp) => {
			validation_cmp.validations && validation_cmp.validations.map((validation_item) => {

				let availble_measurement_id_array = this.getValidationMeasurement_type_id(validation_item);
				if (availble_measurement_id_array.length >= 0) {
					availble_measurement_id_array.map((availble_measurement_id) => {
						let orignal_value = measurementValues[availble_measurement_id] || 0;
						if (_.isObject(validation_item.value)) {
							if (!(orignal_value >= validation_item.value.min && orignal_value <= validation_item.value.max)) {
								validationMessages[availble_measurement_id] = `Value should be In between ${validation_item.value.min} and ${validation_item.value.max}`;
							}
						} else if (orignal_value != validation_item.value) {
							validationMessages[availble_measurement_id] = `Value should be Equal to ${validation_item.value}`;
						}
					});
				}
			});
		});
		return validationMessages;
	}
	validateHeight(validationMessages = []) {
		let measurement_fields = this.props.lists.measurement_fields;
		let height_obj = _.find(measurement_fields, { code: "HEIGHT" });
		let measurementValues = this.measurements;
		if (!height_obj) {
			return validationMessages;
		}
		let height_value = measurementValues[height_obj.measurement_type_id];
		if (!height_value) {
			//validationMessages[height_obj.measurement_type_id] = "Field is Mandatory";
			return validationMessages;
		}
		let heightValidations = _.filter(ValidationObj, function (o) {
			if (o.validation_type == 'HEIGHT') {
				if (o.height == height_value) {
					return true;
				}
				if (_.isObject(o.height) && (height_value >= o.height.min && height_value <= o.height.max)) {
					return true;
				}
			}
		});
		heightValidations && heightValidations.map((validation_cmp) => {
			validation_cmp.validations && validation_cmp.validations.map((validation_item) => {

				let availble_measurement_id_array = this.getValidationMeasurement_type_id(validation_item);
				if (availble_measurement_id_array.length >= 0) {
					availble_measurement_id_array.map((availble_measurement_id) => {
						let orignal_value = measurementValues[availble_measurement_id];
						if (!orignal_value) {
							validationMessages[availble_measurement_id] = "Value is Invalid";
						}
						if (_.isObject(validation_item.value)) {
							if (!(orignal_value >= validation_item.value.min && orignal_value <= validation_item.value.max)) {
								validationMessages[availble_measurement_id] = `Value should be In between ${validation_item.value.min} and ${validation_item.value.max}`;
							}
						} else if (orignal_value != validation_item.value) {
							validationMessages[availble_measurement_id] = `Value should be Equal to ${validation_item.value}`;
						}
					});
				}
			});
		});
		return validationMessages;
	}
	getValidationErrorMessage(validationMessages) {
		let measurement_fields = this.props.lists.measurement_fields;
		let validationElement = [];
		for (const val in validationMessages) {
			let measurement_code = _.find(measurement_fields, { measurement_type_id: parseInt(val) });
			if (measurement_code) {
				validationElement.push(<div>{measurement_code.code} {validationMessages[val]} </div>);
			}
		}
		return validationElement;
	}
	validate() {

		let message = [], isValid = true;
		let validationMessages = [];
		if (this.props.item_type_id && !this.props.displayUpcharge && ( this.props.item_type_id == 1 || this.props.item_type_id == 2  || this.props.item_type_id == 3 ) ) {
			validationMessages = this.validateHeight(validationMessages);
			validationMessages = this.validateHeightWeight(validationMessages);
			validationMessages = this.validateMinMax(validationMessages);
		}
		let measurementValues = this.getMeasurementValues();
		mandatoryFields.map((mandatoryField) => {

			measurementValues.map((item) => {
				let { code } = item;
				code = code && code.toUpperCase();
				if (code === mandatoryField) {
					if (!item.value) {
						isValid = false;
						message.push(code);
					}
				}
			});
		});
		if ((ReactDOM.findDOMNode(this.refs.profile_name).value.trim().length == 0)) {
			isValid = false;
			message.push("Profile Name");
		}
		this.setState({
			validationArray: validationMessages
		});
		let valid_message = (isValid) ? "" : "Please provide values for " + message.toString();
		if (validationMessages.length != 0) {
			if (isValid) {
				// Prompt User to allow him force save
				let contentElement = (
					<div>
						{this.getValidationErrorMessage(validationMessages)}
						<br />
						<br />
						Do you want to still save the measurement values ?
					</div>
				);
				const self = this;
				Popup.create({
					title: 'Confirmation',
					content: contentElement,
					buttons: {
						left: [{
							text: 'CANCEL',
							action: function () {
								Popup.close();
							}
						}],
						right: [{
							text: 'OK',
							action: function () {
								Popup.close();
								self.postValidateSave();
							}
						}]
					}
				});

			}
			isValid = false;
			// valid_message = "One or More Field Values are Invalid";
		}
		return {
			message: valid_message,
			isValid
		}
	}
	postValidateSave() {
		const self = this;
		this.props.save({
			measurement_type: this.measurement_type,
			measurements: this.getMeasurementValues(),
			profile: {
				comment: ReactDOM.findDOMNode(self.refs.comment).value,
				name: ReactDOM.findDOMNode(self.refs.profile_name).value,
				item_type_id: 0,
				measurement_source_id: self.profile.measurement_source_id || self.profile.profile.measurement_source_id,
				profile_id: self.profile.profile_id || undefined,
				measurements: this.getMeasurementValues()
			}
		});
		this.props.close();
	}
	save() {
		const self = this;
		const validate = this.validate();
		if (validate.isValid) {
			this.postValidateSave();
		} else {
			window.scrollTo(0, 0);
			this.props.message('MEARSUREMENT_FORM_VALIDATION', validate.message);
		}
	}

	render() {
		let measurement_source = (
			<div className={cx('input-group')}>
				<label htmlFor="measurement_type">Measurement Type</label>
				<SelectForm type="measurement_type" rel="measurement_type" options={this.props.lists.measurement_types} value={this.profile.measurement_source_id} save={this.saveMeasurementType} disabled={this.props.is_source_disabled} />
			</div>
		);
		let image = <ImageCapture addImage={this.props.addImage} />;
		if (!this.props.addImage)
			image = null;
		let saveCancelButtons=(<span className={cx('buttons-flex-group')}><button className={cx('action', 'secondary')} onClick={this.props.close}>Cancel</button>
<button className={cx('action', 'primary')} onClick={this.save}>Save</button></span>);
		if(this.props.hideSaveCancelButton){
             saveCancelButtons="";
		}

		return (
			<div className={cx('form-container', 'measurement-form')} >
				{measurement_source}
				<div className={cx('input-group')}>
					<label htmlFor="profile_name">Measurement Profile Name</label>
					<input type="text" id="profile_name" ref="profile_name" defaultValue={this.profile.name} />
				</div>
				{image}
				{this.getMeasurementFormFields()}
				<div className={cx('input-group')}>
					<label htmlFor="comment">Comment</label>
					<textarea id="comment" ref="comment" defaultValue={this.profile.comment}></textarea>
				</div>
				 {saveCancelButtons}
			</div>
		);
	}
}

MeasurementsForm.propTypes = {
	lists: PropTypes.object,
	save: PropTypes.func,
	loadFields: PropTypes.func,
	close: PropTypes.func,
	profile: PropTypes.object,
	addImage: PropTypes.func,
	message: PropTypes.func,
	is_source_disabled: PropTypes.bool
};