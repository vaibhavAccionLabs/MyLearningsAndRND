/**
 *
 * Renders an image, enforcing the usage of the alt="" tag
 *
 */

import React, { Component, PropTypes } from 'react';
import trash_icon from 'images/trash.png';
import CustomImage from 'components/CustomImage';
import  _  from 'lodash';
import DragSortableList from 'react-drag-sortable';
import ImageUploader from './ImageUploader';

class UpdateImage extends Component { // eslint-disable-line react/prefer-stateless-function
    constructor(props) {
        super(props);
        this.state = {
			loadingError: null
        };
        this.deleteHandler = this.deleteHandler.bind(this);
        this.handleImageLoadError = this.handleImageLoadError.bind(this);
    }

    handleImageLoadError(src) {
		this.setState({
			loadingError: src
		});
	}
  
    deleteHandler(data){
        let { deleteImage, key } =  this.props;
        let confirmData = confirm("Are You Sure Want to Delete Image");
        if(confirmData){
            deleteImage(data, key);
        }else{
            return false;
        }
    }

    onSort(sortedList) {
      //  debugger;
        let {onDrag} = this.props;
        let NewArrayList = [];
            //console.log("sortedList", sortedList);
          if(_.isArray(sortedList) && sortedList.length > 0){
                sortedList.map((item) => {
                    NewArrayList.push(item.content.props.children[0].props.src);
                });
            }
          //console.log("New Array list",NewArrayList);
          onDrag(NewArrayList);
        }

    checkInDeleteArray(imagePath){
        let {noImage, productsDeleted} = this.props;
        let comp_imagepath = '';
        let copyImgPath = imagePath;
        if(productsDeleted && productsDeleted.length > 0){
            for(let i = 0; i< 4; i++){
                comp_imagepath = copyImgPath.substring(copyImgPath.indexOf('/')+1);
                copyImgPath = comp_imagepath;
           } 
           noImage = (_.includes(productsDeleted, comp_imagepath)) ? true : false;
        }
        return noImage;
    }

    render() {
        debugger;
        let List = [];
        let defaultImage = [];
        let noimage = (<div className={'no-image-data'}>No Image</div>);
        let {showProduct, imgPath, noImage, style, productsDeleted, title, onChange,reset, singleUpload} = this.props;
      // console.log("IMAGE PATH", imgPath);
        let imageBoxStyle = {
            // 'display':'inline-block',
            // 'float':'left',
            // 'marginRight': '30px',
            // 'marginBottom':'10px',
            // ...style
        };
       {(_.isArray(imgPath) ?
             imgPath.map((image,idx)=>{
                noImage = this.checkInDeleteArray(image);
              List.push({content: (<div key={idx} className="imageBox" style={imageBoxStyle}>
                {(!noImage)?<CustomImage className={"display-image"}  width='210px' height='210px' src={image} alt="image name" /> : noimage}
                {(!noImage)?<img className={"deleteImg"} src={trash_icon} onClick={this.deleteHandler.bind(this,image)}/>: ''}
                </div>),  key:(idx)})
             })
             : 
             defaultImage.push(<div key={0} className="imageBox" style={imageBoxStyle}>
             {noImage = this.checkInDeleteArray(imgPath)}
             {(!noImage)?<CustomImage className={"display-image"}  width='210px' height='210px' src={imgPath} alt="image name" /> : noimage}
             </div> ))}
        return ( 
            <div className= {(singleUpload)? 'All-image-container singleUpload' : 'All-image-container'}>
            {(List && List.length > 0) ? 
           <DragSortableList items={List} 
           dropBackTransitionDuration={0.3} 
           onSort={this.onSort.bind(this)} 
           type="grid"/>: defaultImage}
           
            <ImageUploader
            onChange={onChange}
            title={title}
            reset={reset}
            />

            </div>
        );
    }
}
export default UpdateImage;