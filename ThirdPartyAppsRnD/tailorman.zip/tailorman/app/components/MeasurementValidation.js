export const ValidationObj = [{
    "validation_type": "MIN_MAX",
    "validations": [{
        "code": "THIGH",
        "measurement_type_combination": [414],
        "measurement_type_id": 414,
        "value": {
            "min": -0.75,
            "max": 0.5
        }
    }, {
        "code": "SIDE SHAPE -ONLY BACK",
        "measurement_type_combination": [410, 419],
        "measurement_type_id": 410,
        "value": {
            "min": -0.75,
            "max": 0.75
        }
    }, {
        "code": "SIDE SHAPE -FRONT AND BACK",
        "measurement_type_combination": [409],
        "measurement_type_id": 409,
        "value": {
            "min": -0.75,
            "max": 0.75
        }
    }, {
        "code": "SEAT",
        "measurement_type_combination": [408],
        "measurement_type_id": 408,
        "value": {
            "min": -1,
            "max": 1
        }
    }, {
        "code": "SIDE BALANCE",
        "measurement_type_combination": [407],
        "measurement_type_id": 407,
        "value": {
            "min": -0.5,
            "max": 0
        }
    }, {
        "code": "FRONT & BACK RISE (High Low Waist)",
        "measurement_type_combination": [406],
        "measurement_type_id": 406,
        "value": {
            "min": -1,
            "max": 1
        }
    }, {
        "code": "BACK DROP (CUT BACK)",
        "measurement_type_combination": [404],
        "measurement_type_id": 404,
        "value": {
            "min": -0.625,
            "max": 0
        }
    }, {
        "code": "FRONT DROP (CUT FRONT)",
        "measurement_type_combination": [402],
        "measurement_type_id": 402,
        "value": {
            "min": -1.5,
            "max": 0
        }
    }, {
        "code": "FLAT HIP",
        "measurement_type_combination": [397],
        "measurement_type_id": 397,
        "value": {
            "min": -75,
            "max": 0
        }
    }, {
        "code": "DOUBLE CHIN",
        "measurement_type_combination": [190],
        "measurement_type_id": 190,
        "value": {
            "min": 0,
            "max": 0.5
        }
    }, {
        "code": "SQUARE SHOULDER",
        "measurement_type_combination": [191],
        "measurement_type_id": 191,
        "value": {
            "min": -0.5,
            "max": 0
        }
    }, {
        "code": "SLOPING SHOULDER (L + R)",
        "measurement_type_combination": [192],
        "measurement_type_id": 192,
        "value": {
            "min": -0.625,
            "max": 0
        }
    }, {
        "code": "BACK SLOPING (L+ R)",
        "measurement_type_combination": [193],
        "measurement_type_id": 193,
        "value": {
            "min": -0.75,
            "max": 0
        }
    }, {
        "code": "SQUARE BACK NECK",
        "measurement_type_combination": [194],
        "measurement_type_id": 194,
        "value": {
            "min": -0.5,
            "max": 0
        }
    }, {
        "code": "ERECT BACK",
        "measurement_type_combination": [195],
        "measurement_type_id": 195,
        "value": {
            "min": -1,
            "max": 0
        }
    }, {
        "code": "SLEEVE CAP HEIGHT",
        "measurement_type_combination": [196],
        "measurement_type_id": 196,
        "value": {
            "min": -0.875,
            "max": 0
        }
    }, {
        "code": "ACROSS FRONT AT 1ST BUTTON",
        "measurement_type_combination": [180],
        "measurement_type_id": 180,
        "value": {
            "min": -1,
            "max": 1
        }
    }, {
        "code": "ACROSS BACK",
        "measurement_type_combination": [181],
        "measurement_type_id": 181,
        "value": {
            "min": -1,
            "max": 1
        }
    }, {
        "code": "FRONT CHEST",
        "measurement_type_combination": [182],
        "measurement_type_id": 182,
        "value": {
            "min": -1.5,
            "max": 1.5
        }
    }, {
        "code": "FRONT WAIST",
        "measurement_type_combination": [183],
        "measurement_type_id": 183,
        "value": {
            "min": -1.5,
            "max": 1.5
        }
    }, {
        "code": "FRONT HIP",
        "measurement_type_combination": [184],
        "measurement_type_id": 184,
        "value": {
            "min": -1.5,
            "max": 1.5
        }
    }, {
        "code": "BACK CHEST",
        "measurement_type_combination": [185],
        "measurement_type_id": 185,
        "value": {
            "min": -1.5,
            "max": 1.5
        }
    }, {
        "code": "BACK WAIST",
        "measurement_type_combination": [186],
        "measurement_type_id": 186,
        "value": {
            "min": -1.5,
            "max": 1.5
        }
    }, {
        "code": "BACK HIP",
        "measurement_type_combination": [187],
        "measurement_type_id": 187,
        "value": {
            "min": -1.5,
            "max": 1.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_combination": [188],
        "measurement_type_id": 188,
        "value": {
            "min": -0.75,
            "max": 0.75
        }
    }, {
        "code": "ELBOW TILL CUFF",
        "measurement_type_combination": [189],
        "measurement_type_id": 189,
        "value": {
            "min": -0.75,
            "max": 0.75
        }
    }, {//1min
        "code": "LAPEL LIFTING",
        "measurement_type_combination": [255],
        "measurement_type_id": 255,
        "value": {
            "min": -1,
            "max": -0.25
        }
    }, {//2min
        "code": "LAPEL POP",
        "measurement_type_combination": [256],
        "measurement_type_id": 256,
        "value": {
            "min": -1,
            "max": -0.25
        }
    }, {//3min
        "code": "SQUARE BACK NECK",
        "measurement_type_combination": [260],
        "measurement_type_id": 260,
        "value": {
            "min": -0.625,
            "max": -0.25
        }
    }, {//4min
        "code": "ERECT BACK ONLY",
        "measurement_type_combination": [262],
        "measurement_type_id": 262,
        "value": {
            "min": -0.5,
            "max": -0.25
        }
    }, {//5min
        "code": "SQUARE SHOULDER",
        "measurement_type_combination": [267],
        "measurement_type_id": 267,
        "value": {
            "min": -1,
            "max": -0.25
        }
    }, {//6min
        "code": "PITCH SLEEVE LEFT FORWARD",
        "measurement_type_combination": [274],
        "measurement_type_id": 274,
        "value": {
            "min": -0.75,
            "max": -0.25
        }
    }, {//7min
        "code": "PITCH SLEEVE LEFT BACKWARD",
        "measurement_type_combination": [275],
        "measurement_type_id": 275,
        "value": {
            "min": -0.75,
            "max": -0.25
        }
    }, {//8min
        "code": "PITCH SLEEVE RIGHT FORWARD",
        "measurement_type_combination": [276],
        "measurement_type_id": 276,
        "value": {
            "min": -0.75,
            "max": -0.25
        }
    }, {//9min
        "code": "PITCH SLEEVE RIGHT BACKWARD",
        "measurement_type_combination": [277],
        "measurement_type_id": 277,
        "value": {
            "min": -0.75,
            "max": -0.25
        }
    }, {//10min
        "code": "REDUCE SLEEVE WIDTH",
        "measurement_type_combination": [278],
        "measurement_type_id": 278,
        "value": {
            "min": -0.75,
            "max": -0.25
        }
    }, {//11min
        "code": "SHAPE FRONT",
        "measurement_type_combination": [280],
        "measurement_type_id": 280,
        "value": {
            "min": -1,
            "max": 0
        }
    }, {//12min
        "code": "BACK WAIST",
        "measurement_type_combination": [281],
        "measurement_type_id": 281,
        "value": {
            "min": -2,
            "max": 2
        }
    }, {//13min
        "code": "BACK SEAT",
        "measurement_type_combination": [282],
        "measurement_type_id": 282,
        "value": {
            "min": -2,
            "max": 2
        }
    }, {//14min
        "code": "LOWER BACK",
        "measurement_type_combination": [283],
        "measurement_type_id": 283,
        "value": {
            "min": -0.25,
            "max": 0.25
        }
    }, {//15min
        "code": "SH POINT TO SH POINT",
        "measurement_type_combination": [284,16],
        "measurement_type_id": 284,
        "value": {
            "min": -1,
            "max": 0
        }
    }, {//16min
        "code": "CUT FRONT AT CHEST",
        "measurement_type_combination": [285],
        "measurement_type_id": 285,
        "value": {
            "min": -0.75,
            "max": 0
        }
    }, {//17min
        "code": "FRONT EDGE",
        "measurement_type_combination": [286],
        "measurement_type_id": 286,
        "value": {
            "min": 0,
            "max": 1
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 5,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_combination": [432, 654, 172],
        "measurement_type_id": 432,
        "value": {
            "min": 24.5,
            "max": 27.5
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "measurement_type_combination": [434, 660, 174, 1133],
        "value": {
            "min": 22.0,
            "max": 25.0
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "measurement_type_combination": [433, 659, 173, 1132],
        "value": {
            "min": 22.0,
            "max": 25.0
        }
    }, { // 1st row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 8.5,
            "max": 9.5
        }
    }, {
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287, 12],
        "value": {
            "min": 25.5,
            "max": 28.5
        }
    }, {
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 21,
            "max": 24
        }
    }, {
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 21,
            "max": 24
        }
    }, {
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 22,
            "max": 25
        }
    }, {
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 22,
            "max": 25
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 5.1,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 25.0,
            "max": 28.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 25.0,
            "max": 28.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 25.0,
            "max": 28.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 22.0,
            "max": 25.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 22.0,
            "max": 25.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 22.0,
            "max": 25.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 22.0,
            "max": 25.0
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 22.0,
            "max": 25.0
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 22.0,
            "max": 25.0
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 22.0,
            "max": 25.0
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 22.0,
            "max": 25.0
        }
    }, { // 2st row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 34.5,
            "max": 37.5
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 8.5,
            "max": 9.5
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 5.2,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 25.5,
            "max": 28.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 25.5,
            "max": 28.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 25.5,
            "max": 28.5
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, { // 3st row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 35,
            "max": 38
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 8.5,
            "max": 9.5
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 26.5,
            "max": 29.5
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 21.25,
            "max": 24.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 21.25,
            "max": 24.25
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 22.25,
            "max": 25.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 22.25,
            "max": 25.25
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 5.3,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 26.0,
            "max": 29.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 26.0,
            "max": 29.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 26.0,
            "max": 29.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 22.3,
            "max": 25.3
        }
    }, { // 4st row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 35.5,
            "max": 38.5
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 8.5,
            "max": 9.5
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 27,
            "max": 30
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 21.25,
            "max": 24.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 21.25,
            "max": 24.25
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 22.25,
            "max": 25.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 22.25,
            "max": 25.25
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 5.4,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 26.0,
            "max": 29.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 26.0,
            "max": 29.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 26.0,
            "max": 29.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 22.5,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 22.5,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 22.5,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 22.5,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 22.5,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 22.5,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 22.5,
            "max": 25.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 22.5,
            "max": 25.3
        }
    }, { // 5st row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 36.5,
            "max": 39.5
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 9.0,
            "max": 10.0
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 27,
            "max": 30
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 21.5,
            "max": 24.5
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 21.5,
            "max": 24.5
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 22.5,
            "max": 25.5
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 22.5,
            "max": 25.5
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 5.5,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 26.5,
            "max": 29.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 26.5,
            "max": 29.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 26.5,
            "max": 29.5
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, { // 6st row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 37,
            "max": 40
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 9.0,
            "max": 10.0
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 27.5,
            "max": 30.5
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 21.75,
            "max": 24.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 21.75,
            "max": 24.75
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 22.75,
            "max": 25.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 22.75,
            "max": 25.75
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 5.6,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 26.5,
            "max": 29.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 26.5,
            "max": 29.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 26.5,
            "max": 29.5
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 22.8,
            "max": 25.8
        }
    }, { // 7st row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 37.5,
            "max": 40.5
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 9.0,
            "max": 10.0
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
             "min": 27.5,
            "max": 30.5
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 21.75,
            "max": 24.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 21.75,
            "max": 24.75
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 22.75,
            "max": 25.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 22.75,
            "max": 25.75
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 5.7,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 27.0,
            "max": 30.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 27.0,
            "max": 30.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 27.0,
            "max": 30.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, { // 8st row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 38,
            "max": 41
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 9.0,
            "max": 10.0
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 28,
            "max": 31
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 22.25,
            "max": 25.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 22.25,
            "max": 25.25
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 23.25,
            "max": 26.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 23.25,
            "max": 26.25
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 5.8,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 27.0,
            "max": 30.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 27.0,
            "max": 30.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 27.0,
            "max": 30.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 23.3,
            "max": 26.3
        }
    }, { // 9st row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 9.5,
            "max": 10.5
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 28,
            "max": 31
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 22.25,
            "max": 25.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 22.25,
            "max": 25.25
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 23.25,
            "max": 26.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 23.25,
            "max": 26.25
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 5.9,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 28.0,
            "max": 31.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 28.0,
            "max": 31.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 28.0,
            "max": 31.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 23.8,
            "max": 26.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 23.8,
            "max": 26.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 23.8,
            "max": 26.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 23.8,
            "max": 26.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 23.8,
            "max": 26.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 23.8,
            "max": 26.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 23.8,
            "max": 26.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 23.8,
            "max": 26.8
        }
    }, { // 10st row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 39.5,
            "max": 42.5
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 9.5,
            "max": 10.5
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 29,
            "max": 32
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 22.75,
            "max": 25.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 22.75,
            "max": 25.75
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 23.75,
            "max": 26.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 23.75,
            "max": 26.75
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 5.10,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 28.0,
            "max": 31.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 28.0,
            "max": 31.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 28.0,
            "max": 31.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 24.0,
            "max": 27.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 24.0,
            "max": 27.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 24.0,
            "max": 27.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 24.0,
            "max": 27.0
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 24.0,
            "max": 27.0
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 24.0,
            "max": 27.0
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 24.0,
            "max": 27.0
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 24.0,
            "max": 27.0
        }
    }, { // 11st row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 40,
            "max": 43
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 9.5,
            "max": 10.5
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 29,
            "max": 32
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 23,
            "max": 26
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 23,
            "max": 26
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 24,
            "max": 27
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 24,
            "max": 27
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 5.11,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 28.5,
            "max": 31.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 28.5,
            "max": 31.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 28.5,
            "max": 31.5
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 24.3,
            "max": 27.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 24.3,
            "max": 27.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 24.3,
            "max": 27.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 24.3,
            "max": 27.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 24.3,
            "max": 27.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 24.3,
            "max": 27.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 24.3,
            "max": 27.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 24.3,
            "max": 27.3
        }
    }, { // 12st row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 40.5,
            "max": 43.5
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 9.5,
            "max": 10.5
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 29.5,
            "max": 32.5
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 23.25,
            "max": 26.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 23.25,
            "max": 26.25
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 24.25,
            "max": 27.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 24.25,
            "max": 27.25
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 6.0,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 29.0,
            "max": 32.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 29.0,
            "max": 32.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 29.0,
            "max": 32.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 24.8,
            "max": 27.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 24.8,
            "max": 27.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 24.8,
            "max": 27.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 24.8,
            "max": 27.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 24.8,
            "max": 27.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 24.8,
            "max": 27.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 24.8,
            "max": 27.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 24.8,
            "max": 27.8
        }
    }, { // 13 row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 41.5,
            "max": 44.5
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 10.0,
            "max": 11.0
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 30,
            "max": 33
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 23.75,
            "max": 26.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 23.75,
            "max": 26.75
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 24.75,
            "max": 27.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 24.75,
            "max": 27.75
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 6.1,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 29.5,
            "max": 32.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 29.5,
            "max": 32.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 29.5,
            "max": 32.5
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, { // 14 row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 42,
            "max": 45
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 10.0,
            "max": 11.0
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 30.5,
            "max": 33.5
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 24.25,
            "max": 27.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 24.25,
            "max": 27.25
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 25.25,
            "max": 28.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 25.25,
            "max": 28.25
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 6.2,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 29.5,
            "max": 32.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 29.5,
            "max": 32.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 29.5,
            "max": 32.5
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 25.3,
            "max": 28.3
        }
    }, { // 15 row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 42.5,
            "max": 45.5
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 10.0,
            "max": 11.0
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 30.5,
            "max": 33.5
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 24.25,
            "max": 27.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 24.25,
            "max": 27.25
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 25.25,
            "max": 28.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 25.25,
            "max": 28.25
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 6.3,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 30.5,
            "max": 33.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 30.5,
            "max": 33.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 30.5,
            "max": 33.5
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 25.8,
            "max": 28.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 25.8,
            "max": 28.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 25.8,
            "max": 28.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 25.8,
            "max": 28.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 25.8,
            "max": 28.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 25.8,
            "max": 28.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 25.8,
            "max": 28.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 25.8,
            "max": 28.8
        }
    }, { // 16 row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 10.0,
            "max": 11.0
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 31.5,
            "max": 34.5
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 24.75,
            "max": 27.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 24.75,
            "max": 27.75
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 25.75,
            "max": 28.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 25.75,
            "max": 28.75
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 6.4,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 31.0,
            "max": 34.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 31.0,
            "max": 34.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 31.0,
            "max": 34.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, { // 17 row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 44,
            "max": 47
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 10.5,
            "max": 11.5
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 32,
            "max": 35
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 25.25,
            "max": 28.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 25.25,
            "max": 28.25
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 26.25,
            "max": 29.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 26.25,
            "max": 29.25
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 6.5,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 31.5,
            "max": 34.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 31.5,
            "max": 34.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 31.5,
            "max": 34.5
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 26.3,
            "max": 29.3
        }
    }, { // 18 row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 44.5,
            "max": 47.5
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 10.5,
            "max": 11.5
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 32.5,
            "max": 35.5
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 25.25,
            "max": 28.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 25.25,
            "max": 28.25
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 26.25,
            "max": 29.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 26.25,
            "max": 29.25
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 6.6,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 32.0,
            "max": 35.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 32.0,
            "max": 35.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 32.0,
            "max": 35.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 26.8,
            "max": 29.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 26.8,
            "max": 29.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 26.8,
            "max": 29.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 26.8,
            "max": 29.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 26.8,
            "max": 29.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 26.8,
            "max": 29.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 26.8,
            "max": 29.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 26.8,
            "max": 29.8
        }
    }, { // 19 row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 10.5,
            "max": 11.5
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 33,
            "max": 36
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 25.75,
            "max": 28.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 25.75,
            "max": 28.75
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 26.75,
            "max": 29.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 26.75,
            "max": 29.75
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 6.7,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 32.5,
            "max": 35.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 32.5,
            "max": 35.5
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 32.5,
            "max": 35.5
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 27.3,
            "max": 30.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 27.3,
            "max": 30.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 27.3,
            "max": 30.3
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 27.3,
            "max": 30.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 27.3,
            "max": 30.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 27.3,
            "max": 30.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 27.3,
            "max": 30.3
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 27.3,
            "max": 30.3
        }
    }, { // 20 row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 45.5,
            "max": 48.5
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 10.5,
            "max": 11.5
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 33.5,
            "max": 36.5
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 26.25,
            "max": 29.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 26.25,
            "max": 29.25
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 27.25,
            "max": 29.25
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 27.25,
            "max": 29.25
        }
    }]
},
{
    "validation_type": "HEIGHT",
    "height": 6.8,
    "validations": [{
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 432,
        "value": {
            "min": 33.0,
            "max": 36.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 654,
        "value": {
            "min": 33.0,
            "max": 36.0
        }
    }, {
        "code": "NORMAL FRONT LENGTH",
        "measurement_type_id": 172,
        "value": {
            "min": 33.0,
            "max": 36.0
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 434,
        "value": {
            "min": 27.8,
            "max": 30.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 660,
        "value": {
            "min": 27.8,
            "max": 30.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 174,
        "value": {
            "min": 27.8,
            "max": 30.8
        }
    }, {
        "code": "CROWN TO CUFF LEFT",
        "measurement_type_id": 1133,
        "value": {
            "min": 27.8,
            "max": 30.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 433,
        "value": {
            "min": 27.8,
            "max": 30.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 659,
        "value": {
            "min": 27.8,
            "max": 30.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 173,
        "value": {
            "min": 27.8,
            "max": 30.8
        }
    }, {
        "code": "CROWN TO CUFF RIGHT",
        "measurement_type_id": 1132,
        "value": {
            "min": 27.8,
            "max": 30.8
        }
    }, { // 21 row
        "code": "OUTSIDE LEG",
        "measurement_type_combination": [630, 416, 647],
        "measurement_type_id": 630,
        "value": {
            "min": 46.5,
            "max": 49.5
        }
    }, {
        "code": "FRONT RISE",
        "measurement_type_combination": [642, 715],
        "measurement_type_id": 642,
        "value": {
            "min": 11.0,
            "max": 12.0
        }
    },{
        "code": "JACKET LENGTH",
        "measurement_type_id": 287,
        "measurement_type_combination": [287,12],
        "value": {
            "min": 34,
            "max": 37
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 288,
        "measurement_type_combination": [288],
        "value": {
            "min": 26.75,
            "max": 29.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 289,
        "measurement_type_combination": [289],
        "value": {
            "min": 26.75,
            "max": 29.75
        }
    },{
        "code": "SLEEVE LENGTH LEFT",
        "measurement_type_id": 18,
        "measurement_type_combination": [18],
        "value": {
            "min": 27.75,
            "max": 30.75
        }
    },{
        "code": "SLEEVE LENGTH RIGHT",
        "measurement_type_id": 17,
        "measurement_type_combination": [17],
        "value": {
            "min": 27.75,
            "max": 30.75
        }
    }]
}, { // 1 row 
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 50.01,
        "max": 55.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 28,
            "max": 31
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 31.5,
            "max": 34.5
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 14.0625,
            "max": 16.0625
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 11.25,
            "max": 12
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6,
            "max": 7
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 13.375,
            "max": 15.125
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 26,
            "max": 29
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 19,
            "max": 20.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.5
        }
    }]
}, { // 2 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 55.01,
        "max": 60.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 13.875,
            "max": 15.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 14.8125,
            "max": 16.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130, 124],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 33.5,
            "max": 36.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 11.75,
            "max": 12.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6,
            "max": 7
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 28,
            "max": 31
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 20,
            "max": 21.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.5
        }
    }]
},// { // 3rd row  duplicated
//     "validation_type": "WEIGHT_HEIGHT",
//     "height": {
//         "min": 5.1,
//         "max": 5.3
//     },
//     "weight": {
//         "min": 50.01,
//         "max": 55.00
//     },
//     "validations": [{
//         "code": "CHEST",
//         "measurement_type_id": 419,
//         "measurement_type_combination": [419, 159, 1129,655],
//         "value": {
//             "min": 32,
//             "max": 35
//         }
//     }, {
//         "code": "NECK",
//         "measurement_type_id": 422,
//         "measurement_type_combination": [422, 162, 664, 1136,248,20],
//         "value": {
//             "min": 13.375,
//             "max": 15.125
//         }
//     }, {
//         "code": "SHOULDER",
//         "measurement_type_id": 423,
//         "measurement_type_combination": [423, 431, 658, 171, 1131,163],
//         "value": {
//             "min": 14.0625,
//             "max": 16.0625
//         }
//     }, {
//         "code": "WAIST (STOMACH)",
//         "measurement_type_id": 420,
//         "measurement_type_combination": [420, 656, 160, 1130,14,246],
//         "value": {
//             "min": 28,
//             "max": 31
//         }
//     }, {
//         "code": "SEAT",
//         "measurement_type_id": 421,
//         "measurement_type_combination": [421, 657, 161, 1138],
//         "value": {
//             "min": 31.5,
//             "max": 34.5
//         }
//     }, {
//         "code": "BICEP",
//         "measurement_type_id": 424,
//         "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
//         "value": {
//             "min": 11.25,
//             "max": 12
//         }
//     }, {
//         "code": "WRIST",
//         "measurement_type_id": 663,
//         "measurement_type_combination": [663, 720, 721, 1137,678],
//         "value": {
//             "min": 6,
//             "max": 7
//         }
//     }]

// }, { // 4 row
//     "validation_type": "WEIGHT_HEIGHT",
//     "height": {
//         "min": 5.1,
//         "max": 5.3
//     },
//     "weight": {
//         "min": 55.01,
//         "max": 60.00
//     },
//     "validations": [{
//         "code": "CHEST",
//         "measurement_type_id": 419,
//         "measurement_type_combination": [419, 159, 1129,655],
//         "value": {
//             "min": 34,
//             "max": 37
//         }
//     }, {
//         "code": "NECK",
//         "measurement_type_id": 422,
//         "measurement_type_combination": [422, 162, 664, 1136,248,20],
//         "value": {
//             "min": 13.875,
//             "max": 15.625
//         }
//     }, {
//         "code": "SHOULDER",
//         "measurement_type_id": 423,
//         "measurement_type_combination": [423, 431, 658, 171, 1131,163],
//         "value": {
//             "min": 14.8125,
//             "max": 16.8125
//         }
//     }, {
//         "code": "WAIST (STOMACH)",
//         "measurement_type_id": 420,
//         "measurement_type_combination": [420, 656, 160, 1130,14,246],
//         "value": {
//             "min": 30,
//             "max": 33
//         }
//     }, {
//         "code": "SEAT",
//         "measurement_type_id": 421,
//         "measurement_type_combination": [421, 657, 161, 1138],
//         "value": {
//             "min": 33.5,
//             "max": 36.5
//         }
//     }, {
//         "code": "BICEP",
//         "measurement_type_id": 424,
//         "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
//         "value": {
//             "min": 11.75,
//             "max": 12.5
//         }
//     }, {
//         "code": "WRIST",
//         "measurement_type_id": 663,
//         "measurement_type_combination": [663, 720, 721, 1137,678],
//         "value": {
//             "min": 6,
//             "max": 7
//         }
//     }]

// }, 
{ // 5 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 60.01,
        "max": 65.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 14.375,
            "max": 16.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 15.5625,
            "max": 17.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 35.5,
            "max": 38.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 12.25,
            "max": 13
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.25,
            "max": 7.25
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 21,
            "max": 22.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.625
        }
    }]

}, { // 6 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 65.01,
        "max": 70.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 38,
            "max": 41
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 14.875,
            "max": 16.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.3125,
            "max": 18.3125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 37.5,
            "max": 40.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 12.75,
            "max": 13.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.5,
            "max": 7.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 22,
            "max": 23.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.875
        }
    }]

}, { // 7 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 70.01,
        "max": 75.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 38,
            "max": 41
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 14.875,
            "max": 16.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.3125,
            "max": 18.3125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 37.5,
            "max": 40.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 12.75,
            "max": 13.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.5,
            "max": 7.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 22,
            "max": 23.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.875
        }
    }]

}, { // 8 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 75.01,
        "max": 80.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 40,
            "max": 43
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.375,
            "max": 17.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.0625,
            "max": 19.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 39.5,
            "max": 42.25
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13.25,
            "max": 14
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7,
            "max": 8
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 23,
            "max": 24.375
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.75,
            "max": 16.25
        }
    }]

}, { // 9 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 80.01,
        "max": 85.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 40,
            "max": 43
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.375,
            "max": 17.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.0625,
            "max": 19.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 39.5,
            "max": 42.25
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13.25,
            "max": 14
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7,
            "max": 8
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 23,
            "max": 24.375
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.25,
            "max": 17
        }
    }]

}, { // 10 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 85.01,
        "max": 90.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.125,
            "max": 17.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.5625,
            "max": 19.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 42.25,
            "max": 44.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14,
            "max": 14.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7,
            "max": 8
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 24.375,
            "max": 25.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.75,
            "max": 17
        }
    }]

}, { // 11 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 90.01,
        "max": 95.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.625,
            "max": 18.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.0625,
            "max": 20.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 43.75,
            "max": 46
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14.5,
            "max": 15.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.125,
            "max": 26.25
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.75,
            "max": 17.5
        }
    }]

}, { // 12 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 95.01,
        "max": 100.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.625,
            "max": 18.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.0625,
            "max": 20.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 43.75,
            "max": 46
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14.5,
            "max": 15.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.125,
            "max": 26.25
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.75,
            "max": 17.5
        }
    }]

}, { // 13 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 100.01,
        "max": 105.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.125,
            "max": 18.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.5625,
            "max": 20.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 45.25,
            "max": 47.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15,
            "max": 15.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.875,
            "max": 27
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.25,
            "max": 18
        }
    }]

}, { // 14 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 105.01,
        "max": 110.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.125,
            "max": 18.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.5625,
            "max": 20.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 45.25,
            "max": 47.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15,
            "max": 15.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.875,
            "max": 27
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.25,
            "max": 18
        }
    }]

}, { // 15 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 110.01,
        "max": 115.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 49,
            "max": 52
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.625,
            "max": 19.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 19.0625,
            "max": 21.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 46.75,
            "max": 49
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15.5,
            "max": 16.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 26.625,
            "max": 27.75
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.75,
            "max": 18.5
        }
    }]

}, { // 16 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 115.01,
        "max": 120.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 49,
            "max": 52
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.625,
            "max": 19.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 19.875,
            "max": 21.875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 46.75,
            "max": 49
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15.5,
            "max": 16.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 26.625,
            "max": 27.75
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.75,
            "max": 18.5
        }
    }]

}, { // 17 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 120.01,
        "max": 125.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 51,
            "max": 54
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 18.125,
            "max": 19.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 20.375,
            "max": 22.375
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 48.25,
            "max": 50.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 16,
            "max": 16.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 27.375,
            "max": 28.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 18.25,
            "max": 19
        }
    }]

}, { // 18 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.1,
        "max": 5.3
    },
    "weight": {
        "min": 125.01,
        "max": 130.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 51,
            "max": 54
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 18.125,
            "max": 19.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 20.375,
            "max": 22.375
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 48.25,
            "max": 50.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 16,
            "max": 16.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 27.375,
            "max": 28.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 18.25,
            "max": 19
        }
    }]

}, { // 19 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 50.01,
        "max": 55.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 13.375,
            "max": 15.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 14.0625,
            "max": 16.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 28,
            "max": 31
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 31.5,
            "max": 34.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 11.25,
            "max": 12
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.25,
            "max": 7.25
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 26,
            "max": 29
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 19,
            "max": 20.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.5
        }
    }]

}, { // 20 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 55.01,
        "max": 60.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 13.875,
            "max": 15.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 14.8125,
            "max": 16.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 33.5,
            "max": 36.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 11.75,
            "max": 12.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.25,
            "max": 7.25
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 28,
            "max": 31
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 20,
            "max": 21.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.5
        }
    }]

}, { // 21 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 60.01,
        "max": 65.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 14.375,
            "max": 16.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 15.5625,
            "max": 17.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 35.5,
            "max": 38.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 12.25,
            "max": 13
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.5,
            "max": 7.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 21,
            "max": 22.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.625
        }
    }]

}, { // 22 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 65.01,
        "max": 70.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 37.5,
            "max": 40.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 14.875,
            "max": 16.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.3125,
            "max": 18.3125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 37.5,
            "max": 40.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 12.75,
            "max": 13.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.75,
            "max": 7.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 22,
            "max": 23.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.875
        }
    }]

}, { // 23 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 70.01,
        "max": 75.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 38,
            "max": 41
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 14.875,
            "max": 16.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.3125,
            "max": 18.3125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 37.5,
            "max": 40.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 12.75,
            "max": 13.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.75,
            "max": 7.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 22,
            "max": 23.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.875
        }
    }]

}, { // 24 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 75.01,
        "max": 80.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 39.5,
            "max": 42.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.375,
            "max": 17.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.0625,
            "max": 19.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 39.5,
            "max": 42.25
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13.25,
            "max": 14
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.25,
            "max": 8.25
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 23,
            "max": 24.375
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.75,
            "max": 16.25
        }
    }]

}, { // 25 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 80.01,
        "max": 85.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 40,
            "max": 43
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.375,
            "max": 17.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.0625,
            "max": 19.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 39.5,
            "max": 42.25
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13.25,
            "max": 14
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.25,
            "max": 8.25
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 23,
            "max": 24.375
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.75,
            "max": 16.25
        }
    }]

}, { // 26 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 85.01,
        "max": 90.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 42.5,
            "max": 45.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.125,
            "max": 17.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.5625,
            "max": 19.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 42.25,
            "max": 44.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14,
            "max": 14.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.25,
            "max": 8.25
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 37,
            "max": 40
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 24.375,
            "max": 25.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.25,
            "max": 17
        }
    }]

}, { // 27 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 90.01,
        "max": 95.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 43.5,
            "max": 46.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.625,
            "max": 18.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.0625,
            "max": 20.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 43.75,
            "max": 46
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14.5,
            "max": 15.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.75,
            "max": 8.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.125,
            "max": 26.25
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.25,
            "max": 17.5
        }
    }]

}, { // 28 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 95.01,
        "max": 100.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 44.5,
            "max": 47.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.625,
            "max": 18.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.0625,
            "max": 20.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 43.75,
            "max": 46
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14.5,
            "max": 15.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.75,
            "max": 8.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.125,
            "max": 26.25
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.25,
            "max": 17.5
        }
    }]

}, { // 29 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 100.01,
        "max": 105.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 45.5,
            "max": 48.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.125,
            "max": 18.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.5625,
            "max": 20.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 45.25,
            "max": 47.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15,
            "max": 15.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.75,
            "max": 8.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.875,
            "max": 27
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.25,
            "max": 18
        }
    }]

}, { // 30 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 105.01,
        "max": 110.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 46.5,
            "max": 49.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.125,
            "max": 18.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.5625,
            "max": 20.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 45.25,
            "max": 47.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15,
            "max": 15.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.75,
            "max": 8.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.875,
            "max": 27
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.25,
            "max": 18
        }
    }]

}, { // 31 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 110.01,
        "max": 115.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 48,
            "max": 51
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.625,
            "max": 19.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 19.0625,
            "max": 21.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 46.75,
            "max": 49
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15.5,
            "max": 16.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.75,
            "max": 8.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 26.625,
            "max": 28.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.75,
            "max": 18.5
        }
    }]

}, { // 32 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 115.01,
        "max": 120.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 49,
            "max": 52
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.625,
            "max": 19.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 19.0625,
            "max": 21.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 46.75,
            "max": 49
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15.5,
            "max": 16.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.75,
            "max": 8.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 26.625,
            "max": 28.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.75,
            "max": 18.5
        }
    }]

}, { // 33 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 120.01,
        "max": 125.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 50,
            "max": 53
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 18.125,
            "max": 19.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 19.5625,
            "max": 21.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 48.25,
            "max": 50.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 16,
            "max": 16.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.75,
            "max": 8.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 20,
            "max": 21.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 18.25,
            "max": 19
        }
    }]

}, { // 34 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.4,
        "max": 5.8
    },
    "weight": {
        "min": 125.01,
        "max": 130.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 50.5,
            "max": 53.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 18.125,
            "max": 19.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 19.5625,
            "max": 21.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 48.25,
            "max": 50.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 16,
            "max": 16.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.75,
            "max": 8.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 20,
            "max": 21.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 18.25,
            "max": 19
        }
    }]

}, { // 35 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 50.01,
        "max": 55.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 13.875,
            "max": 15.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 14.8125,
            "max": 16.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 33.5,
            "max": 36.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 11.75,
            "max": 12.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.5,
            "max": 7.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 28,
            "max": 31
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 21,
            "max": 22.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.5
        }
    }]

}, { // 36 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 55.01,
        "max": 60.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 13.875,
            "max": 15.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 14.8125,
            "max": 16.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 33.5,
            "max": 36.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 11.75,
            "max": 12.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.5,
            "max": 7.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 28,
            "max": 31
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 21,
            "max": 22.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.5
        }
    }]

}, { // 37 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 60.01,
        "max": 65.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 14.375,
            "max": 16.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 15.5625,
            "max": 17.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 35.5,
            "max": 38.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 12.25,
            "max": 13
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.75,
            "max": 7.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 21,
            "max": 23.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.625
        }
    }]

}, { // 38 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 65.01,
        "max": 70.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 38,
            "max": 41
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 14.875,
            "max": 16.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.3125,
            "max": 18.3125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 37.5,
            "max": 40.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 12.75,
            "max": 13.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7,
            "max": 8
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 21,
            "max": 23.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.875
        }
    }]

}, { // 39 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 70.01,
        "max": 75.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 38,
            "max": 41
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 14.875,
            "max": 16.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.3125,
            "max": 18.3125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 37.5,
            "max": 40.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 12.75,
            "max": 13.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7,
            "max": 8
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 23.5,
            "max": 24.75
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.875
        }
    }]

}, { // 40 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 75.01,
        "max": 80.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.375,
            "max": 17.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.8125,
            "max": 18.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 37,
            "max": 40
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 40.5,
            "max": 43
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13.5,
            "max": 14.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 35,
            "max": 38
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 23.5,
            "max": 24.75
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.875,
            "max": 15.25
        }
    }]

}, { // 41 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 80.01,
        "max": 85.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 40.5,
            "max": 43.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.375,
            "max": 17.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.8125,
            "max": 18.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 37,
            "max": 40
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 40.5,
            "max": 43
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13.5,
            "max": 14.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 35,
            "max": 38
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 24.375,
            "max": 25.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.875,
            "max": 15.25
        }
    }]

}, { // 42 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 85.01,
        "max": 90.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 41.5,
            "max": 44.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.875,
            "max": 17.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.3125,
            "max": 19.3125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 42.25,
            "max": 44.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14,
            "max": 14.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 37,
            "max": 40
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 24.375,
            "max": 25.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.25,
            "max": 17
        }
    }]

}, { // 43 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 90.01,
        "max": 95.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.875,
            "max": 17.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.3125,
            "max": 19.3125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 42.25,
            "max": 44.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14,
            "max": 14.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 37,
            "max": 40
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 24.375,
            "max": 25.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.25,
            "max": 17
        }
    }]

}, { // 44 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 95.01,
        "max": 100.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 43.5,
            "max": 46.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.375,
            "max": 18.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.8125,
            "max": 19.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 43.75,
            "max": 46
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14.5,
            "max": 15.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.125,
            "max": 26.25
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.75,
            "max": 17.5
        }
    }]

}, { // 45 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 100.01,
        "max": 105.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 44,
            "max": 47
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.375,
            "max": 18.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.8125,
            "max": 19.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 43.75,
            "max": 46
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14.5,
            "max": 15.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.125,
            "max": 26.25
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.75,
            "max": 17.5
        }
    }]

}, { // 46 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 105.01,
        "max": 110.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.875,
            "max": 18.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.3125,
            "max": 20.3125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 45.25,
            "max": 47.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15,
            "max": 15.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.875,
            "max": 27
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.25,
            "max": 18
        }
    }]

}, { // 47 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 110.01,
        "max": 115.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 48,
            "max": 51
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.875,
            "max": 18.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.3125,
            "max": 20.3125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 45.25,
            "max": 47.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15,
            "max": 15.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.875,
            "max": 27
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.25,
            "max": 18
        }
    }]

}, { // 48 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 115.01,
        "max": 120.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 48.5,
            "max": 51.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.375,
            "max": 19.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.8125,
            "max": 20.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 46.75,
            "max": 49
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15.5,
            "max": 16.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 26.625,
            "max": 27.75
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.75,
            "max": 18.5
        }
    }]

}, { // 49 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 120.01,
        "max": 125.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 49,
            "max": 52
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.375,
            "max": 19.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.8125,
            "max": 20.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 46.75,
            "max": 49
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15.5,
            "max": 16.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 26.625,
            "max": 27.75
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.75,
            "max": 18.5
        }
    }]

}, { // 50 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 5.9,
        "max": 5.11
    },
    "weight": {
        "min": 125.01,
        "max": 130.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 49.5,
            "max": 52.5
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.875,
            "max": 19.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 19.3125,
            "max": 21.3125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 48.25,
            "max": 50.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 16,
            "max": 16.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 46,
            "max": 48
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 27.375,
            "max": 28.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 18.25,
            "max": 19
        }
    }]

}, { // 51 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 50.01,
        "max": 55.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 13.875,
            "max": 15.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 14.8125,
            "max": 16.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 33.5,
            "max": 36.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 11.75,
            "max": 12.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.5,
            "max": 7.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 28,
            "max": 31
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 27.375,
            "max": 28.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.5
        }
    }]

}, { // 52 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 55.01,
        "max": 60.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 13.875,
            "max": 15.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 14.8125,
            "max": 16.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 33.5,
            "max": 36.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 11.75,
            "max": 12.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.5,
            "max": 7.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 28,
            "max": 31
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 20,
            "max": 21.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.5
        }
    }]

}, { // 53 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 60.01,
        "max": 65.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 14.375,
            "max": 16.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 15.5625,
            "max": 17.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 35.5,
            "max": 38.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 12.25,
            "max": 13
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.75,
            "max": 7.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 21,
            "max": 22.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.625
        }
    }]

}, { // 54 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 65.01,
        "max": 70.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.125,
            "max": 16.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.6875,
            "max": 18.6875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 35,
            "max": 38
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 38.5,
            "max": 41.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13,
            "max": 13.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7,
            "max": 8
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 33,
            "max": 36
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 22.5,
            "max": 24
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.625,
            "max": 16
        }
    }]

}, { // 55 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 70.01,
        "max": 75.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.125,
            "max": 16.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.6875,
            "max": 18.6875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 35,
            "max": 38
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 38.5,
            "max": 41.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13,
            "max": 13.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7,
            "max": 8
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 33,
            "max": 36
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 22.5,
            "max": 24
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.625,
            "max": 16
        }
    }]

}, { // 56 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 75.01,
        "max": 80.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 42,
            "max": 45
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.625,
            "max": 17.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.1875,
            "max": 19.1875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 38,
            "max": 41
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 41.5,
            "max": 43.75
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13.75,
            "max": 14.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 24,
            "max": 26.125
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16,
            "max": 16.75
        }
    }]

}, { // 57 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 80.01,
        "max": 85.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 42,
            "max": 45
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.625,
            "max": 17.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.1875,
            "max": 19.1875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 38,
            "max": 41
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 41.5,
            "max": 43.75
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13.75,
            "max": 14.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 24,
            "max": 26.125
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16,
            "max": 16.75
        }
    }]

}, { // 58 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 85.01,
        "max": 90.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 42,
            "max": 45
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.125,
            "max": 17.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.6875,
            "max": 19.6875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 38,
            "max": 41
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 41.5,
            "max": 43.75
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13.75,
            "max": 14.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 24,
            "max": 26.125
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16,
            "max": 16.75
        }
    }]

}, { // 59 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 90.01,
        "max": 95.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.125,
            "max": 17.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.6875,
            "max": 19.6875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 43.75,
            "max": 46
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14.5,
            "max": 15.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.125,
            "max": 26.25
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.75,
            "max": 17.5
        }
    }]

}, { // 60 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 95.01,
        "max": 100.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.625,
            "max": 18.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.1875,
            "max": 20.1875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 43.75,
            "max": 46
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14.5,
            "max": 15.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.125,
            "max": 26.25
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.75,
            "max": 17.5
        }
    }]

}, { // 61 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 100.01,
        "max": 105.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.625,
            "max": 18.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.1875,
            "max": 20.1875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 43.75,
            "max": 46
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14.5,
            "max": 15.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.125,
            "max": 26.25
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.75,
            "max": 17.5
        }
    }]

}, { // 62 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 105.01,
        "max": 110.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 49,
            "max": 52
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.125,
            "max": 18.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.6875,
            "max": 20.6875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 46.75,
            "max": 49
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15.5,
            "max": 16.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 26.625,
            "max": 27.75
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.75,
            "max": 18.5
        }
    }]

}, { // 63 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 110.01,
        "max": 115.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 49,
            "max": 52
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.125,
            "max": 18.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.6875,
            "max": 20.6875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 46.75,
            "max": 49
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15.5,
            "max": 16.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 26.625,
            "max": 27.75
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.75,
            "max": 18.5
        }
    }]

}, { // 64 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 115.01,
        "max": 120.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 51,
            "max": 54
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.625,
            "max": 19.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 19.1875,
            "max": 21.1875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 48.25,
            "max": 50.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 16,
            "max": 16.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 27.375,
            "max": 28.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 18.25,
            "max": 19
        }
    }]
}, { // 65 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 120.01,
        "max": 125.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 53,
            "max": 56
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.625,
            "max": 19.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 19.1875,
            "max": 21.1875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 49,
            "max": 52
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 49.75,
            "max": 52
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 16.5,
            "max": 17.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 28.125,
            "max": 29.25
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 18.75,
            "max": 19.5
        }
    }]

}, { // 66 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6,
        "max": 6.2
    },
    "weight": {
        "min": 125.01,
        "max": 130.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 55,
            "max": 58
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 18.125,
            "max": 19.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 19.6875,
            "max": 21.6875
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 51,
            "max": 54
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 51.25,
            "max": 53.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 17,
            "max": 17.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 49,
            "max": 52
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 28.875,
            "max": 30
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 19.25,
            "max": 20
        }
    }]

}, { // 67 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 50.01,
        "max": 55.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 13.875,
            "max": 15.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 14.8125,
            "max": 16.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 33.5,
            "max": 36.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 11.75,
            "max": 12.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.5,
            "max": 7.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 28,
            "max": 31
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 20,
            "max": 21.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.5
        }
    }]

}, { // 68 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 55.01,
        "max": 60.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 34,
            "max": 37
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 13.875,
            "max": 15.625
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 14.8125,
            "max": 16.8125
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 33.5,
            "max": 36.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 11.75,
            "max": 12.5
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.5,
            "max": 7.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 28,
            "max": 31
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 20,
            "max": 21.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.5
        }
    }]

}, { // 69 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 60.01,
        "max": 65.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 14.375,
            "max": 16.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 15.5625,
            "max": 17.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 35.5,
            "max": 38.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 12.25,
            "max": 13
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 6.75,
            "max": 7.75
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 21,
            "max": 22.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.625
        }
    }]

}, { // 70 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 65.01,
        "max": 70.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 36,
            "max": 39
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 14.375,
            "max": 16.125
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 15.5625,
            "max": 17.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 32,
            "max": 35
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 35.5,
            "max": 38.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 12.25,
            "max": 13
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7,
            "max": 8
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 30,
            "max": 33
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 21,
            "max": 22.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.5,
            "max": 15.625
        }
    }]

}, { // 71 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 70.01,
        "max": 75.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.125,
            "max": 16.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.0625,
            "max": 18.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 35,
            "max": 38
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 38.5,
            "max": 41.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13,
            "max": 13.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7,
            "max": 8
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 33,
            "max": 36
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 22.5,
            "max": 24
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.625,
            "max": 16
        }
    }]

}, { // 72 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 75.01,
        "max": 80.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.125,
            "max": 16.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.0625,
            "max": 18.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 35,
            "max": 38
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 38.5,
            "max": 41.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13,
            "max": 13.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 33,
            "max": 36
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 22.5,
            "max": 24
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.625,
            "max": 16
        }
    }]

}, { // 73 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 80.01,
        "max": 85.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.625,
            "max": 17.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.5625,
            "max": 18.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 37,
            "max": 40
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 40.5,
            "max": 43
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13.5,
            "max": 14.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 35,
            "max": 38
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 23.5,
            "max": 24.75
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.875,
            "max": 16.5
        }
    }]

}, { // 74 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 85.01,
        "max": 90.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 15.625,
            "max": 17.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 16.5625,
            "max": 18.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 37,
            "max": 40
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 40.5,
            "max": 43
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 13.5,
            "max": 14.25
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 7.5,
            "max": 8.5
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 35,
            "max": 38
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 23.5,
            "max": 24.75
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 15.875,
            "max": 16.5
        }
    }]

}, { // 75 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 90.01,
        "max": 95.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.125,
            "max": 17.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.0625,
            "max": 19.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 42.25,
            "max": 44.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14,
            "max": 14.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 37,
            "max": 40
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 24.375,
            "max": 25.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.25,
            "max": 17
        }
    }]

}, { // 76 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 95.01,
        "max": 100.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.125,
            "max": 17.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.0625,
            "max": 19.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 39,
            "max": 42
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 42.25,
            "max": 44.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 14,
            "max": 14.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 37,
            "max": 40
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 24.375,
            "max": 25.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 16.25,
            "max": 17
        }
    }]
}, { // 77 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 100.01,
        "max": 105.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.625,
            "max": 18.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.5625,
            "max": 19.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 45.25,
            "max": 47.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15,
            "max": 15.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.875,
            "max": 27
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.25,
            "max": 18
        }
    }]

}, { // 78 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 105.01,
        "max": 110.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.625,
            "max": 18.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 17.5625,
            "max": 19.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 43,
            "max": 46
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 45.25,
            "max": 47.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 15,
            "max": 15.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 41,
            "max": 44
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 25.875,
            "max": 27
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 17.25,
            "max": 18
        }
    }]

}, { // 79 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 110.01,
        "max": 115.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 51,
            "max": 54
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.125,
            "max": 18.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.0625,
            "max": 20.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 48.25,
            "max": 50.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 16,
            "max": 16.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 27.375,
            "max": 28.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 18.25,
            "max": 19
        }
    }]

}, { // 80 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 115.01,
        "max": 120.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 51,
            "max": 54
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.125,
            "max": 18.875
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.0625,
            "max": 20.0625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 47,
            "max": 50
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 48.25,
            "max": 50.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 16,
            "max": 16.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 45,
            "max": 48
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 27.375,
            "max": 28.5
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 18.25,
            "max": 19
        }
    }]

}, { // 81 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 120.01,
        "max": 125.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 55,
            "max": 58
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 17.625,
            "max": 19.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.5625,
            "max": 20.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 51,
            "max": 54
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 51.25,
            "max": 53.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 17,
            "max": 17.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 49,
            "max": 52
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 28.875,
            "max": 30
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 19.25,
            "max": 20
        }
    }]

}, { // 82 row
    "validation_type": "WEIGHT_HEIGHT",
    "height": {
        "min": 6.3,
        "max": 6.5
    },
    "weight": {
        "min": 125.01,
        "max": 130.00
    },
    "validations": [{
        "code": "CHEST",
        "measurement_type_id": 419,
        "measurement_type_combination": [419, 159, 1129, 655,13,245],
        "value": {
            "min": 55,
            "max": 58
        }
    }, {
        "code": "NECK",
        "measurement_type_id": 422,
        "measurement_type_combination": [422, 162, 664, 1136,248,20],
        "value": {
            "min": 16.625,
            "max": 18.375
        }
    }, {
        "code": "SHOULDER",
        "measurement_type_id": 423,
        "measurement_type_combination": [423, 431, 658, 171, 1131, 163,249],
        "value": {
            "min": 18.5625,
            "max": 20.5625
        }
    }, {
        "code": "WAIST (STOMACH)",
        "measurement_type_id": 420,
        "measurement_type_combination": [420, 656, 160, 1130,14,246],
        "value": {
            "min": 51,
            "max": 54
        }
    }, {
        "code": "SEAT",
        "measurement_type_id": 421,
        "measurement_type_combination": [421, 657, 161, 1138, 125, 601, 622, 639, 408,247,15],
        "value": {
            "min": 51.25,
            "max": 53.5
        }
    }, {
        "code": "BICEP",
        "measurement_type_id": 424,
        "measurement_type_combination": [424, 448, 662, 164, 188, 1139,19,250],
        "value": {
            "min": 17,
            "max": 17.75
        }
    }, {
        "code": "WRIST",
        "measurement_type_id": 663,
        "measurement_type_combination": [663, 720, 721, 1137,678],
        "value": {
            "min": 8,
            "max": 9
        }
    }, {
        "code": "WAIST",
        "measurement_type_id": 638,
        "measurement_type_combination": [638, 401, 615, 600, 124],
        "value": {
            "min": 49,
            "max": 52
        }
    }, {
        "code": "THIGH",
        "measurement_type_id": 126,
        "measurement_type_combination": [126, 602, 628, 640, 414],
        "value": {
            "min": 28.875,
            "max": 30
        }
    }, {
        "code": "BOTTOM WIDTH",
        "measurement_type_id": 629,
        "measurement_type_combination": [629, 641, 415],
        "value": {
            "min": 19.25,
            "max": 20
        }
    }]
}];