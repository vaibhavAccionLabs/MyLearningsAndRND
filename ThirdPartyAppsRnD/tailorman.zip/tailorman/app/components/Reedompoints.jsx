/**
* reedom Code
*/
import React, { Component } from 'react';
import classNames from 'classnames/bind';
import styles from 'css/components/order/sales';
import ReactDOM from 'react-dom';
const cx = classNames.bind(styles);
class RedeemPoints extends Component {
    constructor(props) {
        super(props);
        this.onClose = this.onClose.bind(this);
        this.onValueChange = this.onValueChange.bind(this);
        this.onCodeValueChange = this.onCodeValueChange.bind(this);
        this.onRedeemCode = this.onRedeemCode.bind(this);
        this.state = {
            inputValue: "",
            inputCodeValue: ""
        }
        this.baseState = this.state;

    }
    getValidationMessage () {
        const points = this.promocode && this.promocode.value;
        let orderdetails = this.props;
        let availablepoints = orderdetails && this.props.orderdetails.loyality_points
        if (points) {
            if (points <= availablepoints && points >= 0) {
                // this.props.validateRedeemPoints(points);
                return true;
            } else if (points > availablepoints) {
                return "you entered more than availablepoints";
            } else if (points < 0) {
                return "Invalid entry of points";
            }
        }
    }
    onClose(e, value) {
        const points = this.promocode.value;
        if(this.getValidationMessage() == true){
            this.props.validateRedeemPoints(points);
        }
    }

    onRedeemCode(e, value) {
        const code = this.redeempromocode.value;
        let { orderdetails: { coupon_details } } = this.props;
        let points = "";
        if (coupon_details && coupon_details.type == "validatepoints") {
            points = coupon_details && coupon_details.points || this.promocode.value;

        } else {
            points = this.promocode.value;
        }
        this.props.redeemCode(code, points);
        this.setState(this.baseState);

    }
    onValueChange(e, data) {
        //For combo selection
        //data does not exist
        data = data || e.currentTarget;

        let { value } = data;

        this.setState({
            inputValue: value
        });
    }

    onCodeValueChange(e, data) {
        //For combo selection
        //data does not exist
        data = data || e.currentTarget;

        let { value } = data;

        this.setState({
            inputCodeValue: value
        });
    }
    render() {
        let spaceMargin = "10px 0px 0px 0px";
        let { orderdetails,discounts } = this.props;
        let coupon_details;
        if(orderdetails.coupon_details && ( orderdetails.coupon_details.type == 'redeempoints' || orderdetails.coupon_details.type == 'validatepoints' )  ){
            coupon_details = orderdetails.coupon_details;
        }
        let disabled = false;
        let iscodevalidated = false;
        if (coupon_details && coupon_details.is_redeemable) {
            iscodevalidated = false;
        } else {
            iscodevalidated = true;
        }
        if( discounts && _.findIndex(discounts,{type:'redeempoints'}) != -1){
            disabled = true;
        }
        // if (orderdetails.coupon_details) {
        //     if (orderdetails.coupon_details.coupon_applied || orderdetails.coupon_details.redeem_applied) {
        //         disabled = true;
        //     }
        // }

        let messageCls = "";
        // if (pointsSuccessDetails) {
        //     if (pointsSuccessDetails.is_redeemable == "false") {
        //         messageCls = "failure";
        //     } else {
        //         messageCls = "success";
        //     }
        // }
        let validationPointsMessage = "";
        let redeemPointsStatusMessage = "";
        if (coupon_details && coupon_details.type == "validatepoints") {
            validationPointsMessage = coupon_details.message;
        } else if (coupon_details && coupon_details.type == "redeempoints") {
            redeemPointsStatusMessage = coupon_details.message;
        }
        let getMessage = this.getValidationMessage();
        if(getMessage != true){
            validationPointsMessage = getMessage;
        }
        return (
            <div style={{ width: "40%" }}>
                <div>Available Reedom points :<span>{(orderdetails) ? orderdetails.loyality_points : 0}</span> </div>
                <div className="promo_input">
                    <input type="number" disabled={disabled} placeholder='Please enter the points to be redeemed' value={this.state.inputValue} onChange={this.onValueChange} ref={(el) => { this.promocode = el }} />
                </div>
                <div className="reedom_button"  ><span className={messageCls}>{validationPointsMessage}</span>
                    <button disabled={disabled} className={cx('submit', 'action', 'primary')} onClick={(e) => this.onClose()}>REDEEM</button></div>

                <div style={{ width: "100%" }}> <input type="text" disabled={disabled} placeholder='Please enter the code to be redeemed' value={this.state.inputCodeValue} onChange={this.onCodeValueChange} ref={(el) => { this.redeempromocode = el }} /></div>
                <div className="reedom_button" ><span className={messageCls} >{redeemPointsStatusMessage}</span><button disabled={disabled ? disabled : iscodevalidated} className={cx('submit', 'action', 'primary')} onClick={(e) => this.onRedeemCode(e, this)}>REDEEM CODE</button></div>

            </div>
        );
    }
}

export default RedeemPoints;