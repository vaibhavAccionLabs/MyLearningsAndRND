import React, { Component } from 'react';

export default class Barcode extends Component {
	constructor(props) {
		super(props);
	 this.renderbarcode = this.renderbarcode.bind(this);
    }

   componentDidMount() {
        this.renderbarcode(this.props.value)
    }
    componentWillReceiveProps(nextProps) {
      if(nextProps.value != this.props.value){
         this.renderbarcode(nextProps.value)
      }
    }

    renderbarcode(name){
       JsBarcode("#code128", name,{displayValue: false,  
        height: 40,
     });
    }

	render(){
		return(
			 <div style={{margin:'auto'}}>
                <svg id="code128"></svg>
			 </div>
			


		)
	 }
}

