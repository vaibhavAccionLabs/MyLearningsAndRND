import React, { Component } from 'react';
import plus_icon from 'images/plusicon.png';


class ImageUploader extends Component {
    constructor(props) {
        super(props);
        this.state = {
            displayFileName : ''
        };
        this.onFileChangeHandler = this.onFileChangeHandler.bind(this);
    }

   reset () {
    this.uploadingImage.value = '';
    this.setState({
        displayFileName : ''
    });
   }

   onFileChangeHandler(){
       let {reset} = this.props;
       if(this.uploadingImage.value != ''){
        let getFileName = this.uploadingImage.files[0];
        this.setState({
            displayFileName:getFileName.name
        });
        this.props.onChange(getFileName);
       }
       if(reset){
        this.reset();
      }
   }

    render() {
        let {displayFileName} = this.state;
        return ( 
        <div className={'imageBox'}>
            <div className={'file-choose-option'}>
                <label className={'title'}>{this.props.title}</label>
                <label htmlFor="file-input" className={"file-input"}>
                <img src={plus_icon} className={'file-image'}/>
                </label>
                <input accept=".jpg"  className={'file-input-type'} ref={(ref) => {this.uploadingImage = ref}} type="file" onChange={this.onFileChangeHandler}/>
                </div>
                <div className={'display-file-name'}>{(displayFileName)? "FileName:-  " + displayFileName : ""}</div>
            </div>
        );
    }
}

export default ImageUploader;