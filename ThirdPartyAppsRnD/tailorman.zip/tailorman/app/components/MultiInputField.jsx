import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';


export default class MultiInputField extends Component {
    constructor(props) {
        super(props);
        this.state = {
            chips: [],
            inputValue: null
        }

        this.setChips = this.setChips.bind(this);
        this.onKeyDown = this.onKeyDown.bind(this);
        this.deleteChip = this.deleteChip.bind(this);
        this.focusInput = this.focusInput.bind(this);
        this.onTextInputChange = this.onTextInputChange.bind(this);
        this.onFocusLeave = this.onFocusLeave.bind(this);
    }


    onTextInputChange() {
        let value = ReactDOM.findDOMNode(this.refs.multi_input).value;
        this.setState({ 'inputValue': value });
    }


    componentDidMount() {
        this.setChips(this.props.chips);
    }

    componentWillReceiveProps(nextProps) {
        
        this.setChips(nextProps.chips);
        if (nextProps.isValue) {
            this.setState({
                inputValue: ""
            })
        }
    }

    setChips(chips) {
       this.setState({ chips });
      
    }

    onKeyDown(event) {
        this.props.onKeyDown(event);
    }

    onFocusLeave(event) {
        this.props.onFocusLeave(event);
    }


    deleteChip(chip) {
        this.props.onDeletechip &&  this.props.onDeletechip(chip)
        let index = this.state.chips.indexOf(chip);

        let chips = this.state.chips;

        if (index >= 0) {
            
            chips.splice(index, 1);
            this.setState({
                chips
            });
        }
    }

    focusInput(event) {
        let children = event.target.children;

        if (children.length) children[children.length - 1].focus();
    }

    render() {
        
        let chips = this.state.chips && this.state.chips.map((chip, index) => {
            return (
                <span className="chip" key={index}>
                    <span className="chip-value">{chip}</span>
                    <button type="button" className="chip-delete-button" onClick={this.deleteChip.bind(null, chip)}>x</button>
                </span>
            );
        });

        let placeholder = !this.props.max || chips.length < this.props.max ? this.props.placeholder : '';

        return (
            <div className="multi-input-container">
                <label htmlFor="multi_input">{this.props.labelName}</label>
                <div className="chips" onClick={this.focusInput}>
                    {chips}

                    <input type={this.props.type} id="multi_inputtt" ref="multi_input" onKeyDown={this.onKeyDown} onChange={this.onTextInputChange} value={this.state.inputValue} className="chips-input" onBlur={this.onFocusLeave} />
                </div>
            </div>
        );
    }
}

MultiInputField.propTypes = {
    chips: React.PropTypes.array,
    onKeyDown: React.PropTypes.func
}