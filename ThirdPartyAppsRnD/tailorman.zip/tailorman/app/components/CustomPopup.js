/**
 *
 * Renders an popup, enforcing the usage of the alt="" tag
 *
 */

import React, { Component, PropTypes } from 'react';
import styles from 'css/components/CustomPopup';
import classNames from 'classnames/bind';
const cx = classNames.bind(styles);

class CustomPopup extends Component { // eslint-disable-line react/prefer-stateless-function
    constructor(props) {
        super(props);
    }



    render() {
       let {className,visible,children}=this.props;
       let activeCls =null;
       let closeBtn = null;

       let box=null;
       if(visible){
           activeCls ="mm-popup--visible";
             if (this.props.closeBtn) {
                closeBtn = <button onClick={this.props.handleClose} className={cx('mm-popup__close')} onClick={this.props.onCancelClick}></button>;
            }

        box = (
                <article role="dialog" tabIndex="-1" ref={(el) => { this.boxRef = el; }} style={{ opacity: 10001, outline: 'none' }} className={cx('mm-popup__box')}>
                    {closeBtn}
                    <header className={cx('mm-popup__box__header')}>
                        <h1 className={cx('mm-popup__box__header__title')}>{this.props.title}</h1>
                    </header>
                     <div className={cx('mm-popup__box__body')}>
                    {children}
                    </div>
                    <footer className={cx("mm-popup__box__footer")} ><div className={cx("mm-popup__box__footer__left-space")}><button className={cx("mm-popup__btn")} onClick={this.props.onCancelClick}>CANCEL</button></div><div className={cx("mm-popup__box__footer__right-space")}><button className={cx("mm-popup__btn null")} onClick={this.props.onAddClick}>SAVE</button></div></footer>
                </article>
            );
       }

      // <div role="presentation" onClick={this.bound.containerClick} className={this.className('overlay')} style={overlayStyle} />

         return (
            <div className={className}>
                <div role="presentation"  className={cx(`mm-popup ${activeCls}`)} />
                {box}
            </div>
        );
    }
}

// We require the use of src and alt, only enforced by react in dev mode
CustomPopup.propTypes = {
};

export default CustomPopup;