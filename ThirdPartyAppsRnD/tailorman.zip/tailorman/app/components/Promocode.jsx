/**
* Promo Code
*/
import React, { Component } from 'react';
import classNames from 'classnames/bind';
import styles from 'css/components/order/sales';
import ReactDOM from 'react-dom';
const cx = classNames.bind(styles);
class PromoCode extends Component {

    constructor(props) {
        super(props);
        this.onClose = this.onClose.bind(this);
        this.onApply = this.onApply.bind(this);
        this.onValueChange = this.onValueChange.bind(this);
        this.state = {
            inputValue: ""
        }
    }
    onClose(e) {
        let { coupon_details } = this.props;

        //	if(coupon_details && !coupon_details.coupon_applied){
        let promocode = this.input.value;
        this.props.validatePromoCode(promocode);
        //    }

    }
    onValueChange(e, data) {
        data = data || e.currentTarget;
        let { value } = data;

        this.setState({
            inputValue: value,
            message: "",
        });

    }
    onApply(e) {
        let { coupon_details } = this.props;

        //	if(coupon_details && !coupon_details.coupon_applied){
        let promocode = this.input.value
        this.props.savePromoCode(promocode);
        //   }
    }
    render() {
        let { coupon_details,discounts } = this.props;
        if(coupon_details && coupon_details.type != "coupon"){
            coupon_details = {};
        }
        let disabled = false;
        let iscodevalidated = false;
        if ( coupon_details && coupon_details.is_redeemable == "true"){
            iscodevalidated = false;
        }else{
            iscodevalidated = true;
        }
        // if (coupon_details) {
        //     if (coupon_details.coupon_applied  || coupon_details.redeem_applied) {
        //         disabled = true;
        //     }
        // }
        if( discounts && _.findIndex(discounts,{type:'coupon'}) != -1 ){
            disabled = true;
        }
        return (
            <div style={{ width: "35%" }}>
                <div>Have a promo code?</div>
                <div className="promo_input">
                    <input disabled={disabled} type="text" placeholder='Please enter your promotional code' onChange={this.onValueChange}
                        ref={(el) => { this.input = el }} value={this.state.inputValue} />
                    <span className={this.state.msgclass}>{coupon_details && coupon_details.message}</span>
                </div>
                <div className="promo_buttons">
                    <button type="button" disabled={disabled ? disabled : iscodevalidated } className={cx('submit', 'action', 'primary', 'disable')} onClick={(e) => this.onApply(e, this)}>APPLY</button>
                    <button disabled={disabled}  className={cx('submit', 'action', 'primary')} onClick={(e) => this.onClose()}>Validate</button>
                </div>
            </div>
        );
    }
}

export default PromoCode;