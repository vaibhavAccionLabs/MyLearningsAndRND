/**
* Promo Code
*/
import React, { Component } from 'react';
import classNames from 'classnames/bind';
import styles from 'css/components/order/sales';
import ReactDOM from 'react-dom';
const cx = classNames.bind(styles);
import CustomPopup from './CustomPopup';
import PaymentTable from './PaymentTable';

class OrderPendingPaymentDetails extends Component {

    constructor(props) {
        super(props);
        this.state = {
            msg: '',
            payments: [{
                id: 1,
                payment_mode: '',
                amount: '',
                reference: '',
            }]
        }
        this.renderEditable = this.renderEditable.bind(this);
        this.onRowAdd = this.onRowAdd.bind(this);
        this.onAddClick = this.onAddClick.bind(this);

    }
    onRowAdd() {

        var payments = this.state.payments;
        var len = payments.length;
        var newData = {
            id: len + 1,
            payment_mode: '',
            amount: '',
            reference: ''
        };
        payments.push(newData);
        this.setState({
            payments
        })



    }
    isValid(payments){
        let total_paid_amount = 0;
        payments.length > 0 && payments.map((payment, index) => {
          total_paid_amount += payment.amount && parseInt(payment.amount) || 0;
        });

        if (total_paid_amount > this.props.total_amount) {
            return false;
        }
        return true;
    }
    onAddClick() {

        var newArray = [];
        var payments = this.state.payments;
        payments.map((item, index) => {
            if (item.payment_mode && item.amount) {
                newArray.push(item);
            }
        });
        if(!this.isValid(newArray)){
            return true;
        }
        if ( this.state.msg && this.state.msg.length > 0) {

        } else {
            this.props.onAddPendingAmount('pending_amount', newArray);
            this.setState({
                payments: [{
                    id: 1,
                    payment_mode: '',
                    amount: '',
                    reference: '',
                }]
            });
            this.props.onAddPaymentClick();
        }

    }
    renderEditable(payments, msg) {

        // if(!msg.length > 0 ){
        this.setState({
            payments,
            msg
        });
        // }
        // this.setState({msg});
    }
    componentDidMount() {
        if (this.props.pending_amount.length > 0) {
            this.setState({
                payments: this.props.pending_amount || []
            })
        }
    }
    componentWillReceiveProps(nextProps) {
        if (JSON.stringify(nextProps.pending_amount) != JSON.stringify(this.state.payments)) {
            if (nextProps.pending_amount.length > 0) {
                this.setState({
                    payments: nextProps.pending_amount
                })
            }

        }

    }
    render() {

        let paidAmount = 0;
        let { total_amount } = this.props;
        let { payments } = this.state;
        payments && payments.map((item, index) => {
            if (item.amount) {
                paidAmount += parseInt(item.amount);
            }
        });
        let { msg } = this.state;
        let errorMsg = "";
        if (msg) {
            errorMsg = <div className={cx("table_error_msg")}>{msg}</div>;
        };
        let pendingAmount = ((parseInt(total_amount) - paidAmount) >= 0) ? parseInt(total_amount) - paidAmount : total_amount;
        
        return (
            <div>
                <CustomPopup visible={this.props.openPaymentPopup} onCancelClick={this.props.onAddPaymentClick} title="Order Pending Payment Details" onAddClick={this.onAddClick} closeBtn={true}>
                    <div><div style={{ float: 'none', display: 'inline-block' }} >Total Amount : {total_amount}</div> <div style={{ float: 'right', display: 'inline-block' }}>Pending Amount : {pendingAmount}</div></div>
                    <PaymentTable
                        payments={this.state.payments}
                        renderEditable={this.renderEditable}
                        onRowAdd={this.onRowAdd} total_amount={total_amount} payment_types={this.props.payment_types} />
                </CustomPopup>

            </div>
        );
    }
}

export default OrderPendingPaymentDetails;