import React, { Component, PropTypes } from 'react';
import classNames from 'classnames/bind';
import styles from 'css/components/stylesForm';
import ReactDOM from 'react-dom';
import { updateMessage } from '../actions/order';
import { fetchList } from '../actions/list';
import MultipleChoice from './MultipleChoice';
import SelectForm from './SelectForm';
import Select from 'react-select';
import _ from 'lodash';
import Collapse, { Panel } from 'rc-collapse';
const cx = classNames.bind(styles);
import { lining_sku } from 'types/liningsku';
import { UPCHARGE_UNIT_VALUE, UPCHARGE_UNIT_PERCENTAGE, ADDITIONAL_UPCHARGE, DELIVERY_UPCHARGE } from 'types';
import { connect } from 'react-redux';
import Popup from 'react-popup';

class StylesForm extends Component {
	constructor(props) {
		super(props);

		this.getStylesFormFields = this.getStylesFormFields.bind(this);
		this.saveDesignSelection = this.saveDesignSelection.bind(this);
		this.saveAndClose = this.saveAndClose.bind(this);
		this.saveDesignSelectionText = this.saveDesignSelectionText.bind(this);
		this.saveDesignSelectionCombo = this.saveDesignSelectionCombo.bind(this);
		this.getAdditionalUpcharge = this.getAdditionalUpcharge.bind(this);
		this.getUpcharge = this.getUpcharge.bind(this);
		this.hasUpcharge = this.hasUpcharge.bind(this);

		this.accordion = true;

		this.upCharges = this.props.upcharges || [];
		this.toggleAccordion = this.toggleAccordion.bind(this);
		this.onStyleCommentChange = this.onStyleCommentChange.bind(this);
		this.onStyleNameChange = this.onStyleNameChange.bind(this);
		this.getUpchargeObject = this.getUpchargeObject.bind(this);
		this.getQuickUpcharge = this.getQuickUpcharge.bind(this);
		this.state = {
			styleComment: null,
			styleName: null
		}
	}

	onStyleCommentChange() {
		let comment = ReactDOM.findDOMNode(this.refs.comment).value;
		this.setState({ 'styleComment': comment });
	}
	onStyleNameChange() {
		let comment = ReactDOM.findDOMNode(this.refs.comment).value;
		this.setState({ 'styleComment': comment });
	}

	updateFabricDesign(nextProps) {
		let formatedFabricDesign = null;
		let { fabricDesign, lists } = nextProps;



		if (fabricDesign && fabricDesign.length > 0) {
			formatedFabricDesign = fabricDesign;
		}
		if (!formatedFabricDesign && !this.fabricDesign) {
			this.props.loadFields();
		}
		if (!formatedFabricDesign && lists && lists.fabric_design_fields) {
			formatedFabricDesign = _.clone(nextProps.lists.fabric_design_fields, true) || [];
		}
		this.fabricDesign = formatedFabricDesign || [];
	}
	componentWillReceiveProps(nextProps) {
		if (nextProps.profile && nextProps.profile.comment) {
			this.setState({ 'styleComment': nextProps.profile.comment });
		}
		// if(nextProps.profile && nextProps.profile.name){
		// 	this.setState({'styleName':nextProps.profile.name});
		// }
		this.updateFabricDesign(nextProps);
	}

	componentDidMount() {
		if (this.props.profile) {
			this.setState({ 'styleComment': this.props.profile.comment });
		}
		// this.props.loadFields();
		window.scrollTo(0, 0);
	}
	getQuickUpcharge(design, index, upcharges = []) {
		if (index > -1 && (design.upcharge[index] || design["upcharge percentage"][index])) {
			const value = design.upcharge[index] || design["upcharge percentage"][index];
			const unit = (design.upcharge[index]) ? UPCHARGE_UNIT_VALUE : UPCHARGE_UNIT_PERCENTAGE;
			upcharges = _.compact(upcharges.filter((upcharge) => {
				return upcharge.type != design.name;
			}));
			upcharges.push({
				type: design.name,
				value: value,
				unit: unit
			});
		}
		return upcharges;
	}
	getUpchargeObject() {
		const design_fields = this.fabricDesign;
		var upcharges_array = [];
		/**
		 * Upcharge Getting removed for Same name
		 */
		design_fields.map((type) => {
			type.Designs && type.Designs.map(design => {
				if (design.values) {
					var index = design.selected;
					upcharges_array = this.getQuickUpcharge(design, index, upcharges_array);
				}
				return design;
			});
			return type;
		});

		const _additional_upcharge = ReactDOM.findDOMNode(this.refs.upcharge).value;
		if (parseInt(_additional_upcharge) > 0) {
			upcharges_array = _.compact(upcharges_array.filter((upcharge) => {
				return upcharge.type != ADDITIONAL_UPCHARGE;
			}));
			upcharges_array.push({
				type: ADDITIONAL_UPCHARGE,
				value: parseInt(_additional_upcharge),
				unit: UPCHARGE_UNIT_VALUE
			});
		}
		return upcharges_array;
	}


	getUpcharge(design, index, upcharges = []) {
		if (index > -1 && (design.upcharge[index] || design["upcharge percentage"][index])) {
			const value = design.upcharge[index] || design["upcharge percentage"][index];
			const unit = (design.upcharge[index]) ? UPCHARGE_UNIT_VALUE : UPCHARGE_UNIT_PERCENTAGE;
			upcharges = _.compact(upcharges.filter((upcharge) => {
				return upcharge.type != design.name;
			}));
			upcharges.push({
				type: design.name,
				value: value,
				unit: unit
			});
		} else if (index == -1 || !(design.upcharge[index] || design["upcharge percentage"][index])) {
			upcharges = _.compact(upcharges.filter((upcharge) => {
				return upcharge.type != design.name;
			}));
		}
		return upcharges;
	}
	hasUpcharge(design, index, upcharges) {
		if (index > -1) {
			const upcharge = _.find(upcharges, { type: design.name });
			if (upcharge) {
				return {
					type: design.name,
					value: upcharge.value,
					unit: upcharge.unit,
					display_name: upcharge.value + ((upcharge.unit == UPCHARGE_UNIT_VALUE) ? ' INR' : ' % on MRP')
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	saveDesignSelection(type_id, design_id, value) {
		const self = this;
		const design_fields = this.fabricDesign;
		let profile_name = null;
		let profiledom = ReactDOM.findDOMNode(this.refs.profile_name);
		if (profiledom) {
			profile_name = profiledom.value
		}

		this.props.save(design_fields.map((type) => {
			if (type.id === type_id) {
				type.Designs && type.Designs.map(design => {
					if (design.id === design_id && design.values) {
						var index = design.values.indexOf(value[0]);
						design.selected = index;
						if (design.liningDependent === "true") {
							let liningDependentObject = _.find(type.Designs, { dependentName: design.name });
							liningDependentObject.text = '';
						}
						self.upCharges = self.getUpcharge(design, index, self.upCharges);
					}
					return design;
				});
			}

			return type;

		}), ReactDOM.findDOMNode(this.refs.comment).value, self.upCharges, false, {
				profile: {
					name: profile_name,
					item_type_id: 0,
					profile_id: this.props.profile ? this.props.profile.profile_id : -1,
					fabric_design: this.fabricDesign,
					comment: ReactDOM.findDOMNode(this.refs.comment).value
				}
			});
	}
	saveDesignSelectionCombo(type_id, design_id, value) {
		var design_fields = this.fabricDesign;
		const self = this;
		this.props.save(design_fields.map((type) => {

			if (type.id === type_id) {
				let selectedRecord = _.find(type.Designs, { id: design_id });
				type.Designs.map(design => {
					if (design.id === design_id) {
						design.selected = 0;
						design.text = value.name;
						design.values = [value.name];
						design.upcharge = value.upcharge ? [value.upcharge] : [];
						self.upCharges = self.getUpcharge(design, design.selected, self.upCharges);
					}
					if (selectedRecord && (selectedRecord.name == design.dependentName)) {
						design.text = value.name || value.target.value;
					}
					return design;
				});
			}
			return type;
		}), ReactDOM.findDOMNode(this.refs.comment).value);
	}
	saveDesignSelectionText(type_id, design_id, value) {
		var design_fields = this.fabricDesign;
		this.props.save(design_fields.map((type) => {
			if (type.id === type_id) {
				type.Designs && type.Designs.map(design => {
					if (design.id === design_id) {
						design.text = value.name || value.target.value;
					}
					return design;
				});
			}
			return type;
		}), ReactDOM.findDOMNode(this.refs.comment).value);

	}

	getAdditionalUpcharge() {
		let additional_upchage;
		if (this.props.upcharges && this.props.upcharges.length > 0)
			additional_upchage = _.find(this.props.upcharges, { type: ADDITIONAL_UPCHARGE });
		if (additional_upchage)
			return additional_upchage.value;
		else
			return 0;
	}

	saveAndClose() {
		var { displayUpcharge } = this.props;
		var self = this;
		if ((ReactDOM.findDOMNode(this.refs.profile_name).value.trim().length == 0) && this.props.is_new_style) {
			window.scrollTo(0, 0);
			this.props.message('MEARSUREMENT_FORM_VALIDATION', "Please provide values for Styling Profile Name");
		}
		else {
			let isStyleValid = true;
			if (this.fabricDesign && this.fabricDesign[0].name == "TROUSER") {
				//    let searchResults = _.find(this.fabricDesign[0].Designs, (item) => {
				this.fabricDesign[0].Designs.map(function (item) {
					if ((item.type == "text") || (item.type == "combo")) {
						let buttonsObj = _.find(this.fabricDesign[0].Designs, { name: "BUTTONS" });
						if (buttonsObj && (buttonsObj.text == "Tonal")) {
							isStyleValid = true;
						}
						else {
							if (!item.text) {
								if (displayUpcharge) {
									if (!_.isEmpty(item.upcharge)) {
										isStyleValid = false;
									}
								} else {
									isStyleValid = false;
								}
							}
						}
					} else if (item.selected == undefined || item.selected == -1) {
						if (displayUpcharge) {
							if (!_.isEmpty(item.upcharge)) {
								isStyleValid = false;
							}
						} else {
							isStyleValid = false;
						}
					}
				}, this);
			}
			if (isStyleValid) {
				const _additional_upcharge = ReactDOM.findDOMNode(this.refs.upcharge).value;
				if (parseInt(_additional_upcharge) > 0) {
					let upcharges = _.compact(this.upCharges.filter((upcharge) => {
						return upcharge.type != ADDITIONAL_UPCHARGE;
					}));
					upcharges.push({
						type: ADDITIONAL_UPCHARGE,
						value: parseInt(_additional_upcharge),
						unit: UPCHARGE_UNIT_VALUE
					});
					this.upCharges = upcharges;
				}
				let profile_name = null;
				if (ReactDOM.findDOMNode(this.refs.profile_name)) {
					profile_name = ReactDOM.findDOMNode(this.refs.profile_name).value
				}
				this.props.save(this.fabricDesign, ReactDOM.findDOMNode(this.refs.comment).value, this.upCharges, true, {
					profile: {
						name: this.props.profile ? this.props.profile.name : profile_name,
						item_type_id: 0,
						profile_id: this.props.profile ? this.props.profile.profile_id : -1,
						fabric_design: this.fabricDesign,
						comment: ReactDOM.findDOMNode(this.refs.comment).value
					}
				});
				//this.props.close();
			} else {
				Popup.create({
					title: 'Styling Validation Error',
					content: 'All Fields are Mandatory',
					buttons: {
						left: [{
							text: 'CANCEL',
							action: function () {
								Popup.close();
							}
						}],
						right: [{
							text: 'OK',
							action: function () {
								Popup.close();
							}
						}]
					}
				});
				// this.props.dispatch(updateMessage('MEARSUREMENT_FORM_VALIDATION', 'All fields are mandatory'));
				//window.scrollTo(0, 0);
			}
			return isStyleValid;
		}
	}
	toggleAccordion(activeKey) {
		this.props.toggleAccordion(activeKey);
	}
	getStylesFormFields() {

		var _that = this;

		let fabric_designs;
		if (this.props.isUpdate) {
			fabric_designs = this.fabricDesign;
		} else {
			fabric_designs = this.props.profile ? this.props.profile.fabric_design : this.fabricDesign;
		}

		let is_collapse = false;
		if (fabric_designs && fabric_designs.length > 0) {
			const _styles = fabric_designs.map((type) => {
				var designs = type.Designs && type.Designs.map((design) => {
					if (!this.props.displayUpcharge || !_.isEmpty(design.upcharge) || design.isupcharge) {

						if (design.type == 'option') {
							// 	if (design.name == "BUTTONS") {
							// 		let buttonSkuObj = _.find(fabric_designs[0].Designs, { name: "BUTTON SKU" });
							// 		//_that.saveDesignSelectionText.bind(this, type.id, design.id)
							// 		let selectedRecord =  _.find(_that.props.item_type_style_dropdown, { name:buttonSkuObj.text}); 

							// 		return(
							// 			<div className={cx('input-group')}>
							// 				<label htmlFor="fit" className="required">BUTTONS</label>
							// 				<SelectForm type="BUTTONS" rel="BUTTONS" options={_that.props.item_type_style_dropdown} value={selectedRecord?selectedRecord.id:""} save={ _that.saveDesignSelectionText.bind(this, type.id, buttonSkuObj.id)}/>
							// 			</div>

							// 		)


							// }
							let upchargesList = _that && _that.upCharges;
							let scopeUpcharges = _that.getUpcharge(design, design.selected, upchargesList);

							const upcharge = _that.hasUpcharge(design, design.selected, scopeUpcharges);

							console.log("upcharge", upcharge);
							return (
								<div className={cx('input-group')} key={design.id + design.type}>
									<label htmlFor={"type-" + type.id + "-design-" + design.id}>{design.name}</label>
									<MultipleChoice
										isMultiple={false}
										options={design.values}
										selected={design.values[design.selected]}
										disabled={design.disabled}
										rel={"design-" + design.id}
										save={_that.saveDesignSelection.bind(this, type.id, design.id)}
									/>
									<span className={cx({
										'foot-note': true,
										'design': true,
										'green': upcharge
									})}>{(upcharge) ? "Upcharge:  " + upcharge.display_name : "No Upcharge"}</span>
								</div>
							);
						} else if (design.type == 'text') {
							let disableInputField = false;
							if (design.dependentName == "BUTTONS") {
								let design_dependent_record = _.find(type.Designs, { name: design.dependentName });
								if (design_dependent_record && design_dependent_record.text) {
									disableInputField = true;
									//design.text = design_dependent_record.text;
								}
								// let buttonsObj = _.find(fabric_designs[0].Designs, { name: "BUTTONS" });
								// if (buttonsObj && (buttonsObj.values[buttonsObj.selected] == "Tonal")) {
								//disableInputField = false;
								//}

							}
							if (design.is_lining_dependent == "true") {
								let design_dependent_record = _.find(type.Designs, { name: design.dependentName });
								if (design_dependent_record && design_dependent_record.text) {
									disableInputField = true;
									//design.text = design_dependent_record.text;
								}
								// let buttonsObj = _.find(fabric_designs[0].Designs, { name: "BUTTONS" });
								// if (buttonsObj && (buttonsObj.values[buttonsObj.selected] == "Tonal")) {
								//disableInputField = false;
								//}

							}

							return (
								<div className={cx('input-group')} key={design.id + design.type}>
									<label htmlFor={"type-" + type.id + "-design-" + design.id}>{design.name}</label>
									<input type="text" rel={"design-" + design.id} value={design.text} onChange={_that.saveDesignSelectionText.bind(this, type.id, design.id)} disabled={disableInputField} />
								</div>
							);
						} else if (design.type == 'combo') {
							let options = [];
							let display_as_text = false;
							let upchargeValue = "";
							let selectedRecord = {};
							if (design.reference === 'liningsku') {
								/**
								 * Format the Data
								 */
								let design_dependent_record = _.find(type.Designs, { "liningDependent": "true", name: design.dependentName });
								if (design_dependent_record && design_dependent_record.selected != -1 && !isNaN(parseInt(design_dependent_record.selected)) && design_dependent_record.selected != 2) {
									options = _.filter(lining_sku, { 'type': design_dependent_record.selected });
								} else {
									display_as_text = true;
								}
							}
							if (design.name === 'BUTTONS') {
								/**
								 * Format the Data
								 */
								if (_that.props.item_type_style_dropdown) {
									options = _that.props.item_type_style_dropdown;
									selectedRecord = _.find(options, { 'name': design.text })
									upchargeValue = (selectedRecord) ? selectedRecord.upcharge : "";
								}
							}
							if (design.is_lining_fabric === 'true') {
								/**
								 * Format the Data
								 */
								if (_that.props.item_style_lining_dropdown) {
									options = _that.props.item_style_lining_dropdown;
									selectedRecord = _.find(options, { 'name': design.text })
									upchargeValue = (selectedRecord) ? selectedRecord.upcharge : "";
								}
							}
							return (
								<div className={cx('input-group')} key={design.id + design.type}>
									<label htmlFor={"type-" + type.id + "-design-" + design.id}>{design.name}</label>
									{
										display_as_text ? <input type="text" rel={"design-" + design.id} value={design.text} onChange={_that.saveDesignSelectionText.bind(this, type.id, design.id)} /> : <SelectForm options={options}
											value={design.text}
											save={_that.saveDesignSelectionCombo.bind(this, type.id, design.id)}
										/>}
									<span className={cx({
										'foot-note': true,
										'design': true,
										'green': upchargeValue
									})}>{(upchargeValue) ? "Upcharge:  " + upchargeValue : "No Upcharge"}</span>
								</div>
							)
						}
					}
				});
				let elements = null;
				if (type.collapse) {
					is_collapse = true;
					elements = (
						<Panel header={type.name} key={type.id}>
							<div className={cx('input-category')} key={type.id} >
								{designs}
							</div>
						</Panel>
					);
				} else {
					elements = (
						<div className={cx('input-category')} key={type.id} >
							<h3>{type.name}</h3>
							{designs}
						</div>
					)
				}

				return elements;
			});
			if (is_collapse) {
				return <Collapse
					accordion={this.accordion}
					onChange={this.toggleAccordion}
					activeKey={this.props.activeKey}
				>{_styles}</Collapse>
			} else {
				return _styles;
			}
		}
	}
	render() {
		if (!this.fabricDesign) {
			this.updateFabricDesign(this.props);
		}
		let hideSaveCancelButton = (<span className={cx('buttons-flex-group')}><button className={cx('cancel', 'action', 'secondary')} onClick={this.props.close}>Cancel</button>
			<button onClick={this.saveAndClose} className={cx('action', 'primary')} >Save</button></span>);
		if (this.props.hideSaveCancelButton) {
			hideSaveCancelButton = "";
		}
		let styleComment;
		//	if(this.props.isUpdate){
		styleComment = this.state.styleComment;
		//}else{
		//styleComment = this.props.profile ? this.props.profile.comment : null;
		//	}
		let styleName = this.props.profile ? this.props.profile.name : null;


		let styleStateName;
		if (this.props.is_new_style) {
			if (this.props.style_profile_id) {
				let styleStateProfile = _.find(this.props.lists.style_profiles, { id: this.props.style_profile_id });
				if (styleStateProfile) {
					styleStateName = styleStateProfile.name;
				}
			} else {
				styleStateName = this.props.profile && this.props.profile.name;
			}

		} else {
			styleStateName = this.state.styleName;
		}
		let styling_disabled = false;
		let styling_profile;

		let labelField = '';
		if (!this.props.isUpdate) {
			labelField = <em className={cx('mandatory')}>*</em>;
		}



		if (this.props.isUpdate) {

			styling_disabled = true;
			styling_profile = (
				<div style={{
					display: 'none'
				}}>
					<div className={cx('input-group')}>
						<label htmlFor="profile_name">Styling Profile Name
							{labelField}
						</label>
						<input type="text" id="profile_name" ref="profile_name" value={styleName} disabled={true} />
					</div>
				</div>
			);
		} else {
			styling_profile = (<div className={cx('input-group')}>
				<label htmlFor="profile_name">Styling Profile Name
				<em className={"mandatory"}>*</em>
				</label>
				<input type="text" id="profile_name" value={styleStateName} ref="profile_name" />
			</div>);
		}


		return (
			<div className={cx('form-container')} >
				{styling_profile}
				{this.getStylesFormFields()}

				<div className={cx('input-group')}>
					<label htmlFor="comments">Custom Upcharge</label>
					<input type="number" id="upcharge" ref="upcharge" defaultValue={this.getAdditionalUpcharge()} />
				</div>
				<div className={cx('input-group')}>
					<label htmlFor="comments">Comments</label>
					<textarea id="comment" ref="comment" value={styleComment} onChange={this.onStyleCommentChange}></textarea>
				</div>
				{hideSaveCancelButton}
			</div>
		);
	}
}

StylesForm.propTypes = {
	lists: PropTypes.object,
	save: PropTypes.func,
	loadFields: PropTypes.func,
	fabricDesign: PropTypes.array,
	upcharges: PropTypes.array
};
export default StylesForm;