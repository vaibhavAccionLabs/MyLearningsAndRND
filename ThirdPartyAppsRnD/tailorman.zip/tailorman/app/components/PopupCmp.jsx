import React, { Component, PropTypes } from 'react';
import classNames from 'classnames/bind';
import styles from 'css/components/searchList';
import ReactDOM from 'react-dom';
import Select from 'react-select';
import clear from 'images/clear.png';
const cx = classNames.bind(styles);
import Popup from 'react-popup';


export default class PopupCmp extends Component {
    constructor(props) {
        // debugger;
        super(props);
    }

    search() {
        const keyword = ReactDOM.findDOMNode(this.refs.keyword).value;
        if (keyword.length === 0)
            this.hasSearched = false;
        this.props.search(keyword);
    }

    select(id) {
        this.selected = id;
        this.props.select(id);
      //  this.clear();
    }
    clear() {
        ReactDOM.findDOMNode(this.refs.keyword).value = '';
      //  this.search();
    }

    renderList(clearList) {
        const self = this;
        if ((this.props.results && this.props.results.length > 0)& !clearList.clearList) {
            return this.props.results.map((result, index) => {
                return <li onClick={self.select.bind(this, result.id)} className={cx({
                    'active': this.selected && String(this.selected).length > 0 && this.selected == result.id
                })} key={index}>
                    {this.props.renderItem(result)}
                </li>
            });
        } else {
            if (!this.hasSearched)
                return (<span className={cx('no-results-label')}>Please search above for results</span>);
            return (<span className={cx('no-results-label')}>No results match your query</span>);

        }

    }

    render() {
        
        let contentElement = (
			<div className={cx('form-container')}>
					<div className={cx('input-group')}>
						<label htmlFor="add_address">Add Shipping/Billing Address</label>
						<input type="add_address" id="add_address" />
					</div>
					{/* <div className={cx('input-group')}>
						<label htmlFor="address_country">Country</label>
						<SelectForm type="address_country" rel="address_country" fluid search={true} selection options={data.countries} save={this.setSelectedCountry.bind(this)} value={country}/>
					</div>
					<div className={cx('input-group')}>
						<label htmlFor="address_state">State</label>
						<SelectForm type="address_state" rel="address_state" fluid search={true} selection options={data.states} value={state} save={this.setSelectedState.bind(this)}/>
					</div> */}
					</div>
				);
        let popUp =  Popup.create({
					title: 'Add Address',
					content: contentElement,
					buttons: {
						left: [{
							text: 'CANCEL',
							action: function () {
								Popup.close();
							}
						}],
						right: [{
							text: 'ADD',
							action: function () {
								//Popup.close();
								self.addAddress();
							}
						}]
					}
				});
        return popUp;
    }
}

PopupCmp.propTypes = {
    // search: PropTypes.func,
    // select: PropTypes.func,
    // results: PropTypes.array,
    // renderItem: PropTypes.func,
    // placeholder: PropTypes.string
};