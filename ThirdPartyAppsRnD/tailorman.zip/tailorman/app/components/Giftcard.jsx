/**
* Gift Card
*/
import React, { Component } from 'react';
import classNames from 'classnames/bind';
import ReactDOM from 'react-dom';
import styles from 'css/components/giftcarddetails';
const cx = classNames.bind(styles);

class GiftCard extends Component {
    constructor(props) {
        super(props);
        this.Appplyvocher = this.Appplyvocher.bind(this);
        this.onVocherChange = this.onVocherChange.bind(this);
        this.onRedeemChange = this.onRedeemChange.bind(this);
        this.onRedeemCode = this.onRedeemCode.bind(this);
        this.state = {
            giftVocher: "",
            redeemAmount: "",
            errmsg: ''
        }
        this.baseState = this.state;

    }

    componentDidMount() {
        let { giftCardDetails } = this.props.giftcard
        this.setState({
            giftVocher: giftCardDetails && giftCardDetails.gift_vocher || ""
        })
    }

    Appplyvocher(e, value) {
        let { discounts } = this.props.orderdetails;
        if (this.state.giftVocher) {
            if (_.findIndex(discounts, { giftcard: this.state.giftVocher }) == -1) {
                this.props.validateGiftCupon(this.state.giftVocher, this.props.customerdetails.customer_id)

            } else {
                this.setState({
                    errmsg: "The coupon had been already used!"
                })
            }
            this.setState({
                redeemAmount: ""
            })

        }
    }

    onRedeemCode(e) {
        let { pending_amount, discounts } = this.props.orderdetails;
        let { giftCardDetails } = this.props.giftcard
        let redeemAmount = this.state.redeemAmount;
        let giftvalue = giftCardDetails.gift_amount
        let giftamount = {
            id: pending_amount.length + 1,
            payment_mode: 11,
            amount: this.state.redeemAmount,
            reference: '',
            isDisabled: true,
            gift_vocher_id: giftCardDetails.gift_vocher_id
        };
        let discount = {
            value: this.state.redeemAmount,
            giftcard: this.state.giftVocher,
            is_payment_mode: true
        }

        if (redeemAmount <= giftvalue && redeemAmount > 0) {
            this.setState({
                giftVocher: '',
                errmsg: ''
            })
            pending_amount.push(giftamount)
            this.props.updatePaymentdetails('pending_amount', pending_amount)
            this.props.updateGiftCardDiscount(discount)
            this.props.redeemGiftCuponAmount()
        } else {
            this.setState({
                errmsg: "Please enter the valid amount to redeem !"
            })
        }
    }
    onVocherChange(e) {
        this.setState({
            giftVocher: e.target.value,
            errmsg: ''
        });
    }

    onRedeemChange(e) {

        this.setState({
            redeemAmount: e.target.value,
            errmsg: ''
        });
    }
    render() {
        let { giftCardDetails } = this.props.giftcard
        let messageCls = giftCardDetails && giftCardDetails.isredeemable ? "" : 'failure'
        return (
            <div style={{ width: "40%" }}>
                <div className="promo_input">
                    <input type="text" placeholder='Please enter your gift code' value={this.state.giftVocher} onChange={(e) => { this.onVocherChange(e) }} />
                </div>
                <div className="reedom_button"  ><span className={messageCls}>{giftCardDetails.msg || this.state.errmsg}</span>
                    <button className={cx('submit', 'action', 'primary')} onClick={(e) => this.Appplyvocher()}>APPLY</button></div>
                {giftCardDetails.isredeemable ?
                    (<div><div style={{ width: "100%" }} className="promo_input"> <input type="number" placeholder='Please enter amount to redeem' value={this.state.redeemAmount} onChange={(e) => { this.onRedeemChange(e) }} /></div>
                        <div className="reedom_button" ><span className="failure" >{this.state.errmsg}</span><button className={cx('submit', 'action', 'primary')} onClick={(e) => this.onRedeemCode(e, this)}>REDEEM</button></div>

                        <div className='git-card-value'>
                            <div className='gift-value'> Gift value : <span style={{ float: 'right' }}><b>{giftCardDetails.gift_amount}</b></span><hr /></div>
                            <div>Validity : <span style={{ float: 'right' }}><b>{giftCardDetails.delivery_date}</b></span> <hr /></div>
                        </div></div>) : ''
                }

            </div>
        );
    }
}

export default GiftCard;