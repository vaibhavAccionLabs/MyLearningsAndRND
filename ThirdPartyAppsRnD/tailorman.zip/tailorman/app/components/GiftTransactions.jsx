import React, { Component } from 'react';
const cx = classNames.bind(styles);
import classNames from 'classnames/bind';
import styles from 'css/components/giftcarddetails';
import back from 'images/back-arrow.png';
import { Link } from 'react-router';
import { connect } from 'react-redux';
import {fetchGiftTransactions} from 'actions/giftcard'
import moment from 'moment';

// const transactions=[{amount:500,traxactionId:'#123',vocher:'abcde'},{amount:600,traxactionId:'#3456',vocher:'efghei'}]

class GiftTransactions extends Component{

	constructor(props){
		super(props);

	}
    componentDidMount(){
    	this.props.dispatch(fetchGiftTransactions(this.props.params.giftvoucherId))
    }
    renderTransactions(){
    	  	let giftTransactions = this.props.giftcard.giftTransactions || []
    	  		return (giftTransactions.length>0 ? <div className={cx('payment-details')}>
								<table>
									<tr>
									    <th>Order Id</th>
									    {/* <th>Gift Vocher Id</th> */}
										{/* <th>Gift_transaction_id</th> */}
										<th>Amount</th>
										<th>Created On</th>
									</tr>
							        {giftTransactions.map((item,index)=>{
		                                return <tr key={index}>
										     		<td>{item.order_id}</td>
										     		{/* <td>{item.gift_vocher_id}</td> */}
													{/* <td>{item.gift_transaction_id}</td> */}
													<td>{item.amount}</td>
													<td>{moment(item.created).format('YYYY-MM-DD')}</td>
								     			</tr>
							         	 })
								    }
								</table>
				        </div> : <div style={{'textAlign':'center',width: '100%'}}>No transactions Available </div>)
    }
  render(){
  	let giftvoucherId = this.props.params.giftvoucherId;

  	console.log('hello',this.props.giftcard.giftTransactions)
  	return(
  			<div className={cx('container')} >
  			<Link to="/giftcards" className={cx('back')} ><img src={back} /></Link>
  			<h1>Gift Card Transactions</h1>
		  		{this.renderTransactions()}
			</div>
		)
  }

}


function mapStateToProps({giftcard}) {
	return {
		giftcard
	};
}
export default connect(mapStateToProps)(GiftTransactions);