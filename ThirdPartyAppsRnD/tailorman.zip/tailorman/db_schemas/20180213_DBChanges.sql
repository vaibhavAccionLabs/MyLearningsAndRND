
alter table b_order add column approved_by character varying;

-- FUNCTION: public."UpdateOrderV2"integer, integer, integer, integer, integer, integer, date, character varying, date, character varying, character varying, character varying, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, integer, date, json, integer, json

-- DROP FUNCTION public."UpdateOrderV2"integer, integer, integer, integer, integer, integer, date, character varying, date, character varying, character varying, character varying, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, integer, date, json, integer, json;

CREATE OR REPLACE FUNCTION public."UpdateOrderV2"(
	in_order_id integer,
	in_tailor_id integer,
	in_customer_id integer,
	in_order_type_id integer,
	in_store_id integer,
	in_user_id integer,
	in_order_date date,
	in_occasion character varying,
	in_occation_date date,
	in_benficiary_name character varying,
	in_benficiary_mobile character varying,
	in_benificiary_email character varying,
	in_priority_id integer,
	in_payment_type_id integer,
	in_payment_details character varying,
	in_total_amount double precision,
	in_comment character varying,
	in_display_name character varying,
	in_full_payment_flag character,
	in_billing_address character varying,
	in_delivery_address character varying,
	in_pin_number character varying,
	in_sales_man_id integer,
	in_pin_date date,
	in_redeemcoupon_json json,
	in_international_shipping_charges integer,
	in_shipping_taxes json,
    in_approved_by character varying)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

 
DECLARE

BEGIN 

update b_order set (
             tailor_id, customer_id, order_type_id, store_id, user_id, 
            order_date, occasion, occation_date, benficiary_name, benficiary_mobile, 
            benificiary_email, created_by, created_time, modified_by, modified_time, 
            priority_id, payment_type_id, payment_details,total_amount,comment,display_name,full_payment_flag,billing_address,delivery_address, pin_number,sales_man_id,pin_date,redeemcoupon_json,international_shipping_charges,shipping_taxes,approved_by)
    = ( in_tailor_id, in_customer_id, in_order_type_id, in_store_id, in_user_id, 
            in_order_date, in_occasion, in_occation_date,in_benficiary_name, in_benficiary_mobile, 
            in_benificiary_email, in_user_id, now(), in_user_id, now(), 
            in_priority_id, in_payment_type_id, in_payment_details,in_total_amount,in_comment,in_display_name,in_full_payment_flag, in_billing_address,in_delivery_address, in_pin_number,in_sales_man_id,in_pin_date,in_redeemcoupon_json,in_international_shipping_charges,in_shipping_taxes,in_approved_by) where order_id=in_order_id ;
return true ;
END;

$function$;

ALTER FUNCTION public."UpdateOrderV2"(integer, integer, integer, integer, integer, integer, date, character varying, date, character varying, character varying, character varying, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, integer, date, json, integer, json,character varying)
    OWNER TO tailorman_db;

------------------------------------------


-- FUNCTION: public."GetCustomerOrderList"integer

 DROP FUNCTION public."GetCustomerOrderList"(integer);

CREATE OR REPLACE FUNCTION public."GetCustomerOrderList"(
	in_customer_id integer)
RETURNS TABLE(order_id integer, tailor_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, priority_id integer, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, sales_man_id integer, shipping_charges integer,approved_by character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT o.order_id, o.tailor_id, o.customer_id, o.order_type_id, o.store_id, o.user_id, 
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
       o.priority_id, o.payment_type_id, o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag as is_full_payment ,o.billing_address,
       o.delivery_address, o.pin_number,o.sales_man_id,o.international_shipping_charges,o.approved_by as approved_details 
  FROM b_order o where o.customer_id=in_customer_id order by o.created_time desc
;
END;

$function$;

ALTER FUNCTION public."GetCustomerOrderList"(integer)
    OWNER TO tailorman_db;

------------------------------------------


DROP VIEW IF EXISTS public.v_orders;

CREATE OR REPLACE VIEW public.v_orders AS
 SELECT i.order_id,
    i.order_item_id,
    i.discount_comment,
    c.name AS customer,
    f.supplier_product_code AS sku,
    t.name AS tailor,
    sm.name AS salesman,
    i.qty,
    i.mrp AS base_price,
    i.mrp+i.upcharge_amount AS mrp,
    i.discount_amount,
    i.bill_amount,
    o.order_date,
    o.approved_by,
        CASE
            WHEN it.mtm_flag = 'Y'::bpchar THEN "left"(f.supplier_product_code::text, 2) || i.order_item_id
            ELSE NULL::text
        END AS imp_number,
    ft.code AS finish_type,
    s.address AS store,
    o.pin_number,
    ( SELECT ws.code
           FROM b_item_wf_stage s_1,
            b_workflow_stage ws
          WHERE s_1.workflow_stage_id = ws.stage_id AND s_1.order_item_id = i.order_item_id AND s_1.current_stage_flag = 'Y'::bpchar
         LIMIT 1) AS status,
    c.customer_id,
    c.email,
    c.mobile,
    ( SELECT pf.profile_name
           FROM b_item_wf_stage s_1,
            b_customer_measurement_profile pf
          WHERE s_1.profile_id = pf.profile_id AND s_1.order_item_id = i.order_item_id AND s_1.workflow_stage_id = 1
         LIMIT 1) AS profile_name,
    replace(o.billing_address::text, '\n'::text, ''::text) AS billing_address,
    c.address AS customer_address,
    c.dob AS customer_dob
   FROM b_order_item i
     JOIN b_order o ON o.order_id = i.order_id
     JOIN m_item_type it ON i.item_type_id = it.item_type_id
     LEFT JOIN m_customer c ON o.customer_id = c.customer_id
     LEFT JOIN m_fabric f ON i.sku_id = f.fabric_id
     LEFT JOIN m_store s ON o.store_id = s.store_id
     LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id
     LEFT JOIN m_sales_man sm ON o.sales_man_id = sm.sales_man_id
     LEFT JOIN m_finish_type ft ON i.finish_type = ft.finish_type_id
  ORDER BY i.order_id, i.order_item_id;

ALTER TABLE public.v_orders
    OWNER TO tailorman_db;