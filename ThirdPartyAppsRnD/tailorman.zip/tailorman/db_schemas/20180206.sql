CREATE TABLE capilary_tiers(
    capilary_tiers_id serial,
    name  character varying(500) NOT NULL,
    code  character varying(500) NOT NULL,
    rangefrom integer,
    rangeTo   integer,
    isactive character(1) DEFAULT 'Y'::bpchar NOT NULL,
	created timestamp without time zone DEFAULT now() NOT NULL,
    created_by integer, 
    updated timestamp without time zone DEFAULT now() NOT NULL,
    updated_by integer,
    fyearid character varying(500) NOT NULL 
);

insert into capilary_tiers(name,code,rangefrom,rangeTo,created,updated,fyearId) values('GOLD','GOLD TIER',500,5000,now(),now(),'2017-18');

CREATE TABLE capilary_charges(
    capilary_charges_id serial,
    name  character varying(500) NOT NULL,
    code  character varying(500) NOT NULL
);
insert into capilary_charges(name,code) values('Styling','STYLE');
insert into capilary_charges(name,code) values('Measurements','ALTER');

-- update capilary_charges set code = '' where code = 'ALTER';


CREATE TABLE capilary_charge_rules(
    capilary_charge_rules_id serial,
    name  character varying(500) NOT NULL,
	capilary_charges_id integer,
	capilary_tiers_id integer,
	min_amount integer,
	max_amount integer,
	max_orders integer,
    discount_type character varying
);
-- insert into capilary_charge_rules(name,capilary_charges_id,capilary_tiers_id,min_amount,max_amount,max_orders,discount_type) values('Order Gold Discount',1,1,2000,5000,5,'MULTIPLE');
            -- insert into capilary_charge_rules(name,capilary_charges_id,capilary_tiers_id,min_amount,max_amount,max_orders,discount_type) values('Order Gold ONE Alteration',2,1,2000,0,1,'SINGLE');


-- 
-- insert into capilary_charge_rules(name,capilary_charges_id,capilary_tiers_id,min_amount,max_amount,max_orders) values('Order Measurements',2,1,100,1000,1);

-- select ccr.name,ccr.capilary_charge_rules_id,ccr.min_amount,ccr.max_amount,ccr.max_orders from capilary_charge_rules ccr LEFT JOIN  
-- capilary_tiers ct ON ct.capilary_tiers_id =ccr.capilary_tiers_id LEFT JOIN capilary_charges cc ON cc.capilary_charges_id = ccr.capilary_charges_id where ccr.name='Order Styling' and ct.name ="GOLD"


-- select * from capilary_charge_customer_trx where order_id =order_id
CREATE TABLE capilary_charge_customer_trx(
    capilary_charge_customer_trx_id serial,
    customer_id integer,
	order_id integer,
	fyearid character varying(500) NOT NULL, 
	capilary_charge_rules_id integer,
	discount_amount integer
);


-- select ccr.max_orders,ct.fyearid,ccr.name from capilary_charge_rules ccr LEFT JOIN capilary_tiers ct ON ct.capilary_tiers_id =ccr.capilary_tiers_id LEFT JOIN capilary_charges cc ON cc.capilary_charges_id = ccr.capilary_charges_id where ccr.name='Order Measurements' and ct.name ='GOLD';


-- select  count(*) from capilary_charge_customer_trx  cct LEFT JOIN capilary_charge_rules ccr ON ccr.capilary_charge_rules_id =cct.capilary_charge_rules_id where cct.customer_id=21722 and ccr.name='Order Measurements';



-- select ccr.max_orders,ct.fyearid,ccr.name,cct.order_id,ccr.min_amount,ccr.max_amount from capilary_charge_rules ccr LEFT JOIN capilary_tiers ct ON ct.capilary_tiers_id =ccr.capilary_tiers_id LEFT JOIN capilary_charges cc ON cc.capilary_charges_id = ccr.capilary_charges_id LEFT JOIN capilary_charge_customer_trx cct ON ccr.capilary_charge_rules_id =cct.capilary_charge_rules_id where ct.name ='GOLD' and cct.customer_id=21722;


--  select ccr.max_orders,ct.fyearid,ccr.capilary_charge_rules_id,ccr.name,(select array_to_string(array_agg(distinct order_id), ',')from capilary_charge_customer_trx where  capilary_charge_rules_id =ccr.capilary_charge_rules_id group by capilary_charge_rules_id),ccr.min_amount,ccr.max_amount  from capilary_charge_rules ccr LEFT JOIN capilary_tiers ct ON ct.capilary_tiers_id =ccr.capilary_tiers_id LEFT JOIN capilary_charges cc ON cc.capilary_charges_id = ccr.capilary_charges_id LEFT JOIN capilary_charge_customer_trx cct ON ccr.capilary_charge_rules_id =cct.capilary_charge_rules_id where ct.name ='GOLD' and cct.customer_id=21722  