-- Updated in file name 20170727_GetOrderListItemV2.sql


-- CREATE OR REPLACE FUNCTION public."GetOrderItemListV2"(IN in_order_id integer)
--     RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, comment character varying, profile_id integer, priority_id integer, display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, block character varying, item_size character varying, upcharge json, taxes json, discount_value double precision, discount_type integer, order_flag integer, bill_amount double precision, pickup_location character varying, discount_comment character varying)
--     LANGUAGE 'plpgsql'
--     VOLATILE
--     COST 100.0ROWS 1000.0 
-- AS $function$ 
-- declare
-- var_block character varying ;
-- var_item_size character varying ;

-- BEGIN 
 
--  return query 
-- SELECT i.order_item_id, i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
--       i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
--       i.comment, (select s.profile_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,var_block, var_item_size,
--       i.upcharge , i.taxes  ,i.discount,i.discount_type ,i.order_flag , i.bill_amount,(CASE WHEN i.pickup_id IS NOT NULL THEN (select name from store_locations where pickup_id =i.pickup_id) ELSE (CASE WHEN i.delivery_id  IS NOT NULL THEN (select address from m_customer_addresses where m_customer_addresses_id =i.delivery_id) ELSE '' END) END) as pickup_location,
--       i.discount_comment
--  FROM public.b_order_item i  
--  inner join m_fabric f on i.sku_id=f.fabric_id 
--  inner join m_item_type it on i.item_type_id = it.item_type_id
--  left join m_finish_type ft on i.finish_type = ft.finish_type_id
--  left join m_priority_type p on i.priority_id = p.priority_type_id
--  where i.order_Id=in_order_id 
 
--  ;

-- END;
-- $function$;
- FUNCTION: public."GetWorkOrderList"integer[], date, date, character varying, integer, integer

-- DROP FUNCTION public."GetWorkOrderList"integer[], date, date, character varying, integer, integer;
 DROP FUNCTION public."GetPendingWorkOrders"(in_customer_id integer);
CREATE OR REPLACE FUNCTION public."GetPendingWorkOrders"(in_customer_id integer,in_store_id integer)
RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, order_item_comment character varying, profile_id integer, priority_id integer, order_item_display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_details character varying, total_amount double precision, order_comment character varying, order_display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, tailor_name character varying, order_type text, store character varying, user_name character varying, payment_type character varying, sales_man character varying, customer_name character varying, customer_mobile character varying, customer_address character varying, cusomer_id integer, current_status character varying, current_stage_id integer)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$
  BEGIN 
  return query 
SELECT i.order_item_id, i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
       i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
       i.comment, (select s.profile_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
       o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,pm.code ,sm.name,
       c.name, c.mobile, c.address , c.customer_id ,(select ws.code from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),
       (select ws.stage_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1)
  FROM public.b_order_item i , m_fabric f, m_item_type it , m_finish_type ft , m_priority_type p ,
  b_order o , m_tailor t,  m_store s, m_user u,m_payment_type pm , m_sales_man sm ,m_customer c 

  where i.order_id=o.order_id
	and i.sku_id=f.fabric_id 
	and i.item_type_id = it.item_type_id
	and i.finish_type = ft.finish_type_id
	and i.priority_id = p.priority_type_id
	and o.tailor_id = t.tailor_id
	and o.store_id =in_store_id
	and o.payment_type_id =pm.payment_type_id
	and o.sales_man_id = sm.sales_man_id
	and o.user_id=u.user_id
	and c.customer_id =o.customer_id
	and exists (select 1 from b_item_wf_stage s where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' and s.workflow_stage_id =13)
    and (o.customer_id =in_customer_id or in_customer_id is null)
  ;

END;

$function$;

ALTER FUNCTION public."GetPendingWorkOrders"(integer)
    OWNER TO tailorman_db;


CREATE OR REPLACE FUNCTION public.UpdateOrderItem(
	in_order_id integer,
	in_order_item_id integer,
	in_style_id integer,
	in_workflow_id integer,
	in_sku_id integer,
	in_item_type_id integer,
	in_mrp double precision,
	in_qty integer,
	in_finish_type integer,
	in_fit_on_date date,
	in_delivery_date date,
	in_comment character varying,
	in_profile_id integer,
	in_priority_id integer,
	in_display_name character varying,
	in_upcharge json,
	in_taxes json,
	in_discount_type integer,
	in_discount_value double precision,
	in_order_flag integer,
	in_bill_amount double precision,
	in_upcharge_amount double precision,
	in_delivery_upcharge_amount double precision,
	in_discount_amount double precision,
	in_discount_comment character varying)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE
var_order_item_id integer;
var_start_stage_id integer;
BEGIN 
 
if in_order_flag =2 then 
	var_start_stage_id :=0;
else
var_start_stage_id :=1;
end if;

update b_order_item set (
             style_id , sku_id, item_type_id, 
             mrp , qty , finish_type , fit_on_date , delivery_date ,comment , profile_id,priority_id,display_name,upcharge , taxes  ,discount_type, discount,order_flag,bill_amount,
             upcharge_amount, 
       delivery_upcharge_amount, discount_amount,discount_comment)
    = ( in_style_id,  in_sku_id, in_item_type_id, 
             in_mrp , in_qty , in_finish_type , in_fit_on_date , in_delivery_date,in_comment,in_profile_id,in_priority_id,in_display_name,in_upcharge , 
    in_taxes  ,   in_discount_type,  in_discount_value ,in_order_flag,in_bill_amount,in_upcharge_amount, 
      in_delivery_upcharge_amount, in_discount_amount,in_discount_comment) 
             where order_id= in_order_id and order_item_id =in_order_item_id and workflow_id =in_workflow_id;

update b_item_wf_stage s set current_stage_flag ='N' 
		where s.workflow_id=in_workflow_id 
		and s.order_item_id=in_order_item_id;

		update b_item_wf_stage s
			set profile_id=in_profile_id , comment=in_comment ,current_stage_flag ='Y' , created_time=now()
		where s.workflow_id=in_workflow_id and s.workflow_stage_id=var_start_stage_id
		and s.order_item_id=in_order_item_id;
		if not found then

		insert into b_item_wf_stage(workflow_id ,
						    workflow_stage_id ,
						    order_item_id ,
						    profile_id ,
						    comment ,
						    user_id  ,
						    created_time ) values

						    (in_workflow_id ,
						    var_start_stage_id ,
						    in_order_item_id ,
						    in_profile_id ,
						    in_comment ,
						    (select user_id from b_order where order_id=in_order_id) ,
						    now()

						    );

		end if;
             
return true ;
END;

$function$;



CREATE OR REPLACE FUNCTION public.SaveOrderItem(
	in_order_id integer,
	in_style_id integer,
	in_workflow_id integer,
	in_sku_id integer,
	in_item_type_id integer,
	in_mrp double precision,
	in_qty integer,
	in_finish_type integer,
	in_fit_on_date date,
	in_delivery_date date,
	in_comment character varying,
	in_profile_id integer,
	in_priority_id integer,
	in_display_name character varying,
  in_workflow_start_stage_id integer)
RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE
var_order_item_id integer;
BEGIN 
select nextval ('b_order_item_order_item_id_seq') into var_order_item_id;
INSERT INTO b_order_item(
            order_item_id, order_id, style_id, workflow_id, sku_id, item_type_id, 
             mrp , qty , finish_type , fit_on_date , delivery_date ,comment , profile_id,priority_id,display_name)
    VALUES (var_order_item_id, in_order_id, in_style_id, in_workflow_id, in_sku_id, in_item_type_id, 
             in_mrp , in_qty , in_finish_type , in_fit_on_date , in_delivery_date,in_comment,in_profile_id,in_priority_id,in_display_name);

	if exists (select 1 from m_item_type where item_type_id =in_item_type_id and mtm_flag='Y') then
				insert into b_item_wf_stage(workflow_id ,
						    workflow_stage_id ,
						    order_item_id ,
						    profile_id ,
						    comment ,
						    user_id  ,
						    created_time ) values

						    (in_workflow_id ,
						    in_workflow_start_stage_id ,
						    var_order_item_id ,
						    in_profile_id ,
						    in_comment ,
						    (select user_id from b_order where order_id=in_order_id) ,
						    now()

						    );
	end if;

return var_order_item_id ;
END;

$function$;


CREATE OR REPLACE FUNCTION public."UpdateOrderItem"(
	in_order_id integer,
	in_order_item_id integer,
	in_style_id integer,
	in_workflow_id integer,
	in_sku_id integer,
	in_item_type_id integer,
	in_mrp double precision,
	in_qty integer,
	in_finish_type integer,
	in_fit_on_date date,
	in_delivery_date date,
	in_comment character varying,
	in_profile_id integer,
	in_priority_id integer,
	in_display_name character varying,
	in_upcharge json,
	in_taxes json,
	in_discount_type integer,
	in_discount_value double precision,
	in_order_flag integer,
	in_bill_amount double precision,
	in_upcharge_amount double precision,
	in_delivery_upcharge_amount double precision,
	in_discount_amount double precision,
	in_discount_comment character varying,
  in_workflow_start_stage_id integer)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE
var_order_item_id integer;
var_start_stage_id integer;
BEGIN 
 
if in_order_flag =2 then 
	var_start_stage_id :=0;
else
var_start_stage_id :=1;
end if;
if in_workflow_start_stage_id  IS NOT NULL then
 var_start_stage_id:= in_workflow_start_stage_id;
 end if;

update b_order_item set (
             style_id , sku_id, item_type_id, 
             mrp , qty , finish_type , fit_on_date , delivery_date ,comment , profile_id,priority_id,display_name,upcharge , taxes  ,discount_type, discount,order_flag,bill_amount,
             upcharge_amount, 
       delivery_upcharge_amount, discount_amount,discount_comment)
    = ( in_style_id,  in_sku_id, in_item_type_id, 
             in_mrp , in_qty , in_finish_type , in_fit_on_date , in_delivery_date,in_comment,in_profile_id,in_priority_id,in_display_name,in_upcharge , 
    in_taxes  ,   in_discount_type,  in_discount_value ,in_order_flag,in_bill_amount,in_upcharge_amount, 
      in_delivery_upcharge_amount, in_discount_amount,in_discount_comment) 
             where order_id= in_order_id and order_item_id =in_order_item_id and workflow_id =in_workflow_id;

update b_item_wf_stage s set current_stage_flag ='N' 
		where s.workflow_id=in_workflow_id 
		and s.order_item_id=in_order_item_id;

		update b_item_wf_stage s
			set profile_id=in_profile_id , comment=in_comment ,current_stage_flag ='Y' , created_time=now()
		where s.workflow_id=in_workflow_id and s.workflow_stage_id=var_start_stage_id
		and s.order_item_id=in_order_item_id;
		if not found then

		insert into b_item_wf_stage(workflow_id ,
						    workflow_stage_id ,
						    order_item_id ,
						    profile_id ,
						    comment ,
						    user_id  ,
						    created_time ) values

						    (in_workflow_id ,
						    var_start_stage_id ,
						    in_order_item_id ,
						    in_profile_id ,
						    in_comment ,
						    (select user_id from b_order where order_id=in_order_id) ,
						    now()

						    );

		end if;
             
return true ;
END;
$function$



