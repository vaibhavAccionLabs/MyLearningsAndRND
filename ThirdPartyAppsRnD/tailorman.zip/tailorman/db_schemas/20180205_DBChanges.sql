-- FUNCTION: public."SaveCustomer"character varying, character varying, date, character varying, character varying, character varying, double precision, double precision, integer, character varying

-- DROP FUNCTION public."SaveCustomer"character varying, character varying, date, character varying, character varying, character varying, double precision, double precision, integer, character varying;

CREATE OR REPLACE FUNCTION public."SaveCustomer"(
	in_name character varying,
	in_gender character varying,
	in_dob date,
	in_mobile character varying,
	in_email character varying,
	in_height double precision,
	in_weight double precision,
	in_source_id integer,
	in_comment character varying)
RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE

var_customer_id integer;
BEGIN 

select m.customer_id into var_customer_id from m_customer m where m.email =in_email;
UPDATE public.m_customer
   SET name=in_name, gender=in_gender, dob=in_dob,
       height=in_height, weight=in_weight, source_id=in_source_id, comment=in_comment ,mobile=in_mobile
 WHERE email=in_email and trim(in_email) <>'';

 if not found then
select nextval ('m_customer_customer_id_seq') into var_customer_id;
INSERT INTO m_customer(
            customer_id, name, gender, dob, mobile, email, height, 
            weight, source_id,comment)
    VALUES (var_customer_id, in_name, in_gender, in_dob, in_mobile, in_email, in_height, 
            in_weight, in_source_id,in_comment);
end if;
return var_customer_id ;
END;

$function$;

ALTER FUNCTION public."SaveCustomer"(character varying, character varying, date, character varying, character varying, double precision, double precision, integer, character varying)
    OWNER TO tailorman_db;


--------------------------------------------------------------------------------------------------------


-- FUNCTION: public."UpdateCustomer"integer, character varying, character varying, date, character varying, character varying, character varying, double precision, double precision, integer, character varying

-- DROP FUNCTION public."UpdateCustomer"integer, character varying, character varying, date, character varying, character varying, character varying, double precision, double precision, integer, character varying;

CREATE OR REPLACE FUNCTION public."UpdateCustomer"(
	in_customer_id integer,
	in_name character varying,
	in_gender character varying,
	in_dob date,
	in_mobile character varying,
	in_email character varying,
	in_height double precision,
	in_weight double precision,
	in_source_id integer,
	in_comment character varying)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE

BEGIN 

UPDATE public.m_customer
   SET name=in_name, gender=in_gender, dob=in_dob,
       height=in_height, weight=in_weight, source_id=in_source_id, comment=in_comment ,mobile=in_mobile , email =in_email
 WHERE customer_id = in_customer_id;

return true ;
END;

$function$;

ALTER FUNCTION public."UpdateCustomer"(integer, character varying, character varying, date, character varying, character varying, double precision, double precision, integer, character varying)
    OWNER TO tailorman_db;
