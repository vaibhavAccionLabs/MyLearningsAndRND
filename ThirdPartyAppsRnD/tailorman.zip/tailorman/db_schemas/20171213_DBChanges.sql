CREATE TABLE public.b_customer_style_profile(
   profile_id serial NOT NULL,
   customer_id integer,
   item_type_id integer,
   order_item_id integer,
   profile_name character varying,
   fabric_design json,
   upcharge json
);
------------------------------------------------------
CREATE OR REPLACE FUNCTION public."SaveStylingProfile"(
	in_customer_id integer,
	in_item_type_id integer,
	in_profile_name character varying,
    order_item_id integer,
	fabric_design json,
    upcharge json)
RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE

var_profile_id integer;
BEGIN 

select nextval ('b_customer_style_profile_profile_id_seq') into var_profile_id;

INSERT INTO b_customer_style_profile(
            profile_id, customer_id, item_type_id, order_item_id, 
            profile_name, fabric_design,upcharge)
    VALUES (var_profile_id, in_customer_id, in_item_type_id,  order_item_id, 
            in_profile_name, fabric_design,upcharge);
return var_profile_id ;

END;

$function$;

ALTER FUNCTION public."SaveStylingProfile"(integer, integer, character varying,integer,json,json)
    OWNER TO tailorman_db;

------------------------------------------------------------
  CREATE OR REPLACE FUNCTION public."GetStylingProfileList"(
	in_customer_id integer,
	in_item_type_id integer)
    RETURNS TABLE(in_profile_name character varying,profile_id integer,customer_id integer,item_type_id integer,order_item_id integer,fabric_design json,comment character varying,upcharge json)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$
 BEGIN 
  return query SELECT m.profile_name,m.profile_id,m.customer_id,m.item_type_id,m.order_item_id,m.fabric_design,s.comment,m.upcharge
  from b_customer_style_profile m left join b_order_item_fabric_design s on m.order_item_id = s.order_item_id 
  where m.customer_id = in_customer_id and m.item_type_id = in_item_type_id;

END;

$function$;
ALTER FUNCTION public."GetStylingProfileList"(integer,integer)
    OWNER TO tailorman_db;

CREATE OR REPLACE FUNCTION public."GetOrderItemFabricDesign"(
	in_order_item_id integer)
RETURNS TABLE(order_item_id integer, fabric_design json, comment character varying,profile_name character varying,profile_id integer)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

BEGIN
RETURN QUERY  select d.order_item_id,d.fabric_design,d.comment,s.profile_name,s.profile_id from b_order_item_fabric_design d left join b_customer_style_profile s
 on d.order_item_id = s.order_item_id where d.order_item_id =in_order_item_id;

  
END;

$function$;

ALTER FUNCTION public."GetOrderItemFabricDesign"(integer)
    OWNER TO tailorman_db;

-------------------------------------------------
-- FUNCTION: public."SaveFabricDesign"integer, json, json, character varying,integer

-- DROP FUNCTION public."SaveFabricDesign"integer, json, json, character varying,integer;

CREATE OR REPLACE FUNCTION public."SaveFabricDesign"(
	in_order_item_id integer,
	in_fabric_design json,
	in_selected_fabric_design json,
	in_comment character varying,
    in_profile_id integer)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$



BEGIN

update b_customer_measurement_profile ucmp SET modified_flag = 1 where ucmp.profile_id IN ( select bcp.profile_id from b_order_item boi LEFT JOIN b_order bo ON bo.order_id = boi.order_id LEFT JOIN b_customer_measurement_profile bcp ON bo.customer_id = bcp.customer_id AND bcp.item_type_id = boi.item_type_id where boi.order_item_id = in_order_item_id AND modified_flag = 0);

update b_order_item_fabric_design set fabric_design = in_fabric_design, selected_fabric_design=in_selected_fabric_design, comment=in_comment where order_item_id=in_order_item_id;

if not found then
insert into b_order_item_fabric_design(order_item_id, fabric_design,selected_fabric_design,comment) values (in_order_item_id, in_fabric_design, in_selected_fabric_design, in_comment);

end if;

update b_customer_style_profile set fabric_design = in_fabric_design where profile_id = in_profile_id;
 return true;
END;



$function$;

ALTER FUNCTION public."SaveFabricDesign"(integer, json, json, character varying,integer)
    OWNER TO tailorman