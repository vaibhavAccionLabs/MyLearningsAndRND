-- Inserting new records in m_sales_man table

INSERT INTO m_sales_man(name) VALUES 
('Shakti'), 
('Anupriya'),
('Anulika'),
('Azra'),
('Bhoomika'),
('Sakeena');