CREATE OR REPLACE FUNCTION public."GetOrderDetails"(
	in_order_id integer)
    RETURNS TABLE(order_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, order_type text, store character varying, user_name character varying, payment_type character varying, shipping_charges integer, pin_date timestamp without time zone, redeemcoupon_json json, customer_email character varying, customer_name character varying, store_address character varying, state_code integer, gst_code character varying, city character varying, half_amount integer, store_initials character varying, invoice_number character varying, store_email character varying, shipping_taxes json, benficiary_mobile character varying, tailor_name character varying, sales_man character varying, tailor_id integer, sales_man_id integer )
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT o.order_id, o.customer_id, o.order_type_id, o.store_id, o.user_id, 
       o.order_date, o.created_by, o.created_time, o.modified_by, o.modified_time, 
        o.payment_type_id, o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
      (case when o.delivery_location_id ='courier' then o.delivery_address else ( case when o.delivery_location_id is null then o.delivery_address else (select ss.address from m_store ss where ss.store_id::text =o.delivery_location_id) end )  end) as delivery_address, o.pin_number,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,(select string_agg(DISTINCT p.code,',') :: character varying from c_order_payment cop LEFT JOIN m_payment_type p ON cop.payment_mode =p.payment_type_id where cop.order_id = in_order_id ) as payment_details, o.international_shipping_charges,o.pin_date,o.redeemcoupon_json,mc.email,mc.name,s.store_address,s.state_code,s.gst_code,s.city,(select SUM(cop.amount)::integer from c_order_payment cop where cop.order_id = in_order_id)as half_amount,s.store_initials,o.invoice_number,s.email,o.shipping_taxes, COALESCE(o.benficiary_mobile,''),t.name,sm.name,o.tailor_id,o.sales_man_id 
  FROM b_order o
  	--EFT JOIN c_order_payment cop on cop.order_id = in_order_id
    LEFT JOIN m_store s on o.store_id =s.store_id
    LEFT JOIN m_store ss on o.store_id =ss.store_id
    LEFT JOIN m_user u on o.user_id=u.user_id
    LEFT JOIN m_payment_type p on o.payment_type_id =p.payment_type_id
    LEFT JOIN m_customer mc on o.customer_id=mc.customer_id
    LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id
    LEFT JOIN m_sales_man sm ON o.sales_man_id = sm.sales_man_id
where o.order_id=in_order_id;
END;

$function$;

ALTER FUNCTION public."GetOrderDetails"(integer)
    OWNER TO postgres;


-----------------------


-- FUNCTION: public."UpdateOrderPayment"(integer, integer, integer, boolean, json)

-- DROP FUNCTION public."UpdateOrderPayment"(integer, integer, integer, boolean, json);

CREATE OR REPLACE FUNCTION public."UpdateOrderPayment"(
	in_order_id integer,
	in_cutomer_id integer,
	in_workflow_id integer,
	in_success boolean,
	in_payment_response json)
    RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

DECLARE
var_start_stage_id integer;

 
BEGIN 

if in_success then 
  var_start_stage_id := 1;
  insert into c_order_payment (created_by,updated_by,store_id,order_id,customer_id,created,updated,amount,reference,payment_mode)select 0,0,11, in_order_id, bo.customer_id, now(),now(),bo.total_amount,'ONLINE',9 from b_order bo where bo.order_id = in_order_id;

else

    var_start_stage_id := -1;

end if;

update b_order b set work_flow_stage_id = in_workflow_id,order_date = now()::date where b.order_id = in_order_id;
-- update b_item_wf_stage b set workflow_stage_id = var_start_stage_id from  b_order bo LEFT JOIN b_order_item boi ON boi.order_id=bo.order_id  where bo.order_id =in_order_id;
update b_item_wf_stage b set workflow_stage_id = var_start_stage_id where b.order_item_id in (select order_item_id from b_order_item where order_id = in_order_id);
insert into order_payment(cutomer_id,order_id,created_date,success,payment_response) values (in_cutomer_id,in_order_id,now(),in_success,in_payment_response);

return true ;
END;

$function$;

ALTER FUNCTION public."UpdateOrderPayment"(integer, integer, integer, boolean, json)
    OWNER TO tailorman_db;

