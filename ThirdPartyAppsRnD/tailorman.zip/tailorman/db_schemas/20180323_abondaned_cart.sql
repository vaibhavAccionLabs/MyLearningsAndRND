ALTER TABLE public.b_order
    ADD COLUMN abon_mail_status boolean DEFAULT false;

DROP VIEW public.v_cart_abandoned;

CREATE OR REPLACE VIEW public.v_cart_abandoned AS
 SELECT bo.order_id,
    mc.name,
    mc.email,
    mc.mobile,
    mc.address,
    bo.order_date,
    bo.total_amount,
    bo.created_time,
    bo.abon_mail_status,
    ( SELECT array_to_json(array_agg(boi.*)) AS array_to_json
           FROM v_order_line boi
          WHERE boi.order_id = bo.order_id) AS order_items_list
   FROM b_order bo
     LEFT JOIN m_customer mc ON mc.customer_id = bo.customer_id
  WHERE bo.store_id = 11 
  AND bo.created_by = 0 
  AND NOT (bo.order_id IN ( SELECT op.order_id
           FROM order_payment op
           WHERE op.success = true));

ALTER TABLE public.v_cart_abandoned
    OWNER TO tailorman_db;

-- CREATE OR REPLACE VIEW public.v_cart_abandoned AS
--     select 
--         bo.order_id,
--         mc.name,
--         mc.email,
--         mc.mobile,
--         mc.address,
--         bo.order_date,
--         bo.total_amount,
--         (select 
--             array_to_json(array_agg(boi)) 
--             from v_order_line boi 
--             where boi.order_id = bo.order_id 
--         ) as order_items_list 
--         from b_order bo 
--         LEFT JOIN m_customer mc ON mc.customer_id = bo.customer_id
--         where 
--         bo.store_id = 11 AND 
--         bo.created_by = 0 AND 
--         bo.order_id NOT IN (select op.order_id from order_payment op where op.success = true);

-- ALTER TABLE public.v_cart_abandoned
--     OWNER TO tailorman_db;


CREATE OR REPLACE VIEW public.v_order_line AS
    SELECT 
    i.order_id,
    i.order_item_id,
    i.display_name,
    i.item_type_id,
    f.supplier_product_code,
    f.sku_code,
    i.qty,
    i.mrp AS base_price,
    i.mrp + i.upcharge_amount AS mrp,
    i.bill_amount,
    i.customer_fit_on_date,
    i.customer_delivery_date,
    ft.code AS finish_type,
    i.fit_on_date,
    i.delivery_date,
    i.comment,
    i.upcharge,
    ( SELECT ws.code
           FROM b_item_wf_stage s_1,
            b_workflow_stage ws
          WHERE s_1.workflow_stage_id = ws.stage_id AND s_1.order_item_id = i.order_item_id AND s_1.current_stage_flag = 'Y'::bpchar
         LIMIT 1) AS status,
          i.discount_comment,
          i.discount_amount,
          i.discount,
          i.discount_type,
          i.upcharge_amount,
          it.descr AS item_type_descr,
          it.mtm_flag,
          ( select boifm.fabric_measurements from b_order_item_fabric_measurement boifm where boifm.order_item_id = i.order_item_id) as fabricmeasurement
   FROM b_order_item i
     LEFT JOIN m_item_type it ON i.item_type_id = it.item_type_id
     LEFT JOIN m_fabric f ON i.sku_id = f.fabric_id
     LEFT JOIN m_finish_type ft ON i.finish_type = ft.finish_type_id
  ORDER BY i.order_id, i.order_item_id;

ALTER TABLE public.v_order_line
    OWNER TO tailorman_db;