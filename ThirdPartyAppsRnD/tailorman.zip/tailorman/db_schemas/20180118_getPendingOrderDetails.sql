DROP FUNCTION public."GetPendingWorkOrders"(
	in_customer_id integer,
	in_store_id integer);
CREATE OR REPLACE FUNCTION public."GetPendingWorkOrders"(
	in_customer_id integer,
	in_store_id integer)
RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, order_item_comment character varying, profile_id integer, priority_id integer, order_item_display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_details character varying, total_amount double precision, order_comment character varying, order_display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, tailor_name character varying, order_type text, store character varying, user_name character varying, payment_type character varying, sales_man character varying, customer_name character varying, customer_mobile character varying, customer_address character varying, cusomer_id integer, current_status character varying, current_stage_id integer, bespoke_url character varying,image bytea,style_id integer)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

  BEGIN 
  return query 
SELECT DISTINCT ON (i.order_item_id) i.order_item_id , i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
       i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
       i.comment, (select s.profile_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
       o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,pm.code ,sm.name,
       c.name, c.mobile, c.address , c.customer_id ,(select ws.code from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),
       (select ws.stage_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),o.bespoke_url,boi.image,i.style_id
  FROM public.b_order_item i  LEFT JOIN b_order_image boi ON boi.order_id=i.order_id and boi.image_id=i.item_type_id, m_fabric f, m_item_type it , m_finish_type ft , m_priority_type p ,
  b_order o , m_tailor t,  m_store s, m_user u,m_payment_type pm , m_sales_man sm ,m_customer c 

  where i.order_id=o.order_id
	and i.sku_id=f.fabric_id 
	and i.item_type_id = it.item_type_id
	and i.finish_type = ft.finish_type_id
	and i.priority_id = p.priority_type_id
	and o.tailor_id = t.tailor_id
	and o.store_id = s.store_id
    and o.store_id = in_store_id
	and o.payment_type_id =pm.payment_type_id
	and o.sales_man_id = sm.sales_man_id
	and o.user_id=u.user_id
	and c.customer_id =o.customer_id
	and exists (select 1 from b_item_wf_stage s where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' and s.workflow_stage_id =13)
    and (o.customer_id =in_customer_id or in_customer_id is null)
  ;

END;
$function$