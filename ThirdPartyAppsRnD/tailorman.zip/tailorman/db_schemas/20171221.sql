ALTER TABLE public.b_order
    ADD COLUMN pi_email_status boolean DEFAULT False;

DROP FUNCTION "GetOrderDetails"(integer);

CREATE OR REPLACE FUNCTION public."GetOrderDetails"(
	in_order_id integer)
    RETURNS TABLE(order_id integer, tailor_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, sales_man_id integer, tailor_name character varying, order_type text, store character varying, user_name character varying, payment_type character varying, sales_man character varying, shipping_charges integer, pin_date timestamp without time zone, redeemcoupon_json json,customer_email character varying,customer_name character varying,store_address character varying,state_code integer,gst_code character varying,city character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT o.order_id, o.tailor_id, o.customer_id, o.order_type_id, o.store_id, o.user_id, 
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
        o.payment_type_id, o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,o.sales_man_id  , t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,p.code ,sm.name, o.international_shipping_charges,o.pin_date,o.redeemcoupon_json,mc.email,mc.name,s.store_address,s.state_code,s.gst_code,s.city
  FROM b_order o , m_tailor t,  m_store s, m_user u,m_payment_type p , m_sales_man sm,m_customer mc
where o.order_id=in_order_id 
	and o.tailor_id = t.tailor_id
	and o.store_id =s.store_id
	and o.payment_type_id =p.payment_type_id
	and o.sales_man_id = sm.sales_man_id
	and o.user_id=u.user_id
    and o.customer_id=mc.customer_id
;
END;

$function$;

ALTER FUNCTION public."GetOrderDetails"(integer)
    OWNER TO tailorman_db;