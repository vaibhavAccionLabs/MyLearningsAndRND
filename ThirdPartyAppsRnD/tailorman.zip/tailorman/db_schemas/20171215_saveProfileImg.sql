

alter table b_order_image ADD COLUMN profile_id integer;

CREATE OR REPLACE FUNCTION public."SaveProfileImage"(
	in_profile_id integer,
	in_image_id integer,
	in_image bytea)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE

BEGIN 

insert into b_order_image(profile_id,image_id,image) values (in_profile_id,in_image_id, in_image);

return true;
END;

$function$;


CREATE OR REPLACE FUNCTION public."SaveOrderImage"(
	in_order_id integer,
	in_image_id integer,
	in_image bytea)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE

BEGIN 

insert into b_order_image(order_id,image_id,image) values (in_order_id,in_image_id, in_image);

return true;
END;

$function$;

ALTER FUNCTION public."SaveOrderImage"(integer, integer, bytea)
    OWNER TO tailorman_db;
