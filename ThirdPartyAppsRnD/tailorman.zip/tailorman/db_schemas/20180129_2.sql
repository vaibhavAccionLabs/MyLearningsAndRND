ALTER TABLE public.m_customer_addresses
    ADD COLUMN default_address boolean;



DROP FUNCTION public."GetCustomerAddressList"(integer);

CREATE OR REPLACE FUNCTION public."GetCustomerAddressList"(
	in_param integer)
RETURNS TABLE(m_customer_addresses_id integer, m_customer_id integer, address character varying, country character varying, state character varying,address_type character varying,default_address boolean)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN return query SELECT * FROM m_customer_addresses ca where ca.m_customer_id =in_param order by m_customer_addresses_id; END; 

$function$;

ALTER FUNCTION public."GetCustomerAddressList"(integer)
    OWNER TO tailorman_db;

