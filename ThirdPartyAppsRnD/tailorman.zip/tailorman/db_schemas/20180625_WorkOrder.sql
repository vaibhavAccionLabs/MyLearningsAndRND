DROP FUNCTION public."GetWorkOrderList"(integer[], date, date, character varying, integer, integer);

CREATE OR REPLACE FUNCTION public."GetWorkOrderList"(
	in_stage_id_list integer[],
	in_start_date date,
	in_end_date date,
	in_customer_param character varying,
	in_order_id integer,
	in_customer_id integer)
    RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, order_item_comment character varying, profile_id integer, priority_id integer, order_item_display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_details character varying, total_amount double precision, order_comment character varying, order_display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, tailor_name character varying, order_type text, store character varying, user_name character varying, payment_type character varying, sales_man character varying, customer_name character varying, customer_mobile character varying,customer_email character varying,customer_address character varying, cusomer_id integer, current_status character varying, current_stage_id integer, bespoke_url character varying, mtm_flag character)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query 
SELECT i.order_item_id, i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
       i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
       i.comment, (select s.profile_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
       o.payment_details, o.total_amount ,o.comment,o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,pm.code ,sm.name,
       c.name, c.mobile, c.email,c.address , c.customer_id ,(select ws.code from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),
       (select ws.stage_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),o.bespoke_url,it.mtm_flag
  FROM public.b_order_item i
  LEFT JOIN m_fabric f ON i.sku_id=f.fabric_id
  LEFT JOIN m_item_type it ON i.item_type_id = it.item_type_id
  LEFT JOIN m_finish_type ft ON i.finish_type = ft.finish_type_id
  LEFT JOIN m_priority_type p ON i.priority_id = p.priority_type_id
  LEFT JOIN b_order o ON i.order_id=o.order_id
  LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id
  LEFT JOIN m_store s ON o.store_id =s.store_id
  LEFT JOIN m_user u ON o.user_id=u.user_id
  LEFT JOIN m_payment_type pm ON o.payment_type_id =pm.payment_type_id
  LEFT JOIN m_sales_man sm ON o.sales_man_id = sm.sales_man_id
  LEFT JOIN m_customer c ON c.customer_id =o.customer_id
  where 
	o.order_date between in_start_date and in_end_date
	and exists (select 1 from b_item_wf_stage s where (in_stage_id_list @> ARRAY[s.workflow_stage_id]  or  cast (ARRAY[0] as integer [] ) <@ in_stage_id_list ) and s.order_item_id=i.order_item_id and s.current_stage_flag='Y')
	and (in_customer_param ='' or (c.name ilike  '%' || in_customer_param || '%' or c.mobile ilike '%' ||  in_customer_param || '%' or c.email ilike '%' ||  in_customer_param || '%' ))
	--and (in_store_id_list @> ARRAY[s.store_id]  or  cast (ARRAY[0] as integer [] ) <@ in_store_id_list )
	and (o.order_id= in_order_id or in_order_id is null)
	and (o.customer_id =in_customer_id or in_customer_id is null)
    AND i.is_active = true
    AND o.is_active = true;

END;

$function$;

ALTER FUNCTION public."GetWorkOrderList"(integer[], date, date, character varying, integer, integer)
    OWNER TO tailorman_db;