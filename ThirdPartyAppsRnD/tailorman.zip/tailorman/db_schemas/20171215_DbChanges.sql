DROP FUNCTION public."GetSKUDetails"(integer, character varying);

----

CREATE OR REPLACE FUNCTION public."GetSKUDetails"(
    in_item_type_id integer,
    in_product_sku_code character varying)
    RETURNS TABLE(fabric_id integer, fabric_sku_code character varying, name character varying, allow_custom_flag integer, allow_mtm_flag integer, allow_std_flag integer, mrp double precision, product_sku_code character varying, supplier_price double precision, fabric_width double precision, fabric_image_url character varying, fabric_lead_time double precision,is_bundled character varying, bundled_sku_list text)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$
 BEGIN 
  return query SELECT f.fabric_id,f.sku_code,f.name,f.allow_custom_flag,f.allow_mtm_flag,f.allow_std_flag,f.shirt_mrp,f.supplier_product_code,f.supplier_price,f.fabric_width,f.fabric_image_url,
  f.fabric_lead_time,f.is_bundled,f.bundled_sku_list
  from m_fabric f where item_type_id = in_item_type_id  and  f.supplier_product_code ilike  '%' || in_product_sku_code || '%' order by 1
;
END;

$function$;

ALTER FUNCTION public."GetSKUDetails"(integer, character varying)
    OWNER TO tailorman_db;
