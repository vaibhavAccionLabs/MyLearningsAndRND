CREATE OR REPLACE FUNCTION public."SaveCapillaryActivities"(
	in_event_name character varying,
	in_record_id integer,
	in_status boolean,
    in_updated_date timestamp with time zone,
	in_store_id integer
    )
    RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE

var_capillary_activities_id integer;

BEGIN 

select capillary_activities_id into var_capillary_activities_id from capillary_activities where event_name = in_event_name AND record_id = in_record_id limit 1;
		if not found then

		insert into capillary_activities(event_name,record_id,status,updated_date,store_id) values

						    (in_event_name ,
						    in_record_id ,
						    in_status ,
						    in_updated_date ,
						    in_store_id
						    );

		end if;
             
return true ;
END;

$function$;

ALTER FUNCTION public."SaveCapillaryActivities"(character varying, integer, boolean, timestamp with time zone, integer)
    OWNER TO tailorman_db;


