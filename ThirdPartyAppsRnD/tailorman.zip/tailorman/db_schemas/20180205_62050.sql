
ALTER TABLE public.m_tailor
    ADD COLUMN active boolean DEFAULT True;

CREATE OR REPLACE FUNCTION public."GetTailorList"(
	)
    RETURNS TABLE(tailor_id integer, tailor_name character varying, mobile character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$
 BEGIN 
  return query SELECT  t.tailor_id ,
  t.name,
  t.mobile from m_tailor t where t.active = true;
END;

$function$;

ALTER FUNCTION public."GetTailorList"()
    OWNER TO tailorman_db;



-------------------------------------------------


ALTER TABLE public.m_sales_man
    ADD COLUMN active boolean DEFAULT True;

CREATE OR REPLACE FUNCTION public."GetSalesManList"(
	)
    RETURNS TABLE(sales_man_id integer, sales_man_name character varying, mobile character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$
 BEGIN 
  return query SELECT  s.sales_man_id ,
  s.name,
  s.mobile from m_sales_man s where s.active = true;
END;

$function$;

ALTER FUNCTION public."GetSalesManList"()
    OWNER TO tailorman_db;


-- Update the 

-- 1. sujeeth
-- 2. naveen alokam
-- 3. sakeena

-- Active flag for the records to false.