-- FUNCTION: public."GetMeasurementProfileValuesV2"integer

-- DROP FUNCTION public."GetMeasurementProfileValuesV2"integer;

-- CREATE OR REPLACE FUNCTION public."GetMeasurementProfileValuesV2"(
-- 	in_profile_id integer)
-- RETURNS TABLE(measurement_type_id integer, value double precision, delta_flag_value boolean,measurement_type character varying)
--     LANGUAGE 'plpgsql'
--     COST 100.0
--     VOLATILE 
--     ROWS 1000.0
-- AS $function$
--  BEGIN 
--   return query SELECT m.measurement_type_id, m.value ,m.delta_flag_value, mt.code 
--   FROM b_profile_measurement m  , m_measurement_type mt

--   where  m.profile_id=in_profile_id 
-- and m.measurement_type_id = mt.measurement_type_id
-- order by mt.show_order_id
--   ;

-- END;

-- $function$;

-- ALTER FUNCTION public."GetMeasurementProfileValuesV2"(integer)
--     OWNER TO tailorman_db;
    
-- drop function "GetMeasurementProfileValuesV2"(integer)


alter table m_store add column user_name character varying,add column password character varying;

-- update m_store set user_name='tm.blr.touchstone1' , password='65deb51c7e8e307dd563268e5494a2e7' where store_id = 5;

-- update m_store set user_name='tm.blr.indiranagar1', password='65deb51c7e8e307dd563268e5494a2e7' where store_id = 2;

-- update m_store set user_name='tm.blr.jayanagar1', password='65deb51c7e8e307dd563268e5494a2e7' where store_id = 3;

-- update m_store set user_name='tm.blr.whitefield1', password='65deb51c7e8e307dd563268e5494a2e7' where store_id = 1;

-- update m_store set user_name='tm.blr.travellingteam1', password='65deb51c7e8e307dd563268e5494a2e7' where store_id = 4;

-- --Chennai
-- update m_store set user_name='tm.chn.collegeroad1', password='65deb51c7e8e307dd563268e5494a2e7' where store_id = 6;

-- update m_store set user_name='tm.chn.ttkroad1', password='65deb51c7e8e307dd563268e5494a2e7' where store_id = 8;

-- update m_store set user_name='tm.chn. phoenixmall1', password='65deb51c7e8e307dd563268e5494a2e7' where store_id = 7;

-- --Kolkata
-- update m_store set user_name='tm.kol.chowringheeroad1', password='65deb51c7e8e307dd563268e5494a2e7' where store_id = 10;

-- --Hyderabad
-- update m_store set user_name='tm.hyd.jubileehills1', password='65deb51c7e8e307dd563268e5494a2e7' where store_id = 9;

-- update m_store set user_name='tm.hyd.pgcentral1', password='65deb51c7e8e307dd563268e5494a2e7' where store_id = 13;
-- update m_store set user_name = 'demo.pawan1',password='62cc2d8b4bf2d8728120d052163a77df' where store_id = 11

-- Amazon -- tm.blr.amazon1 -- tm123
-- HNICORP -- tm.blr.hanicorp1 -- tm123
-- online -- tailorman.online1 --   tm123
-- https://www.md5hashgenerator.com/

alter table capillary_activities add column store_id integer 
