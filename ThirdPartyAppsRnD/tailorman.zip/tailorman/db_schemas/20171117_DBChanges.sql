-- Added delta_flag column as boolean
ALTER table m_measurement_type add column delta_flag boolean default false;
------------------------------------------------------------------------------------------------------------------------------------

update m_measurement_type set delta_flag = true where item_type_id =1, measurement_source_id=4 and code = 'Neck';
------------------------------------------------------------------------------------------------------------------------------------

ALTER table b_profile_measurement add column delta_flag_value boolean default false;
------------------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public."SaveMeasurementProfileValues"(
	in_profile_id integer,
	in_measurement_type_id integer,
	in_value double precision,
	in_descr character varying,
in_delta_flag_value boolean)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE
 
BEGIN 

UPDATE b_profile_measurement
   SET  
       value=in_value,
       descr=in_descr,
       delta_flag_value = in_delta_flag_value
 WHERE profile_id=in_profile_id  and measurement_type_id=in_measurement_type_id;

 if not found then
    INSERT INTO b_profile_measurement(
            profile_id, measurement_type_id, value, descr,delta_flag_value)
    VALUES (in_profile_id, in_measurement_type_id, in_value, in_descr,in_delta_flag_value);

   end if;
return true; 
END;

$function$;
------------------------------------------------------------------------------------------------------------------------------------