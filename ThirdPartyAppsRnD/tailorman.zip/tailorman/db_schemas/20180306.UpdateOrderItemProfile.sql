-------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public."UpdateOrderItemMeasurementProfile"(
	in_order_id integer,
	in_order_item_id integer,
	in_workflow_id integer,
	in_comment character varying,
	in_profile_id integer,
    in_workflow_start_stage_id integer
    )
    RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE

BEGIN 
    update b_item_wf_stage s
      set profile_id=in_profile_id , comment=in_comment ,current_stage_flag ='Y' , created_time=now()
    where s.workflow_id=in_workflow_id and s.workflow_stage_id=in_workflow_start_stage_id
    and s.order_item_id=in_order_item_id;
    if not found then

    insert into b_item_wf_stage(workflow_id ,
                workflow_stage_id ,
                order_item_id ,
                profile_id ,
                comment ,
                user_id  ,
                created_time ) values

                (in_workflow_id ,
                in_workflow_start_stage_id ,
                in_order_item_id ,
                in_profile_id ,
                in_comment ,
                (select user_id from b_order where order_id=in_order_id) ,
                now()

                );

    end if;
             
return true ;
END;

$function$;
