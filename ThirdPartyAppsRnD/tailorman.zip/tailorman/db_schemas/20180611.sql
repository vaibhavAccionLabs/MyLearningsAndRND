 DROP FUNCTION public."GetSKUSaleDetails"(character varying);

CREATE OR REPLACE FUNCTION public."GetSKUSaleDetails"(
	in_product_sku_code character varying)
    RETURNS TABLE(fabric_id integer, fabric_sku_code character varying, name character varying, allow_custom_flag integer, allow_mtm_flag integer, allow_std_flag integer, mrp double precision, product_sku_code character varying, supplier_price double precision, fabric_width double precision, fabric_image_url character varying, fabric_lead_time double precision, is_bundled character varying, bundled_sku_list text, item_type_id integer, code character varying,mtm_flag character,rtw_image_count integer,isavailableforweb boolean,item_type_name character varying,threedmeta json)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query 
  SELECT 
  f.fabric_id,
  f.sku_code,
  f.name,
  f.allow_custom_flag,
  f.allow_mtm_flag,
  f.allow_std_flag,
  f.shirt_mrp,
  f.supplier_product_code,
  f.supplier_price,
  f.fabric_width,
  f.fabric_image_url,
  f.fabric_lead_time,
  f.is_bundled,
  f.bundled_sku_list,
  f.item_type_id,
  mi.code,
  mi.mtm_flag,
  f.rtw_image_count,
  f.isavailableforweb,
  mi.descr,
  f.threedmeta
  from m_fabric f left join m_item_type mi on f.item_type_id = mi.item_type_id where f.supplier_product_code ilike  '%' || in_product_sku_code || '%' order by 1
;
END;

$function$;

ALTER FUNCTION public."GetSKUSaleDetails"(character varying)
    OWNER TO tailorman_db;


ALTER TABLE public.m_fabric
   ADD COLUMN threedmeta json;


------------------------------


-- GetSKUDetailsWithProductName

DROP FUNCTION public."GetSKUDetailsWithProductName"(character varying, character varying, character varying);

CREATE OR REPLACE FUNCTION public."GetSKUDetailsWithProductName"(
	in_product_name character varying,
	in_m_item_type_mtm_flag character varying,
	in_m_item_type_descr character varying)
    RETURNS SETOF TABLE(fabric_id integer, fabric_sku_code character varying, name character varying, is_bundled character varying, bundled_sku_list text, allow_custom_flag integer, allow_mtm_flag integer, allow_std_flag integer, mrp double precision, product_sku_code character varying, supplier_price double precision, fabric_width double precision, fabric_image_url character varying, fabric_lead_time double precision, type_view_option json, care_info character varying, construction character varying, item_type_id integer, item_type_name character varying, currency character varying, shortdescr character varying, mtm_flag character, color_info character varying, material_info character varying, count character varying, rtw_description character varying, rtw_image_count integer, default_style_code character varying, discount_value double precision, discount_type integer, discount_comment character varying, discount_amount double precision,threedmeta json)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN  
  return query SELECT 
    f.fabric_id,
    f.sku_code,
    f.name,
    f.is_bundled,
    f.bundled_sku_list,
    f.allow_custom_flag,
    f.allow_mtm_flag,
    f.allow_std_flag,
    f.shirt_mrp,
    f.supplier_product_code,
    f.supplier_price,
    f.fabric_width,
    f.fabric_image_url,
    f.fabric_lead_time,
  	t.view_option,
    f.care_info,
    f.construction,
    f.item_type_id,
    t.descr,
    cast('INR' as character varying),
    cast ( CONCAT(f.color_info,' ',t.descr) as character varying ),
    t.mtm_flag,
    f.color_info,
    f.material_info_for_wo,
    f.count,
    f.rtw_description,
    f.rtw_image_count,
    its.code,
    CASE WHEN ( t.discount=0 OR t.discount is null ) THEN f.discount ELSE t.discount END as discount_value,
    CASE WHEN ( t.discount=0 OR t.discount is null ) THEN f.discount_type ELSE t.discount_type END,
    CASE WHEN ( t.discount=0 OR t.discount is null ) THEN f.discount_comment ELSE t.discount_comment END,
    CASE WHEN ( t.discount=0 OR t.discount is null ) THEN ceiling(( f.shirt_mrp * f.discount)/100) ELSE ceiling(( f.shirt_mrp * t.discount)/100)  END as discount_amount,
    f.threedmeta
  from m_fabric f JOIN m_item_type t ON f.item_type_id = t.item_type_id
  LEFT JOIN product_style ps ON ps.sku_id = f.fabric_id
  LEFT JOIN item_type_style its ON its.item_type_style_id = ps.style_id
  where lower(f.name)  = lower(in_product_name) and t.mtm_flag=in_m_item_type_mtm_flag and lower(t.descr) =lower(in_m_item_type_descr)
;
END;

$function$;

ALTER FUNCTION public."GetSKUDetailsWithProductName"(character varying, character varying, character varying)
    OWNER TO tailorman_db;