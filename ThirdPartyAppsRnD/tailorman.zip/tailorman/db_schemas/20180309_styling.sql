-- select * from "GetStylingProfileList"(:in_customer_id, :in_item_type_id);

ALTER TABLE public.b_customer_style_profile
    ADD COLUMN created_date date DEFAULT now();

DROP FUNCTION "GetStylingProfileList"(integer,integer);

CREATE OR REPLACE FUNCTION public."GetStylingProfileList"(
	in_customer_id integer,
	in_item_type_id integer)
    RETURNS TABLE(profile_id integer, customer_id integer, item_type_id integer, order_item_id integer, in_profile_name character varying, fabric_design json, comments character varying,created_date date)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT 
	m.profile_id,
	m.customer_id,
	m.item_type_id,
	m.order_item_id,
	m.profile_name,
	m.fabric_design,
	m.comments,
    m.created_date
  from b_customer_style_profile m where m.customer_id = in_customer_id and m.item_type_id = in_item_type_id;

END;

$function$;

ALTER FUNCTION public."GetStylingProfileList"(integer, integer)
    OWNER TO tailorman_db;


---------------------------------
-------------------------------


-- FUNCTION: public."SaveFabricDesign"(integer, json, json, character varying, integer)

-- DROP FUNCTION public."SaveFabricDesign"(integer, json, json, character varying, integer);

CREATE OR REPLACE FUNCTION public."SaveFabricDesign"(
	in_order_item_id integer,
	in_fabric_design json,
	in_selected_fabric_design json,
	in_comment character varying,
	in_profile_id integer)
    RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

BEGIN

update b_customer_measurement_profile ucmp SET modified_flag = 1 where ucmp.profile_id IN ( select bcp.profile_id from b_order_item boi LEFT JOIN b_order bo ON bo.order_id = boi.order_id LEFT JOIN b_customer_measurement_profile bcp ON bo.customer_id = bcp.customer_id AND bcp.item_type_id = boi.item_type_id where boi.order_item_id = in_order_item_id AND modified_flag = 0);

update b_order_item_fabric_design set fabric_design = in_fabric_design, selected_fabric_design=in_selected_fabric_design, comment=in_comment,profile_id=in_profile_id where order_item_id=in_order_item_id;

if not found then
insert into b_order_item_fabric_design(order_item_id, fabric_design,selected_fabric_design,comment,profile_id) values (in_order_item_id, in_fabric_design, in_selected_fabric_design, in_comment,in_profile_id);

end if;

-- update b_customer_style_profile set fabric_design = in_fabric_design,comments=in_comment where profile_id = in_profile_id;
 return true;
END;

$function$;

ALTER FUNCTION public."SaveFabricDesign"(integer, json, json, character varying, integer)
    OWNER TO tailorman_db;