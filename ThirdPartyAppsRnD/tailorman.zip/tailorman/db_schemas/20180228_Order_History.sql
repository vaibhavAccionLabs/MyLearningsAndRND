CREATE OR REPLACE FUNCTION public."GetCustomerOrderHistory"(
	in_customer_id integer)
    RETURNS TABLE(order_id integer, display_name character varying,modified_time timestamp with time zone,order_date date, occation_date date,benficiary_mobile character varying,benficiary_name character varying,sale_items json)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT 
    o.order_id,
    o.display_name,
    o.modified_time,
    o.order_date,
    o.occation_date,
    o.benficiary_mobile,
    o.benficiary_name,
    (select (array_to_json(array_agg(b_order_item))) FROM b_order_item where b_order_item.order_id = o.order_id)
  FROM b_order o where o.customer_id=in_customer_id order by o.created_time desc
;
END;

$function$;

ALTER FUNCTION public."GetCustomerOrderHistory"(integer)
    OWNER TO tailorman_db;

