CREATE OR REPLACE FUNCTION public."GetCustomerOrderHistory"(
	in_customer_id integer)
    RETURNS TABLE(order_id integer, display_name character varying,modified_time timestamp with time zone,order_date date, occation_date date,benficiary_mobile character varying,benficiary_name character varying,sale_items json)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT 
    o.order_id,
    o.display_name,
    o.modified_time,
    o.order_date,
    o.occation_date,
    o.benficiary_mobile,
    o.benficiary_name,
    (select (array_to_json(array_agg(b_order_item))) FROM b_order_item where b_order_item.order_id = o.order_id)
  FROM b_order o where o.customer_id=in_customer_id order by o.created_time desc
;
END;

$function$;

ALTER FUNCTION public."GetCustomerOrderHistory"(integer)
    OWNER TO tailorman_db;


-----

-- select * from m_sales_man

insert into m_sales_man(name,is_active)values('Dipti',true);
insert into m_sales_man(name,is_active)values('Giridhar',true);

-----

-------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public."UpdateOrderItemMeasurementProfile"(
	in_order_id integer,
	in_order_item_id integer,
	in_workflow_id integer,
	in_comment character varying,
	in_profile_id integer,
    in_workflow_start_stage_id integer
    )
    RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE

BEGIN 
    update b_item_wf_stage s
      set profile_id=in_profile_id , comment=in_comment ,current_stage_flag ='Y' , created_time=now()
    where s.workflow_id=in_workflow_id and s.workflow_stage_id=in_workflow_start_stage_id
    and s.order_item_id=in_order_item_id;
    if not found then

    insert into b_item_wf_stage(workflow_id ,
                workflow_stage_id ,
                order_item_id ,
                profile_id ,
                comment ,
                user_id  ,
                created_time ) values

                (in_workflow_id ,
                in_workflow_start_stage_id ,
                in_order_item_id ,
                in_profile_id ,
                in_comment ,
                (select user_id from b_order where order_id=in_order_id) ,
                now()

                );

    end if;
             
return true ;
END;

$function$;


---------------------------------

-- DROP FUNCTION public."GetOrderItemDetails"(integer);

-- CREATE OR REPLACE FUNCTION public."GetOrderItemDetails"(
-- 	in_order_item_id integer)
--     RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, comment character varying, profile_id integer, priority_id integer, display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, block character varying, item_size character varying, upcharge json, taxes json, discount_value double precision, discount_type integer, care_info character varying, fabric_design character varying, construction character varying, color_info character varying, fabric_width double precision, fusing character varying, thread_shade character varying, material_info_for_wo character varying, order_status character varying, supplier_product_code character varying, material_composition character varying, marker_type character varying, marker_width double precision, pattern_repeat_size character varying, nap_test character varying, pocket_color character varying, buttons character varying, buttons_supplier_product_code character varying, seam_tape character varying, lining character varying, lining_supplier_product_code character varying, lining_width double precision, tonal_ucf character varying, canvas character varying, tonal_button_sku character varying, tonal_lining_sku character varying, discount_comment character varying,customer_fit_on_date date, customer_delivery_date date)    LANGUAGE 'plpgsql'
--     COST 100.0
--     VOLATILE     ROWS 1000.0
-- AS $function$

 
-- declare
-- var_block character varying ;
-- var_item_size character varying ;
-- var_measurement_profile_id integer;
-- BEGIN 
-- select ws.profile_id into var_measurement_profile_id from public.b_item_wf_stage ws where ws.order_item_id = in_order_item_id and ws.workflow_stage_id =1 limit 1;
 
--   return query 
-- SELECT i.order_item_id, i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
--        i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
--        i.comment, var_measurement_profile_id, i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,(select b.block_name from b_profile_measurement pm , b_customer_measurement_profile pf , m_item_type_block b
--       where pm.profile_id =var_measurement_profile_id and 
--       pf.profile_id =pm.profile_id and
--       pm.value =b.block_id
--       and (pm.measurement_type_id in(
--       select m.measurement_type_id from m_measurement_type m where m.item_type_id= i.item_type_id and
--       m.measurement_source_id = pf.measurement_source_id  and m.code='FINAL TRYON DROP' ) or pm.measurement_type_id =-1000) limit 1
--       ) as i_block, (select cast( pm.value as character varying) from b_profile_measurement pm , b_customer_measurement_profile pf 
--       where pm.profile_id =var_measurement_profile_id and 
--       pf.profile_id =pm.profile_id 
--       and (pm.measurement_type_id in(
--       select m.measurement_type_id from m_measurement_type m where m.item_type_id= i.item_type_id and
--       m.measurement_source_id = pf.measurement_source_id  and m.code='FINAL TRYON SIZE' ) or pm.measurement_type_id =-1001 )limit 1
--       ) as i_size,
--        i.upcharge , i.taxes  ,i.discount,i.discount_type ,f.care_info, f.fabric_design ,f.construction,f.color_info,
--  (case when i.item_type_id =1 then f.fabric_width else null  end),
--        f.fusing,f.thread_shade,f.material_info_for_wo,
--        (select ws.code from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1) as status
--       ,f.supplier_product_code1,
-- f.material_composition,
-- f.marker_type,
-- f.marker_width ,
-- f.pattern_repeat_size,
-- f.nap_test,
-- f.pocket_color,
-- f.buttons,
-- f.buttons_supplier_product_code,
-- f.seam_tape,
-- (case when i.item_type_id =3 then null else f.lining end),
-- f.lining_supplier_product_code,
-- (case when i.item_type_id =3 then null else f.lining_width  end),
-- f.tonal_ucf,
-- f.canvas ,f.tonal_button_sku , 
-- (case when i.item_type_id =3 then null else f.tonal_lining_sku  end),
-- i.discount_comment,
-- i.customer_fit_on_date, i.customer_delivery_date
--   FROM public.b_order_item i , m_fabric f, m_item_type it , m_finish_type ft , m_priority_type p
--   where i.order_item_id=in_order_item_id 
--  and i.sku_id=f.fabric_id 
--  and i.item_type_id = it.item_type_id
--  and i.finish_type = ft.finish_type_id
--  and i.priority_id = p.priority_type_id
  
--   ;
-- END;

-- $function$;

-- ALTER FUNCTION public."GetOrderItemDetails"(integer)
--     OWNER TO tailorman_db;

--------------------


-- DROP FUNCTION public."GetStoreLocations"(
-- 	);
CREATE OR REPLACE FUNCTION public."GetStoreLocations"(
	)
    RETURNS TABLE (store_id integer ,name character varying) 
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$
 BEGIN 
  return query SELECT   s.store_id, s.address
  FROM m_store s;
END;

$function$;


-----------------------------

alter table b_order add column delivery_location_id character varying;
 
alter table b_order add column  fiton_location_id character varying;


----



DROP FUNCTION public."GetPendingOrderDetails"(
	in_order_id integer);
CREATE OR REPLACE FUNCTION public."GetPendingOrderDetails"(
	in_order_id integer)
RETURNS TABLE(order_id integer, tailor_id integer, customer_id integer, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, sales_man_id integer, tailor_name character varying, sales_man character varying,store_id integer,delivery_location_id character varying,fiton_location_id character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT o.order_id, o.tailor_id, o.customer_id,o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.sales_man_id  , t.name ,sm.name,
       o.store_id,
       o.delivery_location_id,
       o.fiton_location_id
  FROM b_order o 
  LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id 
  LEFT JOIN m_store s ON o.store_id = s.store_id
  LEFT JOIN m_sales_man sm ON sm.sales_man_id = o.sales_man_id
  LEFT JOIN m_customer mc ON mc.customer_id = o.customer_id
where o.order_id=in_order_id ;
END;

$function$;


--------------


-- DROP FUNCTION public."GetOrderDetails"(integer);

-- CREATE OR REPLACE FUNCTION public."GetOrderDetails"(
-- 	in_order_id integer)
-- RETURNS TABLE(order_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, order_type text, store character varying, user_name character varying, payment_type character varying, shipping_charges integer, pin_date timestamp without time zone, redeemcoupon_json json, customer_email character varying, customer_name character varying, store_address character varying, state_code integer, gst_code character varying, city character varying, half_amount integer, store_initials character varying, invoice_number character varying, store_email character varying, shipping_taxes json)
--     LANGUAGE 'plpgsql'
--     COST 100.0
--     VOLATILE 
--     ROWS 1000.0
-- AS $function$

--  BEGIN 
--   return query SELECT o.order_id, o.customer_id, o.order_type_id, o.store_id, o.user_id, 
--        o.order_date, o.created_by, o.created_time, o.modified_by, o.modified_time, 
--         o.payment_type_id, o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
--       (case when o.delivery_location_id ='courier' then o.delivery_address else ( case when o.delivery_location_id is null then o.delivery_address else (select ss.address from m_store ss where ss.store_id::text =o.delivery_location_id) end )  end) as delivery_address, o.pin_number,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,p.code , o.international_shipping_charges,o.pin_date,o.redeemcoupon_json,mc.email,mc.name,s.store_address,s.state_code,s.gst_code,s.city,cop.amount as half_amount,s.store_initials,o.invoice_number,s.email,o.shipping_taxes 
--   FROM b_order o
--   	LEFT JOIN c_order_payment cop on cop.order_id = in_order_id
--     LEFT JOIN m_store s on o.store_id =s.store_id
--     LEFT JOIN m_store ss on o.store_id =ss.store_id
--     LEFT JOIN m_user u on o.user_id=u.user_id
--     LEFT JOIN m_payment_type p on o.payment_type_id =p.payment_type_id
--     LEFT JOIN m_customer mc on o.customer_id=mc.customer_id
-- where o.order_id=in_order_id;
-- END;

-- $function$;



---------------



DROP FUNCTION public."GetOrderItemDetails"(integer);

CREATE OR REPLACE FUNCTION public."GetOrderItemDetails"(
	in_order_item_id integer)
    RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, comment character varying, profile_id integer, priority_id integer, display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, block character varying, item_size character varying, upcharge json, taxes json, discount_value double precision, discount_type integer, care_info character varying, fabric_design character varying, construction character varying, color_info character varying, fabric_width double precision, fusing character varying, thread_shade character varying, material_info_for_wo character varying, order_status character varying, supplier_product_code character varying, material_composition character varying, marker_type character varying, marker_width double precision, pattern_repeat_size character varying, nap_test character varying, pocket_color character varying, buttons character varying, buttons_supplier_product_code character varying, seam_tape character varying, lining character varying, lining_supplier_product_code character varying, lining_width double precision, tonal_ucf character varying, canvas character varying, tonal_button_sku character varying, tonal_lining_sku character varying, discount_comment character varying, customer_fit_on_date date, customer_delivery_date date,customer_delivery_address character varying )
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 
declare
var_block character varying ;
var_item_size character varying ;
var_measurement_profile_id integer;
BEGIN 
select ws.profile_id into var_measurement_profile_id from public.b_item_wf_stage ws where ws.order_item_id = in_order_item_id and ws.workflow_stage_id =1 limit 1;
 
  return query 
SELECT i.order_item_id, i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
       i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
       i.comment, var_measurement_profile_id, i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,(select b.block_name from b_profile_measurement pm , b_customer_measurement_profile pf , m_item_type_block b
      where pm.profile_id =var_measurement_profile_id and 
      pf.profile_id =pm.profile_id and
      pm.value =b.block_id
      and (pm.measurement_type_id in(
      select m.measurement_type_id from m_measurement_type m where m.item_type_id= i.item_type_id and
      m.measurement_source_id = pf.measurement_source_id  and m.code='FINAL TRYON DROP' ) or pm.measurement_type_id =-1000) limit 1
      ) as i_block, (select cast( pm.value as character varying) from b_profile_measurement pm , b_customer_measurement_profile pf 
      where pm.profile_id =var_measurement_profile_id and 
      pf.profile_id =pm.profile_id 
      and (pm.measurement_type_id in(
      select m.measurement_type_id from m_measurement_type m where m.item_type_id= i.item_type_id and
      m.measurement_source_id = pf.measurement_source_id  and m.code='FINAL TRYON SIZE' ) or pm.measurement_type_id =-1001 )limit 1
      ) as i_size,
       i.upcharge , i.taxes  ,i.discount,i.discount_type ,f.care_info, f.fabric_design ,f.construction,f.color_info,
 (case when i.item_type_id =1 then f.fabric_width else null  end),
       f.fusing,f.thread_shade,f.material_info_for_wo,
       (select ws.code from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1) as status
      ,f.supplier_product_code1,
f.material_composition,
f.marker_type,
f.marker_width ,
f.pattern_repeat_size,
f.nap_test,
f.pocket_color,
f.buttons,
f.buttons_supplier_product_code,
f.seam_tape,
(case when i.item_type_id =3 then null else f.lining end),
f.lining_supplier_product_code,
(case when i.item_type_id =3 then null else f.lining_width  end),
f.tonal_ucf,
f.canvas ,f.tonal_button_sku , 
(case when i.item_type_id =3 then null else f.tonal_lining_sku  end),
i.discount_comment,
i.customer_fit_on_date, i.customer_delivery_date,
(select address as customer_delivery_address from m_customer_addresses where m_customer_addresses_id = i.delivery_id )
  FROM public.b_order_item i , m_fabric f, m_item_type it , m_finish_type ft , m_priority_type p
  where i.order_item_id=in_order_item_id 
 and i.sku_id=f.fabric_id 
 and i.item_type_id = it.item_type_id
 and i.finish_type = ft.finish_type_id
 and i.priority_id = p.priority_type_id
  
  ;
END;

$function$;


---------


DROP FUNCTION public."GetOrderItemDetails"(integer);

CREATE OR REPLACE FUNCTION public."GetOrderItemDetails"(
	in_order_item_id integer)
    RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, comment character varying, profile_id integer, priority_id integer, display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, block character varying, item_size character varying, upcharge json, taxes json, discount_value double precision, discount_type integer, care_info character varying, fabric_design character varying, construction character varying, color_info character varying, fabric_width double precision, fusing character varying, thread_shade character varying, material_info_for_wo character varying, order_status character varying, supplier_product_code character varying, material_composition character varying, marker_type character varying, marker_width double precision, pattern_repeat_size character varying, nap_test character varying, pocket_color character varying, buttons character varying, buttons_supplier_product_code character varying, seam_tape character varying, lining character varying, lining_supplier_product_code character varying, lining_width double precision, tonal_ucf character varying, canvas character varying, tonal_button_sku character varying, tonal_lining_sku character varying, discount_comment character varying, customer_fit_on_date date, customer_delivery_date date,customer_delivery_address character varying )
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 
declare
var_block character varying ;
var_item_size character varying ;
var_measurement_profile_id integer;
BEGIN 
select ws.profile_id into var_measurement_profile_id from public.b_item_wf_stage ws where ws.order_item_id = in_order_item_id and ws.workflow_stage_id =1 limit 1;
 
  return query 
SELECT i.order_item_id, i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
       i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
       i.comment, var_measurement_profile_id, i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,(select b.block_name from b_profile_measurement pm , b_customer_measurement_profile pf , m_item_type_block b
      where pm.profile_id =var_measurement_profile_id and 
      pf.profile_id =pm.profile_id and
      pm.value =b.block_id
      and (pm.measurement_type_id in(
      select m.measurement_type_id from m_measurement_type m where m.item_type_id= i.item_type_id and
      m.measurement_source_id = pf.measurement_source_id  and m.code='FINAL TRYON DROP' ) or pm.measurement_type_id =-1000) limit 1
      ) as i_block, (select cast( pm.value as character varying) from b_profile_measurement pm , b_customer_measurement_profile pf 
      where pm.profile_id =var_measurement_profile_id and 
      pf.profile_id =pm.profile_id 
      and (pm.measurement_type_id in(
      select m.measurement_type_id from m_measurement_type m where m.item_type_id= i.item_type_id and
      m.measurement_source_id = pf.measurement_source_id  and m.code='FINAL TRYON SIZE' ) or pm.measurement_type_id =-1001 )limit 1
      ) as i_size,
       i.upcharge , i.taxes  ,i.discount,i.discount_type ,f.care_info, f.fabric_design ,f.construction,f.color_info,
 (case when i.item_type_id =1 then f.fabric_width else null  end),
       f.fusing,f.thread_shade,f.material_info_for_wo,
       (select ws.code from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1) as status
      ,f.supplier_product_code1,
f.material_composition,
f.marker_type,
f.marker_width ,
f.pattern_repeat_size,
f.nap_test,
f.pocket_color,
f.buttons,
f.buttons_supplier_product_code,
f.seam_tape,
(case when i.item_type_id =3 then null else f.lining end),
f.lining_supplier_product_code,
(case when i.item_type_id =3 then null else f.lining_width  end),
f.tonal_ucf,
f.canvas ,f.tonal_button_sku , 
(case when i.item_type_id =3 then null else f.tonal_lining_sku  end),
i.discount_comment,
i.customer_fit_on_date, i.customer_delivery_date,
(select address as customer_delivery_address from m_customer_addresses where m_customer_addresses_id = i.delivery_id )
  FROM public.b_order_item i , m_fabric f, m_item_type it , m_finish_type ft , m_priority_type p
  where i.order_item_id=in_order_item_id 
 and i.sku_id=f.fabric_id 
 and i.item_type_id = it.item_type_id
 and i.finish_type = ft.finish_type_id
 and i.priority_id = p.priority_type_id
  
  ;
END;

$function$;


------------------


ALTER TABLE public.b_customer_style_profile
    ADD COLUMN created_date date DEFAULT now();

DROP FUNCTION "GetStylingProfileList"(integer,integer);

CREATE OR REPLACE FUNCTION public."GetStylingProfileList"(
	in_customer_id integer,
	in_item_type_id integer)
    RETURNS TABLE(profile_id integer, customer_id integer, item_type_id integer, order_item_id integer, in_profile_name character varying, fabric_design json, comments character varying,created_date date)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT 
	m.profile_id,
	m.customer_id,
	m.item_type_id,
	m.order_item_id,
	m.profile_name,
	m.fabric_design,
	m.comments,
    m.created_date
  from b_customer_style_profile m where m.customer_id = in_customer_id and m.item_type_id = in_item_type_id;

END;

$function$;

ALTER FUNCTION public."GetStylingProfileList"(integer, integer)
    OWNER TO tailorman_db;


---------------------------------
-------------------------------


-- FUNCTION: public."SaveFabricDesign"(integer, json, json, character varying, integer)

-- DROP FUNCTION public."SaveFabricDesign"(integer, json, json, character varying, integer);

CREATE OR REPLACE FUNCTION public."SaveFabricDesign"(
	in_order_item_id integer,
	in_fabric_design json,
	in_selected_fabric_design json,
	in_comment character varying,
	in_profile_id integer)
    RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

BEGIN

update b_customer_measurement_profile ucmp SET modified_flag = 1 where ucmp.profile_id IN ( select bcp.profile_id from b_order_item boi LEFT JOIN b_order bo ON bo.order_id = boi.order_id LEFT JOIN b_customer_measurement_profile bcp ON bo.customer_id = bcp.customer_id AND bcp.item_type_id = boi.item_type_id where boi.order_item_id = in_order_item_id AND modified_flag = 0);

update b_order_item_fabric_design set fabric_design = in_fabric_design, selected_fabric_design=in_selected_fabric_design, comment=in_comment,profile_id=in_profile_id where order_item_id=in_order_item_id;

if not found then
insert into b_order_item_fabric_design(order_item_id, fabric_design,selected_fabric_design,comment,profile_id) values (in_order_item_id, in_fabric_design, in_selected_fabric_design, in_comment,in_profile_id);

end if;

-- update b_customer_style_profile set fabric_design = in_fabric_design,comments=in_comment where profile_id = in_profile_id;
 return true;
END;

$function$;

ALTER FUNCTION public."SaveFabricDesign"(integer, json, json, character varying, integer)
    OWNER TO tailorman_db;    


----

UPDATE b_customer_style_profile
SET created_date = bo.created_time::date
FROM
 b_order_item boi 
 LEFT JOIN b_order bo ON bo.order_id = boi.order_id
WHERE
 boi.order_item_id = b_customer_style_profile.order_item_id AND bo.created_time is NOT NULL;

----------------------------------------------

DROP FUNCTION public."GetOrderDetails"(integer);

CREATE OR REPLACE FUNCTION public."GetOrderDetails"(
	in_order_id integer)
RETURNS TABLE(order_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, order_type text, store character varying, user_name character varying, payment_type character varying, shipping_charges integer, pin_date timestamp without time zone, redeemcoupon_json json, customer_email character varying, customer_name character varying, store_address character varying, state_code integer, gst_code character varying, city character varying, half_amount integer, store_initials character varying, invoice_number character varying, store_email character varying, shipping_taxes json,benficiary_mobile character varying,tailor_name character varying,sales_man character varying,tailor_id integer,sales_man_id integer)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT o.order_id, o.customer_id, o.order_type_id, o.store_id, o.user_id, 
       o.order_date, o.created_by, o.created_time, o.modified_by, o.modified_time, 
        o.payment_type_id, o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
      (case when o.delivery_location_id ='courier' then o.delivery_address else ( case when o.delivery_location_id is null then o.delivery_address else (select ss.address from m_store ss where ss.store_id::text =o.delivery_location_id) end )  end) as delivery_address, o.pin_number,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,p.code , o.international_shipping_charges,o.pin_date,o.redeemcoupon_json,mc.email,mc.name,s.store_address,s.state_code,s.gst_code,s.city,cop.amount as half_amount,s.store_initials,o.invoice_number,s.email,o.shipping_taxes, COALESCE(o.benficiary_mobile,''),t.name,sm.name,o.tailor_id,o.sales_man_id 
  FROM b_order o
  	LEFT JOIN c_order_payment cop on cop.order_id = in_order_id
    LEFT JOIN m_store s on o.store_id =s.store_id
    LEFT JOIN m_store ss on o.store_id =ss.store_id
    LEFT JOIN m_user u on o.user_id=u.user_id
    LEFT JOIN m_payment_type p on o.payment_type_id =p.payment_type_id
    LEFT JOIN m_customer mc on o.customer_id=mc.customer_id
    LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id
    LEFT JOIN m_sales_man sm ON o.sales_man_id = sm.sales_man_id
where o.order_id=in_order_id;
END;
$function$;

----------------------

DROP FUNCTION "GetCustomerOrderList"(integer);


CREATE OR REPLACE FUNCTION public."GetCustomerOrderList"(
	in_customer_id integer)
    RETURNS TABLE(order_id integer, tailor_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, priority_id integer, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, sales_man_id integer, shipping_charges integer, approved_by character varying, w_o_print_status boolean, pending_amount json,coupon_details json,shipping_taxes json)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT 
    o.order_id, 
    o.tailor_id, 
    o.customer_id, 
    o.order_type_id, 
    o.store_id, 
    o.user_id, 
    o.order_date, 
    o.occasion, 
    o.occation_date, 
    o.benficiary_name, 
    o.benficiary_mobile, 
    o.benificiary_email, 
    o.created_by, 
    o.created_time, 
    o.modified_by, 
    o.modified_time,
    o.priority_id, 
    o.payment_type_id, 
    o.payment_details, 
    o.total_amount,
    o.comment, 
    o.display_name,
    o.full_payment_flag,
    o.billing_address,
    o.delivery_address, 
    o.pin_number,
    o.sales_man_id,
    o.international_shipping_charges,
    o.approved_by as approved_details,
    case when (select 
     count(ws.code) 
from b_item_wf_stage s 
LEFT JOIN b_workflow_stage ws ON s.workflow_stage_id=ws.stage_id
LEFT JOIN b_order_item boi ON s.order_item_id = boi.order_item_id
where boi.order_id= o.order_id and s.current_stage_flag='Y' and ws.stage_id IN (2,3,4) ) > 0 then true else false END,
(select (array_to_json(array_agg(c_order_payment))) FROM  c_order_payment where c_order_payment.order_id = o.order_id),
    o.redeemcoupon_json as coupon_details,
    o.shipping_taxes as shipping_taxes
  FROM b_order o where o.customer_id=in_customer_id order by o.created_time desc
;
END;

$function$;

ALTER FUNCTION public."GetCustomerOrderList"(integer)
    OWNER TO tailorman_db;


--------------------------


CREATE OR REPLACE FUNCTION public."GetPendingWorkOrders"(
	in_customer_id integer,
	in_store_id integer)
    RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, order_item_comment character varying, profile_id integer, priority_id integer, order_item_display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_details character varying, total_amount double precision, order_comment character varying, order_display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, tailor_name character varying, order_type text, store character varying, user_name character varying, payment_type character varying, sales_man character varying, customer_name character varying, customer_mobile character varying, customer_address character varying, cusomer_id integer, current_status character varying, current_stage_id integer, bespoke_url character varying, image bytea, style_id integer)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

  BEGIN 
  return query 
SELECT i.order_item_id , i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
       i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
       i.comment, (select s.profile_id from b_item_wf_stage s 
       LEFT JOIN b_workflow_stage ws ON s.workflow_stage_id=ws.stage_id where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
       o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,pm.code ,sm.name,
       c.name, c.mobile, c.address , c.customer_id ,(select ws.code from b_item_wf_stage s 
       LEFT JOIN b_workflow_stage ws ON s.workflow_stage_id=ws.stage_id where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),
       (select ws.stage_id from b_item_wf_stage s 
       LEFT JOIN b_workflow_stage ws ON s.workflow_stage_id=ws.stage_id
       where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),o.bespoke_url,(select boi.image from b_order_image boi where boi.order_id=i.order_id and boi.image_id = 1 limit 1),boifd.order_item_id
  FROM public.b_order_item i
  LEFT JOIN m_fabric f ON i.sku_id=f.fabric_id
  LEFT JOIN m_item_type it ON i.item_type_id = it.item_type_id
  LEFT JOIN m_finish_type ft ON i.finish_type = ft.finish_type_id
  LEFT JOIN m_priority_type p ON i.priority_id = p.priority_type_id
  LEFT JOIN b_order o ON o.order_id = i.order_id
  LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id
  LEFT JOIN m_store s ON o.store_id = s.store_id
  LEFT JOIN m_payment_type pm ON o.payment_type_id = pm.payment_type_id
  LEFT JOIN m_sales_man sm ON o.sales_man_id = sm.sales_man_id
  LEFT JOIN m_user u ON o.user_id=u.user_id
  LEFT JOIN m_customer c ON c.customer_id =o.customer_id
  LEFT JOIN b_order_item_fabric_design boifd ON boifd.order_item_id = i.order_item_id
--   LEFT JOIN b_order_image boi ON boi.order_id=i.order_id and boi.image_id=1
  where o.store_id = in_store_id
	and exists (select 1 from b_item_wf_stage s where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' and s.workflow_stage_id =13)
    and (o.customer_id =in_customer_id or in_customer_id is null) order by o.created_time desc
  ;

END;

$function$;

ALTER FUNCTION public."GetPendingWorkOrders"(integer, integer)
    OWNER TO tailorman_db;

------