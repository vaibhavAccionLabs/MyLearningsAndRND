-- FUNCTION: public."SaveOrder" integer, integer, integer, integer, date, integer, integer, character varying, double precision, character varying, character varying, character varying, character varying, character varying

-- DROP FUNCTION public."SaveOrder" integer, integer, integer, integer, date, integer, integer, character varying, double precision, character varying, character varying, character varying, character varying, character varying;

CREATE OR REPLACE FUNCTION public."SaveOrder"(
	in_customer_id integer,
	in_order_type_id integer,
	in_store_id integer,
	in_user_id integer,
	in_order_date date,
	in_priority_id integer,
	in_payment_type_id integer,
	in_payment_details character varying,
	in_total_amount double precision,
	in_comment character varying,
	in_display_name character varying,
	in_billing_address character varying,
	in_delivery_address character varying,
	in_pin_number character varying)
RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE

var_order_id integer;
BEGIN 

select nextval ('b_order_order_id_seq') into var_order_id;

INSERT INTO b_order(
            order_id, customer_id, order_type_id, store_id, user_id, 
            order_date, created_by, created_time, modified_by, modified_time, 
            priority_id, payment_type_id, payment_details,total_amount,comment,display_name ,billing_address,delivery_address, pin_number)
    VALUES (var_order_id, in_customer_id, in_order_type_id, in_store_id, in_user_id, 
            in_order_date, in_user_id, now(), in_user_id, now(), 
            in_priority_id, in_payment_type_id, in_payment_details,in_total_amount,in_comment,in_display_name, in_billing_address,in_delivery_address, in_pin_number);
return var_order_id ;
END;

$function$;

ALTER FUNCTION public."SaveOrder"( integer, integer, integer, integer, date, integer, integer, character varying, double precision, character varying, character varying, character varying, character varying, character varying)
    OWNER TO tailorman_db;


-----------------------------------------------



-- FUNCTION: public."UpdateOrderV2"integer, integer, integer, integer, integer, date, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, date, json, integer, json

-- DROP FUNCTION public."UpdateOrderV2"integer, integer, integer, integer, integer, date, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, date, json, integer, json;

CREATE OR REPLACE FUNCTION public."UpdateOrderV2"(
	in_order_id integer,
	in_customer_id integer,
	in_order_type_id integer,
	in_store_id integer,
	in_user_id integer,
	in_order_date date,
	in_priority_id integer,
	in_payment_type_id integer,
	in_payment_details character varying,
	in_total_amount double precision,
	in_comment character varying,
	in_display_name character varying,
	in_full_payment_flag character,
	in_billing_address character varying,
	in_delivery_address character varying,
	in_pin_number character varying,
	in_pin_date date,
	in_redeemcoupon_json json,
	in_international_shipping_charges integer,
	in_shipping_taxes json)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

 
DECLARE

BEGIN 

update b_order set (
             customer_id, order_type_id, store_id, user_id, 
            order_date, created_by, created_time, modified_by, modified_time, 
            priority_id, payment_type_id, payment_details,total_amount,comment,display_name,full_payment_flag,billing_address,delivery_address, pin_number,pin_date,redeemcoupon_json,international_shipping_charges,shipping_taxes)
    = ( in_customer_id, in_order_type_id, in_store_id, in_user_id, 
            in_order_date, in_user_id, now(), in_user_id, now(), 
            in_priority_id, in_payment_type_id, in_payment_details,in_total_amount,in_comment,in_display_name,in_full_payment_flag, in_billing_address,in_delivery_address, in_pin_number,in_pin_date,in_redeemcoupon_json,in_international_shipping_charges,in_shipping_taxes) where order_id=in_order_id ;
return true ;
END;

$function$;

ALTER FUNCTION public."UpdateOrderV2"(integer, integer, integer, integer, integer, date, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, date, json, integer, json)
    OWNER TO tailorman_db;


--------------------------------------------------


-- FUNCTION: public."GetOrderDetails"integer

DROP FUNCTION public."GetOrderDetails"(integer);

CREATE OR REPLACE FUNCTION public."GetOrderDetails"(
	in_order_id integer)
    RETURNS TABLE(order_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, order_type text, store character varying, user_name character varying, payment_type character varying, shipping_charges integer, pin_date timestamp without time zone, redeemcoupon_json json, customer_email character varying, customer_name character varying, store_address character varying, state_code integer, gst_code character varying, city character varying, half_amount integer, store_initials character varying, invoice_number character varying, store_email character varying, shipping_taxes json)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT o.order_id, o.customer_id, o.order_type_id, o.store_id, o.user_id, 
       o.order_date, o.created_by, o.created_time, o.modified_by, o.modified_time, 
        o.payment_type_id, o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,p.code , o.international_shipping_charges,o.pin_date,o.redeemcoupon_json,mc.email,mc.name,s.store_address,s.state_code,s.gst_code,s.city,cop.amount as half_amount,s.store_initials,o.invoice_number,s.email,o.shipping_taxes 
  FROM b_order o ,m_store s, m_user u,m_payment_type p ,m_customer mc
  	LEFT JOIN c_order_payment cop on cop.order_id = in_order_id
where o.order_id=in_order_id 
	and o.store_id =s.store_id
	and o.payment_type_id =p.payment_type_id
	and o.user_id=u.user_id
    and o.customer_id=mc.customer_id
;
END;

$function$;

ALTER FUNCTION public."GetOrderDetails"(integer)
    OWNER TO tailorman_db;

----------------------------------------------------------------

-- FUNCTION: public."GetPendingWorkOrders"integer, integer

DROP FUNCTION public."GetPendingWorkOrders"(integer, integer);

CREATE OR REPLACE FUNCTION public."GetPendingWorkOrders"(
	in_customer_id integer,
	in_store_id integer)
RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, order_item_comment character varying, profile_id integer, priority_id integer, order_item_display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, order_date date,created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_details character varying, total_amount double precision, order_comment character varying, order_display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying,order_type text, store character varying, user_name character varying, payment_type character varying, customer_name character varying, customer_mobile character varying, customer_address character varying, cusomer_id integer, current_status character varying, current_stage_id integer, bespoke_url character varying, image bytea, style_id integer)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

  BEGIN 
  return query 
SELECT DISTINCT ON (i.order_item_id) i.order_item_id , i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
       i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
       i.comment, (select s.profile_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,
       o.order_date,  o.created_by, o.created_time, o.modified_by, o.modified_time, 
       o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,pm.code ,
       c.name, c.mobile, c.address , c.customer_id ,(select ws.code from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),
       (select ws.stage_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),o.bespoke_url,boi.image,i.style_id
  FROM public.b_order_item i  LEFT JOIN b_order_image boi ON boi.order_id=i.order_id and boi.image_id=i.item_type_id, m_fabric f, m_item_type it , m_finish_type ft , m_priority_type p ,
  b_order o , m_tailor t,  m_store s, m_user u,m_payment_type pm , m_sales_man sm ,m_customer c 

  where i.order_id=o.order_id
	and i.sku_id=f.fabric_id 
	and i.item_type_id = it.item_type_id
	and i.finish_type = ft.finish_type_id
	and i.priority_id = p.priority_type_id
	and o.store_id = s.store_id
    and o.store_id = in_store_id
	and o.payment_type_id =pm.payment_type_id
	and o.user_id=u.user_id
	and c.customer_id =o.customer_id
	and exists (select 1 from b_item_wf_stage s where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' and s.workflow_stage_id =13)
    and (o.customer_id =in_customer_id or in_customer_id is null)
  ;

END;

$function$;

ALTER FUNCTION public."GetPendingWorkOrders"(integer, integer)
    OWNER TO tailorman_db;

    ----------------------------------------


    
-- FUNCTION: public."GetPendingOrderDetails"integer

-- DROP FUNCTION public."GetPendingOrderDetails"integer;

CREATE OR REPLACE FUNCTION public."GetPendingOrderDetails"(
	in_order_id integer)
    RETURNS TABLE(order_id integer, tailor_id integer, customer_id integer, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, sales_man_id integer, tailor_name character varying, sales_man character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT o.order_id, o.tailor_id, o.customer_id,o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.sales_man_id  , t.name ,sm.name
  FROM b_order o , m_tailor t,  m_store s,m_sales_man sm,m_customer mc
where o.order_id=in_order_id 
	and o.tailor_id = t.tailor_id
	and o.sales_man_id = sm.sales_man_id
;
END;

$function$;

ALTER FUNCTION public."GetPendingOrderDetails"(integer)
    OWNER TO tailorman_db;