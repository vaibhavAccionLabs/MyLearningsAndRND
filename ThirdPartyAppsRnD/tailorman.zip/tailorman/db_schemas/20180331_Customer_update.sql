CREATE OR REPLACE FUNCTION public."GetCustomerAddressList"(
	in_param integer)
    RETURNS TABLE(m_customer_addresses_id integer, m_customer_id integer, address character varying, country character varying, state character varying, address_type character varying, default_address boolean, city character varying, locality character varying, phone character varying, pincode character varying, name character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN return query SELECT 
 ca.m_customer_addresses_id,
 ca.m_customer_id,
 ca.address,
 ca.country_code,
 ca.state,
 ca.address_type,
 ca.default_address,
 ca.city,
 ca.locality,
 ca.phone,
 ca.pincode,
 ca.name
 FROM m_customer_addresses ca where ca.m_customer_id =in_param order by m_customer_addresses_id; 
 END; 

$function$;

-- ALTER FUNCTION public."GetCustomerAddressList"(integer)
--     OWNER TO postgres;