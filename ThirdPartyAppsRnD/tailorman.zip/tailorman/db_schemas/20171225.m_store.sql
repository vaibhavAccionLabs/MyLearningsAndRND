
alter table m_store add column store_initials character varying; 

update m_store set store_initials = 'AMZ' where code='AMAZON';
update m_store set store_initials = 'TT-B' where code='BLRTT001';
update m_store set store_initials = 'ON' where code='ONLINE';
update m_store set store_initials = 'KOL' where code='KOLSS001';

update m_store set store_initials = 'CR' where code='CHECR001';
update m_store set store_initials = 'PM' where code='CHEPM001';
update m_store set store_initials = 'TTK' where code='CHETK001';

update m_store set store_initials = 'HYD' where code='HYDJH001';
update m_store set store_initials = 'HYD – PG' where code='HYDPG001';
update m_store set store_initials = 'HNI' where code='BLRHN001';

update m_store set store_initials = 'JN' where code='BLRJN001';
update m_store set store_initials = 'WF' where code='BLRWF001';
update m_store set store_initials = 'IN' where code='BLRIN001';

update m_store set store_initials = 'TS' where code='BLRSN001';

update m_store set store_initials = 'TT' where code='BLRKU001';


DROP FUNCTION public."GetOrderDetails"(
	in_order_id integer);
CREATE OR REPLACE FUNCTION public."GetOrderDetails"(
	in_order_id integer)
RETURNS TABLE(order_id integer, tailor_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, sales_man_id integer, tailor_name character varying, order_type text, store character varying, user_name character varying, payment_type character varying, sales_man character varying, shipping_charges integer, pin_date timestamp without time zone, redeemcoupon_json json, customer_email character varying, customer_name character varying, store_address character varying, state_code integer, gst_code character varying, city character varying, half_amount integer,invoice_number character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT o.order_id, o.tailor_id, o.customer_id, o.order_type_id, o.store_id, o.user_id, 
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
        o.payment_type_id, o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,o.sales_man_id  , t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,p.code ,sm.name, o.international_shipping_charges,o.pin_date,o.redeemcoupon_json,mc.email,mc.name,s.store_address,s.state_code,s.gst_code,s.city,cop.amount as half_amount,o.invoice_number 
  FROM b_order o , m_tailor t,  m_store s, m_user u,m_payment_type p , m_sales_man sm,m_customer mc
  	LEFT JOIN c_order_payment cop on cop.order_id = in_order_id
where o.order_id=in_order_id 
	and o.tailor_id = t.tailor_id
	and o.store_id =s.store_id
	and o.payment_type_id =p.payment_type_id
	and o.sales_man_id = sm.sales_man_id
	and o.user_id=u.user_id
    and o.customer_id=mc.customer_id
;
END;

$function$;


--  auto invoice number generating

alter table m_store add column start_invoice_number integer default 0; 
alter table m_store add column current_invoice_number integer default 0;  
alter table m_store add column next_invoice_number integer default 1; 

alter table b_order add column invoice_number character varying;

-- select invoice_number from b_order where order_id =28853 and invoice_number IS NOT NULL;

-- select * from public."GetInvoiceNumber"(:in_order_id,:in_store_id)

CREATE OR REPLACE FUNCTION public."GetInvoiceNumber"(
	in_order_id integer,in_store_id integer)
RETURNS character varying
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
DECLARE 

var_invoice_number  character varying;
var_concate_number_into_store  character varying;



 BEGIN 
  select invoice_number into var_invoice_number from b_order where order_id =in_order_id and invoice_number IS NOT NULL and invoice_number !='';
  if not found then
  select concat(store_initials::text ||'/' || "GetFYear"(current_date)|| '/'|| next_invoice_number::text) into var_invoice_number from m_store where store_id=in_store_id;
  update b_order set invoice_number =var_invoice_number where order_id=in_order_id;
  update m_store set current_invoice_number =next_invoice_number ,next_invoice_number=next_invoice_number+1 where store_id=in_store_id;
--   select invoice_number into var_invoice_number from b_order where order_id =in_order_id and invoice_number IS NOT NULL;

  end if;


  return var_invoice_number;


END;

$function$;



CREATE OR REPLACE FUNCTION public."GetFYear"(
	inpdate date)
RETURNS character varying
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
DECLARE 

    result character varying;
    nyr integer;
    mntvalue integer;
    curyr  integer;

BEGIN 

select extract('MONTH' from inpdate) into mntvalue;

select cast(to_char(inpdate,'YY') as INTEGER ) into curyr;

IF mntvalue > 3 THEN
    
    nyr := curyr + 1;
	
 ELSE

 	nyr := curyr;
 	curyr := nyr - 1;
 
END IF;

result := cast(curyr as text) || '-' || cast(nyr as text);

return result;

END;

$function$;



alter table m_store add column start_invoice_number integer default 0; 
alter table m_store add column current_invoice_number integer default 0;  
alter table m_store add column next_invoice_number integer default 1; 
--JN
update m_store set start_invoice_number =394 ,current_invoice_number =394,next_invoice_number=395 where store_id=3;
--WF
update m_store set start_invoice_number =101 ,current_invoice_number =101,next_invoice_number=102 where store_id=1;
--TS

update m_store set start_invoice_number =536 ,current_invoice_number =536,next_invoice_number=537 where store_id=5;
--IN

update m_store set start_invoice_number =719 ,current_invoice_number =719,next_invoice_number=720 where store_id=2;
--TT

update m_store set start_invoice_number =184 ,current_invoice_number =184,next_invoice_number=185 where store_id=4;
--AMAZON

update m_store set start_invoice_number =116 ,current_invoice_number =116,next_invoice_number=117 where store_id=12;
--Online

update m_store set start_invoice_number =90 ,current_invoice_number =90,next_invoice_number=91 where store_id=11;
--HNI
update m_store set start_invoice_number =57 ,current_invoice_number =57,next_invoice_number=58 where store_id=16;
--CR

update m_store set start_invoice_number = 1009 ,current_invoice_number =1009,next_invoice_number=1010 where store_id=6;
--PM
update m_store set start_invoice_number = 385 ,current_invoice_number =385,next_invoice_number=386 where store_id=7;
--TTK
update m_store set start_invoice_number = 602 ,current_invoice_number = 602,next_invoice_number=603 where store_id=8;
--HYD
update m_store set start_invoice_number = 1466 ,current_invoice_number = 1466,next_invoice_number=1467 where store_id=9;
--HYD-PG
update m_store set start_invoice_number = 24 ,current_invoice_number = 24,next_invoice_number=25 where store_id=13;
--Kolkata
update m_store set start_invoice_number = 159 ,current_invoice_number = 159,next_invoice_number=160 where store_id=10;




CREATE OR REPLACE FUNCTION public."GetInvoiceNumber"(
	in_order_id integer,in_store_id integer)
RETURNS character varying
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
DECLARE 

var_invoice_number  integer;
var_concate_number_into_store  character varying;
result character varying;
var_store_initials character varying;



BEGIN 
  select invoice_number into result from b_order where order_id =in_order_id and invoice_number IS NOT NULL and invoice_number !='';
  if not found then

  select next_invoice_number into var_invoice_number from m_store where store_id = in_store_id;
  select store_initials::text into var_store_initials from m_store where store_id = in_store_id;

  
    result := var_store_initials ||'/'|| "GetFYear"(current_date)|| '/' || var_invoice_number::text;
  


  update b_order set invoice_number =result where order_id=in_order_id;
  update m_store set current_invoice_number = var_invoice_number , next_invoice_number=var_invoice_number+1 where store_id=in_store_id;

  end if;


  return result;


END;


$function$;






















