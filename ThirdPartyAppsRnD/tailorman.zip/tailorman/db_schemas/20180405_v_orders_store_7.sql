CREATE OR REPLACE VIEW public.v_orders_store_7 AS
 SELECT o.order_id AS rcpt_num,
    to_char(o.order_date::timestamp with time zone, 'YYYYMMDD'::text) AS rcpt_dt,
    to_char(o.order_date::timestamp with time zone, 'YYYYMMDD'::text) AS business_dt,
    to_char(timezone('EST'::text, timezone('UTC'::text, o.created_time)), 'HH24:MI:SS'::text) AS rcpt_tm,
    it.omrp AS mrp,
    it.ba AS inv_amt,
    it.da AS discount_amount,
    it.ta AS tax_amt,
    pt.code AS payment_mode,
    'Sale' AS transaction_status,
    0 AS service_tax,
    0 AS service_charge
   FROM b_order o,
    m_payment_type pt,
    ( SELECT i.order_id,
            sum( ( i.mrp + i.upcharge_amount)*i.qty ::double precision ) AS omrp,
            sum(i.bill_amount) AS ba,
            sum(i.discount_amount) AS da,
            sum((((((i.taxes -> 0) -> 'value'::text)::character varying)::double precision) + ((((i.taxes -> 1) -> 'value'::text)::character varying)::double precision)) * i.qty::double precision) AS ta
           FROM b_order_item i
          GROUP BY i.order_id) it
  WHERE o.order_id = it.order_id AND o.payment_type_id = pt.payment_type_id AND o.store_id = 7 AND o.is_active = true
  ORDER BY (to_char(o.order_date::timestamp with time zone, 'YYYYMMDD'::text));

ALTER TABLE public.v_orders_store_7
    OWNER TO tailorman_db;