DROP FUNCTION public."GetWorkOrderList"(integer[], date, date, character varying, integer, integer);

CREATE OR REPLACE FUNCTION public."GetWorkOrderList"(
	in_stage_id_list integer[],
	in_start_date date,
	in_end_date date,
	in_customer_param character varying,
	in_order_id integer,
	in_customer_id integer)
    RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, order_item_comment character varying, profile_id integer, priority_id integer, order_item_display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_details character varying, total_amount double precision, order_comment character varying, order_display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, tailor_name character varying, order_type text, store character varying, user_name character varying, payment_type character varying, sales_man character varying, customer_name character varying, customer_mobile character varying, customer_address character varying, cusomer_id integer, current_status character varying, current_stage_id integer, bespoke_url character varying, mtm_flag character)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query 
SELECT i.order_item_id, i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
       i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
       i.comment, (select s.profile_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
       o.payment_details, o.total_amount ,o.comment,o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,pm.code ,sm.name,
       c.name, c.mobile, c.address , c.customer_id ,(select ws.code from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),
       (select ws.stage_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),o.bespoke_url,it.mtm_flag
  FROM public.b_order_item i
  LEFT JOIN m_fabric f ON i.sku_id=f.fabric_id
  LEFT JOIN m_item_type it ON i.item_type_id = it.item_type_id
  LEFT JOIN m_finish_type ft ON i.finish_type = ft.finish_type_id
  LEFT JOIN m_priority_type p ON i.priority_id = p.priority_type_id
  LEFT JOIN b_order o ON i.order_id=o.order_id
  LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id
  LEFT JOIN m_store s ON o.store_id =s.store_id
  LEFT JOIN m_user u ON o.user_id=u.user_id
  LEFT JOIN m_payment_type pm ON o.payment_type_id =pm.payment_type_id
  LEFT JOIN m_sales_man sm ON o.sales_man_id = sm.sales_man_id
  LEFT JOIN m_customer c ON c.customer_id =o.customer_id
  where 
	o.order_date between in_start_date and in_end_date
	and exists (select 1 from b_item_wf_stage s where (in_stage_id_list @> ARRAY[s.workflow_stage_id]  or  cast (ARRAY[0] as integer [] ) <@ in_stage_id_list ) and s.order_item_id=i.order_item_id and s.current_stage_flag='Y')
	and (in_customer_param ='' or (c.name ilike  '%' || in_customer_param || '%' or c.mobile ilike '%' ||  in_customer_param || '%' or c.email ilike '%' ||  in_customer_param || '%' ))
	--and (in_store_id_list @> ARRAY[s.store_id]  or  cast (ARRAY[0] as integer [] ) <@ in_store_id_list )
	and (o.order_id= in_order_id or in_order_id is null)
	and (o.customer_id =in_customer_id or in_customer_id is null)
    AND i.is_active = true
    AND o.is_active = true;

END;

$function$;

ALTER FUNCTION public."GetWorkOrderList"(integer[], date, date, character varying, integer, integer)
    OWNER TO tailorman_db;


--------------------------------------------


CREATE OR REPLACE VIEW public.dashboard_view_query AS
 SELECT i.order_item_id,
    i.order_id,
    i.workflow_id,
    i.sku_id,
    i.item_type_id,
    i.mrp,
    i.qty,
    i.finish_type,
    i.fit_on_date,
    i.delivery_date,
    ( SELECT s_1.profile_id
           FROM b_item_wf_stage s_1,
            b_workflow_stage ws
          WHERE s_1.workflow_stage_id = ws.stage_id AND s_1.order_item_id = i.order_item_id AND s_1.current_stage_flag = 'Y'::bpchar
         LIMIT 1) AS profile_id,
    i.priority_id,
    i.display_name,
    f.supplier_product_code,
    it.descr,
    ft.code AS m_finish_type_code,
    p.code AS m_priority_type_code,
    o.order_date,
    o.occasion,
    o.occation_date,
    o.benficiary_name,
    o.benficiary_mobile,
    o.benificiary_email,
    o.created_by,
    o.created_time,
    o.modified_by,
    o.modified_time,
    o.payment_details,
    o.total_amount,
    o.comment,
    o.full_payment_flag,
    o.billing_address,
    o.delivery_address,
    o.pin_number,
    t.name AS m_tailor_name,
        CASE
            WHEN o.order_type_id = 1 THEN 'Offline'::text
            ELSE 'Online'::text
        END AS order_type,
    s.address,
    u.fname,
    pm.code,
    sm.name,
    c.name AS m_customer_name,
    c.mobile,
    c.address AS m_customer_name_address,
    c.customer_id,
    ( SELECT ws.code
           FROM b_item_wf_stage s_1,
            b_workflow_stage ws
          WHERE s_1.workflow_stage_id = ws.stage_id AND s_1.order_item_id = i.order_item_id AND s_1.current_stage_flag = 'Y'::bpchar
         LIMIT 1) AS b_workflow_stage_code,
    ( SELECT ws.stage_id
           FROM b_item_wf_stage s_1,
            b_workflow_stage ws
          WHERE s_1.workflow_stage_id = ws.stage_id AND s_1.order_item_id = i.order_item_id AND s_1.current_stage_flag = 'Y'::bpchar
         LIMIT 1) AS stage_id,
    o.store_id
   FROM b_order_item i,
    m_fabric f,
    m_item_type it,
    m_finish_type ft,
    m_priority_type p,
    b_order o,
    m_tailor t,
    m_store s,
    m_user u,
    m_payment_type pm,
    m_sales_man sm,
    m_customer c
  WHERE i.order_id = o.order_id 
  AND i.sku_id = f.fabric_id 
  AND i.item_type_id = it.item_type_id 
  AND i.finish_type = ft.finish_type_id 
  AND i.priority_id = p.priority_type_id 
  AND o.tailor_id = t.tailor_id 
  AND o.store_id = s.store_id 
  AND o.payment_type_id = pm.payment_type_id 
  AND o.sales_man_id = sm.sales_man_id 
  AND o.user_id = u.user_id
  AND o.is_active = true 
  AND i.is_active = true
  AND c.customer_id = o.customer_id;

ALTER TABLE public.dashboard_view_query
    OWNER TO tailorman_db;

------------------------------------------------------


DROP FUNCTION public."GetCustomerOrderList"(integer);

CREATE OR REPLACE FUNCTION public."GetCustomerOrderList"(
	in_customer_id integer)
    RETURNS TABLE(order_id integer, tailor_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, gstnumber character varying, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, priority_id integer, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, sales_man_id integer, shipping_charges integer, approved_by character varying, w_o_print_status boolean, pending_amount json, coupon_details json, shipping_taxes json)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT 
    o.order_id, 
    o.tailor_id, 
    o.customer_id, 
    o.order_type_id, 
    o.store_id, 
    o.user_id, 
    o.order_date, 
    o.gstnumber,
    o.occasion, 
    o.occation_date, 
    o.benficiary_name, 
    o.benficiary_mobile, 
    o.benificiary_email, 
    o.created_by, 
    o.created_time, 
    o.modified_by, 
    o.modified_time,
    o.priority_id, 
    o.payment_type_id, 
    o.payment_details, 
    o.total_amount,
    o.comment, 
    o.display_name,
    o.full_payment_flag,
    o.billing_address,
    o.delivery_address, 
    o.pin_number,
    o.sales_man_id,
    o.international_shipping_charges,
    o.approved_by as approved_details,
    case when (select 
     count(ws.code) 
from b_item_wf_stage s 
LEFT JOIN b_workflow_stage ws ON s.workflow_stage_id=ws.stage_id
LEFT JOIN b_order_item boi ON s.order_item_id = boi.order_item_id
where boi.order_id= o.order_id and s.current_stage_flag='Y' and ws.stage_id IN (2,3,4) ) > 0 then true else false END,
(select (array_to_json(array_agg(c_order_payment))) FROM  c_order_payment where c_order_payment.order_id = o.order_id),
    o.redeemcoupon_json as coupon_details,
    o.shipping_taxes as shipping_taxes
  FROM b_order o 
  where o.customer_id=in_customer_id
  AND o.is_active = true 
  AND o.created_by is NOT NULL
  order by o.created_time desc
;
END;

$function$;

ALTER FUNCTION public."GetCustomerOrderList"(integer)
    OWNER TO tailorman_db;


------------------------------------------------------------


DROP FUNCTION public."GetCustomerOrderHistory"(integer);

CREATE OR REPLACE FUNCTION public."GetCustomerOrderHistory"(
	in_customer_id integer)
    RETURNS TABLE(order_id integer, display_name character varying, modified_time timestamp with time zone, order_date date, occation_date date, benficiary_mobile character varying, benficiary_name character varying, sale_items json)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT 
    o.order_id,
    o.display_name,
    o.modified_time,
    o.order_date,
    o.occation_date,
    o.benficiary_mobile,
    o.benficiary_name,
    (select (array_to_json(array_agg(b_order_item))) FROM b_order_item where b_order_item.order_id = o.order_id AND b_order_item.is_active = true)
  FROM b_order o
  where o.is_active = true
  AND o.created_by is NOT NULL
  AND o.customer_id=in_customer_id 
  order by o.created_time desc
;
END;

$function$;

ALTER FUNCTION public."GetCustomerOrderHistory"(integer)
    OWNER TO tailorman_db;

----------------------------------------------------------------------------


CREATE OR REPLACE VIEW public.v_cart_abandoned AS
 SELECT bo.order_id,
    mc.name,
    mc.email,
    mc.mobile,
    mc.address,
    bo.order_date,
    bo.total_amount,
    bo.created_time,
    bo.abon_mail_status,
    ( SELECT array_to_json(array_agg(boi.*)) AS array_to_json
           FROM v_order_line boi
          WHERE boi.order_id = bo.order_id) AS order_items_list
   FROM b_order bo
     LEFT JOIN m_customer mc ON mc.customer_id = bo.customer_id
  WHERE bo.store_id = 11 
  AND bo.created_by = 0 
  AND bo.is_active = true
  AND NOT (bo.order_id IN ( SELECT op.order_id
           FROM order_payment op
          WHERE op.success = true));

ALTER TABLE public.v_cart_abandoned
    OWNER TO tailorman_db;


---------------------------------------------------------


CREATE OR REPLACE VIEW public.v_orders AS
 SELECT i.order_id,
    i.order_item_id,
    i.discount_comment,
    c.name AS customer,
    f.supplier_product_code AS sku,
    t.name AS tailor,
    sm.name AS salesman,
    i.qty,
    i.mrp AS base_price,
    i.mrp + i.upcharge_amount AS mrp,
    i.discount_amount,
    i.bill_amount,
    i.customer_fit_on_date,
    i.customer_delivery_date,
    o.order_date,
    o.approved_by,
        CASE
            WHEN it.mtm_flag = 'Y'::bpchar THEN "left"(f.supplier_product_code::text, 2) || i.order_item_id
            ELSE NULL::text
        END AS imp_number,
    ft.code AS finish_type,
    s.address AS store,
    o.pin_number,
    ( SELECT ws.code
           FROM b_item_wf_stage s_1,
            b_workflow_stage ws
          WHERE s_1.workflow_stage_id = ws.stage_id AND s_1.order_item_id = i.order_item_id AND s_1.current_stage_flag = 'Y'::bpchar
         LIMIT 1) AS status,
    c.customer_id,
    c.email,
    c.mobile,
    ( SELECT pf.profile_name
           FROM b_item_wf_stage s_1,
            b_customer_measurement_profile pf
          WHERE s_1.profile_id = pf.profile_id AND s_1.order_item_id = i.order_item_id AND s_1.workflow_stage_id = 1
         LIMIT 1) AS profile_name,
    replace(o.billing_address::text, '\n'::text, ''::text) AS billing_address,
    c.address AS customer_address,
    c.dob AS customer_dob,
    fm.fabric_measurements -> 'size'::text AS size
   FROM b_order_item i
     JOIN b_order o ON o.order_id = i.order_id
     JOIN m_item_type it ON i.item_type_id = it.item_type_id
     LEFT JOIN m_customer c ON o.customer_id = c.customer_id
     LEFT JOIN m_fabric f ON i.sku_id = f.fabric_id
     LEFT JOIN m_store s ON o.store_id = s.store_id
     LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id
     LEFT JOIN m_sales_man sm ON o.sales_man_id = sm.sales_man_id
     LEFT JOIN m_finish_type ft ON i.finish_type = ft.finish_type_id
     LEFT JOIN b_order_item_fabric_measurement fm ON i.order_item_id = fm.order_item_id
     where o.is_active = true
     AND i.is_active = true
  ORDER BY i.order_id, i.order_item_id;

ALTER TABLE public.v_orders
    OWNER TO tailorman_db;


------------------------------------------------------------------


DROP FUNCTION public."GetCustomerList"(character varying);

CREATE OR REPLACE FUNCTION public."GetCustomerList"(
	in_param character varying)
    RETURNS TABLE(customer_id integer, name character varying, gender character varying, dob date, mobile character varying, address character varying, email character varying, height double precision, weight double precision, source character varying, comment character varying, total_order_amount double precision)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT c.customer_id,c.name, c.gender, c.dob, c.mobile, c.address, c.email, c.height, 
       c.weight, s.code , c.comment,(SELECT sum(o.total_amount)+ c.total_order_amount  
        FROM b_order AS o
        WHERE c.customer_id = o.customer_id
        AND o.is_active = true
       ) AS total_order_amount  
  FROM m_source s,m_customer c 
  where c.source_id = s.source_id and (c.name ilike  '%' || in_param || '%' or c.mobile ilike '%' ||  in_param || '%' or c.email ilike '%' ||  in_param || '%' ) ;

END;

$function$;

ALTER FUNCTION public."GetCustomerList"(character varying)
    OWNER TO tailorman_db;

-------------------------------------------------------

CREATE OR REPLACE FUNCTION public."DeleteOrderV2"(
	in_order_id integer)
    RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 BEGIN 
  update b_order set is_active = false where order_id=in_order_id;
  return true;
END;

$function$;

ALTER FUNCTION public."DeleteOrderV2"(integer)
    OWNER TO tailorman_db;

--------------------------------------------------------------
CREATE OR REPLACE FUNCTION public."DeleteOrderItemV2"(
	in_order_item_id integer)
    RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 BEGIN 
  update b_order_item set is_active = false where order_item_id=in_order_item_id;
  UPDATE b_order SET total_amount = (select SUM(bill_amount) from b_order_item where order_id IN (select order_id from b_order_item where order_item_id = in_order_item_id limit 1 ) AND is_active = true ) where order_id IN (select order_id from b_order_item where order_item_id = in_order_item_id limit 1 );
  return true;
END;

$function$;

ALTER FUNCTION public."DeleteOrderItemV2"(integer)
    OWNER TO tailorman_db;

----------------------------------------------------------------

ALTER TABLE public.b_order_item
    ADD COLUMN is_active boolean DEFAULT True;

-----------------------------------------------------------------

CREATE OR REPLACE VIEW public.v_order_line AS
 SELECT i.order_id,
    i.order_item_id,
    i.display_name,
    i.item_type_id,
    f.supplier_product_code,
    f.sku_code,
    i.qty,
    i.mrp AS base_price,
    i.mrp + i.upcharge_amount AS mrp,
    i.bill_amount,
    i.customer_fit_on_date,
    i.customer_delivery_date,
    ft.code AS finish_type,
    i.fit_on_date,
    i.delivery_date,
    i.comment,
    i.upcharge,
    ( SELECT ws.code
           FROM b_item_wf_stage s_1,
            b_workflow_stage ws
          WHERE s_1.workflow_stage_id = ws.stage_id AND s_1.order_item_id = i.order_item_id AND s_1.current_stage_flag = 'Y'::bpchar
         LIMIT 1) AS status,
    i.discount_comment,
    i.discount_amount,
    i.discount,
    i.discount_type,
    i.upcharge_amount,
    it.descr AS item_type_descr,
    it.mtm_flag,
    ( SELECT boifm.fabric_measurements
           FROM b_order_item_fabric_measurement boifm
          WHERE boifm.order_item_id = i.order_item_id) AS fabricmeasurement
   FROM b_order_item i
     LEFT JOIN m_item_type it ON i.item_type_id = it.item_type_id
     LEFT JOIN m_fabric f ON i.sku_id = f.fabric_id
     LEFT JOIN m_finish_type ft ON i.finish_type = ft.finish_type_id
    WHERE i.is_active = true
  ORDER BY i.order_id, i.order_item_id;

ALTER TABLE public.v_order_line
    OWNER TO tailorman_db;

--------------------------------------------------------------------------


CREATE OR REPLACE VIEW public.v_orders_store_7 AS
 SELECT o.order_id AS rcpt_num,
    to_char(o.order_date::timestamp with time zone, 'YYYYMMDD'::text) AS rcpt_dt,
    to_char(o.order_date::timestamp with time zone, 'YYYYMMDD'::text) AS business_dt,
    to_char(timezone('EST'::text, timezone('UTC'::text, o.created_time)), 'HH24:MI:SS'::text) AS rcpt_tm,
    it.omrp AS mrp,
    it.ba AS inv_amt,
    it.da AS discount_amount,
    it.ta AS tax_amt,
    pt.code AS payment_mode,
    'Sale' AS transaction_status,
    0 AS service_tax,
    0 AS service_charge
   FROM b_order o,
    m_payment_type pt,
    ( SELECT i.order_id,
            sum(i.mrp) AS omrp,
            sum(i.bill_amount) AS ba,
            sum(i.discount_amount) AS da,
            sum((((((i.taxes -> 0) -> 'value'::text)::character varying)::double precision) + ((((i.taxes -> 1) -> 'value'::text)::character varying)::double precision)) * i.qty::double precision) AS ta
           FROM b_order_item i where i.is_active = true
          GROUP BY i.order_id) it
  WHERE o.order_id = it.order_id AND o.payment_type_id = pt.payment_type_id AND o.store_id = 7 AND o.is_active = true
  ORDER BY (to_char(o.order_date::timestamp with time zone, 'YYYYMMDD'::text));

ALTER TABLE public.v_orders_store_7
    OWNER TO tailorman_db;


--------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public."GetOrderItemListV2"(
	in_order_id integer)
    RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, comment character varying, profile_id integer, priority_id integer, product_sku character varying, sku character varying, fabric_description character varying, item_type character varying, finish_type character varying, priority character varying, block character varying, item_size character varying, upcharge json, taxes json, discount_value double precision, discount_type integer, order_flag integer, bill_amount double precision, pickup_location character varying, discount_comment character varying, hsn_code integer, discount_amount double precision, customer_delivery_date date, customer_fit_on_date date, fabric_measurement json, size json, display_name character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 
declare
var_block character varying ;
var_item_size character varying ;

BEGIN 
return query 
SELECT i.order_item_id, i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
i.comment, (select s.profile_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,f.supplier_product_code , f.sku_code, f.name, it.descr ,ft.code ,p.code ,var_block, var_item_size,
i.upcharge , i.taxes ,i.discount,i.discount_type ,i.order_flag , i.bill_amount,(CASE WHEN i.pickup_id IS NOT NULL THEN (select sl.address from m_store sl where sl.store_id = i.pickup_id) ELSE (CASE WHEN i.delivery_id IS NOT NULL THEN (select address from m_customer_addresses where m_customer_addresses_id =i.delivery_id) ELSE '' END) END) as pickup_location,
i.discount_comment, f.hsn_code,i.discount_amount,i.customer_delivery_date,i.customer_fit_on_date,fm.fabric_measurements,fm.fabric_measurements->'size' as size,(CASE WHEN fm.fabric_measurements->'size' IS NOT NULL THEN (select concat(i.display_name::text, ' - Size ',fm.fabric_measurements->>'size'::text) 
)  ELSE (select i.display_name) END) as display_name 
FROM public.b_order_item i 
inner join m_fabric f on i.sku_id=f.fabric_id 
inner join m_item_type it on i.item_type_id = it.item_type_id
left join m_finish_type ft on i.finish_type = ft.finish_type_id
left join m_priority_type p on i.priority_id = p.priority_type_id
left join b_order_item_fabric_measurement fm on i.order_item_id = fm.order_item_id 
where i.order_Id=in_order_id AND i.is_active = true
;

END;

$function$;

ALTER FUNCTION public."GetOrderItemListV2"(integer)
    OWNER TO tailorman_db;

----------------------------

------------------------------------------------------


CREATE OR REPLACE FUNCTION public."GetPendingWorkOrders"(
	in_customer_id integer,
	in_store_id integer)
    RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, order_item_comment character varying, profile_id integer, priority_id integer, order_item_display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_details character varying, total_amount double precision, order_comment character varying, order_display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, tailor_name character varying, order_type text, store character varying, user_name character varying, payment_type character varying, sales_man character varying, customer_name character varying, customer_mobile character varying, customer_address character varying, cusomer_id integer, current_status character varying, current_stage_id integer, bespoke_url character varying, image bytea, style_id integer)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

  BEGIN 
  return query 
SELECT i.order_item_id , i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
       i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
       i.comment, (select s.profile_id from b_item_wf_stage s 
       LEFT JOIN b_workflow_stage ws ON s.workflow_stage_id=ws.stage_id where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
       o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,pm.code ,sm.name,
       c.name, c.mobile, c.address , c.customer_id ,(select ws.code from b_item_wf_stage s 
       LEFT JOIN b_workflow_stage ws ON s.workflow_stage_id=ws.stage_id where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),
       (select ws.stage_id from b_item_wf_stage s 
       LEFT JOIN b_workflow_stage ws ON s.workflow_stage_id=ws.stage_id
       where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),o.bespoke_url,(select boi.image from b_order_image boi where boi.order_id=i.order_id and boi.image_id = 1 limit 1),boifd.order_item_id
  FROM public.b_order_item i
  LEFT JOIN m_fabric f ON i.sku_id=f.fabric_id
  LEFT JOIN m_item_type it ON i.item_type_id = it.item_type_id
  LEFT JOIN m_finish_type ft ON i.finish_type = ft.finish_type_id
  LEFT JOIN m_priority_type p ON i.priority_id = p.priority_type_id
  LEFT JOIN b_order o ON o.order_id = i.order_id
  LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id
  LEFT JOIN m_store s ON o.store_id = s.store_id
  LEFT JOIN m_payment_type pm ON o.payment_type_id = pm.payment_type_id
  LEFT JOIN m_sales_man sm ON o.sales_man_id = sm.sales_man_id
  LEFT JOIN m_user u ON o.user_id=u.user_id
  LEFT JOIN m_customer c ON c.customer_id =o.customer_id
  LEFT JOIN b_order_item_fabric_design boifd ON boifd.order_item_id = i.order_item_id
--   LEFT JOIN b_order_image boi ON boi.order_id=i.order_id and boi.image_id=1
  where o.store_id = in_store_id
    AND i.is_active = true
	and exists (select 1 from b_item_wf_stage s where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' and s.workflow_stage_id =13)
    and (o.customer_id =in_customer_id or in_customer_id is null) order by o.created_time desc
  ;

END;

$function$;

ALTER FUNCTION public."GetPendingWorkOrders"(integer, integer)
    OWNER TO tailorman_db;

