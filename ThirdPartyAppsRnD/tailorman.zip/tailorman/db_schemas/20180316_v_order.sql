-- View: public.v_orders

DROP VIEW public.v_orders;

CREATE OR REPLACE VIEW public.v_orders AS
 SELECT i.order_id,
    i.order_item_id,
    i.discount_comment,
    c.name AS customer,
    f.supplier_product_code AS sku,
    t.name AS tailor,
    sm.name AS salesman,
    i.qty,
    i.mrp AS base_price,
    i.mrp + i.upcharge_amount AS mrp,
    i.discount_amount,
    i.bill_amount,
    i.customer_fit_on_date,
    i.customer_delivery_date,
    o.order_date,
    o.approved_by,
        CASE
            WHEN it.mtm_flag = 'Y'::bpchar THEN "left"(f.supplier_product_code::text, 2) || i.order_item_id
            ELSE NULL::text
        END AS imp_number,
    ft.code AS finish_type,
    s.address AS store,
    o.pin_number,
    ( SELECT ws.code
           FROM b_item_wf_stage s_1,
            b_workflow_stage ws
          WHERE s_1.workflow_stage_id = ws.stage_id AND s_1.order_item_id = i.order_item_id AND s_1.current_stage_flag = 'Y'::bpchar
         LIMIT 1) AS status,
    c.customer_id,
    c.email,
    c.mobile,
    ( SELECT pf.profile_name
           FROM b_item_wf_stage s_1,
            b_customer_measurement_profile pf
          WHERE s_1.profile_id = pf.profile_id AND s_1.order_item_id = i.order_item_id AND s_1.workflow_stage_id = 1
         LIMIT 1) AS profile_name,
    replace(o.billing_address::text, '\n'::text, ''::text) AS billing_address,
    c.address AS customer_address,
    c.dob AS customer_dob,
    fm.fabric_measurements -> 'size'::text AS size,
    f.sku_code as FABRIC SUPPLIER CODE
   FROM b_order_item i
     JOIN b_order o ON o.order_id = i.order_id
     JOIN m_item_type it ON i.item_type_id = it.item_type_id
     LEFT JOIN m_customer c ON o.customer_id = c.customer_id
     LEFT JOIN m_fabric f ON i.sku_id = f.fabric_id
     LEFT JOIN m_store s ON o.store_id = s.store_id
     LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id
     LEFT JOIN m_sales_man sm ON o.sales_man_id = sm.sales_man_id
     LEFT JOIN m_finish_type ft ON i.finish_type = ft.finish_type_id
     LEFT JOIN b_order_item_fabric_measurement fm ON i.order_item_id = fm.order_item_id
  ORDER BY i.order_id, i.order_item_id;

ALTER TABLE public.v_orders
    OWNER TO tailorman_db;


