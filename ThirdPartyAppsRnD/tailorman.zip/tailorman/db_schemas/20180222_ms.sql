ALTER TABLE public.b_customer_measurement_profile
    ADD COLUMN created_date date;

---------------------------------------------------
---------------------------------------------------

-- FUNCTION: public."GetMeasurementProfileList"(integer, integer)

DROP FUNCTION public."GetMeasurementProfileList"(integer, integer);

CREATE OR REPLACE FUNCTION public."GetMeasurementProfileList"(
	in_customer_id integer,
	in_item_type_id integer)
    RETURNS TABLE(profile_id integer, measurement_source_id integer, profile_name character varying, comment character varying, measurement_source character varying,created_date date)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$
 BEGIN 
  return query SELECT 
    m.profile_id, 
    m.measurement_source_id, 
    m.profile_name, 
    m.comment, 
    s.code,
    m.created_date
  FROM b_customer_measurement_profile m , m_measurement_source s where  m.customer_id=in_customer_id and m.item_type_id=in_item_type_id
 and m.measurement_source_id= s.measurement_source_id
  ;
END;

$function$;

ALTER FUNCTION public."GetMeasurementProfileList"(integer, integer)
    OWNER TO tailorman_db;

---------------------------------------------

-- FUNCTION: public."SaveMeasurementProfile"(integer, integer, integer, character varying, character varying)

-- DROP FUNCTION public."SaveMeasurementProfile"(integer, integer, integer, character varying, character varying);

CREATE OR REPLACE FUNCTION public."SaveMeasurementProfile"(
	in_customer_id integer,
	in_item_type_id integer,
	in_measurement_source_id integer,
	in_profile_name character varying,
	in_comment character varying)
    RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE

var_profile_id integer;
BEGIN 

select nextval ('b_customer_measurement_profile_profile_id_seq') into var_profile_id;

INSERT INTO b_customer_measurement_profile(
            profile_id, customer_id, item_type_id, measurement_source_id, 
            profile_name, comment,modified_flag,created_date)
    VALUES (var_profile_id, in_customer_id, in_item_type_id,  in_measurement_source_id, 
            in_profile_name, in_comment,1,now()::date);
return var_profile_id ;

END;

$function$;

ALTER FUNCTION public."SaveMeasurementProfile"(integer, integer, integer, character varying, character varying)
    OWNER TO tailorman_db;

