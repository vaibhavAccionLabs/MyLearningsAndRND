CREATE TABLE item_type_style_dropdownlist(
    item_type_style_dropdownlist_id serial,
    button_sku character varying,
    button_type  character varying,
    descr character varying,
    supplier_product_code character varying,
    upcharge integer,
    item_type_id integer,
    is_lining boolean
);

insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
                                values ('BTN0001','Metal','Shiny Silver Button','T1751AB6/1',300,3);


-- insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining) 
                                -- values ('LS-1','Morza Silk Beige','LD00001',300,true);




insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('Tonal','','','',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0001','Metal','Shiny Silver Button','T1751AB6/1',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0002','Metal','Antique Silver Button','T1751AB6/2',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0003','Metal','Copper Button-3','T1751AB6/3',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0004','Metal','Antique Button','T1781AB6',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0005','Metal','Black Metal Button','T1771AB6',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0006','Metal','Antique Gold Button','T1769AB6',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0007','Metal','Antique Gold Button','52-20155',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0008','Metal','Antique Silver Button','50-20155',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0009','Metal','Antique Button','RR-13524',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0010','Metal','Shiny Gold Button-10','RHK-15103',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0011','Metal','Lion Crest Gold Blazer Button','11 (Metal)',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0012','Metal','Gold Golf Kings Crest Metal Button','12',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0013','Metal','Antique Gold Metal Button-13','13',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0014','Metal','Antique Gold Metal Button-14','14',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0015','Metal','Dull Silver Metal Blazer Button','15',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0016','Metal','Gold Crest Metal Button-16','16',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0017','Metal','Gold Crest Metal Button-17','17',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0018','Metal','Grey Gold Lion Crest Metal Button','18',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0019','Metal','Gold Metal Blazer Button-19','19',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0020','Metal','Gold Metal Blazer Button-20','20',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0021','Metal','Gold Metal Shank Button-21','21',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0023','Metal','Copper Crest Metal Button','23',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0024','Metal','Copper Blazer Button-24','24',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0025','Metal','Gold Metal Shank Button-25','25',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0026','Metal','Olive Gold Metal Button','26',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0027','Metal','Olive Gold Lion Crest Button','27',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0029','Metal','Silver Gold Metal Button-29','29',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0032','Metal','Silver Gold Metal Button-32','32',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0033','Metal','Olive Gold Metal Blazer Button','33',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0034','Metal','Off White Gold Metal Blazer Button','34',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0035','Metal','Grey Silver Metal Button','35',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0036','Metal','Silver Shiny Gold Blazer Button','36',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0037','Metal','Copper Blazer Button-37','37',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0038','Metal','Copper Button-38','38',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0039','Metal','Blue Gold Metal Button','39',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0040','Metal','Black Silver Plastic Metal Button','40',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0041','Metal','Antique Silver Metal Button','41',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0042','Metal','Antique Silver Blazer Button','42',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0043','Metal','Copper Blazer Button-43','43',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0044','Metal','Gold Crest Metal Button-44','44',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0045','Metal','Antique Gold Crowned Eagle Metal Button','45',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0046','Metal','Gold Metal Blazer Button 46','46',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0047','Metal','Black Metal Blazer Button','47',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0048','Metal','Metal Matte With Lion Crest Metal Button','48',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0049J','Metal','Shiny Gold Button-49','49',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0050','Urea Button Tonal','White Urea Button','TBWHITE',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0053','Urea Button Tonal','Beige Brown Urea Button','TB11',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0054','Urea Button Tonal','Cream Urea Button','TBCREAM',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0055','Urea Button Tonal','Green Urea Button','Green',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0056','Urea Button Tonal','Opal Gray Urea Button','TBGREY',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0057','Fancy Button Tonal','Bright Blue Fancy Button','TFB00001',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0058','Fancy Button Tonal','Brick Red Fancy Button','TFB00002',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0059','Fancy Button Tonal','Beige Fancy Button','TFB00003',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0060','Fancy Button Tonal','Pink Lemonade Fancy Button','TFB00004',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0061','Fancy Button Tonal','Red Ochre Fancy Button','TFB00005',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0062','Fancy Button Tonal','Blue Heron Fancy Button','TFB00006',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0063','Fancy Button Tonal','Brown Stone Fancy Button','TFB00007',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0064','Fancy Button Tonal','Madder Brown Fancy Button','TFB00008',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0065','Fancy Button Tonal','Blue Ice Fancy Button','TFB00009',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0066','Fancy Button Tonal','Vermillion Orange Fancy Button','TFB00010',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0067','Fancy Button Tonal','Black Fancy Button','TFB00011',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0068','Fancy Button Tonal','Elfin Yellow Fancy Buton','TFB00012',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0069','Fancy Button Tonal','Black Berry Wine Fancy Button','TFB00013',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0070','Urea Button Tonal','Wood Brown Urea Button','TUB00012',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0071','Urea Button Tonal','Brown Urea Button','TUB00016',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0072','Urea Button Tonal','Navy Urea Button','TUB00026',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0073','Urea Button Tonal','Light Grey Urea Button','TUB00042',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0074','Urea Button Tonal','Charcoal Grey Urea Button','TUB00043',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0075','Urea Button Tonal','Dark Grey Urea Button','TUB00045',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0076','Urea Button Tonal','Grey Urea Button','TUB00059',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0077','Urea Button Tonal','Black Urea Button','TUB00099',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0078','Urea Button Tonal','Taupe Urea Button','TUB00125',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0099','Plastic','Plastic Button-99B','918480/42',60,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0100','Plastic','Plastic Button-100B','917587/74',60,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0101','Plastic','Plastic Button-101B','918282/43',60,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0102','Plastic','Plastic Button-102B','917587/66',60,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0103','Plastic','Plastic Button-103B','918480/91',60,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0104','Plastic','Plastic Button-104B','918475/46',60,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0105','Plastic','Plastic Button-105B','918480/26',60,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0106','Plastic','Plastic Button-106B','918282/49',60,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0107','Plastic','Plastic Button-107B','918487/26',60,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0108','Metal','Navy','RHK41933',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0109','Metal','Silver','RHK43010',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0110','Metal','Gold Flat','REC16470',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0111','Metal','Gold Dome','REC16474',300,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0112','Self-Fabric','Self-Fabric','',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0113','Satin','Wine Satin','',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0114','Satin','Black Satin','',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0115','Satin','Navy Satin','',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0116','Satin','White Satin','',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0117','Velvet','Blue Velvet','',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0118','Velvet','Black Velvet','',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0119','Velvet','Wine Velvet','',0,4);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('Tonal','','','',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0007','Metal','Antique Gold Button','52-20155',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0008','Metal','Antique Silver Button','50-20155',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0010','Metal','Shiny Gold Button-10','RHK-15103',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0011','Metal','Lion Crest Gold Blazer Button','11 (Metal)',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0013','Metal','Antique Gold Metal Button-13','13',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0015','Metal','Dull Silver Metal Blazer Button','15',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0018','Metal','Grey Gold Lion Crest Metal Button','18',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0019','Metal','Gold Metal Blazer Button-19','19',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0024','Metal','Copper Blazer Button-24','24',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0032','Metal','Silver Gold Metal Button-32','32',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0033','Metal','Olive Gold Metal Blazer Button','33',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0034','Metal','Off White Gold Metal Blazer Button','34',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0036','Metal','Silver Shiny Gold Blazer Button','36',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0037','Metal','Copper Blazer Button-37','37',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0041','Metal','Antique Silver Metal Button','41',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0042','Metal','Antique Silver Blazer Button','42',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0043','Metal','Copper Blazer Button-43','43',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0046','Metal','Gold Metal Blazer Button 46','46',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0047','Metal','Black Metal Blazer Button','47',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0048','Metal','Metal Matte With Lion Crest Metal Button','48',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0049J','Metal','Shiny Gold Button-49','49',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0050','Urea Button Tonal','White Urea Button','TBWHITE',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0053','Urea Button Tonal','Beige Brown Urea Button','TB11',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0054','Urea Button Tonal','Cream Urea Button','TBCREAM',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0055','Urea Button Tonal','Green Urea Button','Green',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0056','Urea Button Tonal','Opal Gray Urea Button','TBGREY',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0057','Fancy Button Tonal','Bright Blue Fancy Button','TFB00001',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0058','Fancy Button Tonal','Brick Red Fancy Button','TFB00002',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0059','Fancy Button Tonal','Beige Fancy Button','TFB00003',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0060','Fancy Button Tonal','Pink Lemonade Fancy Button','TFB00004',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0061','Fancy Button Tonal','Red Ochre Fancy Button','TFB00005',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0062','Fancy Button Tonal','Blue Heron Fancy Button','TFB00006',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0063','Fancy Button Tonal','Brown Stone Fancy Button','TFB00007',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0064','Fancy Button Tonal','Madder Brown Fancy Button','TFB00008',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0065','Fancy Button Tonal','Blue Ice Fancy Button','TFB00009',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0066','Fancy Button Tonal','Vermillion Orange Fancy Button','TFB00010',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0067','Fancy Button Tonal','Black Fancy Button','TFB00011',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0068','Fancy Button Tonal','Elfin Yellow Fancy Buton','TFB00012',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0069','Fancy Button Tonal','Black Berry Wine Fancy Button','TFB00013',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0070','Urea Button Tonal','Wood Brown Urea Button','TUB00012',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0071','Urea Button Tonal','Brown Urea Button','TUB00016',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0072','Urea Button Tonal','Navy Urea Button','TUB00026',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0073','Urea Button Tonal','Light Grey Urea Button','TUB00042',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0074','Urea Button Tonal','Charcoal Grey Urea Button','TUB00043',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0075','Urea Button Tonal','Dark Grey Urea Button','TUB00045',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0076','Urea Button Tonal','Grey Urea Button','TUB00059',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0077','Urea Button Tonal','Black Urea Button','TUB00099',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0078','Urea Button Tonal','Taupe Urea Button','TUB00125',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0099','Plastic','Plastic Button-99J','918480/42',120,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0100','Plastic','Plastic Button-100J','917587/74',120,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0101','Plastic','Plastic Button-101J','918282/43',120,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0102','Plastic','Plastic Button-102J','917587/66',120,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0103','Plastic','Plastic Button-103J','918480/91',120,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0104','Plastic','Plastic Button-104J','918475/46',120,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0105','Plastic','Plastic Button-105J','918480/26',120,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0106','Plastic','Plastic Button-106J','918282/49',120,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0107','Plastic','Plastic Button-107J','918487/26',120,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0108','Metal','Navy','RHK41933',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0109','Metal','Silver','RHK43010',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0110','Metal','Gold Flat','REC16470',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0111','Metal','Gold Dome','REC16474',500,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0112','Self-Fabric','Self-Fabric','',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0113','Satin','Wine Satin','',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0114','Satin','Black Satin','',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0115','Satin','Navy Satin','',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0116','Satin','White Satin','',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0117','Velvet','Blue Velvet','',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0118','Velvet','Black Velvet','',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0119','Velvet','Wine Velvet','',0,2);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('Tonal','','','',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0001','Metal','Shiny Silver Button','T1751AB6/1',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0002','Metal','Antique Silver Button','T1751AB6/2',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0003','Metal','Copper Button-3','T1751AB6/3',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0004','Metal','Antique Button','T1781AB6',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0005','Metal','Black Metal Button','T1771AB6',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0006','Metal','Antique Gold Button','T1769AB6',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0007','Metal','Antique Gold Button','52-20155',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0008','Metal','Antique Silver Button','50-20155',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0009','Metal','Antique Button','RR-13524',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0010','Metal','Shiny Gold Button-10','RHK-15103',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0011','Metal','Lion Crest Gold Blazer Button','11 (Metal)',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0012','Metal','Gold Golf Kings Crest Metal Button','12',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0013','Metal','Antique Gold Metal Button-13','13',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0014','Metal','Antique Gold Metal Button-14','14',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0015','Metal','Dull Silver Metal Blazer Button','15',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0016','Metal','Gold Crest Metal Button-16','16',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0017','Metal','Gold Crest Metal Button-17','17',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0018','Metal','Grey Gold Lion Crest Metal Button','18',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0019','Metal','Gold Metal Blazer Button-19','19',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0020','Metal','Gold Metal Blazer Button-20','20',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0021','Metal','Gold Metal Shank Button-21','21',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0023','Metal','Copper Crest Metal Button','23',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0024','Metal','Copper Blazer Button-24','24',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0025','Metal','Gold Metal Shank Button-25','25',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0026','Metal','Olive Gold Metal Button','26',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0027','Metal','Olive Gold Lion Crest Button','27',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0029','Metal','Silver Gold Metal Button-29','29',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0032','Metal','Silver Gold Metal Button-32','32',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0033','Metal','Olive Gold Metal Blazer Button','33',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0034','Metal','Off White Gold Metal Blazer Button','34',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0035','Metal','Grey Silver Metal Button','35',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0036','Metal','Silver Shiny Gold Blazer Button','36',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0037','Metal','Copper Blazer Button-37','37',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0038','Metal','Copper Button-38','38',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0039','Metal','Blue Gold Metal Button','39',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0040','Metal','Black Silver Plastic Metal Button','40',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0041','Metal','Antique Silver Metal Button','41',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0042','Metal','Antique Silver Blazer Button','42',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0043','Metal','Copper Blazer Button-43','43',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0044','Metal','Gold Crest Metal Button-44','44',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0045','Metal','Antique Gold Crowned Eagle Metal Button','45',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0046','Metal','Gold Metal Blazer Button 46','46',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0047','Metal','Black Metal Blazer Button','47',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0048','Metal','Metal Matte With Lion Crest Metal Button','48',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0049J','Metal','Shiny Gold Button-49','49',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0050','Urea Button Tonal','White Urea Button','TBWHITE',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0053','Urea Button Tonal','Beige Brown Urea Button','TB11',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0054','Urea Button Tonal','Cream Urea Button','TBCREAM',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0055','Urea Button Tonal','Green Urea Button','Green',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0056','Urea Button Tonal','Opal Gray Urea Button','TBGREY',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0057','Fancy Button Tonal','Bright Blue Fancy Button','TFB00001',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0058','Fancy Button Tonal','Brick Red Fancy Button','TFB00002',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0059','Fancy Button Tonal','Beige Fancy Button','TFB00003',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0060','Fancy Button Tonal','Pink Lemonade Fancy Button','TFB00004',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0061','Fancy Button Tonal','Red Ochre Fancy Button','TFB00005',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0062','Fancy Button Tonal','Blue Heron Fancy Button','TFB00006',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0063','Fancy Button Tonal','Brown Stone Fancy Button','TFB00007',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0064','Fancy Button Tonal','Madder Brown Fancy Button','TFB00008',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0065','Fancy Button Tonal','Blue Ice Fancy Button','TFB00009',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0066','Fancy Button Tonal','Vermillion Orange Fancy Button','TFB00010',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0067','Fancy Button Tonal','Black Fancy Button','TFB00011',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0068','Fancy Button Tonal','Elfin Yellow Fancy Buton','TFB00012',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0069','Fancy Button Tonal','Black Berry Wine Fancy Button','TFB00013',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0070','Urea Button Tonal','Wood Brown Urea Button','TUB00012',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0071','Urea Button Tonal','Brown Urea Button','TUB00016',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0072','Urea Button Tonal','Navy Urea Button','TUB00026',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0073','Urea Button Tonal','Light Grey Urea Button','TUB00042',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0074','Urea Button Tonal','Charcoal Grey Urea Button','TUB00043',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0075','Urea Button Tonal','Dark Grey Urea Button','TUB00045',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0076','Urea Button Tonal','Grey Urea Button','TUB00059',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0077','Urea Button Tonal','Black Urea Button','TUB00099',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0078','Urea Button Tonal','Taupe Urea Button','TUB00125',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0099','Plastic','Plastic Button-99B','918480/42',60,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0100','Plastic','Plastic Button-100B','917587/74',60,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0101','Plastic','Plastic Button-101B','918282/43',60,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0102','Plastic','Plastic Button-102B','917587/66',60,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0103','Plastic','Plastic Button-103B','918480/91',60,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0104','Plastic','Plastic Button-104B','918475/46',60,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0105','Plastic','Plastic Button-105B','918480/26',60,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0106','Plastic','Plastic Button-106B','918282/49',60,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0107','Plastic','Plastic Button-107B','918487/26',60,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0108','Metal','Navy','RHK41933',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0109','Metal','Silver','RHK43010',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0110','Metal','Gold Flat','REC16470',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0111','Metal','Gold Dome','REC16474',300,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0112','Self-Fabric','Self-Fabric','',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0113','Satin','Wine Satin','',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0114','Satin','Black Satin','',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0115','Satin','Navy Satin','',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0116','Satin','White Satin','',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0117','Velvet','Blue Velvet','',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0118','Velvet','Black Velvet','',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0119','Velvet','Wine Velvet','',0,5);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0052','Pearl','Shirt Black Perl 16 L','Black Perl 16 L',0,1);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0081','Plastic','Shirts Classic White 14 L','917233/W23',0,1);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0082','Plastic','Shirts Classic Black 14 L','917233/BK23',0,1);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0084','Plastic','Dover','917233/Dk.Purple',0,1);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0085','Plastic','Bruinen','917233/Lilac',0,1);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0086','Plastic','Dathan','917233/Purple',0,1);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0087','Plastic','Sastead','917233/Dk.Blue',0,1);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0088','Plastic','Blubrok','917233/Grey',0,1);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0089','Plastic','Strautin','917233/Lt.Blue',0,1);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0090','Plastic','Peahwell','917233/Red',0,1);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0091','Plastic','Chaiton','917233/Bluish Grey',0,1);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0092','Plastic','Meley','917233/Pink',0,1);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('Tonal','','','',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0050','Urea Button Tonal','White Urea Button','TBWHITE',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0053','Urea Button Tonal','Beige Brown Urea Button','TB11',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0054','Urea Button Tonal','Cream Urea Button','TBCREAM',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0055','Urea Button Tonal','Green Urea Button','Green',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0056','Urea Button Tonal','Opal Gray Urea Button','TBGREY',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0057','Fancy Button Tonal','Bright Blue Fancy Button','TFB00001',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0058','Fancy Button Tonal','Brick Red Fancy Button','TFB00002',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0059','Fancy Button Tonal','Beige Fancy Button','TFB00003',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0060','Fancy Button Tonal','Pink Lemonade Fancy Button','TFB00004',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0061','Fancy Button Tonal','Red Ochre Fancy Button','TFB00005',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0062','Fancy Button Tonal','Blue Heron Fancy Button','TFB00006',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0063','Fancy Button Tonal','Brown Stone Fancy Button','TFB00007',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0064','Fancy Button Tonal','Madder Brown Fancy Button','TFB00008',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0065','Fancy Button Tonal','Blue Ice Fancy Button','TFB00009',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0066','Fancy Button Tonal','Vermillion Orange Fancy Button','TFB00010',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0067','Fancy Button Tonal','Black Fancy Button','TFB00011',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0068','Fancy Button Tonal','Elfin Yellow Fancy Buton','TFB00012',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0069','Fancy Button Tonal','Black Berry Wine Fancy Button','TFB00013',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0070','Urea Button Tonal','Wood Brown Urea Button','TUB00012',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0071','Urea Button Tonal','Brown Urea Button','TUB00016',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0072','Urea Button Tonal','Navy Urea Button','TUB00026',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0073','Urea Button Tonal','Light Grey Urea Button','TUB00042',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0074','Urea Button Tonal','Charcoal Grey Urea Button','TUB00043',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0075','Urea Button Tonal','Dark Grey Urea Button','TUB00045',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0076','Urea Button Tonal','Grey Urea Button','TUB00059',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0077','Urea Button Tonal','Black Urea Button','TUB00099',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0078','Urea Button Tonal','Taupe Urea Button','TUB00125',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0099','Plastic','Plastic Button-99S','918480/42',160,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0100','Plastic','Plastic Button-100S','917587/74',160,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0101','Plastic','Plastic Button-101S','918282/43',160,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0102','Plastic','Plastic Button-102S','917587/66',160,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0103','Plastic','Plastic Button-103S','918480/91',160,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0104','Plastic','Plastic Button-104S','918475/46',160,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0105','Plastic','Plastic Button-105S','918480/26',160,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0106','Plastic','Plastic Button-106S','918282/49',160,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0107','Plastic','Plastic Button-107S','918487/26',160,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0112','Self-Fabric','Self-Fabric','',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0113','Satin','Wine Satin','',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0114','Satin','Black Satin','',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0115','Satin','Navy Satin','',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0116','Satin','White Satin','',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0117','Velvet','Blue Velvet','',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0118','Velvet','Black Velvet','',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0119','Velvet','Wine Velvet','',0,31);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('Tonal','','','',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0050','Urea Button Tonal','White Urea Button','TBWHITE',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0053','Urea Button Tonal','Beige Brown Urea Button','TB11',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0054','Urea Button Tonal','Cream Urea Button','TBCREAM',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0055','Urea Button Tonal','Green Urea Button','Green',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0056','Urea Button Tonal','Opal Gray Urea Button','TBGREY',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0057','Fancy Button Tonal','Bright Blue Fancy Button','TFB00001',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0058','Fancy Button Tonal','Brick Red Fancy Button','TFB00002',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0059','Fancy Button Tonal','Beige Fancy Button','TFB00003',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0060','Fancy Button Tonal','Pink Lemonade Fancy Button','TFB00004',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0061','Fancy Button Tonal','Red Ochre Fancy Button','TFB00005',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0062','Fancy Button Tonal','Blue Heron Fancy Button','TFB00006',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0063','Fancy Button Tonal','Brown Stone Fancy Button','TFB00007',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0064','Fancy Button Tonal','Madder Brown Fancy Button','TFB00008',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0065','Fancy Button Tonal','Blue Ice Fancy Button','TFB00009',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0066','Fancy Button Tonal','Vermillion Orange Fancy Button','TFB00010',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0067','Fancy Button Tonal','Black Fancy Button','TFB00011',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0068','Fancy Button Tonal','Elfin Yellow Fancy Buton','TFB00012',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0069','Fancy Button Tonal','Black Berry Wine Fancy Button','TFB00013',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0070','Urea Button Tonal','Wood Brown Urea Button','TUB00012',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0071','Urea Button Tonal','Brown Urea Button','TUB00016',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0072','Urea Button Tonal','Navy Urea Button','TUB00026',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0073','Urea Button Tonal','Light Grey Urea Button','TUB00042',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0074','Urea Button Tonal','Charcoal Grey Urea Button','TUB00043',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0075','Urea Button Tonal','Dark Grey Urea Button','TUB00045',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0076','Urea Button Tonal','Grey Urea Button','TUB00059',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0077','Urea Button Tonal','Black Urea Button','TUB00099',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0078','Urea Button Tonal','Taupe Urea Button','TUB00125',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0099','Plastic','Plastic Button-99P','918480/42',40,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0100','Plastic','Plastic Button-100P','917587/74',40,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0101','Plastic','Plastic Button-101P','918282/43',40,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0102','Plastic','Plastic Button-102P','917587/66',40,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0103','Plastic','Plastic Button-103P','918480/91',40,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0104','Plastic','Plastic Button-104P','918475/46',40,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0105','Plastic','Plastic Button-105P','918480/26',40,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0106','Plastic','Plastic Button-106P','918282/49',40,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0107','Plastic','Plastic Button-107P','918487/26',40,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0112','Self-Fabric','Self-Fabric','',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0113','Satin','Wine Satin','',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0114','Satin','Black Satin','',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0115','Satin','Navy Satin','',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0116','Satin','White Satin','',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0117','Velvet','Blue Velvet','',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0118','Velvet','Black Velvet','',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0119','Velvet','Wine Velvet','',0,3);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('Tonal','','','',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0001','Metal','Shiny Silver Button','T1751AB6/1',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0002','Metal','Antique Silver Button','T1751AB6/2',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0003','Metal','Copper Button-3','T1751AB6/3',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0004','Metal','Antique Button','T1781AB6',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0005','Metal','Black Metal Button','T1771AB6',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0006','Metal','Antique Gold Button','T1769AB6',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0007','Metal','Antique Gold Button','52-20155',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0008','Metal','Antique Silver Button','50-20155',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0009','Metal','Antique Button','RR-13524',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0010','Metal','Shiny Gold Button-10','RHK-15103',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0011','Metal','Lion Crest Gold Blazer Button','11 (Metal)',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0012','Metal','Gold Golf Kings Crest Metal Button','12',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0013','Metal','Antique Gold Metal Button-13','13',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0014','Metal','Antique Gold Metal Button-14','14',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0015','Metal','Dull Silver Metal Blazer Button','15',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0016','Metal','Gold Crest Metal Button-16','16',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0017','Metal','Gold Crest Metal Button-17','17',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0018','Metal','Grey Gold Lion Crest Metal Button','18',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0019','Metal','Gold Metal Blazer Button-19','19',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0020','Metal','Gold Metal Blazer Button-20','20',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0021','Metal','Gold Metal Shank Button-21','21',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0023','Metal','Copper Crest Metal Button','23',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0024','Metal','Copper Blazer Button-24','24',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0025','Metal','Gold Metal Shank Button-25','25',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0026','Metal','Olive Gold Metal Button','26',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0027','Metal','Olive Gold Lion Crest Button','27',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0029','Metal','Silver Gold Metal Button-29','29',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0032','Metal','Silver Gold Metal Button-32','32',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0033','Metal','Olive Gold Metal Blazer Button','33',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0034','Metal','Off White Gold Metal Blazer Button','34',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0035','Metal','Grey Silver Metal Button','35',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0036','Metal','Silver Shiny Gold Blazer Button','36',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0037','Metal','Copper Blazer Button-37','37',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0038','Metal','Copper Button-38','38',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0039','Metal','Blue Gold Metal Button','39',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0040','Metal','Black Silver Plastic Metal Button','40',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0041','Metal','Antique Silver Metal Button','41',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0042','Metal','Antique Silver Blazer Button','42',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0043','Metal','Copper Blazer Button-43','43',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0044','Metal','Gold Crest Metal Button-44','44',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0045','Metal','Antique Gold Crowned Eagle Metal Button','45',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0046','Metal','Gold Metal Blazer Button 46','46',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0047','Metal','Black Metal Blazer Button','47',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0048','Metal','Metal Matte With Lion Crest Metal Button','48',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0049J','Metal','Shiny Gold Button-49','49',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0050','Urea Button Tonal','White Urea Button','TBWHITE',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0053','Urea Button Tonal','Beige Brown Urea Button','TB11',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0054','Urea Button Tonal','Cream Urea Button','TBCREAM',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0055','Urea Button Tonal','Green Urea Button','Green',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0056','Urea Button Tonal','Opal Gray Urea Button','TBGREY',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0057','Fancy Button Tonal','Bright Blue Fancy Button','TFB00001',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0058','Fancy Button Tonal','Brick Red Fancy Button','TFB00002',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0059','Fancy Button Tonal','Beige Fancy Button','TFB00003',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0060','Fancy Button Tonal','Pink Lemonade Fancy Button','TFB00004',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0061','Fancy Button Tonal','Red Ochre Fancy Button','TFB00005',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0062','Fancy Button Tonal','Blue Heron Fancy Button','TFB00006',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0063','Fancy Button Tonal','Brown Stone Fancy Button','TFB00007',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0064','Fancy Button Tonal','Madder Brown Fancy Button','TFB00008',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0065','Fancy Button Tonal','Blue Ice Fancy Button','TFB00009',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0066','Fancy Button Tonal','Vermillion Orange Fancy Button','TFB00010',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0067','Fancy Button Tonal','Black Fancy Button','TFB00011',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0068','Fancy Button Tonal','Elfin Yellow Fancy Buton','TFB00012',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0069','Fancy Button Tonal','Black Berry Wine Fancy Button','TFB00013',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0070','Urea Button Tonal','Wood Brown Urea Button','TUB00012',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0071','Urea Button Tonal','Brown Urea Button','TUB00016',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0072','Urea Button Tonal','Navy Urea Button','TUB00026',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0073','Urea Button Tonal','Light Grey Urea Button','TUB00042',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0074','Urea Button Tonal','Charcoal Grey Urea Button','TUB00043',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0075','Urea Button Tonal','Dark Grey Urea Button','TUB00045',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0076','Urea Button Tonal','Grey Urea Button','TUB00059',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0077','Urea Button Tonal','Black Urea Button','TUB00099',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0078','Urea Button Tonal','Taupe Urea Button','TUB00125',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0099','Plastic','Plastic Button-99W','918480/42',60,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0100','Plastic','Plastic Button-100W','917587/74',60,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0101','Plastic','Plastic Button-101W','918282/43',60,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0102','Plastic','Plastic Button-102W','917587/66',60,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0103','Plastic','Plastic Button-103W','918480/91',60,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0104','Plastic','Plastic Button-104W','918475/46',60,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0105','Plastic','Plastic Button-105W','918480/26',60,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0106','Plastic','Plastic Button-106W','918282/49',60,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0107','Plastic','Plastic Button-107W','918487/26',60,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0108','Metal','Navy','RHK41933',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0109','Metal','Silver','RHK43010',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0110','Metal','Gold Flat','REC16470',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0111','Metal','Gold Dome','REC16474',300,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0112','Self-Fabric','Self-Fabric','',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0113','Satin','Wine Satin','',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0114','Satin','Black Satin','',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0115','Satin','Navy Satin','',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0116','Satin','White Satin','',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0117','Velvet','Blue Velvet','',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0118','Velvet','Black Velvet','',0,6);
insert into item_type_style_dropdownlist(button_sku,button_type,descr,supplier_product_code,upcharge,item_type_id ) 
values ('BTN0119','Velvet','Wine Velvet','',0,6);



-------------------------------------------------------------------------------------------------------------------------


insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('Tonal','','',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LS-1','Morza Silk Beige','LD00001',2500,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LS-2','Morza Silk Maroon','LD00002',2500,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LS-3','Morza Silk Black','LD00003',2500,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-7','Blue Brown Paisley','LD00007',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-9','Grey With White Polka Dots','LD00009',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-11','Gold Steep Twill','LD00011',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-12','Grey Silver Mini Polka','LD00012',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-13','Orange Green Paisley','LD00013',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-14','Grey Paisley','LD00014',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-15','Small Paisley Blue','LD00015',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-16','Polka Dot Stripe Silver','LD00016',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-51','Polka Dot Black-White','LD00051',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-52','Polka Dot Grey-White','LD00052',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-53','Polka Dot Purple-Gold','LD00053',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-54','Brown Dots','LD00054',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-55','Grey Cubes','LD00055',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-56','Pink Cubes','LD00056',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-57','Sea Green Stripes','LD00057',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-58','Grey & White Stripe','LD00058',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-59','Brown stripes','LD00059',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-60','Charcoal Grey Stripe','LD00060',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-61','Indigo Stripes','LD00061',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-62','Black & Grey Stripe','LD00062',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-63','The Orange Blue ','LD00063',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-64','Multi-Coloured stripes','LD00064',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-65','Tan Matt','LD00065',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-66','Olive Matt','LD00066',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-67','Indigo Matt','LD00067',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-68','Black Matt','LD00068',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-69','Two tone Matt Tan','LD00069',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-70','Brown Two-tone Houndstooth','LD00070',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-71','Paisley Green','LD00071',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-72','Paisley Olive','LD00072',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-73','Sky Blue Paisley','LD00073',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-74','Paisley Blue','LD00074',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-75','Paisley Black','LD00075',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-76','Blue Black Paisley','LD00076',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-77','Paisley Brown','LD00077',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-78','Paisley Grey','LD00078',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-79','Mughal Art','LD00079',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-80','White Grey Checks','LD00080',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-81','The Brown Checks','LD00081',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-82','Polka Dot Brown-Beige','LD00082',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-83','Red Two-tone','LD00083',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-84','Honeysuckle','LD00084',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-85','Beeswax','LD00085',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-86','Silver Cloud','LD00086',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-87','Woodbine','LD00087',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-88','Peapod','LD00088',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-89','Purple Twill','LD00089',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-90','Gold Twill','LD00090',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-91','Brown Gold Two-Tone','LD00091',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-92','Brown Twill','LD00092',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-93','Pale Turquoise','LD00093',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-94','Pale Violet Red','LD00094',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-95','Beige Two-Tone','LD00095',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-96','Khaki Self Dots','LD00096',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-97','Dark Khaki','LD00097',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-98','Navy With White Mini Polka','LD00098',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-99','Black With Blue Mini Polka','LD00099',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-100','Black With White Polka','LD00100',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-101','Black With White Mini Polka','LD00101',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-102','White With Black Mini Polka','LD00102',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-103','Black With White Triangles','LD00103',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-104','Blue With White Traingles','LD00104',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-105','Witney','LD00105',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-106','Wivenhoe','LD00106',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-107','Steyning','LD00107',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-108','Woburn','LD00108',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-109','Stow','LD00109',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-110','Brown Diamond Dobby','LD00110',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-111','Navy Diamond Dobby','LD00111',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-112','Grey Diamond Dobby','LD00112',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-113','Black Diamond Dobby','LD00113',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-114','Allen','LD00114',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-115','Regina','LD00115',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-116','Glenn Heights','LD00116',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-117','Godley','LD00117',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-118','Shrewsbury','LD00118',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-119','Hideaway','LD00119',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-120','Howardwick','LD00120',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-121','Marion','LD00121',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-122','Morden ','LD00122',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-123','Menard','LD00123',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-124','Muenster','LD00124',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-125','Gregory','LD00125',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-126','Black White Micro Gingham','LD00126',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-127','Maroon Beige Micro Gingham','LD00127',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-128','Greenville','LD00128',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-129','Beige Black Hound','LD00129',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-130','Multicolor Diamond Printed ','LD00130',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-131','Bastrop','LD00131',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-132','Aquilla','LD00132',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-133','Norsewood','LD00133',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-134','Argyle','LD00134',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-135','Bellaire','LD00135',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-136','Bremond','LD00136',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-137','Prescot','LD00137',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-138','Brenham','LD00138',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-139','Blossom','LD00139',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-140','Grey Satin Leaves and Clovers','LD00140',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-142','Callisburg','LD00142',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-144','Green Ivory Printed','LD00144',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-145','Brown Olive Printed','LD00145',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-146','Browndell','LD00146',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-147','Markham','LD00147',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-148','Mughal Art-Brown','LD00148',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-149','Blue Ridge','LD00149',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-150','Beige Olive Paisley','LD00150',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-151','Brown Paisley','LD00151',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-152','Beige Black Paisley','LD00152',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-153','Pecan Hill','LD00153',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-154','Carrollton','LD00154',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-155','Lilac Paisley','LD00155',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-156','Atlanta','LD00156',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-157','Olive Paisley','LD00157',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-158','Beige Paisley','LD00158',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-159','Orange Paisley','LD00159',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-160','Brown Paisley Jaquard','LD00160',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-161','Black Jaquard Paisley','LD00161',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-162','Cornwall','LD00162',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-163','Blue Moon','LD00163',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-164','Blue Two-Tone Houndstooth','LD00164',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-165','Brandon ','LD00165',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-166','Shefford','LD00166',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-167','Blue Cream Paisley','LD00167',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-168','Polka Dot Stripe Light Grey ','LD00168',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-169','Polka Dot Stripe Cream','LD00169',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-170','Polka Dot Stripe Black','LD00170',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-171','Polka Dot Stripe Blue','LD00171',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-172','Grey Micro Check','LD00172',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-173','Grey Pin Dot','LD00173',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-174','Mini Polka Dot Stripe Black','LD00174',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-175','Navy Micro Dot','LD00175',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-176','Peace River ','LD00176',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-177','Khaki Herring','LD00177',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-178','Alaskan Blue','LD00178',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-179','Green Olive Herring','LD00179',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-1','Beige Twill','LD00180',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-2','Dark Brown Twill','LD00181',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-3','Grey Twill','LD00182',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-4','Navy Twill','LD00183',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-5','Dark Grey Twill','LD00184',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-17','Off White Twill','LD00188',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-20','Ivory Twill','LD00191',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-101','Black Solid','LD00199',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-102','Navy Solid','LD00200',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-103','Dark Grey Solid','LD00201',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-104','Light Grey Solid','LD00202',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-105','Dark Brown Solid','LD00203',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-106','Khaki Solid','LD00204',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-107','Beige Solid','LD00205',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-108','Navy Shiny Twill','LD00206',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-109','Beige Shiny Twill','LD00210',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-110','Cream Shiny Twill','LD00211',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-111','Yellow Shiny Twill','LD00212',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-112','Blush Shiny Twill','LD00213',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-113','Green Shiny Twill','LD00214',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-114','Bulgarian Rose','LD00215',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-115','Purple Shiny Twill','LD00216',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-116','Venetian Red','LD00217',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-117','Cornsilk Beige','LD00218',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('VL-118','Dartmouth Green','LD00219',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-21','Rosewood Solid','LD00220',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-22','Light Khaki Solid','LD00221',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-23','Olive Solid','LD00222',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-24','Silver Gray Solid','LD00223',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-25','True Blue Solid','LD00224',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-26','Turquoise Blue','LD00225',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-27','Tangelo Solid','LD00226',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-28','Electric Crimson','LD00227',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-29','Pink Solid','LD00228',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-30','Chartreuse Solid','LD00229',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-31','Ash Grey Solid','LD00230',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('L-32','Brown Solid','LD00231',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-232','Macroon Beige Paisley','LD00232',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-233','Orange Blue Paisley','LD00233',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-234','Multicolor Paisley','LD00234',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-235','Prussian Blue Paisley','LD00235',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-236','Charcoal Grey Paisley','LD00236',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-237','Ivory Floral Print','LD00237',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-238','Mustard Beige Floral Prinr','LD00238',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-239','Multicolor Floral Print','LD00239',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-240','Multicolor Geometric Print','LD00240',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-241','Black & White Print','LD00241',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-242','Beige With Blue Round Print','LD00242',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-243','Black With Blue Round Print','LD00243',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-244','Grey Light Blue Print','LD00244',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-245','Teal Blue With Big Diamond Print','LD00245',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-246','Maroon Blue Geometric Print','LD00246',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-247','Olive with Black Buti Print','LD00247',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-248','Beige Brown Plaid','LD00248',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-249','Blue White Chevron','LD00249',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-250','Silver Grey Mini Prints','LD00250',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-251','Mineral Navy Mini Print','LD00251',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-252','Espresso Brown Self Diamonds','LD00252',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-253','Black Houndstooth','LD00253',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-254','Ivory Twill','LD00254',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-255','Maroon Twill','LD00255',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-256','Rose Pink Twill','LD00256',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-257','Persian Red Twill','LD00257',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-258','Violet Indigo Twill','LD00258',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-259','Fired Brick Twill','LD00259',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-260','Scarlet Red Twill','LD00260',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-261','Tangerine Twill','LD00261',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-262','Blazing Yellow Twill','LD00262',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-263','Deep Sky Blue Twill','LD00263',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-264','Emerald Green Twill','LD00264',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-265','Dark Green Twiil','LD00265',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-266','Lemon Yellow Solid','LD00266',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-267','Lime Green Twill','LD00267',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-268','Azure Blue Solid','LD00268',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-269','Garnet Pink Twill','LD00269',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-270','Gold Blue Jacquard','LD00270',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-271','Blue Navy Jacquard','LD00271',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-272','Red Brown Jacquard','LD00272',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-273','Teal Blue Houndstooth','LD00273',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-274','Garnet Houndstooth','LD00274',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-275','Magenta Small Paisley','LD00275',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-276','Dark Blue Small Paisley','LD00276',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-277','Grey Blue Small Paisley','LD00277',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-278','Light Grey Small Paisley','LD00278',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-279','Purple Small Paisley','LD00279',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-280','Blue Black Jacquard Paisley','LD00280',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-281','Maroon Red Jacquard Paisley','LD00281',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-282','Light Blue Gold Jacquard Paisley','LD00282',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-283','Blue Gold Jacquard Paisley','LD00283',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-284','Purple Gold Jacquard Paisley','LD00284',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-285','Grey Polka Dots','LD00285',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-286','Blue Polka Dots','LD00286',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-287','Pink Polka Dots','LD00287',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-288','Black Polka Dots','LD00288',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-289','Grey Flower Jacquard','LD00289',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-290','Sapphire Blue Flower Jacquard','LD00290',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-291','Black Flower Jacquard','LD00291',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-292','Berry Flower Jacquard','LD00292',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-293','Black Mini Paisley','LD00293',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-294','Blue Diamonds','LD00294',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-295','Black Seamless Pattern','LD00295',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-296','Cream Polka Dot','LD00296',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-297','Aegean Blue Printed','LD00297',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-298','Beige Mini Print','LD00298',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-299','Dark Navy Floral Print','LD00299',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-300','Brown Mini Print','LD00300',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-301','Brown Abstract Print','LD00301',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-302','Light Grey Geometric Print','LD00302',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-303','Blue Houndstooth','LD00303',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-304','Grey Polka With PinStripe','LD00304',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-305','Damask Print','LD00305',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-306','Light Blue Geometric Flowers','LD00306',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-307','Brown Wine Lattice Print','LD00307',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-308','Multicolor Paisley','LD00308',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-309','Beige Rust Diamond Structure','LD00309',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-310','Ivory Polka Dots','LD00310',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-311','Navy Green Paisley','LD00311',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-312','Gray Wine Lattice Print','LD00312',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-313','Bluebird Pinstripe Polka','LD00313',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-314','Multicolor Floral Paisley','LD00314',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-315','Navy Box Print','LD00315',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-316','Beige Paisley Print','LD00316',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-317','Beige Navy Lattice Print','LD00317',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-318','Dark Navy Flower Print','LD00318',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-319','Navy Mini Diamonds','LD00319',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-320','Beige Grey Lattice Print','LD00320',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-321','French Navy Seamless Mini Lines','LD00321',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-322','Copper Gray Paisley','LD00322',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-323','Flint Navy Mini Polka','LD00323',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-324','Rich Navy Mini Polka','LD00324',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-325','Navy Geometric Floral Print','LD00325',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-326','Black Dobby','LD00326',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-327','Navy Geometric Lines Structured','LD00327',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-328','Navy Brown Lattice Print','LD00328',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-329','Charcoal Olive Paisley','LD00329',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-330','Black With White Dots','LD00330',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-331','Black Floral Dobby','LD00331',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-332','Maroon Dots','LD00332',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-333','Black Dots','LD00333',0,true);
insert into item_type_style_dropdownlist(button_sku,descr,supplier_product_code,upcharge,is_lining ) 
values ('LD-334','Navy Geometric Dobby','LD00334',0,true);