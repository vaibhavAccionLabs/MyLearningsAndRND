alter table m_store add column store_address character varying;
alter table m_store add column state_code integer;
alter table m_store add column gst_code character varying;

update m_store set store_address = 'No. 2, Bowring Hospital Road, Shivaji Nagar, Bengaluru, Karnataka',state_code=29,gst_code='29AAFCC0250L1ZO' where store_id= 5;


update m_store set store_address = '1/7, 10 Main, First Floor, Ashoka Pillar Circle, 100 Feet Road, 1st Block, Jayanagar, Bengalure, Karnataka',state_code=29,gst_code='29AAFCC0250L1ZO' where store_id= 3;
update m_store set store_address = 'Unit-2, Hagadur Main Road, Whitefield, Bengaluru, Karnataka',state_code=29,gst_code='29AAFCC0250L1ZO' where store_id= 1;
update m_store set store_address = '1201, 100 FT Road, HAL 2nd stage, Indiranagar, Bengaluru, Karnataka',state_code=29,gst_code='29AAFCC0250L1ZO' where store_id= 2;
update m_store set store_address='No. 2, Bowring Hospital Road, Shivaji Nagar, Bengaluru, Karnataka',state_code=29,gst_code='29AAFCC0250L1ZO' where store_id= 4;


update m_store set store_address = 'Survey No.48/2 Kudlu Village, Anekal Taluk Sarjapura Hobli, Bangalore District, Bbmp, Bangalore',state_code=29,gst_code='29AAFCC0250L1ZO' where store_id = 11;


update m_store set store_address = '41-42, College Road, Chennai, Tamil Nadu',state_code=29,gst_code='29AAFCC0250L1ZO' where store_id = 12;
update m_store set store_address = 'Survey No.48/2 Kudlu Village, Anekal Taluk Sarjapura Hobli, Bangalore District, Bbmp, Bangalore',state_code=29,gst_code='29AAFCC0250L1ZO' where store_id = 14;
update m_store set store_address = 'Survey No.48/2 Kudlu Village, Anekal Taluk Sarjapura Hobli, Bangalore District, Bbmp, Bangalore',state_code=29,gst_code='29AAFCC0250L1ZO' where store_id = 15;

update m_store set store_address = 'Survey No.48/2 Kudlu Village, Anekal Taluk Sarjapura Hobli, Bangalore District, Bbmp, Bangalore',state_code=33,gst_code='33AAFCC0250L1ZZ' where store_id = 6;
update m_store set store_address = 'No-142, Phoenix Market City, Velachery Main Road, Chennai',state_code=33,gst_code='33AAFCC0250L1ZZ' where store_id = 7;
update m_store set store_address = 'Door No 550, 136, TTK Road, Sriram Nagar, Chennai',state_code=33,gst_code='33AAFCC0250L1ZZ' where store_id = 8;

update m_store set store_address = '8-2-293/82/A/1132/A, Ground Floor, Road No 36, Jubilee Hills, Telengana, Hyderabad',state_code=36,gst_code='36AAFCC0250L1ZT' where store_id = 9;

update m_store set store_address = '53, Chowringhee Road, Kolkata, West Bengal',state_code=19,gst_code='19AAFCC0250L1ZP' where store_id = 10;



-- CREATE OR REPLACE FUNCTION public."GetOrderDetails"(
-- 	in_order_id integer)
-- RETURNS TABLE(order_id integer, tailor_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, sales_man_id integer, tailor_name character varying, order_type text, store character varying,store_address character varying,state_code integer,gst_code character varying,city character varying,user_name character varying, payment_type character varying, sales_man character varying, shipping_charges integer, pin_date timestamp without time zone, redeemcoupon_json json)
--     LANGUAGE 'plpgsql'
--     COST 100.0
--     VOLATILE 
--     ROWS 1000.0
-- AS $function$

--  BEGIN 
--   return query SELECT o.order_id, o.tailor_id, o.customer_id, o.order_type_id, o.store_id, o.user_id, 
--        o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
--        o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
--         o.payment_type_id, o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
--        o.delivery_address, o.pin_number,o.sales_man_id  , t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,s.store_address,s.state_code,s.gst_code,s.city,u.fname,p.code ,sm.name, o.international_shipping_charges,o.pin_date,o.redeemcoupon_json
--   FROM b_order o , m_tailor t,  m_store s, m_user u,m_payment_type p , m_sales_man sm
-- where o.order_id=in_order_id 
-- 	and o.tailor_id = t.tailor_id
-- 	and o.store_id =s.store_id
-- 	and o.payment_type_id =p.payment_type_id
-- 	and o.sales_man_id = sm.sales_man_id
-- 	and o.user_id=u.user_id
-- ;
-- END;

-- $function$;