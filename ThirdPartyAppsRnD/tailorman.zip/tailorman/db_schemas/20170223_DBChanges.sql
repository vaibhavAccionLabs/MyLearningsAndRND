-- FUNCTION: public."GetCustomerList"character varying

DROP FUNCTION public."GetCustomerList"(character varying);

CREATE OR REPLACE FUNCTION public."GetCustomerList"(
	in_param character varying)
RETURNS TABLE(customer_id integer, name character varying, gender character varying, dob date, mobile character varying, address character varying, email character varying, height double precision, weight double precision, source character varying, comment character varying,total_order_amount double precision)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$
 BEGIN 
  return query SELECT c.customer_id,c.name, c.gender, c.dob, c.mobile, c.address, c.email, c.height, 
       c.weight, s.code , c.comment,(SELECT sum(o.total_amount)+ c.total_order_amount  
        FROM b_order AS o
        WHERE c.customer_id = o.customer_id
       ) AS total_order_amount  
  FROM m_source s,m_customer c 
  where c.source_id = s.source_id and (c.name ilike  '%' || in_param || '%' or c.mobile ilike '%' ||  in_param || '%' or c.email ilike '%' ||  in_param || '%' ) ;

END;

$function$;

ALTER FUNCTION public."GetCustomerList"(character varying)
    OWNER TO tailorman_db;
