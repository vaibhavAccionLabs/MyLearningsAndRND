CREATE OR REPLACE FUNCTION public."UpdateOrder"(
	in_order_id integer,
	in_tailor_id integer,
	in_customer_id integer,
	in_order_type_id integer,
	in_store_id integer,
	in_user_id integer,
	in_order_date date,
	in_occasion character varying,
	in_occation_date date,
	in_benficiary_name character varying,
	in_benficiary_mobile character varying,
	in_benificiary_email character varying,
	in_priority_id integer,
	in_payment_type_id integer,
	in_payment_details character varying,
	in_total_amount double precision,
	in_comment character varying,
	in_display_name character varying,
	in_full_payment_flag character,
	in_billing_address character varying,
	in_delivery_address character varying,
	in_pin_number character varying,
	in_sales_man_id integer,
	in_shipping_charges integer)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

 
DECLARE

BEGIN 

update b_order set (
             tailor_id, customer_id, order_type_id, store_id, user_id, 
            order_date, occasion, occation_date, benficiary_name, benficiary_mobile, 
            benificiary_email, created_by, created_time, modified_by, modified_time, 
            priority_id, payment_type_id, payment_details,total_amount,comment,display_name,full_payment_flag,billing_address,delivery_address, pin_number,sales_man_id, international_shipping_charges)
    = ( in_tailor_id, in_customer_id, in_order_type_id, in_store_id, in_user_id, 
            in_order_date, in_occasion, in_occation_date,in_benficiary_name, in_benficiary_mobile, 
            in_benificiary_email, in_user_id, now(), in_user_id, now(), 
            in_priority_id, in_payment_type_id, in_payment_details,in_total_amount,in_comment,in_display_name,in_full_payment_flag, in_billing_address,in_delivery_address, in_pin_number,in_sales_man_id, in_shipping_charges) where order_id=in_order_id and customer_id = in_customer_id ;
return true ;
END;

$function$;

ALTER FUNCTION public."UpdateOrder"(integer, integer, integer, integer, integer, integer, date, character varying, date, character varying, character varying, character varying, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, integer, integer)
    OWNER TO tailorman_db;