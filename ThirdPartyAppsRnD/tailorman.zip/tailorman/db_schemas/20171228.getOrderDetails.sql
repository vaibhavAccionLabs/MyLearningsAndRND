

alter table m_store add column email character varying;

--kudlu -1
update m_store set email='ppd@tailorman.com' where store_id=14;

--HNI - banguluru HNI-2
update m_store set email='hnicorp@tailorman.com' where store_id=15;

--HNI - corp HNI-3
update m_store set email='hnicorp@tailorman.com' where store_id=16;

--Online-4
update m_store set email='ppd@tailorman.com' where store_id=11;

--IN-5
update m_store set email='guidestore_in_blr@tailorman.com' where store_id=2;

--CR-6
update m_store set email='guidestore_cr_che@tailorman.com' where store_id=6;

--WF-7
update m_store set email='guidestore_wf_blr@tailorman.com' where store_id=1;

--AMAZON-8
update m_store set email='ppd@tailorman.com' where store_id=12;

--PM-9
update m_store set email='guidestore_pm_che@tailorman.com' where store_id=7;

--JN-10
update m_store set email='guidestore_jn_blr@tailorman.com' where store_id=3;

--HYD-11
update m_store set email='guidestore_jh_hyd@tailorman.com' where store_id=9;

--HYD-PG-12
update m_store set email='guidestore_pg_hyd@tailorman.com' where store_id=13;

--Kolkata
update m_store set email='guidestore_ss_kol@tailorman.com' where store_id=10;

--TS
update m_store set email='guidestore@tailorman.com' where store_id=5;

--TT
update m_store set email='tt@tailorman.com' where store_id=4;


--TTK
update m_store set email='guidestore_ttk_che@tailorman.com' where store_id=8;


--TT
--update m_store set email='supriya.malla@walkingtree.tech' where store_id=4;

DROP FUNCTION public."GetOrderDetails"(
	in_order_id integer);
CREATE OR REPLACE FUNCTION public."GetOrderDetails"(
	in_order_id integer)
RETURNS TABLE(order_id integer, tailor_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, sales_man_id integer, tailor_name character varying, order_type text, store character varying, user_name character varying, payment_type character varying, sales_man character varying, shipping_charges integer, pin_date timestamp without time zone, redeemcoupon_json json, customer_email character varying, customer_name character varying, store_address character varying, state_code integer, gst_code character varying, city character varying, half_amount integer, store_initials character varying, invoice_number character varying,store_email character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT o.order_id, o.tailor_id, o.customer_id, o.order_type_id, o.store_id, o.user_id, 
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
        o.payment_type_id, o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,o.sales_man_id  , t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,p.code ,sm.name, o.international_shipping_charges,o.pin_date,o.redeemcoupon_json,mc.email,mc.name,s.store_address,s.state_code,s.gst_code,s.city,cop.amount as half_amount,s.store_initials,o.invoice_number,s.email 
  FROM b_order o , m_tailor t,  m_store s, m_user u,m_payment_type p , m_sales_man sm,m_customer mc
  	LEFT JOIN c_order_payment cop on cop.order_id = in_order_id
where o.order_id=in_order_id 
	and o.tailor_id = t.tailor_id
	and o.store_id =s.store_id
	and o.payment_type_id =p.payment_type_id
	and o.sales_man_id = sm.sales_man_id
	and o.user_id=u.user_id
    and o.customer_id=mc.customer_id
;
END;

$function$;







CREATE OR REPLACE FUNCTION public."GetTaxes"(
	local boolean,
	sku_code character varying)
RETURNS SETOF json 
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

DECLARE
var_sku_array character varying[];
var_condition boolean;

BEGIN
var_sku_array:=array['JA00000','TR00000','BU00000','WC00000','SW00000','SH00000','JAALTER','TRALTER','BUALTER','WCALTER','SWALTER','SHALTER'];
var_condition:=true;

FOR Counter in 1 ..array_upper(var_sku_array, 1)
	LOOP
		if(sku_code=var_sku_array[Counter]) then var_condition:=false; RETURN QUERY SELECT cast('[{ "name": "CGST", "percent" : 9,  "order" : 1 }, {"name" : "SGST" , "percent" : 9, "order" : 2}]' as json);
		end if;
	END LOOP;
if var_condition then
if local then
RETURN QUERY SELECT cast('[{ "name": "CGST", "percent" : 6,  "order" : 1 }, {"name" : "SGST" , "percent" : 6, "order" : 2}]' as json);

else
RETURN QUERY SELECT cast('[{ "name": "IGST", "percent" : 12,  "order" : 1 }]' as json);

end if;
end if;
  
END;

$function$;

--order_view added booked_date
CREATE OR REPLACE VIEW public.order_view AS
SELECT m_store.code AS store, b_order.order_date,to_char(b_order.created_time, 'YYYY-MM-DD HH24:MI') as booked_date, m_customer.name, 
    m_customer.mobile, m_customer.address, m_customer.email, b_order.occasion, 
    b_order.benficiary_name, m_fabric.supplier_product_code, 
    m_item_type.code AS item, m_item_type.descr
   FROM b_order, b_order_item, m_customer, m_fabric, m_store, m_item_type
  WHERE b_order.order_id = b_order_item.order_id AND m_fabric.fabric_id = b_order_item.sku_id AND m_store.store_id = b_order.store_id AND m_customer.customer_id = b_order.customer_id AND m_item_type.item_type_id = b_order_item.item_type_id AND b_order.order_date IS NOT NULL
  ORDER BY b_order.order_date DESC;
