select * from m_sales_man

insert into m_sales_man(name,is_active)values('Dipti',true);
insert into m_sales_man(name,is_active)values('Giridhar',true);
