
alter table b_order_item_fabric_design add column profile_id integer;

------------------------------------------------------------------

-- FUNCTION: public."GetOrderItemFabricDesign"integer

-- DROP FUNCTION public."GetOrderItemFabricDesign"(integer);

CREATE OR REPLACE FUNCTION public."GetOrderItemFabricDesign"(
	in_order_item_id integer)
RETURNS TABLE(order_item_id integer, fabric_design json, comment character varying, profile_name character varying, profile_id integer,selected_profile_id integer)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

BEGIN
RETURN QUERY  select d.order_item_id,d.fabric_design,d.comment,s.profile_name,s.profile_id,d.profile_id as selected_profile_id from b_order_item_fabric_design d left join b_customer_style_profile s
 on d.order_item_id = s.order_item_id where d.order_item_id =in_order_item_id;

  
END;

$function$;

ALTER FUNCTION public."GetOrderItemFabricDesign"(integer)
    OWNER TO tailorman_db;
