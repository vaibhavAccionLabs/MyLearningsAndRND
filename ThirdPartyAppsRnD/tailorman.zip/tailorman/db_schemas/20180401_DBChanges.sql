-- FUNCTION: public."UpdateOrderPayment"integer, integer, integer, boolean, json

-- DROP FUNCTION public."UpdateOrderPayment"integer, integer, integer, boolean, json;

CREATE OR REPLACE FUNCTION public."UpdateOrderPayment"(
	in_order_id integer,
	in_cutomer_id integer,
	in_workflow_id integer,
	in_success boolean,
	in_payment_response json)
    RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

DECLARE
var_start_stage_id integer;

 
BEGIN 

if in_success then 
  var_start_stage_id := 1;
else
var_start_stage_id := -1;
end if;

update b_order b set work_flow_stage_id = in_workflow_id where b.order_id = in_order_id;
update b_item_wf_stage b set workflow_stage_id = var_start_stage_id from  b_order bo LEFT JOIN b_order_item boi ON boi.order_id=bo.order_id  where bo.order_id =in_order_id;

insert into order_payment(cutomer_id,order_id,created_date,success,payment_response) values (in_cutomer_id,in_order_id,now(),in_success,in_payment_response);

return true ;
END;

$function$;

ALTER FUNCTION public."UpdateOrderPayment"(integer, integer, integer, boolean, json)
    OWNER TO tailorman_db;

-------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public."UpdateOrderItemV2"(
	in_order_id integer,
	in_order_item_id integer,
	in_style_id integer,
	in_workflow_id integer,
	in_sku_id integer,
	in_item_type_id integer,
	in_mrp double precision,
	in_qty integer,
	in_finish_type integer,
	in_fit_on_date date,
	in_delivery_date date,
	in_comment character varying,
	in_profile_id integer,
	in_priority_id integer,
	in_display_name character varying,
	in_upcharge json,
	in_taxes json,
	in_discount_type integer,
	in_discount_value double precision,
	in_order_flag integer,
	in_bill_amount double precision,
	in_upcharge_amount double precision,
	in_delivery_upcharge_amount double precision,
	in_discount_amount double precision,
	in_pickup_id integer,
	in_delivery_id integer)
    RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE
var_order_item_id integer;
var_start_stage_id integer;
BEGIN 


var_start_stage_id := -1;


update b_order_item set (
             style_id , sku_id, item_type_id, 
             mrp , qty , finish_type , fit_on_date , delivery_date ,comment , profile_id,priority_id,display_name,upcharge , taxes  ,discount_type, discount,order_flag,bill_amount,
             upcharge_amount, 
       delivery_upcharge_amount, discount_amount,pickup_id,delivery_id)
    = ( in_style_id,  in_sku_id, in_item_type_id, 
             in_mrp , in_qty , in_finish_type , in_fit_on_date , in_delivery_date,in_comment,in_profile_id,in_priority_id,in_display_name,in_upcharge , 
    in_taxes  ,   in_discount_type,  in_discount_value ,in_order_flag,in_bill_amount,in_upcharge_amount, 
      in_delivery_upcharge_amount, in_discount_amount,in_pickup_id,in_delivery_id) 
             where order_id= in_order_id and order_item_id =in_order_item_id and workflow_id =in_workflow_id;

update b_item_wf_stage s set current_stage_flag ='N' 
    where s.workflow_id=in_workflow_id 
    and s.order_item_id=in_order_item_id;

    update b_item_wf_stage s
      set profile_id=in_profile_id , comment=in_comment ,current_stage_flag ='Y' , created_time=now()
    where s.workflow_id=in_workflow_id and s.workflow_stage_id=var_start_stage_id
    and s.order_item_id=in_order_item_id;
    if not found then

    insert into b_item_wf_stage(workflow_id ,
                workflow_stage_id ,
                order_item_id ,
                profile_id ,
                comment ,
                user_id  ,
                created_time ) values

                (in_workflow_id ,
                var_start_stage_id ,
                in_order_item_id ,
                in_profile_id ,
                in_comment ,
                (select user_id from b_order where order_id=in_order_id) ,
                now()

                );

    end if;
             
return true ;
END;

$function$;

ALTER FUNCTION public."UpdateOrderItemV2"(integer, integer, integer, integer, integer, integer, double precision, integer, integer, date, date, character varying, integer, integer, character varying, json, json, integer, double precision, integer, double precision, double precision, double precision, double precision, integer, integer)
    OWNER TO tailorman_db;

-----------------------------------------

-- FUNCTION: public."GetRTWSKUDetails"integer, character varying, character varying, character varying, integer

-- DROP FUNCTION public."GetRTWSKUDetails"integer, character varying, character varying, character varying, integer;

CREATE OR REPLACE FUNCTION public."GetRTWSKUDetails"(
	in_store_id integer,
	in_product_sku_code character varying,
	in_size character varying,
	in_fit character varying,
	in_item_type_id integer)
RETURNS TABLE(fabric_id integer, fabric_sku_code character varying, name character varying, mrp double precision, product_sku_code character varying, item_type_id integer, store_id integer, inventory_count bigint, size character varying, fit character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 
BEGIN  
  return query SELECT f.fabric_id,f.sku_code,f.name,f.shirt_mrp,f.supplier_product_code,m.item_type_id,mc.store_id,sum(mc.inventory_count),mc.size,mc.fit
 from m_fabric f 
 join m_item_type m on m.item_type_id = f.item_type_id and m.mtm_flag='N'
 join m_category_rtw_inventory_measurment mc on mc.item_type_id=m.item_type_id and mc.sku_code=f.supplier_product_code and mc.inventory_count > 0 and mc.store_id=in_store_id and mc.size=in_size and mc.fit=in_fit and mc.item_type_id = in_item_type_id 
 where f.in_stock_qty>0 and  
 	f.supplier_product_code ilike  '%' || in_product_sku_code || '%'
GROUP BY f.fabric_id, f.sku_code,  f.name, f.shirt_mrp, f.supplier_product_code,m.item_type_id,mc.size,
mc.store_id,mc.fit order by 1
;
END;

$function$;

ALTER FUNCTION public."GetRTWSKUDetails"(integer, character varying, character varying, character varying, integer)
    OWNER TO tailorman_db;