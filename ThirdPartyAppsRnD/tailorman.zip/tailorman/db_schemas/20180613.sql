
CREATE TABLE public.gift_vocher(
   gift_vocher_id serial NOT NULL,
   b_order_item_id integer,
   recepient_name character varying,
   recepient_email character varying,
   delivery_date date,
   amount double precision,
   coupon_code character varying,
   created_date date,
   message character varying,
   from_name character varying,
   from_email character varying,
   balance_amount double precision,
   isactive character(1) DEFAULT 'N'::bpchar NOT NULL,
   ispaymentprocessed character(1) DEFAULT 'Y'::bpchar NOT NULL,
   last_email_sent date 
);

CREATE TABLE public.gift_transaction(
   gift_transaction_id serial NOT NULL, 
   gift_vocher_id integer,
   order_id integer,
   amount double precision,
   created timestamp without time zone DEFAULT now() NOT NULL,
   created_by integer
);

insert into m_payment_type (code,descr)values('GiftCard','GiftCard');


--SELECT * FROM "GetGiftVochersList"('2018-06-15','2018-06-18',null,null);

CREATE OR REPLACE FUNCTION public."GetGiftVochersList"(
	in_start_date date,
	in_end_date date,
	in_store_id integer,
	in_customer_id integer)
    RETURNS TABLE(gift_vocher_id integer, recepient_name character varying, recepient_email character varying, delivery_date date,amount double precision,store_address character varying,customer_id integer,customer_name character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query 
SELECT gv.gift_vocher_id,gv.recepient_name,gv.recepient_email,gv.delivery_date,gv.amount,ms.address,mc.customer_id,mc.name FROM gift_vocher gv
 LEFT JOIN b_order_item boi ON boi.order_item_id = gv.b_order_item_id
 LEFT JOIN b_order b ON b.order_id = boi.order_id
 LEFT JOIN m_store ms ON ms.store_id = b.store_id
 LEFT JOIN m_customer mc ON mc.customer_id = b.customer_id  
  WHERE 
	gv.created_date between in_start_date and in_end_date
	and (b.store_id= in_store_id or in_store_id is null)
	and (b.customer_id =in_customer_id or in_customer_id is null)
  AND gv.ispaymentprocessed = 'Y';

END;

$function$;
