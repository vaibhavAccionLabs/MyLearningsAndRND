alter table m_customer_addresses add column address_type character varying;

------------------------------------------------

-- FUNCTION: public."GetCustomerAddressList"integer

 -- FUNCTION: public."GetCustomerAddressList"integer

 DROP FUNCTION public."GetCustomerAddressList"(integer);

CREATE OR REPLACE FUNCTION public."GetCustomerAddressList"(
	in_param integer)
RETURNS TABLE(m_customer_addresses_id integer, m_customer_id integer, address character varying, country character varying, state character varying,address_type character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN return query SELECT * FROM m_customer_addresses ca where ca.m_customer_id =in_param order by m_customer_addresses_id; END; 

$function$;

ALTER FUNCTION public."GetCustomerAddressList"(integer)
    OWNER TO tailorman_db;


------------------------------------------------


-- FUNCTION: public."InsertCustomerAddress"integer, character varying, character varying

-- DROP FUNCTION public."InsertCustomerAddress"integer, character varying, character varying;

CREATE OR REPLACE FUNCTION public."InsertCustomerAddress"(
	m_customer_id integer,
	address character varying,
	address_type character varying)
RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

 DECLARE var_customer_address_id integer; 
 BEGIN select nextval ('m_customer_addresses_m_customer_addresses_id_seq') into var_customer_address_id; 
 INSERT INTO m_customer_addresses(m_customer_addresses_id, m_customer_id, address, country_code,state,address_type) 
 VALUES (var_customer_address_id, m_customer_id, address, null,null,address_type); 
 return var_customer_address_id ;
  END; 

$function$;

ALTER FUNCTION public."InsertCustomerAddress"(integer, character varying, character varying)
    OWNER TO tailorman_db;