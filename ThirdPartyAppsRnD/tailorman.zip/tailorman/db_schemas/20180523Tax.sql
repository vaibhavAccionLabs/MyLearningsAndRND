CREATE OR REPLACE FUNCTION public."GetTaxes"(
	in_store_id integer,
	sku_code character varying)
    RETURNS SETOF json 
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE
AS $function$

DECLARE
var_sku_array character varying[];
var_condition boolean;
var_is_local boolean;
BEGIN
var_sku_array:=array['JA00000','TR00000','BU00000','WC00000','SW00000','SH00000','JAALTER','TRALTER','BUALTER','WCALTER','SWALTER','SHALTER'];
var_condition:=true;
var_is_local:=true;
if in_store_id = 11 OR in_store_id = 12 then 
    var_is_local:=false;
end if;

FOR Counter in 1 ..array_upper(var_sku_array, 1)
	LOOP
		if(sku_code=var_sku_array[Counter]) then 
            var_condition:=false;
		end if;
	END LOOP;
if var_condition then
    if var_is_local then
        RETURN QUERY SELECT cast('[{ "name": "CGST", "percent" : 6,  "order" : 1 }, {"name" : "SGST" , "percent" : 6, "order" : 2}]' as json);
    else
        RETURN QUERY SELECT cast('[{ "name": "IGST", "percent" : 12,  "order" : 1 }]' as json);
    end if;
end if;
if var_condition = false then
    if var_is_local then
        RETURN QUERY SELECT cast('[{ "name": "CGST", "percent" : 2.5,  "order" : 1 }, {"name" : "SGST" , "percent" : 2.5, "order" : 2}]' as json);
    else
        RETURN QUERY SELECT cast('[{ "name": "IGST", "percent" : 5,  "order" : 1 }]' as json);
end if;
end if;
END;

$function$;