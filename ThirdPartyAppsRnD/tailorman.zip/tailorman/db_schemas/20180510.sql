

CREATE OR REPLACE FUNCTION public."SaveOrderItem"(
	in_order_id integer,
	in_style_id integer,
	in_workflow_id integer,
	in_sku_id integer,
	in_item_type_id integer,
	in_mrp double precision,
	in_qty integer,
	in_finish_type integer,
	in_fit_on_date date,
	in_delivery_date date,
	in_comment character varying,
	in_profile_id integer,
	in_priority_id integer,
	in_display_name character varying,
	in_workflow_start_stage_id integer,
	in_customer_fit_on_date date,
	in_customer_delivery_date date,
	in_upcharge json,
	in_taxes json)
    RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

 
DECLARE
var_order_item_id integer;
BEGIN 
select nextval ('b_order_item_order_item_id_seq') into var_order_item_id;
INSERT INTO b_order_item(
            order_item_id, order_id, style_id, workflow_id, sku_id, item_type_id, 
             mrp , qty , finish_type , fit_on_date , delivery_date ,comment , profile_id,priority_id,display_name,customer_fit_on_date,customer_delivery_date,upcharge ,taxes)
    VALUES (var_order_item_id, in_order_id, in_style_id, in_workflow_id, in_sku_id, in_item_type_id, 
             in_mrp , in_qty , in_finish_type , in_fit_on_date , in_delivery_date,in_comment,in_profile_id,in_priority_id,in_display_name,in_customer_fit_on_date,in_customer_delivery_date,in_upcharge,in_taxes);

	if exists (select 1 from m_item_type where item_type_id =in_item_type_id and mtm_flag='Y') then
				insert into b_item_wf_stage(workflow_id ,
						    workflow_stage_id ,
						    order_item_id ,
						    profile_id ,
						    comment ,
						    user_id  ,
						    created_time ) values

						    (in_workflow_id ,
						    in_workflow_start_stage_id ,
						    var_order_item_id ,
						    in_profile_id ,
						    in_comment ,
						    (select user_id from b_order where order_id=in_order_id) ,
						    now()

						    );
	end if;

return var_order_item_id ;
END;

$function$;
