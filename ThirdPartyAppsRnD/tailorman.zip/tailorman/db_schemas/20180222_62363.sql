alter table b_order add column receipt_number character varying;

alter table c_order_payment add column reference character varying,add column payment_mode integer;

-- alter table c_order_payment add column payment_mode integer;


-------------------------------------------------------------------
-- FUNCTION: public."GetReceiptNumber"integer, integer

-- DROP FUNCTION public."GetReceiptNumber"integer, integer;

CREATE OR REPLACE FUNCTION public."GetReceiptNumber"(
	in_order_id integer,
	in_store_id integer)
RETURNS character varying
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

DECLARE 

var_receipt_number  integer;
var_concate_number_into_store  character varying;
result character varying;
var_store_initials character varying;

BEGIN 
  select receipt_number into result from b_order where order_id =in_order_id and receipt_number IS NOT NULL and receipt_number !='';
  if not found then

  select next_receipt_number into var_receipt_number from m_store where store_id = in_store_id;
  select store_initials::text into var_store_initials from m_store where store_id = in_store_id;

  
    result := 'RV /'|| var_store_initials|| '/' || var_receipt_number::text;
  

  update b_order set receipt_number = result where order_id=in_order_id;
  update m_store set current_receipt_number = var_receipt_number , next_receipt_number=var_receipt_number+1 where store_id=in_store_id;

  end if;

  return result;

END;

$function$;

ALTER FUNCTION public."GetReceiptNumber"(integer, integer)
    OWNER TO tailorman_db;


----------------------------

alter table m_store add column start_receipt_number integer default 0; 
alter table m_store add column current_receipt_number integer default 0;  
alter table m_store add column next_receipt_number integer default 1; 
--JN
update m_store set start_receipt_number =394 ,current_receipt_number =394,next_receipt_number=395 where store_id=3;
--WF
update m_store set start_receipt_number =101 ,current_receipt_number =101,next_receipt_number=102 where store_id=1;
--TS

update m_store set start_receipt_number =536 ,current_receipt_number =536,next_receipt_number=537 where store_id=5;
--IN

update m_store set start_receipt_number =719 ,current_receipt_number =719,next_receipt_number=720 where store_id=2;
--TT

update m_store set start_receipt_number =184 ,current_receipt_number =184,next_receipt_number=185 where store_id=4;
--AMAZON

update m_store set start_receipt_number =116 ,current_receipt_number =116,next_receipt_number=117 where store_id=12;
--Online

update m_store set start_receipt_number =90 ,current_receipt_number =90,next_receipt_number=91 where store_id=11;
--HNI
update m_store set start_receipt_number =57 ,current_receipt_number =57,next_receipt_number=58 where store_id=16;
--CR

update m_store set start_receipt_number = 1009 ,current_receipt_number =1009,next_receipt_number=1010 where store_id=6;
--PM
update m_store set start_receipt_number = 385 ,current_receipt_number =385,next_receipt_number=386 where store_id=7;
--TTK
update m_store set start_receipt_number = 602 ,current_receipt_number = 602,next_receipt_number=603 where store_id=8;
--HYD
update m_store set start_receipt_number = 1466 ,current_receipt_number = 1466,next_receipt_number=1467 where store_id=9;
--HYD-PG
update m_store set start_receipt_number = 24 ,current_receipt_number = 24,next_receipt_number=25 where store_id=13;
--Kolkata
update m_store set start_receipt_number = 159 ,current_receipt_number = 159,next_receipt_number=160 where store_id=10;


-----------------------------------------------------------

