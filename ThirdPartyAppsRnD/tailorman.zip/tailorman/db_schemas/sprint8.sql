-- FUNCTION: public."SaveOrder" integer, integer, integer, integer, date, integer, integer, character varying, double precision, character varying, character varying, character varying, character varying, character varying

-- DROP FUNCTION public."SaveOrder" integer, integer, integer, integer, date, integer, integer, character varying, double precision, character varying, character varying, character varying, character varying, character varying;

CREATE OR REPLACE FUNCTION public."SaveOrder"(
	in_customer_id integer,
	in_order_type_id integer,
	in_store_id integer,
	in_user_id integer,
	in_order_date date,
	in_priority_id integer,
	in_payment_type_id integer,
	in_payment_details character varying,
	in_total_amount double precision,
	in_comment character varying,
	in_display_name character varying,
	in_billing_address character varying,
	in_delivery_address character varying,
	in_pin_number character varying)
RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE

var_order_id integer;
BEGIN 

select nextval ('b_order_order_id_seq') into var_order_id;

INSERT INTO b_order(
            order_id, customer_id, order_type_id, store_id, user_id, 
            order_date, created_by, created_time, modified_by, modified_time, 
            priority_id, payment_type_id, payment_details,total_amount,comment,display_name ,billing_address,delivery_address, pin_number)
    VALUES (var_order_id, in_customer_id, in_order_type_id, in_store_id, in_user_id, 
            in_order_date, in_user_id, now(), in_user_id, now(), 
            in_priority_id, in_payment_type_id, in_payment_details,in_total_amount,in_comment,in_display_name, in_billing_address,in_delivery_address, in_pin_number);
return var_order_id ;
END;

$function$;

ALTER FUNCTION public."SaveOrder"( integer, integer, integer, integer, date, integer, integer, character varying, double precision, character varying, character varying, character varying, character varying, character varying)
    OWNER TO tailorman_db;


-----------------------------------------------



-- FUNCTION: public."UpdateOrderV2"integer, integer, integer, integer, integer, date, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, date, json, integer, json

-- DROP FUNCTION public."UpdateOrderV2"integer, integer, integer, integer, integer, date, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, date, json, integer, json;

CREATE OR REPLACE FUNCTION public."UpdateOrderV2"(
	in_order_id integer,
	in_customer_id integer,
	in_order_type_id integer,
	in_store_id integer,
	in_user_id integer,
	in_order_date date,
	in_priority_id integer,
	in_payment_type_id integer,
	in_payment_details character varying,
	in_total_amount double precision,
	in_comment character varying,
	in_display_name character varying,
	in_full_payment_flag character,
	in_billing_address character varying,
	in_delivery_address character varying,
	in_pin_number character varying,
	in_pin_date date,
	in_redeemcoupon_json json,
	in_international_shipping_charges integer,
	in_shipping_taxes json)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

 
DECLARE

BEGIN 

update b_order set (
             customer_id, order_type_id, store_id, user_id, 
            order_date, created_by, created_time, modified_by, modified_time, 
            priority_id, payment_type_id, payment_details,total_amount,comment,display_name,full_payment_flag,billing_address,delivery_address, pin_number,pin_date,redeemcoupon_json,international_shipping_charges,shipping_taxes)
    = ( in_customer_id, in_order_type_id, in_store_id, in_user_id, 
            in_order_date, in_user_id, now(), in_user_id, now(), 
            in_priority_id, in_payment_type_id, in_payment_details,in_total_amount,in_comment,in_display_name,in_full_payment_flag, in_billing_address,in_delivery_address, in_pin_number,in_pin_date,in_redeemcoupon_json,in_international_shipping_charges,in_shipping_taxes) where order_id=in_order_id ;
return true ;
END;

$function$;

ALTER FUNCTION public."UpdateOrderV2"(integer, integer, integer, integer, integer, date, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, date, json, integer, json)
    OWNER TO tailorman_db;


--------------------------------------------------


-- FUNCTION: public."GetOrderDetails"integer

DROP FUNCTION public."GetOrderDetails"(integer);

CREATE OR REPLACE FUNCTION public."GetOrderDetails"(
	in_order_id integer)
    RETURNS TABLE(order_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, order_type text, store character varying, user_name character varying, payment_type character varying, shipping_charges integer, pin_date timestamp without time zone, redeemcoupon_json json, customer_email character varying, customer_name character varying, store_address character varying, state_code integer, gst_code character varying, city character varying, half_amount integer, store_initials character varying, invoice_number character varying, store_email character varying, shipping_taxes json)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT o.order_id, o.customer_id, o.order_type_id, o.store_id, o.user_id, 
       o.order_date, o.created_by, o.created_time, o.modified_by, o.modified_time, 
        o.payment_type_id, o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,p.code , o.international_shipping_charges,o.pin_date,o.redeemcoupon_json,mc.email,mc.name,s.store_address,s.state_code,s.gst_code,s.city,cop.amount as half_amount,s.store_initials,o.invoice_number,s.email,o.shipping_taxes 
  FROM b_order o
  	LEFT JOIN c_order_payment cop on cop.order_id = in_order_id
    LEFT JOIN m_store s on o.store_id =s.store_id
    LEFT JOIN m_user u on o.user_id=u.user_id
    LEFT JOIN m_payment_type p on o.payment_type_id =p.payment_type_id
    LEFT JOIN m_customer mc on o.customer_id=mc.customer_id
where o.order_id=in_order_id;
END;

$function$;

ALTER FUNCTION public."GetOrderDetails"(integer)
    OWNER TO tailorman_db;

----------------------------------------------------------------

-- FUNCTION: public."GetPendingWorkOrders"integer, integer

-- DROP FUNCTION public."GetPendingWorkOrders"(integer, integer);

-- CREATE OR REPLACE FUNCTION public."GetPendingWorkOrders"(
-- 	in_customer_id integer,
-- 	in_store_id integer)
-- RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, order_item_comment character varying, profile_id integer, priority_id integer, order_item_display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, order_date date,created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_details character varying, total_amount double precision, order_comment character varying, order_display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying,order_type text, store character varying, user_name character varying, payment_type character varying, customer_name character varying, customer_mobile character varying, customer_address character varying, cusomer_id integer, current_status character varying, current_stage_id integer, bespoke_url character varying, image bytea, style_id integer)
--     LANGUAGE 'plpgsql'
--     COST 100.0
--     VOLATILE 
--     ROWS 1000.0
-- AS $function$

--   BEGIN 
--   return query 
-- SELECT DISTINCT ON (i.order_item_id) i.order_item_id , i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
--        i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
--        i.comment, (select s.profile_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,
--        o.order_date,  o.created_by, o.created_time, o.modified_by, o.modified_time, 
--        o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
--        o.delivery_address, o.pin_number,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,pm.code ,
--        c.name, c.mobile, c.address , c.customer_id ,(select ws.code from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),
--        (select ws.stage_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),o.bespoke_url,boi.image,i.style_id
--   FROM public.b_order_item i  
--   LEFT JOIN b_order_image boi ON boi.order_id=i.order_id and boi.image_id=i.item_type_id, m_fabric f, m_item_type it , m_finish_type ft , m_priority_type p ,
--   b_order o , m_tailor t,  m_store s, m_user u,m_payment_type pm , m_sales_man sm ,m_customer c 

--   where i.order_id=o.order_id
-- 	and i.sku_id=f.fabric_id 
-- 	and i.item_type_id = it.item_type_id
-- 	and i.finish_type = ft.finish_type_id
-- 	and i.priority_id = p.priority_type_id
-- 	and o.store_id = s.store_id
--     and o.store_id = in_store_id
-- 	and o.payment_type_id =pm.payment_type_id
-- 	and o.user_id=u.user_id
-- 	and c.customer_id =o.customer_id
-- 	and exists (select 1 from b_item_wf_stage s where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' and s.workflow_stage_id =13)
--     and (o.customer_id =in_customer_id or in_customer_id is null)
--   ;

-- END;

-- $function$;

-- ALTER FUNCTION public."GetPendingWorkOrders"(integer, integer)
--     OWNER TO tailorman_db;

    ----------------------------------------


    
-- FUNCTION: public."GetPendingOrderDetails"integer

-- DROP FUNCTION public."GetPendingOrderDetails"(integer);

CREATE OR REPLACE FUNCTION public."GetPendingOrderDetails"(
	in_order_id integer)
    RETURNS TABLE(order_id integer, tailor_id integer, customer_id integer, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, sales_man_id integer, tailor_name character varying, sales_man character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT o.order_id, o.tailor_id, o.customer_id,o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.sales_man_id  , t.name ,sm.name
  FROM b_order o 
  LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id 
  LEFT JOIN m_store s ON o.store_id = s.store_id
  LEFT JOIN m_sales_man sm ON sm.sales_man_id = o.sales_man_id
  LEFT JOIN m_customer mc ON mc.customer_id = o.customer_id
where o.order_id=in_order_id ;
END;

$function$;

ALTER FUNCTION public."GetPendingOrderDetails"(integer)
    OWNER TO tailorman_db;


--------------------------------------------------------------------------------


create table stock_movement_details(
    stock_movement_details_id SERIAL,
    store_id integer,
    transferred_store_id integer,
    order_item_id integer,
    product_sku character varying,
    size character varying,
    fit character varying,
    stock_movement_type character varying,
    date date,
    count_details character varying,
    item_type_id integer,
    user_id integer
);





-----------------------------------------------------------------




-- FUNCTION: public."GetRTWSKUStockDetails"integer, character varying, character varying, character varying, integer

-- DROP FUNCTION public."GetRTWSKUStockDetails"integer, character varying, character varying, character varying, integer;

CREATE OR REPLACE FUNCTION public."GetRTWSKUStockDetails"(
	in_store_id integer,
	in_product_sku_code character varying,
	in_size character varying,
	in_fit character varying,
	in_item_type_id integer)
RETURNS TABLE(fabric_id integer, fabric_sku_code character varying, name character varying, mrp double precision, product_sku_code character varying, item_type_id integer, store_id integer, inventory_count bigint, size character varying, fit character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 
BEGIN  
  return query SELECT f.fabric_id,f.sku_code,f.name,f.shirt_mrp,f.supplier_product_code,m.item_type_id,mc.store_id,sum(mc.inventory_count),mc.size,mc.fit
 from m_fabric f 
 join m_item_type m on m.item_type_id = f.item_type_id and m.mtm_flag='N'
 join m_category_rtw_inventory_measurment mc on mc.item_type_id=m.item_type_id and mc.sku_code=f.supplier_product_code and mc.store_id=in_store_id and mc.size=in_size and mc.fit=in_fit and mc.item_type_id = in_item_type_id 
 where f.supplier_product_code ilike  '%' || in_product_sku_code || '%'
GROUP BY f.fabric_id, f.sku_code,  f.name, f.shirt_mrp, f.supplier_product_code,m.item_type_id,mc.size,
mc.store_id,mc.fit order by 1
;
END;

$function$;

ALTER FUNCTION public."GetRTWSKUStockDetails"(integer, character varying, character varying, character varying, integer)
    OWNER TO tailorman_db;


---------------------------------------------------



-- FUNCTION: public."GetOrderItemListV2"integer

 DROP FUNCTION public."GetOrderItemListV2"(integer);

CREATE OR REPLACE FUNCTION public."GetOrderItemListV2"(
	in_order_id integer)
RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, comment character varying, profile_id integer, priority_id integer, product_sku character varying, sku character varying, fabric_description character varying, item_type character varying, finish_type character varying, priority character varying, block character varying, item_size character varying, upcharge json, taxes json, discount_value double precision, discount_type integer, order_flag integer, bill_amount double precision, pickup_location character varying, discount_comment character varying, hsn_code integer, discount_amount double precision, customer_delivery_date date, customer_fit_on_date date,fabric_measurement json,size json,display_name character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 
declare
var_block character varying ;
var_item_size character varying ;

BEGIN 
return query 
SELECT i.order_item_id, i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
i.comment, (select s.profile_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,f.supplier_product_code , f.sku_code, f.name, it.descr ,ft.code ,p.code ,var_block, var_item_size,
i.upcharge , i.taxes ,i.discount,i.discount_type ,i.order_flag , i.bill_amount,(CASE WHEN i.pickup_id IS NOT NULL THEN (select sl.address from m_store sl where sl.store_id = i.pickup_id) ELSE (CASE WHEN i.delivery_id IS NOT NULL THEN (select address from m_customer_addresses where m_customer_addresses_id =i.delivery_id) ELSE '' END) END) as pickup_location,
i.discount_comment, f.hsn_code,i.discount_amount,i.customer_delivery_date,i.customer_fit_on_date,fm.fabric_measurements,fm.fabric_measurements->'size' as size,(CASE WHEN fm.fabric_measurements->'size' IS NOT NULL THEN (select concat(i.display_name::text, ' - Size ',fm.fabric_measurements->>'size'::text) 
)  ELSE (select i.display_name) END) as display_name 
FROM public.b_order_item i 
inner join m_fabric f on i.sku_id=f.fabric_id 
inner join m_item_type it on i.item_type_id = it.item_type_id
left join m_finish_type ft on i.finish_type = ft.finish_type_id
left join m_priority_type p on i.priority_id = p.priority_type_id
left join b_order_item_fabric_measurement fm on i.order_item_id = fm.order_item_id 
where i.order_Id=in_order_id 
;

END;

$function$;

ALTER FUNCTION public."GetOrderItemListV2"(integer)
    OWNER TO tailorman_db;

--------------------------------------------------------------------------------------


alter table b_order add column approved_by character varying;

-- FUNCTION: public."UpdateOrderV2"integer, integer, integer, integer, integer, integer, date, character varying, date, character varying, character varying, character varying, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, integer, date, json, integer, json

-- DROP FUNCTION public."UpdateOrderV2"integer, integer, integer, integer, integer, integer, date, character varying, date, character varying, character varying, character varying, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, integer, date, json, integer, json;

CREATE OR REPLACE FUNCTION public."UpdateOrderV2"(
	in_order_id integer,
	in_tailor_id integer,
	in_customer_id integer,
	in_order_type_id integer,
	in_store_id integer,
	in_user_id integer,
	in_order_date date,
	in_occasion character varying,
	in_occation_date date,
	in_benficiary_name character varying,
	in_benficiary_mobile character varying,
	in_benificiary_email character varying,
	in_priority_id integer,
	in_payment_type_id integer,
	in_payment_details character varying,
	in_total_amount double precision,
	in_comment character varying,
	in_display_name character varying,
	in_full_payment_flag character,
	in_billing_address character varying,
	in_delivery_address character varying,
	in_pin_number character varying,
	in_sales_man_id integer,
	in_pin_date date,
	in_redeemcoupon_json json,
	in_international_shipping_charges integer,
	in_shipping_taxes json,
    in_approved_by character varying)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

 
DECLARE

BEGIN 

update b_order set (
             tailor_id, customer_id, order_type_id, store_id, user_id, 
            order_date, occasion, occation_date, benficiary_name, benficiary_mobile, 
            benificiary_email, created_by, created_time, modified_by, modified_time, 
            priority_id, payment_type_id, payment_details,total_amount,comment,display_name,full_payment_flag,billing_address,delivery_address, pin_number,sales_man_id,pin_date,redeemcoupon_json,international_shipping_charges,shipping_taxes,approved_by)
    = ( in_tailor_id, in_customer_id, in_order_type_id, in_store_id, in_user_id, 
            in_order_date, in_occasion, in_occation_date,in_benficiary_name, in_benficiary_mobile, 
            in_benificiary_email, in_user_id, now(), in_user_id, now(), 
            in_priority_id, in_payment_type_id, in_payment_details,in_total_amount,in_comment,in_display_name,in_full_payment_flag, in_billing_address,in_delivery_address, in_pin_number,in_sales_man_id,in_pin_date,in_redeemcoupon_json,in_international_shipping_charges,in_shipping_taxes,in_approved_by) where order_id=in_order_id ;
return true ;
END;

$function$;

ALTER FUNCTION public."UpdateOrderV2"(integer, integer, integer, integer, integer, integer, date, character varying, date, character varying, character varying, character varying, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, integer, date, json, integer, json,character varying)
    OWNER TO tailorman_db;

------------------------------------------
-- alter table b_order add column approved_by character varying;

DROP VIEW IF EXISTS public.v_orders;

CREATE OR REPLACE VIEW public.v_orders AS
 SELECT i.order_id,
    i.order_item_id,
    i.discount_comment,
    c.name AS customer,
    f.supplier_product_code AS sku,
    t.name AS tailor,
    sm.name AS salesman,
    i.qty,
    i.mrp AS base_price,
    i.mrp+i.upcharge_amount AS mrp,
    i.discount_amount,
    i.bill_amount,
    i.customer_fit_on_date,
    i.customer_delivery_date,
    o.order_date,
    o.approved_by,
        CASE
            WHEN it.mtm_flag = 'Y'::bpchar THEN "left"(f.supplier_product_code::text, 2) || i.order_item_id
            ELSE NULL::text
        END AS imp_number,
    ft.code AS finish_type,
    s.address AS store,
    o.pin_number,
    ( SELECT ws.code
           FROM b_item_wf_stage s_1,
            b_workflow_stage ws
          WHERE s_1.workflow_stage_id = ws.stage_id AND s_1.order_item_id = i.order_item_id AND s_1.current_stage_flag = 'Y'::bpchar
         LIMIT 1) AS status,
    c.customer_id,
    c.email,
    c.mobile,
    ( SELECT pf.profile_name
           FROM b_item_wf_stage s_1,
            b_customer_measurement_profile pf
          WHERE s_1.profile_id = pf.profile_id AND s_1.order_item_id = i.order_item_id AND s_1.workflow_stage_id = 1
         LIMIT 1) AS profile_name,
    replace(o.billing_address::text, '\n'::text, ''::text) AS billing_address,
    c.address AS customer_address,
    c.dob AS customer_dob ,
    fm.fabric_measurements->'size' as size 
   FROM b_order_item i
     JOIN b_order o ON o.order_id = i.order_id
     JOIN m_item_type it ON i.item_type_id = it.item_type_id
     LEFT JOIN m_customer c ON o.customer_id = c.customer_id
     LEFT JOIN m_fabric f ON i.sku_id = f.fabric_id
     LEFT JOIN m_store s ON o.store_id = s.store_id
     LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id
     LEFT JOIN m_sales_man sm ON o.sales_man_id = sm.sales_man_id
     LEFT JOIN m_finish_type ft ON i.finish_type = ft.finish_type_id 
     left join b_order_item_fabric_measurement fm on i.order_item_id = fm.order_item_id 
  ORDER BY i.order_id, i.order_item_id;

ALTER TABLE public.v_orders
    OWNER TO tailorman_db;


-------------------------------------------------------------------------------------------


-- FUNCTION: public."GetCustomerOrderList"(integer)

DROP FUNCTION public."GetCustomerOrderList"(integer);

CREATE OR REPLACE FUNCTION public."GetCustomerOrderList"(
	in_customer_id integer)
    RETURNS TABLE(order_id integer, tailor_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, priority_id integer, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, sales_man_id integer, shipping_charges integer,approved_by character varying,w_o_print_status boolean,pending_amount json)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT 
    o.order_id, 
    o.tailor_id, 
    o.customer_id, 
    o.order_type_id, 
    o.store_id, 
    o.user_id, 
    o.order_date, 
    o.occasion, 
    o.occation_date, 
    o.benficiary_name, 
    o.benficiary_mobile, 
    o.benificiary_email, 
    o.created_by, 
    o.created_time, 
    o.modified_by, 
    o.modified_time,
    o.priority_id, 
    o.payment_type_id, 
    o.payment_details, 
    o.total_amount,
    o.comment, 
    o.display_name,
    o.full_payment_flag,
    o.billing_address,
    o.delivery_address, 
    o.pin_number,
    o.sales_man_id,
    o.international_shipping_charges,
    o.approved_by as approved_details,
    case when (select 
     count(ws.code) 
from b_item_wf_stage s 
LEFT JOIN b_workflow_stage ws ON s.workflow_stage_id=ws.stage_id
LEFT JOIN b_order_item boi ON s.order_item_id = boi.order_item_id
where boi.order_id= o.order_id and s.current_stage_flag='Y' and ws.stage_id IN (2,3,4) ) > 0 then true else false END,
(select (array_to_json(array_agg(c_order_payment))) FROM  c_order_payment where c_order_payment.order_id = o.order_id)
  FROM b_order o where o.customer_id=in_customer_id order by o.created_time desc
;
END;

$function$;

ALTER FUNCTION public."GetCustomerOrderList"(integer)
    OWNER TO tailorman_db;

----------------------------------------------------------------------------

alter table m_customer add column total_order_amount double precision default 0;

-- FUNCTION: public."GetCustomerList"character varying

DROP FUNCTION public."GetCustomerList"(character varying);

CREATE OR REPLACE FUNCTION public."GetCustomerList"(
	in_param character varying)
RETURNS TABLE(customer_id integer, name character varying, gender character varying, dob date, mobile character varying, address character varying, email character varying, height double precision, weight double precision, source character varying, comment character varying,total_order_amount double precision)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$
 BEGIN 
  return query SELECT c.customer_id,c.name, c.gender, c.dob, c.mobile, c.address, c.email, c.height, 
       c.weight, s.code , c.comment,(SELECT sum(o.total_amount)+ c.total_order_amount  
        FROM b_order AS o
        WHERE c.customer_id = o.customer_id
       ) AS total_order_amount  
  FROM m_source s,m_customer c 
  where c.source_id = s.source_id and (c.name ilike  '%' || in_param || '%' or c.mobile ilike '%' ||  in_param || '%' or c.email ilike '%' ||  in_param || '%' ) ;

END;

$function$;

ALTER FUNCTION public."GetCustomerList"(character varying)
    OWNER TO tailorman_db;


--------------



alter table b_order add column receipt_number character varying;

alter table c_order_payment add column reference character varying,add column payment_mode integer;

-- alter table c_order_payment add column payment_mode integer;


-------------------------------------------------------------------
-- FUNCTION: public."GetReceiptNumber"integer, integer

-- DROP FUNCTION public."GetReceiptNumber"integer, integer;

CREATE OR REPLACE FUNCTION public."GetReceiptNumber"(
	in_order_id integer,
	in_store_id integer)
RETURNS character varying
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

DECLARE 

var_receipt_number  integer;
var_concate_number_into_store  character varying;
result character varying;
var_store_initials character varying;

BEGIN 
  select receipt_number into result from b_order where order_id =in_order_id and receipt_number IS NOT NULL and receipt_number !='';
  if not found then

  select next_receipt_number into var_receipt_number from m_store where store_id = in_store_id;
  select store_initials::text into var_store_initials from m_store where store_id = in_store_id;

  
    result := 'RV /'|| var_store_initials|| '/' || var_receipt_number::text;
  

  update b_order set receipt_number = result where order_id=in_order_id;
  update m_store set current_receipt_number = var_receipt_number , next_receipt_number=var_receipt_number+1 where store_id=in_store_id;

  end if;

  return result;

END;

$function$;

ALTER FUNCTION public."GetReceiptNumber"(integer, integer)
    OWNER TO tailorman_db;


----------------------------

alter table m_store add column start_receipt_number integer default 0; 
alter table m_store add column current_receipt_number integer default 0;  
alter table m_store add column next_receipt_number integer default 1; 
--JN
update m_store set start_receipt_number =394 ,current_receipt_number =394,next_receipt_number=395 where store_id=3;
--WF
update m_store set start_receipt_number =101 ,current_receipt_number =101,next_receipt_number=102 where store_id=1;
--TS

update m_store set start_receipt_number =536 ,current_receipt_number =536,next_receipt_number=537 where store_id=5;
--IN

update m_store set start_receipt_number =719 ,current_receipt_number =719,next_receipt_number=720 where store_id=2;
--TT

update m_store set start_receipt_number =184 ,current_receipt_number =184,next_receipt_number=185 where store_id=4;
--AMAZON

update m_store set start_receipt_number =116 ,current_receipt_number =116,next_receipt_number=117 where store_id=12;
--Online

update m_store set start_receipt_number =90 ,current_receipt_number =90,next_receipt_number=91 where store_id=11;
--HNI
update m_store set start_receipt_number =57 ,current_receipt_number =57,next_receipt_number=58 where store_id=16;
--CR

update m_store set start_receipt_number = 1009 ,current_receipt_number =1009,next_receipt_number=1010 where store_id=6;
--PM
update m_store set start_receipt_number = 385 ,current_receipt_number =385,next_receipt_number=386 where store_id=7;
--TTK
update m_store set start_receipt_number = 602 ,current_receipt_number = 602,next_receipt_number=603 where store_id=8;
--HYD
update m_store set start_receipt_number = 1466 ,current_receipt_number = 1466,next_receipt_number=1467 where store_id=9;
--HYD-PG
update m_store set start_receipt_number = 24 ,current_receipt_number = 24,next_receipt_number=25 where store_id=13;
--Kolkata
update m_store set start_receipt_number = 159 ,current_receipt_number = 159,next_receipt_number=160 where store_id=10;


-----------------------------------------------------------

DROP FUNCTION "GetPendingWorkOrders"(integer,integer)

CREATE OR REPLACE FUNCTION public."GetPendingWorkOrders"(
	in_customer_id integer,
	in_store_id integer)
    RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, order_item_comment character varying, profile_id integer, priority_id integer, order_item_display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_details character varying, total_amount double precision, order_comment character varying, order_display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, tailor_name character varying, order_type text, store character varying, user_name character varying, payment_type character varying, sales_man character varying, customer_name character varying, customer_mobile character varying, customer_address character varying, cusomer_id integer, current_status character varying, current_stage_id integer, bespoke_url character varying,image bytea, style_id integer)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$

  BEGIN 
  return query 
SELECT i.order_item_id , i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
       i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
       i.comment, (select s.profile_id from b_item_wf_stage s 
       LEFT JOIN b_workflow_stage ws ON s.workflow_stage_id=ws.stage_id where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
       o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,pm.code ,sm.name,
       c.name, c.mobile, c.address , c.customer_id ,(select ws.code from b_item_wf_stage s 
       LEFT JOIN b_workflow_stage ws ON s.workflow_stage_id=ws.stage_id where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),
       (select ws.stage_id from b_item_wf_stage s 
       LEFT JOIN b_workflow_stage ws ON s.workflow_stage_id=ws.stage_id
       where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),o.bespoke_url,boi.image,boifd.order_item_id
  FROM public.b_order_item i
  LEFT JOIN m_fabric f ON i.sku_id=f.fabric_id
  LEFT JOIN m_item_type it ON i.item_type_id = it.item_type_id
  LEFT JOIN m_finish_type ft ON i.finish_type = ft.finish_type_id
  LEFT JOIN m_priority_type p ON i.priority_id = p.priority_type_id
  LEFT JOIN b_order o ON o.order_id = i.order_id
  LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id
  LEFT JOIN m_store s ON o.store_id = s.store_id
  LEFT JOIN m_payment_type pm ON o.payment_type_id = pm.payment_type_id
  LEFT JOIN m_sales_man sm ON o.sales_man_id = sm.sales_man_id
  LEFT JOIN m_user u ON o.user_id=u.user_id
  LEFT JOIN m_customer c ON c.customer_id =o.customer_id
  LEFT JOIN b_order_item_fabric_design boifd ON boifd.order_item_id = i.order_item_id
  LEFT JOIN b_order_image boi ON boi.order_id=i.order_id and boi.image_id=i.item_type_id
  where o.store_id = in_store_id
	and exists (select 1 from b_item_wf_stage s where s.order_item_id=i.order_item_id and s.current_stage_flag='Y' and s.workflow_stage_id =13)
    and (o.customer_id =in_customer_id or in_customer_id is null)
  ;

END;

$function$;

ALTER FUNCTION public."GetPendingWorkOrders"(integer, integer)
    OWNER TO tailorman_db;


-------------------------

CREATE OR REPLACE FUNCTION public."GetWorkOrderList"(
	in_stage_id_list integer[],
	in_start_date date,
	in_end_date date,
	in_customer_param character varying,
	in_order_id integer,
	in_customer_id integer)
    RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, order_item_comment character varying, profile_id integer, priority_id integer, order_item_display_name character varying, product_sku character varying, item_type character varying, finish_type character varying, priority character varying, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_details character varying, total_amount double precision, order_comment character varying, order_display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, tailor_name character varying, order_type text, store character varying, user_name character varying, payment_type character varying, sales_man character varying, customer_name character varying, customer_mobile character varying, customer_address character varying, cusomer_id integer, current_status character varying, current_stage_id integer, bespoke_url character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query 
SELECT i.order_item_id, i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
       i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
       i.comment, (select s.profile_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,i.display_name , f.supplier_product_code , it.descr ,ft.code ,p.code ,
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
       o.payment_details, o.total_amount ,o.comment,o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,pm.code ,sm.name,
       c.name, c.mobile, c.address , c.customer_id ,(select ws.code from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),
       (select ws.stage_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1),o.bespoke_url
  FROM public.b_order_item i
  LEFT JOIN m_fabric f ON i.sku_id=f.fabric_id
  LEFT JOIN m_item_type it ON i.item_type_id = it.item_type_id
  LEFT JOIN m_finish_type ft ON i.finish_type = ft.finish_type_id
  LEFT JOIN m_priority_type p ON i.priority_id = p.priority_type_id
  LEFT JOIN b_order o ON i.order_id=o.order_id
  LEFT JOIN m_tailor t ON o.tailor_id = t.tailor_id
  LEFT JOIN m_store s ON o.store_id =s.store_id
  LEFT JOIN m_user u ON o.user_id=u.user_id
  LEFT JOIN m_payment_type pm ON o.payment_type_id =pm.payment_type_id
  LEFT JOIN m_sales_man sm ON o.sales_man_id = sm.sales_man_id
  LEFT JOIN m_customer c ON c.customer_id =o.customer_id
  where 
	o.order_date between in_start_date and in_end_date
	and exists (select 1 from b_item_wf_stage s where (in_stage_id_list @> ARRAY[s.workflow_stage_id]  or  cast (ARRAY[0] as integer [] ) <@ in_stage_id_list ) and s.order_item_id=i.order_item_id and s.current_stage_flag='Y')
	and (in_customer_param ='' or (c.name ilike  '%' || in_customer_param || '%' or c.mobile ilike '%' ||  in_customer_param || '%' or c.email ilike '%' ||  in_customer_param || '%' ))
	--and (in_store_id_list @> ARRAY[s.store_id]  or  cast (ARRAY[0] as integer [] ) <@ in_store_id_list )
	and (o.order_id= in_order_id or in_order_id is null)
	and (o.customer_id =in_customer_id or in_customer_id is null);

END;

$function$;

ALTER FUNCTION public."GetWorkOrderList"(integer[], date, date, character varying, integer, integer)
    OWNER TO tailorman_db;


insert into m_payment_type (code,descr)values('Card(SBI)','Card(SBI)');
insert into m_payment_type (code,descr)values('Card(Amex)','Card(Amex)');
insert into m_payment_type (code,descr)values('Ezetap','Ezetap');
insert into m_payment_type (code,descr)values('PayU','PayU');

insert into m_payment_type (code,descr)values('Cheque','Cheque');

-- FUNCTION: public."GetFabricDesignParamsV3"(integer)

-- DROP FUNCTION public."GetFabricDesignParamsV3"(integer);

-- CREATE OR REPLACE FUNCTION public."GetFabricDesignParamsV3"(
-- 	in_item_type_id integer)
-- RETURNS SETOF json 
--     LANGUAGE 'plpgsql'
--     COST 100.0
--     VOLATILE 
--     ROWS 1000.0
-- AS $function$

-- BEGIN

-- if in_item_type_id=1 then 
-- RETURN QUERY SELECT cast('[{
-- 		"id": 1,
-- 		"name": "ONLY TUXEDO SHIRTS",
-- 		"Designs": [{
-- 			"id": 1,
-- 			"name": "COLLAR",
-- 			"type" : "option",
-- 			"values" : ["REGULAR WING","REGULAR CUTAWAY","NARROW CUTAWAY"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" :  []
-- 		}, {
-- 			"id": 2,
-- 			"name": "PINTUCK/FRILLS",
-- 			"type" : "option",
-- 			"values" : ["YES","NO"],
-- 			"upcharge" : [700,0],
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 3,
-- 			"name": "BLACK PEARL BUTTONS",
-- 			"type" : "option",
-- 			"values" : ["YES (ALL BUTTONS)","YES (4 BUTTONS)","NO"],
-- 			"upcharge" : [600,300,0 ] ,
-- 			"upcharge percentage" : []
			
-- 		}
-- 		]
-- 	},

-- 	{
-- 		"id": 2,
-- 		"name": "ONLY CLASSIC SHIRTS",
-- 		"Designs": [{
-- 			"id": 1,
-- 			"name": "COLLAR",
-- 			"type" : "option",
-- 			"values" : ["CLASSIC","NARROW CLASSIC","CUTAWAY","NARROW CUTAWAY","MAO","BUTTON DOWN","KURTA","OTHER (see comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"disable_dependency": {
-- 				"MAO": [2]
-- 			}
-- 		},{
-- 			"id": 2,
-- 			"name": "COLLAR BONE",
-- 			"type" : "option",
-- 			"values" : ["NONE","FIXED","REMOVABLE"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		},{
-- 			"id": 3,
-- 			"name": "PLACKET",
-- 			"type" : "option",
-- 			"values" : ["COCEALED BUTTON PLACKET","PLACKET","WITHOUT PLACKET","OTHER"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		},
-- 		{
-- 			"id": 4,
-- 			"name": "CHEST POCKET",
-- 			"type" : "option",
-- 			"values" : ["1 ON WEARERS LEFT","2","NONE"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		},
-- 		{
-- 			"id": 5,
-- 			"name": "INNET POCKET",
-- 			"type" : "option",
-- 			"values" : ["YES","NONE"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}
-- 		]
-- 	},
-- 	{
-- 		"id": 3	,
-- 		"name": "ALL SHIRTS",
-- 		"Designs": [{
-- 			"id": 1,
-- 			"name": "SHIRT HEM",
-- 			"type" : "option",
-- 			"values" : ["STRAIGHT BOTTON WITHOUT SIDE SLIT","CHINESE CUT BOTTOM","STRAIGHT BOTTOM WITH SIDE SLIT"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 2,
-- 			"name": "PLEAT AT BACK",
-- 			"type" : "option",
-- 			"values" : ["NONE","CENTER BOX PLEAT","SIDE PINCH PLEAT"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 3,
-- 			"name": "MONOGRAM",
-- 			"type" : "option",
-- 			"values" : ["NONE","YES"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},  {
-- 			"id": 4,
-- 			"name": "MONOGRAM TEXT",
-- 			"type" : "text",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 5,
-- 			"name": "MONOGRAM COLOUR",
-- 			"type" : "option",
-- 			"values" : ["TONAL","WHITE","BLACK","NAVY","RED","DARK GREEN","MAROON"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		},

-- 		{
-- 			"id": 6,
-- 			"name": "MONOGRAM POSITION",
-- 			"type" : "option",
-- 			"values" : ["LEFT CUFF","POCKET"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 7,
-- 			"name": "CUFF",
-- 			"type" : "option",
-- 			"values" : ["REGULAR","DOOUBLE/FRENCH (Rs 300)","SHORT SLEEVE","SHORT SLEEVE WITH TURNUP","OTHER (see comments)"],
-- 			"upcharge" : [0,300,0,0,0],
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 8,
-- 			"name": "CONTRAST IN COLLAR",
-- 			"type" : "option",
-- 			"values" : ["NONE","TOTAL(OUTSIDE,INSIDE BAND AND UNDER-SIDE) (Rs 300)","ONLY INSIDE BAND (Rs 300)","ONLY UNDER-SIDE (Rs 300)"],
-- 			"upcharge" : [0,300 ,300,300],
-- 			"upcharge percentage" : []
			
-- 		},{
-- 			"id": 9,
-- 			"name": "COLLAR CONTRAST FABRIC OPTIONS",
-- 			"type" : "option",
-- 			"values" : ["CF4","CF5","CF328","CF329","CF623","OTHER (see comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},{
-- 			"id": 10,
-- 			"name": "CUFF",
-- 			"type" : "option",
-- 			"values" : ["NONE","TOTAL(OUTSIDE AND INSIDE) (Rs 300)","ONLY INSIDE (Rs 300)"],
-- 			"upcharge" : [0,300 ,300],
-- 			"upcharge percentage" : []
			
-- 		},{
-- 			"id": 11,
-- 			"name": "CUFF CONTRAST FABRIC OPTIONS",
-- 			"type" : "option",
-- 			"values" : ["CF4","CF5","CF328","CF329","CF623","OTHER (see comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},{
-- 			"id": 12,
-- 			"name": "BUTTON PLACKET",
-- 			"type" : "option",
-- 			"values" : ["NONE","ONLY BUTTON PLACKET(GOES UNDER MAIN PLACKET WHEN FASTENED) (Rs 300)"],
-- 			"upcharge" : [0,300] ,
-- 			"upcharge percentage" : []
			
-- 		},{
-- 			"id": 13,
-- 			"name": "BUTTON PLACKET CONTRAST FABRIC OPTIONS",
-- 			"type" : "option",
-- 			"values" : ["CF4","CF5","CF328","CF329","CF623","OTHER (see comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		}
-- 		]
-- 	}
-- ]' as json)
--   ;

-- elsif in_item_type_id=3 then 
-- RETURN QUERY SELECT cast('[{
-- 		"id": 1,
-- 		"name": "TROUSER",
-- 		"Designs": [{
-- 			"id": 1,
-- 			"name": "PLEAT STYLE",
-- 			"type" : "option",
-- 			"values" : ["Flatfront","2-Pleats","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 2,
-- 			"name": "SIDE POCKETS",
-- 			"type" : "option",
-- 			"values" : ["Slant","Straight",	"Other (See comments)" ],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 3,
-- 			"name": "WAISTBAND V NOTCH OPENING",
-- 			"type" : "option",
-- 			"values" : ["No", "Yes" ],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}, { 
-- 			"id": 4,
-- 			"name": "HEM",
-- 			"type" : "option",
-- 			"values" : ["Plain","Turn Up" ],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 5,
-- 			"name": "STYLE",
-- 			"type" : "option",
-- 			"values" : ["Standard","Tuxedo - satin on side ST 1-Black  (Rs 500)","Tuxedo - satin on side ST 2 -Navy (Rs 500)","Tuxedo - satin on side ST 3-Wine (Rs 500)","Tuxedo - satin on side ST 4 White (Rs 500)"],
-- 			"upcharge" : [0,500,500,500,500] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 6,
-- 			"name": "LINING",
-- 			"type" : "option",
-- 			"values" : ["None","Knee Lining (Rs 100)","FULL LINING (RS400)","Other (See comments)"],
-- 			"upcharge" : [0,100,400,0] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 7,
-- 			"name": "WAISTBAND",
-- 			"type" : "option",
-- 			"values" : ["Plain","CUT BELT WITH HOOK","CUT BELT WITH BUTTON","Buckle -(Rs 100)","Side Elastic (Rs 500)"],
-- 			"upcharge" : [0,0,0,100,500] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 8,
-- 			"name": "INSIDE WAISTBAND POCKET",
-- 			"type" : "option",
-- 			"values" : ["No","Yes (Rs 200)"],
-- 			"upcharge" : [0,200] ,
-- 			"upcharge percentage" : []
-- 		},{
-- 			"id": 9,
-- 			"name": "BUTTONS",
-- 			"is_button" : "true",
-- 			"type" : "combo",
--             "isupcharge":true,
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		},{
-- 			"id": 10,
-- 			"name": "BUTTON SKU",
--             "dependentName":"BUTTONS",
-- 			"type" : "text",
-- 			"isupcharge":true,
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes"
-- 		},{
-- 			"id": 11,
-- 			"name": "BACK HIP POCKET",
-- 			"type" : "option",
-- 			"values" : ["NONE","DOUBLE POCKET (L&R)","LEFT POCKET ONLY","RIGHT POCKET ONLY"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		},{
-- 			"id": 12,
-- 			"name": "FLAT IRON",
-- 			"type" : "option",
-- 			"values" : ["YES","NO"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}
-- 		]
-- 	}
-- ]' as json)
--   ;
--   elsif in_item_type_id=4 then

  
-- RETURN QUERY SELECT cast('[{
-- 		"id": 1,
-- 		"name": "BUNDY",
-- 		"Designs": [{
-- 			"id": 1,
-- 			"name": "STYLE",
-- 			"type" : "option",
-- 			"values" : ["CLASSIC","MULTIBUTTON","CUT WAY","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"Size 32L" : [7,3,7,0],
-- 			"Size 24L" : [0,21,0,0]
-- 		}, {
-- 			"id": 2,
-- 			"name": "COLLAR FABRIC",
-- 			"type" : "option",
-- 			"values" : ["SELF FABRIC","SATIN - BLACK (Rs 500)", "SATIN - NAVY (Rs 500)","SATIN - WINE (Rs 500)","SATIN - WHITE (Rs 500)", "VELVET - BLACK (Rs 500)","VELVET - NAVY (Rs 500)","VELVET - WINE (Rs 500)","Other (See comments)" ],
-- 			"upcharge" : [0,500,500,500,500,500,500,500,0] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 3,
-- 			"name": "PIPING",
-- 			"type" : "option",
-- 			"values" : ["NONE","FLAT PIPING (Rs 500)", "CORD PIPING (Rs 500)"],
-- 			"upcharge" : [0,500,500] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 4,
-- 			"name": "PIPING FABRIC AND COLOUR",
-- 			"type" : "option",
-- 			"values" : ["SELF FABRIC","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","Other (See comments)" ],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 5,
-- 			"name": "BUTTONS",
-- 			"is_button" : "true",
-- 			"type" : "combo",
-- 			"isupcharge":true,
--             "upcharge" : [],
--             "upcharge percentage" : []
-- 		},
-- 		{
-- 			"id": 6,
-- 			"name": "BUTTON SKU",
--             "dependentName":"BUTTONS",
-- 			"type" : "text",
-- 			"isupcharge":true,
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes"
			
-- 		},{
-- 			"id": 7,
-- 			"name": "STRAIGHT POCKET (SINGLE WELT)",
-- 			"type" : "option",
-- 			"values" : ["SELF FABRIC","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","Other (See comments)"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 8,
-- 			"name": "POCKET PIPING",
-- 			"type" : "option",
-- 			"values" : [ "FLAT PIPING","AT CHEST WELT","AT FLAP","CORD PIPING","Other (See comments)"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : [15,15,15,15,0]
-- 		}, {
-- 			"id": 9,
-- 			"name": "LINING",
-- 			"is_lining" : "true",
-- 			"is_lining_fabric" : "true",
-- 			"type" : "combo",
-- 			"upcharge" : [], 
--             "isupcharge":true,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 10,
-- 			"name": "LINING SKU",
--             "type" : "text",
-- 			"is_lining_dependent" : "true",
--             "dependentName" : "LINING",
-- 			"upcharge" : [] , 
--             "isupcharge":true,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes"
-- 		},
-- 		{
-- 			"id": 11,
-- 			"name": "POCKET SQUARE",
-- 			"type" : "option",
-- 			"values" : [ "SAME AS LINING FABRIC","PLAIN RED","GOLD","Other (See comments)"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 12,
-- 			"name": "PLACKET TYPE",
-- 			"type" : "option",
-- 			"values" : [ "NORMAL PLACKET","CONCEALED PLACKET"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 13,
-- 			"name": "DECORATIVE STITCH",
-- 			"type" : "option",
-- 			"values" : [ "MATCHING PICK STITCH (Rs 300)","MATCHING TOP STITCH (Rs 300)"],
-- 			"upcharge" : [300,300],
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 14,
-- 			"name": "BOTTOM HEM",
-- 			"type" : "option",
-- 			"values" : [ "ROUND","SQUARE"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 15,
-- 			"name": "FRONT PLACKET",
-- 			"type" : "option",
-- 			"selected": 0,
-- 			"values" : [ "YES","NO"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}
-- 		]
-- 	}
-- ]' as json)
--   ;

--     elsif in_item_type_id=5 then

  
-- RETURN QUERY SELECT cast('[{
-- 		"id": 1,
-- 		"name": "SHERWANI",
-- 		"Designs": [{
-- 			"id": 1,
-- 			"name": "STYLE",
-- 			"type" : "option",
-- 			"values" : ["CLASSIC","MULTIBUTTON","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 2,
-- 			"name": "COLLAR FABRIC",
-- 			"type" : "option",
-- 			"values" : ["SELF FABRIC","SATIN - BLACK (Rs.500)", "SATIN - NAVY (Rs.500)","SATIN - WINE (Rs.500)","SATIN - WHITE (Rs.500)", "VELVET - BLACK (Rs.500)","VELVET - NAVY (Rs.500)","VELVET - WINE (Rs.500)","Other (See comments)" ],
-- 			"upcharge" : [0,500,500,500,500,500,500,500,0] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 3,
-- 			"name": "PIPING",
-- 			"type" : "option",
-- 			"values" : ["NONE","FLAT PIPING (Rs.500)", "CORD PIPING (Rs.500)" ],
-- 			"upcharge" : [0,500,500] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 4,
-- 			"name": "PIPING FABRIC AND COLOUR",
-- 			"type" : "option",
-- 			"values" : ["SELF FABRIC","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","Other (See comments)" ],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 5,
-- 			"name": "BUTTONS",
-- 			"is_button" : "true" ,
-- 			"type" : "combo",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"isupcharge":true
-- 		},
-- 		{
-- 			"id": 6,
-- 			"name": "BUTTON SKU",
-- 			"dependentName":"BUTTONS",
-- 			"type" : "text",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes",
-- 			"isupcharge":true
-- 		}
-- 		, {
-- 			"id": 7,
-- 			"name": "LINING",
-- 			"is_lining" : "true",
-- 			"is_lining_fabric" : "true",
-- 			"type" : "combo",
--             "upcharge" : [],
-- 			"upcharge percentage" : [],
-- 			"isupcharge":true
-- 		},{
-- 			"id": 8,
-- 			"name": "LINING SKU",
--             "dependentName":"LINING",
-- 			"is_lining_dependent" : "true",
--             "type" : "text",
--             "upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes",
-- 			"isupcharge":true
-- 		},

-- 		 {
-- 			"id": 9,
-- 			"name": "MONOGRAM LOCATION",
-- 			"type" : "option",
-- 			"values" : [ "ON LINING","AT UNDERCOLLAR FELT"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 10,
-- 			"name": "MONOGRAM TEXT",
-- 			"type" : "text",
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 11,
-- 			"name": "MONOGRAM COLOR",
-- 			"type" : "option",
-- 			"values" : ["Tonal", "White", "Black", "Navy", "Red", "Dark Green","Orange","Pink", "Other (See comments)"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 12,
-- 			"name": "PLACKET TYPE",
-- 			"type" : "option",
-- 			"values" : [ "NORMAL PLACKET","CONCEALED PLACKET"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 13,
-- 			"name": "DECORATIVE STITCH",
-- 			"type" : "option",
-- 			"values" : [ "MATCHING PICK STITCH (Rs 300)","MATCHING TOP STITCH (Rs 300)"],
-- 			"upcharge" : [300,300],
-- 			"upcharge percentage" : []
-- 		},
-- 		{
-- 			"id": 14,
-- 			"name": "POCKET SQUARE",
-- 			 "type" : "option",
-- 			"values" : ["GOLD","SAME AS LINING FABRIC"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		}
-- 		]
-- 	}
-- ]' as json)
--   ;

--   elsif in_item_type_id=6 then
  
-- RETURN QUERY SELECT cast('[{
-- 		"id": 1,
-- 		"name": "WAISTCOAT",
-- 		"Designs": [{
-- 			"id": 1,
-- 			"name": "CLOSURE AND LAPEL",
-- 			"type" : "option",
-- 			"values" : ["REGULAR 5 BUTTONS","HIGH 6 BUTTONS","LOW 4 BUTTONS","LOW 3 BUTTONS","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"Size 32L" : [0,0,0,0,0],
-- 			"Size 24L" : [6,7,5,4,0]
-- 		},  {
-- 			"id": 2,
-- 			"name": "PIPING",
-- 			"type" : "option",
-- 			"values" : ["FLAT PIPING (Rs.500)", "CORD PIPING (Rs.500)" ],
-- 			"upcharge" : [500,500] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 3,
-- 			"name": "PIPING FABRIC AND COLOUR",
-- 			"type" : "option",
-- 			"values" : ["SELF FABRIC","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","Other (See comments)" ],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 4,
-- 			"name": "BUTTONS",
-- 			"is_button" : "true",
-- 			"type" : "combo",
-- 			"isupcharge":true,
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		},
-- 		{
-- 			"id": 5,
-- 			"name": "BUTTON SKU",
-- 			"dependentName":"BUTTONS",
-- 			"type" : "text",
-- 			"upcharge" : [] ,
-- 			"isupcharge":true,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes"
			
-- 		}

-- 		, {
-- 			"id": 6,
-- 			"name": "POCKET PIPING (for STRAIGHT/SLANT POCKETS only)",
-- 			"type" : "option",
-- 			"values" : [ "FLAT PIPING","AT CHEST WELT","AT FLAP","CORD PIPING","Other (See comments)"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		},  {
-- 			"id": 7,
-- 			"name": "PIPING FABRIC",
-- 			"type" : "option",
-- 			"values" : ["SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","Other (See comments)"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		},{
-- 			"id": 8,
-- 			"name": "LINING - INSIDE FABRIC",
-- 			"is_lining" : "true",
--             "type" : "combo",
-- 			"upcharge" : [],
-- 			"upcharge percentage" : [],
-- 			"is_lining_fabric" : "true"
-- 		}, {
-- 			"id": 9,
-- 			"name": "LINING - INSIDE FABRIC SKU",
--             "type" : "text",
-- 			"dependentName" : "LINING - INSIDE FABRIC",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes",
-- 			"is_lining_dependent" : "true"
			
-- 		},{
-- 			"id": 10,
-- 			"name": "LINING - OUTSIDE FABRIC",
-- 			"type" : "combo",
-- 			"is_lining" : "true",
--             "upcharge" : [],
-- 			"upcharge percentage" : [],
-- 			"is_lining_fabric" : "true"
-- 		}, {
-- 			"id": 11,
-- 			"name": "LINING - OUTSIDE FABRIC SKU",
-- 			"type" : "text",
--             "dependentName" : "LINING - OUTSIDE FABRIC",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes",
-- 			"is_lining_dependent" : "true"
-- 		},

-- 		{
-- 			"id": 12,
-- 			"name": "CHEST POCKET",
-- 			"type" : "option",
-- 			"values" : [ "NO","YES"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 13,
-- 			"name": "ALL POCKETS IN SATIN",
-- 			"type" : "option",
-- 			"values" : [ "NO","YES","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 14,
-- 			"name": "PICK STITCH",
-- 			"type" : "option",
-- 			"values" : [ "NO","YES (STANDARD)"],
-- 			"upcharge" : [0, 300],
-- 			"upcharge percentage" : []
-- 		}
-- 		]
-- 	}
-- ]' as json)
--   ;

--   elsif in_item_type_id=2  then
-- RETURN QUERY SELECT cast('[{
-- 		"id": 1,
-- 		"name": "REGULAR JACKETS",
-- 		"collapse" : "true",
-- 		"Designs": [{
-- 			"id": 1,
-- 			"name": "CLOSURE AND LAPEL",
-- 			"type" : "option",
-- 			"values" : ["SB2 NORMAL NOTCH","SB2 NARROW NOTCH","SB2 BROAD NOTCH","SB2 NORMAL PEAK","SB2 NARROW PEAK","SB1 NARROW NOTCH","SB1 NARROW PEAK","SB1 NORMAL PEAK","SB1 SUPER NARROW","SB3 NORMAL NOTCH","SB1 SHAWL","SB1 NORMAL PEAK TUXEDO","SB1 NARROW PEAK TUXEDO","SB1 SHAWL TUXEDO","SB2 SHAWL TUXEDO","FORD TUXEDO","Other"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"Size 32L" : [3,3,3,3,3,2,2,2,2,4,2,2,2,2,3,2,0],
-- 			"Size 24L" : [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0]
-- 		}, {
-- 			"id": 2,
-- 			"name": "MELTON",
-- 			"type" : "option",
-- 			"values" : ["NA","Tonal","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 3,
-- 			"name": "VENTS",
-- 			"type" : "option",
-- 			"values" : ["Middle [1]","Side [2]","No Vent"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 4,
-- 			"name": "LINING STYLE",
-- 			"type" : "option",
-- 			"values" : ["Full","Half"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 6,
-- 			"name": "INTERNAL FACING",
-- 			"type" : "option",
-- 			"values" : ["Straight 4 pockets","Framed 4 pockets","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 7,
-- 			"name": "MONOGRAM POSITION",
-- 			 "type" : "option",
-- 			"values" : ["Yes (lining )","None ","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 8,
-- 			"name": "MONOGRAM TEXT (Max 16 Char)",
-- 			"type" : "text",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 9,
-- 			"name": "MONOGRAM COLOUR",
-- 			 "type" : "option",
-- 			"values" : ["Tonal", "White", "Black", "Navy", "Red", "Dark Green","Orange", "Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 10,
-- 			"name": "JACKET FINISH",
-- 			 "type" : "option",
-- 			"values" : ["Firm"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 11,
-- 			"name": "TUXEDO SATIN TRIM",
-- 			 "type" : "option",
-- 			"values" : ["N/A","ST 1-black", "ST 2 -Navy" , "ST 3-Wine" ,"ST 4 White", "Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"disable_dependency": {
-- 				"N/A": [26,27,28]
-- 			}
			
-- 		},
-- 		{
-- 			"id": 26,
-- 			"name": "TUXEDO SATIN TRIM LOCATION - LAPEL",
-- 			 "type" : "option",
-- 			"values" : ["YES","NO"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 27,
-- 			"name": "TUXEDO SATIN TRIM LOCATION - WELT POCKET",
-- 			 "type" : "option",
-- 			"values" : ["YES","NO"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 28,
-- 			"name": "TUXEDO SATIN TRIM LOCATION - FLAP BONE",
-- 			 "type" : "option",
-- 			"values" : ["YES","NO"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 12,
-- 			"name": "JACKET POCKETS",
-- 			 "type" : "option",
-- 			"values" : ["Flap straight", "Flap slant", "2 PATCH + 1 CHEST SINGLE WELT (+15% Upcharge)","2 PATCH + 1 CHEST PATCH (+15% Upcharge)","2 PATCH + 2 CHEST PATCH (+15% Upcharge)","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [0,0,15,15,15,0]
			
-- 		},
-- 		{
-- 			"id": 13,
-- 			"name": "TICKET POCKETS",
-- 			 "type" : "option",
-- 			"values" : ["None", "Straight with Flap", "Slant with Flap", "Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 14,
-- 			"name": "ELBOW PATCHES",
-- 			 "type" : "option",
-- 			"values" : ["None", "Mock Suede", "Self","Other (See comments)"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 15,
-- 			"name": "SLEEVE BUTTONS",
-- 			 "type" : "option",
-- 			"values" : ["Kissing", "Overlapping", "Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 16,
-- 			"name": "SLEEVE BUTTON HOLE",
-- 			 "type" : "option",
-- 			"values" : ["All tonal", "RED","ORANGE","PINK","DARK GREEN","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 17,
-- 			"name": "JACKET CONSTRUCTION",
-- 			 "type" : "option",
-- 			"values" : ["Floating Chest Piece", "Half Canvas (Rs 5000)", "Full Canvas (Rs 10000 )"],
-- 			"upcharge" : [0,2000,4000] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 18,
-- 			"is_button" : "true",
-- 			"name": "BUTTONS",
-- 			"type" : "combo",
-- 			"isupcharge":true,
-- 			"upcharge" :[],
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 19,
-- 			"name": "BUTTON SKU",
-- 			"dependentName":"BUTTONS",
-- 			"type" : "text",
-- 			"isupcharge":true,
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes"
			
-- 		},
-- 		{
-- 			"id": 20,
-- 			"name": "CUFF FINISHING",
-- 			 "type" : "option",
-- 			"values" : ["4 closed", "4 open (Rs 500)", "Other (See comments)"],
-- 			"upcharge" : [0,500,0] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 21,
-- 			"is_lining" : "true",
-- 			"name": "LINING FABRIC",
-- 			"type" : "combo",
-- 			"upcharge" : [] ,
-- 			"is_lining_fabric" : "true",
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 22,
-- 			"name": "LINING SKU",
--             "dependentName" : "LINING FABRIC",
-- 			"type" : "text",
--             "upcharge" : [] ,
-- 			"is_lining_dependent" : "true",
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes"
			
-- 		},
-- 		{
-- 			"id": 23,
-- 			"name": "PICK STITCH",
-- 			 "type" : "option",
-- 			"values" : ["None","Yes (Standard) - (Rs 300)"],
-- 			"upcharge" : [0,300] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 24,
-- 			"name": "TRAVELFLEX",
-- 			 "type" : "option",
-- 			"values" : ["NO","YES (Rs 3000)"],
-- 			"upcharge" : [0,3000] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 25,
-- 			"name": "POCKET SQUARE",
-- 			 "type" : "option",
-- 			"values" : ["GOLD","SAME AS LINING FABRIC","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		}, {
-- 			"id": 29,
-- 			"name": "FLAT PIPING",
-- 			"type" : "option",
-- 			"values" : ["YES","NO"],
-- 			"upcharge" : [500,0] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 30,
-- 			"name": "FLAT PIPING FABRIC AND COLOR",
-- 			"type" : "option",
-- 			"values" : ["SATIN BLACK", "NAVY", "WINE", "WHITE", "VELVET - BLACK", "OTHER SEE COMMENTS"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 31,
-- 			"name": "FLAT PIPING LOCATION",
-- 			"type" : "option",
-- 			"values" : ["COLLAR","LAPEL","CHEST WELT","FLAP","OTHER SEE COMMENTS"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}
-- 		]
-- 	},
-- 	{
-- 		"id": 2,
-- 		"name": "BANDHGALA JACKETS",
-- 		"collapse" : "true",
-- 		"Designs": [{
-- 			"id": 1,
-- 			"name": "CLOSURE",
-- 			"type" : "option",
-- 			"values" : ["Classic Bundhgala without cord piping","Classic Bundhgala with cord piping","Multi Button Bandhgala","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"Size 32L" : [6,6,3,6,0],
-- 			"Size 24L" : [9,9,29,9,0]
-- 		},
-- 		{
-- 			"id": 2,
-- 			"name": "VENTS",
-- 			"type" : "option",
-- 			"values" : ["Middle [1]","Side [2]","No vent"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},{
-- 			"id": 3,
-- 			"name": "LINING STYLE",
-- 			"type" : "option",
-- 			"values" : ["*Full","Half"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},{
-- 			"id": 4,
-- 			"name": "INTERNAL FACING",
-- 			"type" : "option",
-- 			"values" : ["*Straight 4 pockets","Framed 4 pockets","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},{
-- 			"id": 5,
-- 			"name": "MONOGRAM POSITION",
-- 			 "type" : "option",
-- 			"values" : ["*Yes lining","None","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 6,
-- 			"name": "MONOGRAM TEXT (Max 18 Char)",
-- 			"type" : "text",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 7,
-- 			"name": "MONOGRAM COLOUR",
-- 			 "type" : "option",
-- 			"values" : ["Tonal", "White", "Black", "Navy", "Red", "Dark Green","Orange","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 8,
-- 			"name": "JACKET CONSTRUCTION",
-- 			 "type" : "option",
-- 			"values" : ["*Floating Chest Piece"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 9,
-- 			"name": "JACKET FINISH",
-- 			 "type" : "option",
-- 			"values" : ["*Firm"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 10,
-- 			"name": "JACKET POCKETS",
-- 			 "type" : "option",
-- 			"values" : ["*Flap straight","Flap slant","2 PATCH + 1 CHEST SINGLE WELT (+15% Upcharge)","2 PATCH + 1 CHEST PATCH (+15% Upcharge)","2 PATCH + 2 CHEST PATCH (+15% Upcharge)","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [0,0,15]
			
-- 		},
-- 		{
-- 			"id": 11,
-- 			"name": "TICKET POCKETS",
-- 			 "type" : "option",
-- 			"values" : ["*None","Straight with Flap","Slant with Flap","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 12,
-- 			"name": "SLEEVE BUTTONS",
-- 			 "type" : "option",
-- 			"values" : ["*Kissing","Overlapping","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 13,
-- 			"name": "SLEEVE BUTTON HOLE",
-- 			 "type" : "option",
-- 			"values" : ["RED","ORANGE","PINK","DARK GREEN","*All tonal","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 14,
-- 			"name": "CUFF FINISHING",
-- 			 "type" : "option",
-- 			"values" : ["*4 closed","4 open - (Rs 500)","Other (See comments)"],
-- 			"upcharge" : [0,500,0] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 15,
-- 			"is_button" : "true",
-- 			"name": "BUTTONS",
-- 			"type" : "combo",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"isupcharge":true
			
-- 		},
-- 		{
-- 			"id": 16,
-- 			"name": "BUTTON SKU",
-- 			"type" : "text",
-- 			"dependentName":"BUTTONS",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes",
-- 			"isupcharge":true
			
-- 		},
		
-- 		{
-- 			"id": 17,
-- 			"is_lining" : "true",
-- 			"name": "LINING FABRIC",
-- 			"type" : "combo",
--             "upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"is_lining_fabric" : "true"
-- 		},{
-- 			"id": 18,
-- 			"name": "LINING SKU",
--             "dependentName" : "LINING FABRIC",
-- 			"type" : "text",
--             "upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes",
-- 			"is_lining_dependent" : "true"
-- 		},
		
		
-- 		{
-- 			"id": 19,
-- 			"name": "PICK STITCH",
-- 			 "type" : "option",
-- 			"values" : ["*None","Yes (Standard) - (Rs 300)"],
-- 			"upcharge" : [0,300] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 20,
-- 			"name": "CORD PIPING(Satin Trim)",
-- 			 "type" : "option",
-- 			"values" : [ "N/A","ST 1-Black - (Rs 500)","ST 2 -Navy - (Rs 500)","ST 3-Wine - (Rs 500)","ST 4 White - (Rs 500)","Other (See comments)"],
-- 			"upcharge" : [0,500,500,500,500,0] ,
-- 			"upcharge percentage" : [],
-- 			"enable_dependency": {
-- 				"N/A" : [21]
-- 			}
			
-- 		},
-- 		{
-- 			"id": 21,
-- 			"name": "FRONT PLACKET",
-- 			 "type" : "option",
-- 			"values" : ["YES","NO"],
-- 			"disabled": true,
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 22,
-- 			"name": "TRAVELFLEX",
-- 			 "type" : "option",
-- 			"values" : ["NO","YES (Rs 3000)"],
-- 			"upcharge" : [0,3000] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 23,
-- 			"name": "POCKET SQUARE",
-- 			 "type" : "option",
-- 			"values" : ["GOLD","SAME AS LINING FABRIC","OTHER SEE COMMENTS"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		}, {
-- 			"id": 24,
-- 			"name": "FLAT PIPING",
-- 			"type" : "option",
-- 			"values" : ["YES","NO"],
-- 			"upcharge" : [500,0] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 25,
-- 			"name": "FLAT PIPING FABRIC AND COLOR",
-- 			"type" : "option",
-- 			"values" : ["SATIN BLACK", "NAVY", "WINE", "WHITE", "VELVET - BLACK", "OTHER SEE COMMENTS"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 26,
-- 			"name": "FLAT PIPING LOCATION",
-- 			"type" : "option",
-- 			"values" : ["COLLAR","LAPEL","CHEST WELT","FLAP","OTHER SEE COMMENTS"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		},{		
-- 			"id": 27,		
-- 			"name": "FULL COLLAR FABRIC",		
-- 			"type" : "option",		
-- 			"values" : ["SELF FABRIC","ST 1-Black (Rs 500 Upcharge)", "ST 2 -Navy (Rs 500 Upcharge)","ST 3-Wine (Rs 500 Upcharge)","ST 4 White (Rs 500 Upcharge)","VELVET BLACK (Rs 500 Upcharge)","VELVET NAVY (Rs 500 Upcharge)","VELVET WINE (Rs 500 Upcharge)", "OTHER SEE COMMENTS"],		
-- 			"upcharge" : [0,500,500,500,500,500,500,500,0] ,		
-- 			"upcharge percentage" : []		
-- 		},{
-- 			"id": 28,
-- 			"name": "ELBOW PATCHES",
-- 			"type" : "option",
-- 			"values" : ["None", "Mock Suede", "Self","Other (See comments)"],
-- 			"upcharge" : [],
-- 			"upcharge percentage" : []
-- 		}]
-- 	},{
-- 		"id": 3,
-- 		"name": "JACKET - DOUBLE BREASTED - FABRIC & DESIGN",
-- 		"collapse" : "true",
-- 		"Designs": [{
-- 			"id": 1,
-- 			"name": "CLOSURE AND LAPEL (+15%)",
-- 			"type" : "option",
-- 			"values" : ["NORMAL 6X2 BUTTON (+15%)","NORMAL 6X1 BUTTON (+15%)","SHAWL 6X2 BUTTON (+15%)","SHAWL 6X1 BUTTON (+15%)","Other Comments"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
-- 		}, {
-- 			"id": 2,
-- 			"name": "VENTS*",
-- 			"type" : "option",
-- 			"values" : ["*MIDDLE[1]","SIDE[2]","NO VENT"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 3,
-- 			"name": "MELTON*",
-- 			"type" : "option",
-- 			"values" : ["NA","*TONAL", "OTHER"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 4,
-- 			"name": "LINING STYLE*",
-- 			"type" : "option",
-- 			"values" : ["*Full","Half"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 5,
-- 			"name": "INTERNAL FACING",
-- 			"type" : "option",
-- 			"values" : ["*STRAIGHT 4 POCKETS","FRAMED 4 POCKETS","OTHER (SEE COMMENTS)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},	{
-- 			"id": 6,
-- 			"name": "JACKET FINISH*",
-- 			"type" : "option",
-- 			"values" : ["*FIRM"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 7,
-- 			"name": "MONOGRAM POSITION",
-- 			 "type" : "option",
-- 			"values" : ["Yes (lining )","None ","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 8,
-- 			"name": "MONOGRAM TEXT (Max 16 Char)",
-- 			"type" : "text",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 9,
-- 			"name": "MONOGRAM COLOUR",
-- 			 "type" : "option",
-- 			"values" : ["Tonal", "White", "Black", "Navy", "Red", "Dark Green","Orange", "Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 10,
-- 			"name": "JACKET POCKETS",
-- 			 "type" : "option",
-- 			"values" : ["Flap straight", "Flap slant", "Other (See comments)","2 PATCH + 1 CHEST SINGLE WELT (+15% Upcharge)","2 PATCH + 1 CHEST PATCH (+15% Upcharge)","2 PATCH + 2 CHEST PATCH (+15% Upcharge)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 11,
-- 			"name": "TICKET POCKETS",
-- 			 "type" : "option",
-- 			"values" : ["None", "Straight with Flap", "Slant with Flap", "Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 12,
-- 			"name": "ELBOW PATCHES",
-- 			 "type" : "option",
-- 			"values" : ["None", "Mock Suede", "Self","OTHER SEE COMMENTS"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 13,
-- 			"name": "SLEEVE BUTTONS",
-- 			 "type" : "option",
-- 			"values" : ["Kissing", "Overlapping", "Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 14,
-- 			"name": "SLEEVE BUTTON HOLE",
-- 			 "type" : "option",
-- 			"values" : ["All tonal", "Other (See comments)","RED","ORANGE","PINK","DARK GREEN","Other (See comments)"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 15,
-- 			"name": "JACKET CONSTRUCTION",
-- 			 "type" : "option",
-- 			"values" : ["Floating Chest Piece", "Half Canvas (Rs 5000)", "Full Canvas (Rs 10000 )"],
-- 			"upcharge" : [0,2000,4000] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 16,
-- 			"is_button" : "true",
-- 			"name": "BUTTONS",
-- 			"type" : "combo",
-- 			"upcharge" :[],
-- 			"upcharge percentage" : [],
-- 			"isupcharge":true
			
			
-- 		},
-- 		{
-- 			"id": 19,
-- 			"name": "BUTTON SKU",
-- 			 "type" : "text",
-- 			 "dependentName":"BUTTONS",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes",
-- 			"isupcharge":true
			
-- 		},
-- 		{
-- 			"id": 20,
-- 			"name": "CUFF FINISHING",
-- 			 "type" : "option",
-- 			"values" : ["4 closed", "4 open (Rs 500)", "Other (See comments)"],
-- 			"upcharge" : [0,500,0] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 			{
-- 			"id": 21,
-- 			"is_lining" : "true",
-- 			"name": "LINING FABRIC",
--             "liningDependent":"true",
-- 			"is_lining_fabric" : "true",
-- 			"type" : "combo",
-- 			"loaddropdown":"/details/list/item__style_lining_dropdownlist",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes"
			
-- 		},
-- 		{
-- 			"id": 22,
-- 			"name": "LINING SKU",
-- 			"is_lining_dependent" : "true",
--             "dependentName" : "LINING FABRIC",
--             "type" : "text",
--             "reference" : "liningsku",
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : [],
-- 			"in_factory" : "yes"
			
-- 		},
-- 		{
-- 			"id": 23,
-- 			"name": "PICK STITCH",
-- 			 "type" : "option",
-- 			"values" : ["None","Yes (Standard) - (Rs 300)"],
-- 			"upcharge" : [0,300] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 24,
-- 			"name": "TRAVELFLEX",
-- 			 "type" : "option",
-- 			"values" : ["NO","YES (Rs 3000)"],
-- 			"upcharge" : [0,3000] ,
-- 			"upcharge percentage" : []
			
-- 		},
-- 		{
-- 			"id": 25,
-- 			"name": "POCKET SQUARE",
-- 			 "type" : "option",
-- 			"values" : ["GOLD","SAME AS LINING FABRIC","OTHER SEE COMMENTS"],
-- 			"upcharge" : [] ,
-- 			"upcharge percentage" : []
			
-- 		}, {
-- 			"id": 29,
-- 			"name": "FLAT PIPING",
-- 			"type" : "option",
-- 			"values" : ["YES","NO"],
-- 			"upcharge" : [500,0] ,
-- 			"upcharge percentage" : []
-- 		}
-- 		]
-- 	}
-- ]' as json);
--   end if;
  
  
-- END;

-- $function$;

-- ALTER FUNCTION public."GetFabricDesignParamsV3"(integer)
--     OWNER TO tailorman_db;

ALTER TABLE public.b_customer_measurement_profile
    ADD COLUMN created_date date;

---------------------------------------------------
---------------------------------------------------

-- FUNCTION: public."GetMeasurementProfileList"(integer, integer)

DROP FUNCTION public."GetMeasurementProfileList"(integer, integer);

CREATE OR REPLACE FUNCTION public."GetMeasurementProfileList"(
	in_customer_id integer,
	in_item_type_id integer)
    RETURNS TABLE(profile_id integer, measurement_source_id integer, profile_name character varying, comment character varying, measurement_source character varying,created_date date)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE     ROWS 1000.0
AS $function$
 BEGIN 
  return query SELECT 
    m.profile_id, 
    m.measurement_source_id, 
    m.profile_name, 
    m.comment, 
    s.code,
    m.created_date
  FROM b_customer_measurement_profile m , m_measurement_source s where  m.customer_id=in_customer_id and m.item_type_id=in_item_type_id
 and m.measurement_source_id= s.measurement_source_id
  ;
END;

$function$;

ALTER FUNCTION public."GetMeasurementProfileList"(integer, integer)
    OWNER TO tailorman_db;

---------------------------------------------

-- FUNCTION: public."SaveMeasurementProfile"(integer, integer, integer, character varying, character varying)

-- DROP FUNCTION public."SaveMeasurementProfile"(integer, integer, integer, character varying, character varying);

CREATE OR REPLACE FUNCTION public."SaveMeasurementProfile"(
	in_customer_id integer,
	in_item_type_id integer,
	in_measurement_source_id integer,
	in_profile_name character varying,
	in_comment character varying)
    RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$
 
DECLARE

var_profile_id integer;
BEGIN 

select nextval ('b_customer_measurement_profile_profile_id_seq') into var_profile_id;

INSERT INTO b_customer_measurement_profile(
            profile_id, customer_id, item_type_id, measurement_source_id, 
            profile_name, comment,modified_flag,created_date)
    VALUES (var_profile_id, in_customer_id, in_item_type_id,  in_measurement_source_id, 
            in_profile_name, in_comment,1,now()::date);
return var_profile_id ;

END;

$function$;

ALTER FUNCTION public."SaveMeasurementProfile"(integer, integer, integer, character varying, character varying)
    OWNER TO tailorman_db;


-----

UPDATE b_customer_measurement_profile AS v 
SET created_date = bo.created_time::date
FROM b_order_item boi
LEFT JOIN b_order bo on boi.order_id = bo.order_id
WHERE boi.order_item_id = v.order_item_id;

-- DROP FUNCTION public."GetPaymenttypeList"();

alter table m_payment_type add column active boolean default true ;


insert into m_payment_type (code,descr)values('Card(SBI)','Card(SBI)');
insert into m_payment_type (code,descr)values('Card(Amex)','Card(Amex)');
insert into m_payment_type (code,descr)values('Ezetap','Ezetap');
insert into m_payment_type (code,descr)values('PayU','PayU');

insert into m_payment_type (code,descr)values('Cheque','Cheque');

update m_payment_type SET active = false where payment_type_id IN (1,2,3,4,5);

CREATE OR REPLACE FUNCTION public."GetPaymenttypeList"(
	)
    RETURNS TABLE(payment_type_id integer, code character varying, descr character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$
 BEGIN 
  return query SELECT   p.payment_type_id, p.code, p.descr
  FROM m_payment_type p where p.active = true;
END;

$function$;

ALTER FUNCTION public."GetPaymenttypeList"()
    OWNER TO tailorman_db;


----------------------------------

-- Getting the Created Date under the b_item_wf_stage 

UPDATE b_customer_measurement_profile AS v 
SET created_date = biwf.created_time::date
FROM b_item_wf_stage biwf
WHERE biwf.profile_id = v.profile_id;

----------------------------