-- Adding a new column name selected_fabric_design in b_order_item_fabric_design table
ALTER TABLE b_order_item_fabric_design ADD COLUMN selected_fabric_design json;
------------------------------------------------------------------------------------------

-- Creating a new function to insert/update selected fabric design in b_order_item_fabric_design
CREATE OR REPLACE FUNCTION "SaveFabricDesign"(
	in_order_item_id integer,
	in_fabric_design json,
	in_selected_fabric_design json,
	in_comment character varying)
    RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

BEGIN

update b_order_item_fabric_design set fabric_design = in_fabric_design, selected_fabric_design=in_selected_fabric_design, comment=in_comment where order_item_id=in_order_item_id;

if not found then
insert into b_order_item_fabric_design(order_item_id, fabric_design,selected_fabric_design,comment) values (in_order_item_id, in_fabric_design, in_selected_fabric_design, in_comment);

end if;
 return true;
END;

$function$;
--------------------------------------------------------------------------------------------------