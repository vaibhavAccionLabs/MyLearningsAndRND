ALTER TABLE public.item_type_style_dropdownlist
    ADD COLUMN lining_width integer;

-----------------------------------------------

UPDATE item_type_style_dropdownlist SET lining_width = 21 where button_sku IN ('LS-1','LS-2','LS-3','LD-326') AND is_lining = true;

----------------------------------------------

UPDATE item_type_style_dropdownlist SET lining_width = 27 where button_sku IN ('LD-7','LD-9','LD-11','LD-12','LD-13','LD-14','LD-15','LD-16','LD-51','LD-52','LD-53','LD-54','LD-55','LD-56','LD-57','LD-58','LD-59','LD-60','LD-61','LD-62','LD-63','LD-64','LD-65','LD-66','LD-67','LD-68','LD-69','LD-70','LD-71','LD-72','LD-73','LD-74','LD-75','LD-76','LD-77','LD-78','LD-79','LD-80','LD-81','LD-82','LD-83','LD-84','LD-85','LD-86','LD-87','LD-88','LD-89','LD-90','LD-91','LD-92','LD-93','LD-94','LD-95','LD-96','LD-97','LD-98','LD-99','LD-100','LD-101','LD-102','LD-103','LD-104','LD-105','LD-106','LD-107','LD-108','LD-109','LD-110','LD-111','LD-112','LD-113','LD-114','LD-115','LD-116','LD-117','LD-118','LD-119','LD-120','LD-121','LD-122','LD-123','LD-124','LD-125','LD-126','LD-127','LD-128','LD-129','LD-130','LD-131','LD-132','LD-133','LD-134','LD-135','LD-136','LD-137','LD-138','LD-139','LD-140','LD-142','LD-144','LD-145','LD-146','LD-147','LD-148','LD-149','LD-150','LD-151','LD-152','LD-153','LD-154','LD-155','LD-156','LD-157','LD-158','LD-159','LD-160','LD-161','LD-162','LD-163','LD-164','LD-165','LD-166','LD-167','LD-168','LD-169','LD-170','LD-171','LD-172','LD-173','LD-174','LD-175','LD-176','LD-177','LD-178','LD-179','LD-180','LD-181','LD-182','LD-183','LD-184','LD-188','LD-191','LD-199','LD-200','LD-201','LD-202','LD-203','LD-204','LD-205','LD-206','LD-210','LD-211','LD-212','LD-213','LD-214','LD-215','LD-216','LD-217','LD-218','LD-219','LD-220','LD-221','LD-222','LD-223','LD-224','LD-225','LD-226','LD-227','LD-228','LD-229','LD-230','LD-231','LD-232','LD-233','LD-234','LD-235','LD-236','LD-237','LD-238','LD-239','LD-240','LD-241','LD-242','LD-243','LD-244','LD-245','LD-246','LD-247','LD-248','LD-249','LD-250','LD-251','LD-252','LD-253','LD-254','LD-255','LD-256','LD-257','LD-258','LD-259','LD-260','LD-261','LD-262','LD-263','LD-264','LD-265','LD-266','LD-267','LD-268','LD-269','LD-270','LD-271','LD-272','LD-273','LD-274','LD-275','LD-276','LD-277','LD-278','LD-279','LD-280','LD-281','LD-282','LD-283','LD-284','LD-285','LD-286','LD-287','LD-288','LD-289','LD-290','LD-291','LD-292','LD-297','LD-298','LD-313','LD-334') AND is_lining = true;

----------------------------------------------

UPDATE item_type_style_dropdownlist SET lining_width = 28 where button_sku IN ('LD-293','LD-294','LD-295','LD-296','LD-299','LD-300','LD-301','LD-302','LD-303','LD-304','LD-305','LD-306','LD-307','LD-308','LD-309','LD-310','LD-312','LD-317','LD-318','LD-320','LD-321','LD-322','LD-323','LD-324','LD-325','LD-327','LD-328','LD-329','LD-330','LD-331','LD-332','LD-333') AND is_lining = true;

----------------------------------------------

UPDATE item_type_style_dropdownlist SET lining_width = 29 where button_sku IN ('LD-314','LD-315','LD-316','LD-319') AND is_lining = true;

--------------------------------------------