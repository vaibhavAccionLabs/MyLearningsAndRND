--61257

alter table b_order add column shipping_taxes json

----------------------------------------------

-- FUNCTION: public."UpdateOrderV2"integer, integer, integer, integer, integer, integer, date, character varying, date, character varying, character varying, character varying, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, integer, date, json, integer,json

-- DROP FUNCTION public."UpdateOrderV2"integer, integer, integer, integer, integer, integer, date, character varying, date, character varying, character varying, character varying, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, integer, date, json, integer,json;

CREATE OR REPLACE FUNCTION public."UpdateOrderV2"(
	in_order_id integer,
	in_tailor_id integer,
	in_customer_id integer,
	in_order_type_id integer,
	in_store_id integer,
	in_user_id integer,
	in_order_date date,
	in_occasion character varying,
	in_occation_date date,
	in_benficiary_name character varying,
	in_benficiary_mobile character varying,
	in_benificiary_email character varying,
	in_priority_id integer,
	in_payment_type_id integer,
	in_payment_details character varying,
	in_total_amount double precision,
	in_comment character varying,
	in_display_name character varying,
	in_full_payment_flag character,
	in_billing_address character varying,
	in_delivery_address character varying,
	in_pin_number character varying,
	in_sales_man_id integer,
	in_pin_date date,
	in_redeemcoupon_json json,
	in_international_shipping_charges integer,
    in_shipping_taxes json)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

 
DECLARE

BEGIN 

update b_order set (
             tailor_id, customer_id, order_type_id, store_id, user_id, 
            order_date, occasion, occation_date, benficiary_name, benficiary_mobile, 
            benificiary_email, created_by, created_time, modified_by, modified_time, 
            priority_id, payment_type_id, payment_details,total_amount,comment,display_name,full_payment_flag,billing_address,delivery_address, pin_number,sales_man_id,pin_date,redeemcoupon_json,international_shipping_charges,shipping_taxes)
    = ( in_tailor_id, in_customer_id, in_order_type_id, in_store_id, in_user_id, 
            in_order_date, in_occasion, in_occation_date,in_benficiary_name, in_benficiary_mobile, 
            in_benificiary_email, in_user_id, now(), in_user_id, now(), 
            in_priority_id, in_payment_type_id, in_payment_details,in_total_amount,in_comment,in_display_name,in_full_payment_flag, in_billing_address,in_delivery_address, in_pin_number,in_sales_man_id,in_pin_date,in_redeemcoupon_json,in_international_shipping_charges,in_shipping_taxes) where order_id=in_order_id ;
return true ;
END;

$function$;

ALTER FUNCTION public."UpdateOrderV2"(integer, integer, integer, integer, integer, integer, date, character varying, date, character varying, character varying, character varying, integer, integer, character varying, double precision, character varying, character varying, character, character varying, character varying, character varying, integer, date, json, integer,json)
    OWNER TO tailorman_db;

------------------------------------------------------------------

-- FUNCTION: public."GetOrderDetails"integer

-- DROP FUNCTION public."GetOrderDetails"(integer);
DROP FUNCTION "GetOrderDetails"(integer);


CREATE OR REPLACE FUNCTION public."GetOrderDetails"(
	in_order_id integer)
RETURNS TABLE(order_id integer, tailor_id integer, customer_id integer, order_type_id integer, store_id integer, user_id integer, order_date date, occasion character varying, occation_date date, benficiary_name character varying, benficiary_mobile character varying, benificiary_email character varying, created_by integer, created_time timestamp with time zone, modified_by integer, modified_time timestamp with time zone, payment_type_id integer, payment_details character varying, total_amount double precision, comment character varying, display_name character varying, full_payment_flag character, billing_address character varying, delivery_address character varying, pin_number character varying, sales_man_id integer, tailor_name character varying, order_type text, store character varying, user_name character varying, payment_type character varying, sales_man character varying, shipping_charges integer, pin_date timestamp without time zone, redeemcoupon_json json, customer_email character varying, customer_name character varying, store_address character varying, state_code integer, gst_code character varying, city character varying, half_amount integer, store_initials character varying, invoice_number character varying, store_email character varying,shipping_taxes json)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT o.order_id, o.tailor_id, o.customer_id, o.order_type_id, o.store_id, o.user_id, 
       o.order_date, o.occasion, o.occation_date, o.benficiary_name, o.benficiary_mobile, 
       o.benificiary_email, o.created_by, o.created_time, o.modified_by, o.modified_time, 
        o.payment_type_id, o.payment_details, o.total_amount ,o.comment, o.display_name ,o.full_payment_flag ,o.billing_address,
       o.delivery_address, o.pin_number,o.sales_man_id  , t.name ,(case when o.order_type_id =1 then 'Offline' else 'Online' end) as order_type ,s.address ,u.fname,p.code ,sm.name, o.international_shipping_charges,o.pin_date,o.redeemcoupon_json,mc.email,mc.name,s.store_address,s.state_code,s.gst_code,s.city,cop.amount as half_amount,s.store_initials,o.invoice_number,s.email,o.shipping_taxes 
  FROM b_order o , m_tailor t,  m_store s, m_user u,m_payment_type p , m_sales_man sm,m_customer mc
  	LEFT JOIN c_order_payment cop on cop.order_id = in_order_id
where o.order_id=in_order_id 
	and o.tailor_id = t.tailor_id
	and o.store_id =s.store_id
	and o.payment_type_id =p.payment_type_id
	and o.sales_man_id = sm.sales_man_id
	and o.user_id=u.user_id
    and o.customer_id=mc.customer_id
;
END;

$function$;

ALTER FUNCTION public."GetOrderDetails"(integer)
    OWNER TO tailorman_db;


-----61259  changes

-- FUNCTION: public."GetFabricDesignParamsV3"(integer)

-- DROP FUNCTION public."GetFabricDesignParamsV3"(integer);

CREATE OR REPLACE FUNCTION public."GetFabricDesignParamsV3"(
	in_item_type_id integer)
RETURNS SETOF json 
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

BEGIN

if in_item_type_id=1 then 
RETURN QUERY SELECT cast('[
    {
		"id": 1,
		"name": "ONLY TUXEDO SHIRTS",
		"Designs": [{
			"id": 1,
			"name": "COLLAR",
			"type" : "option",
			"values" : ["REGULAR WING","REGULAR CUTAWAY","NARROW CUTAWAY"],
			"upcharge" : [],
			"upcharge percentage" :  []
		}, {
			"id": 2,
			"name": "PINTUCK/FRILLS",
			"type" : "option",
			"values" : ["YES","NO"],
			"upcharge" : [700,0],
			"upcharge percentage" : []
			
		},
		{
			"id": 3,
			"name": "BLACK PEARL BUTTONS",
			"type" : "option",
			"values" : ["YES (ALL BUTTONS)","YES (4 BUTTONS)","NO"],
			"upcharge" : [600,300,0 ] ,
			"upcharge percentage" : []
			
		}
		]
	},

	{
		"id": 2,
		"name": "ONLY CLASSIC SHIRTS",
		"Designs": [{
			"id": 1,
			"name": "COLLAR",
			"type" : "option",
			"values" : ["CLASSIC","NARROW CLASSIC","CUTAWAY","NARROW CUTAWAY","MAO","BUTTON DOWN","KURTA","OTHER (see comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"disable_dependency": {
				"MAO": [2]
			}
		},{
			"id": 2,
			"name": "COLLAR BONE",
			"type" : "option",
			"values" : ["NONE",FIXED","REMOVABLE"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		},{
			"id": 3,
			"name": "PLACKET",
			"type" : "option",
			"values" : ["COCEALED BUTTON PLACKET","PLACKET","WITHOUT PLACKET","OTHER"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		},
		{
			"id": 4,
			"name": "CHEST POCKET",
			"type" : "option",
			"values" : ["1 ON WEARERS LEFT","2","NONE"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		},
		{
			"id": 5,
			"name": "INNET POCKET",
			"type" : "option",
			"values" : ["YES","NONE"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}
		]
	},
    {
		"id": 3	,
		"name": "ALL SHIRTS",
		"Designs": [{
			"id": 1,
			"name": "SHIRT HEM",
			"type" : "option",
			"values" : ["STRAIGHT BOTTON WITHOUT SIDE SLIT","CHINESE CUT BOTTOM","STRAIGHT BOTTOM WITH SIDE SLIT"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 2,
			"name": "PLEAT AT BACK",
			"type" : "option",
			"values" : ["NONE","CENTER BOX PLEAT","SIDE PINCH PLEAT"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 3,
			"name": "MONOGRAM",
			"type" : "option",
			"values" : ["NONE","YES"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},  {
			"id": 4,
			"name": "MONOGRAM TEXT",
			"type" : "text",
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 5,
			"name": "MONOGRAM COLOUR",
			"type" : "option",
			"values" : ["TONAL","WHITE","BLACK","NAVY","RED","DARK GREEN","MAROON"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		},

		{
			"id": 6,
			"name": "MONOGRAM POSITION",
			"type" : "option",
			"values" : ["LEFT CUFF","POCKET"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 7,
			"name": "CUFF",
			"type" : "option",
			"values" : ["REGULAR","DOOUBLE/FRENCH (Rs 300)","SHORT SLEEVE","SHORT SLEEVE WITH TURNUP","OTHER (see comments)"],
			"upcharge" : [0,300,0,0],
			"upcharge percentage" : []
			
		},
		{
			"id": 8,
			"name": "CONTRAST IN COLLAR",
			"type" : "option",
			"values" : ["NONE","TOTAL(OUTSIDE,INSIDE BAND AND UNDER-SIDE) (Rs 300)","ONLY INSIDE BAND (Rs 300)","ONLY UNDER-SIDE (Rs 300)"],
			"upcharge" : [0,300 ,300,300],
			"upcharge percentage" : []
			
		},{
			"id": 9,
			"name": "COLLAR CONTRAST FABRIC OPTIONS",
			"type" : "option",
			"values" : ["CF4","CF5","CF328","CF329","CF623","OTHER (see comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},{
			"id": 10,
			"name": "CUFF",
			"type" : "option",
			"values" : ["NONE","TOTAL(OUTSIDE AND INSIDE) (Rs 300)","ONLY INSIDE (Rs 300)"],
			"upcharge" : [0,300 ,300],
			"upcharge percentage" : []
			
		},{
			"id": 11,
			"name": "CUFF CONTRAST FABRIC OPTIONS",
			"type" : "option",
			"values" : ["CF4","CF5","CF328","CF329","CF623","OTHER (see comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},{
			"id": 12,
			"name": "BUTTON PLACKET",
			"type" : "option",
			"values" : ["NONE","ONLY BUTTON PLACKET(GOES UNDER MAIN PLACKET WHEN FASTENED) (Rs 300)"],
			"upcharge" : [0,300] ,
			"upcharge percentage" : []
			
		},{
			"id": 13,
			"name": "BUTTON PLACKET CONTRAST FABRIC OPTIONS",
			"type" : "option",
			"values" : ["CF4","CF5","CF328","CF329","CF623","OTHER (see comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		}
		]
	}
]' as json)
  ;

elsif in_item_type_id=3 then 
RETURN QUERY SELECT cast('[
     {
		"id": 1,
		"name": "TROUSER",
		"Designs": [{
			"id": 1,
			"name": "PLEAT STYLE",
			"type" : "option",
			"values" : ["Flatfront","2-Pleats","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 2,
			"name": "SIDE POCKETS",
			"type" : "option",
			"values" : ["Slant","Straight",	"Other (See comments)" ],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 3,
			"name": "WAISTBAND V NOTCH OPENING",
			"type" : "option",
			"values" : ["No", "Yes" ],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 4,
			"name": "HEM",
			"type" : "option",
			"values" : ["Plain","Turn Up" ],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 5,
			"name": "STYLE",
			"type" : "option",
			"values" : ["Standard","Tuxedo - satin on side ST 1-Black  (Rs 500)","Tuxedo - satin on side ST 2 -Navy (Rs 500)","Tuxedo - satin on side ST 3-Wine (Rs 500)","Tuxedo - satin on side ST 4 White (Rs 500)"],
			"upcharge" : [0,500,500,500,500] ,
			"upcharge percentage" : []
		}, {
			"id": 6,
			"name": "LINING",
			"type" : "option",
			"values" : ["None","Knee Lining (Rs 100)","FULL LINING (RS400)","Other (See comments)"],
			"upcharge" : [0,100,400,0] ,
			"upcharge percentage" : []
		}, {
			"id": 7,
			"name": "WAISTBAND",
			"type" : "option",
			"values" : ["Plain","Buckle -(Rs 100)","Side Elastic (Rs 500)","CUT BELT WITH HOOK","CUT BELT WITH BUTTON"],
			"upcharge" : [0,100,500] ,
			"upcharge percentage" : []
		}, {
			"id": 8,
			"name": "INSIDE WAISTBAND POCKET",
			"type" : "option",
			"values" : ["No","Yes (Rs 200)"],
			"upcharge" : [0,200] ,
			"upcharge percentage" : []
		},{
			"id": 9,
			"name": "BUTTONS",
			"is_button" : "true",
			"type" : "option",
			"values" : ["Tonal","Fun"],
			"upcharge" : [0,0],
			"upcharge percentage" : []
		},{
			"id": 10,
			"name": "BUTTON SKU",
			"type" : "text",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
		},{
			"id": 11,
			"name": "BACK HIP POCKET",
			"type" : "option",
			"values" : ["NONE","DOUBLE POCKET (L&R)","LEFT POCKET ONLY","RIGHT POCKET ONLY"],
			"upcharge" : [],
			"upcharge percentage" : []
		},{
			"id": 12,
			"name": "FLAT IRON",
			"type" : "option",
			"values" : ["No", "Yes" ],
			"upcharge" : [],
			"upcharge percentage" : []
		}
		]
	}
]' as json)
  ;
  elsif in_item_type_id=4 then

  
RETURN QUERY SELECT cast('[
    {
		"id": 1,
		"name": "BUNDY",
		"Designs": [{
			"id": 1,
			"name": "STYLE",
			"type" : "option",
			"values" : ["CLASSIC","MULTIBUTTON","CUT WAY","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"Size 32L" : [7,3,7,0],
			"Size 24L" : [0,21,0,0]
		}, {
			"id": 2,
			"name": "COLLAR FABRIC",
			"type" : "option",
			"values" : ["SELF FABRIC","SATIN - BLACK (Rs 500)", "SATIN - NAVY (Rs 500)","SATIN - WINE (Rs 500)","SATIN - WHITE (Rs 500)", "VELVET - BLACK (Rs 500)","VELVET - NAVY (Rs 500)","VELVET - WINE (Rs 500)","Other (See comments)" ],
			"upcharge" : [0,500,500,500,500,500,500,500,0] ,
			"upcharge percentage" : []
		}, {
			"id": 3,
			"name": "PIPING",
			"type" : "option",
			"values" : ["FLAT PIPING (Rs 500)", "CORD PIPING (Rs 500)","NONE" ],
			"upcharge" : [500,500,0] ,
			"upcharge percentage" : []
		}, {
			"id": 4,
			"name": "PIPING FABRIC AND COLOUR",
			"type" : "option",
			"values" : ["SELF FABRIC","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","Other (See comments)" ],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 5,
			"name": "BUTTONS",
			"is_button" : "true",
			"type" : "option",
			"values" : ["MATCHING","SELF FABRIC","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","METAL (Rs 500)","Other (See comments)"],
			"upcharge" : [0,0,0,0,0,0,0,0,0,500,0] ,
			"upcharge percentage" : []
		},
		{
			"id": 6,
			"name": "BUTTON SKU",
			 "type" : "text",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		}, {
			"id": 7,
			"name": "STRAIGHT POCKET (SINGLE WELT)",
			"type" : "option",
			"values" : ["SELF FABRIC","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","Other (See comments)"],
			"upcharge" : [],
			"upcharge percentage" : []
		}, {
			"id": 8,
			"name": "POCKET PIPING",
			"type" : "option",
			"values" : [ "FLAT PIPING","AT CHEST WELT","AT FLAP","CORD PIPING","Other (See comments)"],
			"upcharge" : [],
			"upcharge percentage" : [15,15,15,15,0]
		}, {
			"id": 9,
			"name": "LINING",
			"is_lining" : "true",
            "liningDependent":"true",
			"type" : "option",
			"values" : [ "FUN","SILK ( +2500 )","Other (See comments)"],
			"upcharge" : [0,2500,0],
			"upcharge percentage" : []
		}, {
			"id": 10,
			"name": "LINING SKU",
			"type" : "combo",
            "reference" : "liningsku",
            "dependentName" : "LINING",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		},

		{
			"id": 11,
			"name": "POCKET SQUARE",
			"type" : "option",
			"values" : [ "SAME AS LINING FABRIC","PLAIN RED","GOLD","Other (See comments)"],
			"upcharge" : [],
			"upcharge percentage" : []
		}, {
			"id": 12,
			"name": "PLACKET TYPE",
			"type" : "option",
			"values" : [ "NORMAL PLACKET","CONCEALED PLACKET"],
			"upcharge" : [],
			"upcharge percentage" : []
		}, {
			"id": 13,
			"name": "DECORATIVE STITCH",
			"type" : "option",
			"values" : [ "MATCHING PICK STITCH (Rs 300)","MATCHING TOP STITCH (Rs 300)"],
			"upcharge" : [300,300],
			"upcharge percentage" : []
		}, {
			"id": 14,
			"name": "BOTTOM HEM",
			"type" : "option",
			"values" : [ "ROUND","SQUARE"],
			"upcharge" : [],
			"upcharge percentage" : []
		}, {
			"id": 15,
			"name": "FRONT PLACKET",
			"type" : "option",
			"selected": 0,
			"values" : [ "YES","NO"],
			"upcharge" : [],
			"upcharge percentage" : []
		}, {
			"id": 16,
			"name": "FLAT PIPING LOCATION",
			"type" : "option",
			"values" : ["LAPEL", "OTHER SEE COMMENTS"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}
		]
	}
]' as json)
  ;

    elsif in_item_type_id=5 then

  
RETURN QUERY SELECT cast('[{
		"id": 1,
		"name": "SHERWANI",
		"Designs": [{
			"id": 1,
			"name": "STYLE",
			"type" : "option",
			"values" : ["CLASSIC","MULTIBUTTON","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 2,
			"name": "COLLAR FABRIC",
			"type" : "option",
			"values" : ["SELF FABRIC","SATIN - BLACK (Rs.500)", "SATIN - NAVY (Rs.500)","SATIN - WINE (Rs.500)","SATIN - WHITE (Rs.500)", "VELVET - BLACK (Rs.500)","VELVET - NAVY (Rs.500)","VELVET - WINE (Rs.500)","Other (See comments)" ],
			"upcharge" : [0,500,500,500,500,500,500,500,0] ,
			"upcharge percentage" : []
		}, {
			"id": 3,
			"name": "PIPING",
			"type" : "option",
			"values" : ["NONE","FLAT PIPING (Rs.500)", "CORD PIPING (Rs.500)" ],
			"upcharge" : [0,500,500] ,
			"upcharge percentage" : []
		}, {
			"id": 4,
			"name": "PIPING FABRIC AND COLOUR",
			"type" : "option",
			"values" : ["SELF FABRIC","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","Other (See comments)" ],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 5,
			"name": "BUTTONS",
			"is_button" : "true" ,
			"type" : "option",
			"values" : ["MATCHING","SELF FABRIC","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","METAL (Rs 500)","Other (See comments)"],
			"upcharge" : [0,0,0,0,0,0,0,0,0,500,0] ,
			"upcharge percentage" : []
		},
		{
			"id": 6,
			"name": "BUTTON SKU",
			 "type" : "text",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		}

		, {
			"id": 7,
			"name": "LINING",
			"is_lining" : "true",
			"type" : "option",
            "liningDependent":"true",
			"values" : [ "FUN","SILK ( +2500 )","Other (See comments)"],
			"upcharge" : [0,2500,0],
			"upcharge percentage" : []
		},{
			"id": 8,
			"name": "LINING SKU",
            "dependentName" : "LINING",
			"type" : "combo",
            "reference" : "liningsku",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		},

		 {
			"id": 9,
			"name": "MONOGRAM LOCATION",
			"type" : "option",
			"values" : [ "ON LINING","AT UNDERCOLLAR FELT"],
			"upcharge" : [],
			"upcharge percentage" : []
		}, {
			"id": 10,
			"name": "MONOGRAM TEXT",
			"type" : "text",
			"upcharge" : [],
			"upcharge percentage" : []
		}, {
			"id": 11,
			"name": "MONOGRAM COLOR",
			"type" : "option",
			"values" : ["Tonal", "White", "Black", "Navy", "Red", "Dark Green","Orange","Pink", "Other (See comments)"],
			"upcharge" : [],
			"upcharge percentage" : []
		}, {
			"id": 12,
			"name": "PLACKET TYPE",
			"type" : "option",
			"values" : [ "NORMAL PLACKET","CONCEALED PLACKET"],
			"upcharge" : [],
			"upcharge percentage" : []
		}, {
			"id": 13,
			"name": "DECORATIVE STITCH",
			"type" : "option",
			"values" : [ "MATCHING PICK STITCH (Rs 300)","MATCHING TOP STITCH (Rs 300)"],
			"upcharge" : [300,300],
			"upcharge percentage" : []
		},
		{
			"id": 14,
			"name": "POCKET SQUARE",
			 "type" : "option",
			"values" : ["GOLD","SAME AS LINING FABRIC"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		}
		]
	}
]' as json)
  ;

  elsif in_item_type_id=6 then
  
RETURN QUERY SELECT cast('[{
		"id": 1,
		"name": "WAISTCOAT",
		"Designs": [{
			"id": 1,
			"name": "CLOSURE AND LAPEL",
			"type" : "option",
			"values" : ["REGULAR 5 BUTTONS","HIGH 6 BUTTONS","LOW 4 BUTTONS","LOW 3 BUTTONS","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"Size 32L" : [0,0,0,0,0],
			"Size 24L" : [6,7,5,4,0]
		},  {
			"id": 2,
			"name": "PIPING",
			"type" : "option",
			"values" : ["FLAT PIPING (Rs.500)", "CORD PIPING (Rs.500)" ],
			"upcharge" : [500,500] ,
			"upcharge percentage" : []
		}, {
			"id": 3,
			"name": "PIPING FABRIC AND COLOUR",
			"type" : "option",
			"values" : ["SELF FABRIC","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","Other (See comments)" ],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 4,
			"name": "BUTTONS",
			"is_button" : "true",
			"type" : "option",
			"values" : ["MATCHING","SELF FABRIC","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","METAL (Rs 500)","Other (See comments)"],
			"upcharge" : [0,0,0,0,0,0,0,0,0,500,0] ,
			"upcharge percentage" : []
		},
		{
			"id": 5,
			"name": "BUTTON SKU",
			 "type" : "text",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		}

		, {
			"id": 6,
			"name": "POCKET PIPING (for STRAIGHT/SLANT POCKETS only)",
			"type" : "option",
			"values" : [ "FLAT PIPING","AT CHEST WELT","AT FLAP","CORD PIPING","Other (See comments)"],
			"upcharge" : [],
			"upcharge percentage" : []
		},  {
			"id": 7,
			"name": "PIPING FABRIC",
			"type" : "option",
			"values" : ["SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE", "VELVET - BLACK","VELVET - NAVY","VELVET - WINE","Other (See comments)"],
			"upcharge" : [],
			"upcharge percentage" : []
		},{
			"id": 8,
			"name": "LINING - INSIDE FABRIC",
			"is_lining" : "true",
            "liningDependent":"true",
			"type" : "option",
			"values" : [ "FUN","SILK (Rs. 1250)","Other (See comments)"],
			"upcharge" : [0,2500,0],
			"upcharge percentage" : []
		}, {
			"id": 9,
			"name": "LINING - INSIDE FABRIC SKU",
			"type" : "combo",
            "reference" : "liningsku",
            "dependentName" : "LINING - INSIDE FABRIC",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		},{
			"id": 10,
			"name": "LINING - OUTSIDE FABRIC",
            "liningDependent":"true",
			"is_lining" : "true",
			"type" : "option",
			"values" : [ "FUN","SILK (Rs. 1250)","Other (See comments)"],
			"upcharge" : [0,2500,0],
			"upcharge percentage" : []
		}, {
			"id": 11,
			"name": "LINING - OUTSIDE FABRIC SKU",
			"type" : "combo",
            "reference" : "liningsku",
            "dependentName" : "LINING - OUTSIDE FABRIC",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		},

		{
			"id": 12,
			"name": "CHEST POCKET",
			"type" : "option",
			"values" : [ "NO","YES"],
			"upcharge" : [],
			"upcharge percentage" : []
		}, {
			"id": 13,
			"name": "ALL POCKETS IN SATIN",
			"type" : "option",
			"values" : [ "NO","YES","SATIN - BLACK", "SATIN - NAVY","SATIN - WINE","SATIN - WHITE"],
			"upcharge" : [],
			"upcharge percentage" : []
		}, {
			"id": 14,
			"name": "PICK STITCH",
			"type" : "option",
			"values" : [ "NO","YES (STANDARD)"],
			"upcharge" : [0, 300],
			"upcharge percentage" : []
		}, {
			"id": 15,
			"name": "FLAT PIPING",
			"type" : "option",
			"values" : ["YES","NO"],
			"upcharge" : [500,0] ,
			"upcharge percentage" : []
		}, {
			"id": 16,
			"name": "FLAT PIPING FABRIC AND COLOR",
			"type" : "option",
			"values" : ["SATIN BLACK", "NAVY", "WINE", "WHITE", "VELVET - BLACK", "OTHER SEE COMMENTS"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 17,
			"name": "FLAT PIPING LOCATION",
			"type" : "option",
			"values" : ["COLLAR","LAPEL", "OTHER SEE COMMENTS"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}
		]
	}
]' as json)
  ;

  elsif in_item_type_id=2  then
RETURN QUERY SELECT cast('[
     {
		"id": 1,
		"name": "REGULAR JACKETS",
		"collapse" : "true",
		"Designs": [{
			"id": 1,
			"name": "CLOSURE AND LAPEL",
			"type" : "option",
			"values" : ["SB2 NORMAL NOTCH","SB2 NARROW NOTCH","SB2 BROAD NOTCH","SB2 NORMAL PEAK","SB2 NARROW PEAK","SB1 NARROW NOTCH","SB1 NARROW PEAK","SB1 NORMAL PEAK","SB1 SUPER NARROW","SB3 NORMAL NOTCH","SB1 SHAWL","SB1 NORMAL PEAK TUXEDO","SB1 NARROW PEAK TUXEDO","SB1 SHAWL TUXEDO","SB2 SHAWL TUXEDO","FORD TUXEDO","Other"],
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"Size 32L" : [3,3,3,3,3,2,2,2,2,4,2,2,2,2,3,2,0],
			"Size 24L" : [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0]
		}, {
			"id": 2,
			"name": "MELTON",
			"type" : "option",
			"values" : ["NA","Tonal","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 3,
			"name": "VENTS",
			"type" : "option",
			"values" : ["Middle [1]","Side [2]","No Vent"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 4,
			"name": "LINING STYLE",
			"type" : "option",
			"values" : ["Full","Half"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 6,
			"name": "INTERNAL FACING",
			"type" : "option",
			"values" : ["Straight 4 pockets","Framed 4 pockets","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 7,
			"name": "MONOGRAM POSITION",
			 "type" : "option",
			"values" : ["Yes (lining )","None ","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 8,
			"name": "MONOGRAM TEXT (Max 16 Char)",
			"type" : "text",
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 9,
			"name": "MONOGRAM COLOUR",
			 "type" : "option",
			"values" : ["Tonal", "White", "Black", "Navy", "Red", "Dark Green","Orange", "Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 10,
			"name": "JACKET FINISH",
			 "type" : "option",
			"values" : ["Firm"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 11,
			"name": "TUXEDO SATIN TRIM",
			 "type" : "option",
			"values" : ["N/A","ST 1-black", "ST 2 -Navy" , "ST 3-Wine" ,"ST 4 White", "Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"disable_dependency": {
				"N/A": [26,27,28]
			}
			
		},
		{
			"id": 26,
			"name": "TUXEDO SATIN TRIM LOCATION - LAPEL",
			 "type" : "option",
			"values" : ["YES","NO"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 27,
			"name": "TUXEDO SATIN TRIM LOCATION - WELT POCKET",
			 "type" : "option",
			"values" : ["YES","NO"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 28,
			"name": "TUXEDO SATIN TRIM LOCATION - FLAP BONE",
			 "type" : "option",
			"values" : ["YES","NO"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 12,
			"name": "JACKET POCKETS",
			 "type" : "option",
			"values" : ["Flap straight", "Flap slant", "Other (See comments)","2 PATCH + 1 CHEST SINGLE WELT (+15% Upcharge)","2 PATCH + 1 CHEST PATCH (+15% Upcharge)","2 PATCH + 2 CHEST PATCH (+15% Upcharge)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 13,
			"name": "TICKET POCKETS",
			 "type" : "option",
			"values" : ["None", "Straight with Flap", "Slant with Flap", "Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 14,
			"name": "ELBOW PATCHES",
			 "type" : "option",
			"values" : ["None", "Mock Suede", "Self","OTHER SEE COMMENTS"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 15,
			"name": "SLEEVE BUTTONS",
			 "type" : "option",
			"values" : ["Kissing", "Overlapping", "Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 16,
			"name": "SLEEVE BUTTON HOLE",
			 "type" : "option",
			"values" : ["All tonal", "Other (See comments)","RED","ORANGE","PINK","DARK GREEN"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 17,
			"name": "JACKET CONSTRUCTION",
			 "type" : "option",
			"values" : ["Floating Chest Piece", "Half Canvas (Rs 2000)", "Full Canvas (Rs 4000 )"],
			"upcharge" : [0,2000,4000] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 18,
			"is_button" : "true",
			"name": "BUTTONS (Body and Sleeve)",
			 "type" : "option",
			"values" : ["Tonal","Satin ST 1-Black", "ST 2 -Navy","ST 3-Wine","ST 4 White", "Metal - Gold (Rs 500)", "Metal - Silver (Rs 500)","Other (See comments)","VELVET BLACK","VELVET NAVY","VELVET WINE"],
			"upcharge" :[0,0,0,0,0, 500,500,0,0,0,0] ,
			"upcharge percentage" : []
			
			
		},
		{
			"id": 19,
			"name": "BUTTON SKU",
			 "type" : "text",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		},
		{
			"id": 20,
			"name": "CUFF FINISHING",
			 "type" : "option",
			"values" : ["4 closed", "4 open (Rs 500)", "Other (See comments)"],
			"upcharge" : [0,500,0] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 21,
			"is_lining" : "true",
			"name": "LINING FABRIC",
            "liningDependent":"true",
			 "type" : "option",
			"values" : ["Fun (specify article)-", "Silk Lining (Rs 2500) - Specify Article","Other (See comments)"],
			"upcharge" : [0,2500,0] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 22,
			"name": "LINING SKU",
            "dependentName" : "LINING FABRIC",
            "type" : "combo",
            "reference" : "liningsku",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		},
		{
			"id": 23,
			"name": "PICK STITCH",
			 "type" : "option",
			"values" : ["None","Yes (Standard) - (Rs 300)"],
			"upcharge" : [0,300] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 24,
			"name": "TRAVELFLEX",
			 "type" : "option",
			"values" : ["NO","YES (Rs 3000)"],
			"upcharge" : [0,3000] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 25,
			"name": "POCKET SQUARE",
			 "type" : "option",
			"values" : ["GOLD","SAME AS LINING FABRIC","OTHER SEE COMMENTS"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		}, {
			"id": 29,
			"name": "FLAT PIPING",
			"type" : "option",
			"values" : ["YES","NO"],
			"upcharge" : [500,0] ,
			"upcharge percentage" : []
		}, {
			"id": 30,
			"name": "FLAT PIPING FABRIC AND COLOR",
			"type" : "option",
			"values" : ["SATIN BLACK", "NAVY", "WINE", "WHITE", "VELVET - BLACK", "OTHER SEE COMMENTS"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 31,
			"name": "FLAT PIPING LOCATION",
			"type" : "option",
			"values" : ["COLLAR","LAPEL", "OTHER SEE COMMENTS","CHEST WELT","FLAP"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}
		]
	},
	
{
		"id": 2,
		"name": "BANDHGALA JACKETS",
		"collapse" : "true",
		"Designs": [{
			"id": 1,
			"name": "CLOSURE",
			"type" : "option",
			"values" : ["Classic Bundhgala without cord piping","Classic Bundhgala with cord piping","Multi Button Bandhgala","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"Size 32L" : [6,6,3,6,0],
			"Size 24L" : [9,9,29,9,0]
		},
		{
			"id": 2,
			"name": "VENTS",
			"type" : "option",
			"values" : ["Middle [1]","Side [2]","No vent"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},{
			"id": 3,
			"name": "LINING STYLE",
			"type" : "option",
			"values" : ["*Full","Half"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},{
			"id": 4,
			"name": "INTERNAL FACING",
			"type" : "option",
			"values" : ["*Straight 4 pockets","Framed 4 pockets","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},{
			"id": 5,
			"name": "MONOGRAM POSITION",
			 "type" : "option",
			"values" : ["*Yes lining","None","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 6,
			"name": "MONOGRAM TEXT (Max 18 Char)",
			"type" : "text",
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 7,
			"name": "MONOGRAM COLOUR",
			 "type" : "option",
			"values" : ["Tonal", "White", "Black", "Navy", "Red", "Dark Green","Orange","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 8,
			"name": "JACKET CONSTRUCTION",
			 "type" : "option",
			"values" : ["*Floating Chest Piece"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 9,
			"name": "JACKET FINISH",
			 "type" : "option",
			"values" : ["*Firm"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 10,
			"name": "JACKET POCKETS",
			 "type" : "option",
			"values" : ["*Flap straight","Flap slant","Other (See comments)","2 PATCH + 1 CHEST SINGLE WELT (+15% Upcharge)","2 PATCH + 1 CHEST PATCH (+15% Upcharge)","2 PATCH + 2 CHEST PATCH (+15% Upcharge)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 11,
			"name": "TICKET POCKETS",
			 "type" : "option",
			"values" : ["*None","Straight with Flap","Slant with Flap","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 12,
			"name": "SLEEVE BUTTONS",
			 "type" : "option",
			"values" : ["*Kissing","Overlapping","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 13,
			"name": "SLEEVE BUTTON HOLE",
			 "type" : "option",
			"values" : ["RED","ORANGE","PINK","DARK GREEN","*All tonal","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 14,
			"name": "CUFF FINISHING",
			 "type" : "option",
			"values" : ["*4 closed","4 open - (Rs 500)","Other (See comments)"],
			"upcharge" : [0,500,0] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 15,
			"is_button" : "true",
			"name": "BUTTON (Body and Sleeve)",
			 "type" : "option",
			"values" : ["Tonal","ST 1-Black","ST 2 -Navy","ST 3-Wine","ST 4 White","Metal  - Gold (Rs 500)","Metal  - Silver (Rs 500)","Self","Other (See comments)"],
			"upcharge" : [0,0,0,0,0,500,500,0,0] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 16,
			"name": "BUTTON SKU",
			 "type" : "text",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		},
		
		{
			"id": 17,
			"is_lining" : "true",
			"name": "LINING FABRIC",
			"type" : "option",
            "liningDependent":"true",
			"values" : ["Fun (specify article)","Silk Lining (Upcharge Rs 2500) - Specify Article","Other (See comments)" 	],
			"upcharge" : [0,2500,0] ,
			"upcharge percentage" : []
			
		},{
			"id": 18,
			"name": "LINING SKU",
            "dependentName" : "LINING FABRIC",
            "type" : "combo",
            "reference" : "liningsku",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		},
		
		
		{
			"id": 19,
			"name": "PICK STITCH",
			 "type" : "option",
			"values" : ["*None","Yes (Standard) - (Rs 300)"],
			"upcharge" : [0,300] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 20,
			"name": "CORD PIPING(Satin Trim)",
			 "type" : "option",
			"values" : [ "N/A","ST 1-Black - (Rs 500)","ST 2 -Navy - (Rs 500)","ST 3-Wine - (Rs 500)","ST 4 White - (Rs 500)","Other (See comments)"],
			"upcharge" : [0,500,500,500,500,0] ,
			"upcharge percentage" : [],
			"enable_dependency": {
				"N/A" : [21]
			}
			
		},
		{
			"id": 21,
			"name": "FRONT PLACKET",
			 "type" : "option",
			"values" : ["YES","NO"],
			"disabled": true,
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 22,
			"name": "TRAVELFLEX",
			 "type" : "option",
			"values" : ["NO","YES (Rs 3000)"],
			"upcharge" : [0,3000] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 23,
			"name": "POCKET SQUARE",
			 "type" : "option",
			"values" : ["GOLD","SAME AS LINING FABRIC","OTHER SEE COMMENTS"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		}, {
			"id": 24,
			"name": "FLAT PIPING",
			"type" : "option",
			"values" : ["YES","NO"],
			"upcharge" : [500,0] ,
			"upcharge percentage" : []
		}, {
			"id": 25,
			"name": "FLAT PIPING FABRIC AND COLOR",
			"type" : "option",
			"values" : ["SATIN BLACK", "NAVY", "WINE", "WHITE", "VELVET - BLACK", "OTHER SEE COMMENTS"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 26,
			"name": "FLAT PIPING LOCATION",
			"type" : "option",
			"values" : ["COLLAR","LAPEL","CHEST WELT","FLAP","OTHER SEE COMMENTS"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		},{
			"id": 27,
			"name": "FULL COLLAR FABRIC",
			"type" : "option",
			"values" : ["SELF FABRIC","ST 1-Black (Rs 500 Upcharge)", "ST 2 -Navy (Rs 500 Upcharge)","ST 3-Wine (Rs 500 Upcharge)","ST 4 White (Rs 500 Upcharge)","VELVET BLACK (Rs 500 Upcharge)","VELVET NAVY (Rs 500 Upcharge)","VELVET WINE (Rs 500 Upcharge)", "OTHER SEE COMMENTS"],
			"upcharge" : [0,500,500,500,500,500,500,500,0] ,
			"upcharge percentage" : []
		},{
			"id": 28,
			"name": "ELBOW PATCHES",
			 "type" : "option",
			"values" : ["OTHER SEE COMMENTS"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		]
	},
 {
		"id": 3,
		"name": "JACKET - DOUBLE BREASTED - FABRIC & DESIGN",
		"collapse" : "true",
		"Designs": [{
			"id": 1,
			"name": "CLOSURE AND LAPEL (+15%)",
			"type" : "option",
			"values" : ["NORMAL 6X2 BUTTON (+15%)","NORMAL 6X1 BUTTON (+15%)","SHAWL 6X2 BUTTON (+15%)","SHAWL 6X1 BUTTON (+15%)","Other Comments"],
			"upcharge" : [] ,
			"upcharge percentage" : []
		}, {
			"id": 2,
			"name": "VENTS*",
			"type" : "option",
			"values" : ["*MIDDLE[1]","SIDE[2]","NO VENT"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 3,
			"name": "MELTON*",
			"type" : "option",
			"values" : ["NA","*TONAL", "OTHER"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 4,
			"name": "LINING STYLE*",
			"type" : "option",
			"values" : ["*Full","Half"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 5,
			"name": "INTERNAL FACING",
			"type" : "option",
			"values" : ["*STRAIGHT 4 POCKETS","FRAMED 4 POCKETS","OTHER (SEE COMMENTS)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},	{
			"id": 6,
			"name": "JACKET FINISH*",
			"type" : "option",
			"values" : ["*FIRM"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 7,
			"name": "MONOGRAM POSITION",
			 "type" : "option",
			"values" : ["Yes (lining )","None ","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 8,
			"name": "MONOGRAM TEXT (Max 16 Char)",
			"type" : "text",
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 9,
			"name": "MONOGRAM COLOUR",
			 "type" : "option",
			"values" : ["Tonal", "White", "Black", "Navy", "Red", "Dark Green","Orange", "Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 10,
			"name": "JACKET POCKETS",
			 "type" : "option",
			"values" : ["Flap straight", "Flap slant", "Other (See comments)","2 PATCH + 1 CHEST SINGLE WELT (+15% Upcharge)","2 PATCH + 1 CHEST PATCH (+15% Upcharge)","2 PATCH + 2 CHEST PATCH (+15% Upcharge)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 11,
			"name": "TICKET POCKETS",
			 "type" : "option",
			"values" : ["None", "Straight with Flap", "Slant with Flap", "Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 12,
			"name": "ELBOW PATCHES",
			 "type" : "option",
			"values" : ["None", "Mock Suede", "Self","OTHER SEE COMMENTS"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 13,
			"name": "SLEEVE BUTTONS",
			 "type" : "option",
			"values" : ["Kissing", "Overlapping", "Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 14,
			"name": "SLEEVE BUTTON HOLE",
			 "type" : "option",
			"values" : ["All tonal", "Other (See comments)","RED","ORANGE","PINK","DARK GREEN","Other (See comments)"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 15,
			"name": "JACKET CONSTRUCTION",
			 "type" : "option",
			"values" : ["Floating Chest Piece", "Half Canvas (Rs 2000)", "Full Canvas (Rs 4000 )"],
			"upcharge" : [0,2000,4000] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 16,
			"is_button" : "true",
			"name": "BUTTONS (Body and Sleeve)",
			 "type" : "option",
			"values" : [ "ST 1-Black", "ST 2 -Navy","ST 3-Wine","ST 4 White", "Metal - Gold (Rs 500)", "Metal - Silver (Rs 500)","Other (See comments)","VELVET BLACK","VELVET NAVY","VELVET WINE"],
			"upcharge" :[0,0,0,0,0, 500,500,0,0,0,0] ,
			"upcharge percentage" : []
			
			
		},
		{
			"id": 19,
			"name": "BUTTON SKU",
			 "type" : "text",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		},
		{
			"id": 20,
			"name": "CUFF FINISHING",
			 "type" : "option",
			"values" : ["4 closed", "4 open (Rs 500)", "Other (See comments)"],
			"upcharge" : [0,500,0] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 21,
			"is_lining" : "true",
			"name": "LINING FABRIC",
            "liningDependent":"true",
			 "type" : "option",
			"values" : ["Fun (specify article)-", "Silk Lining (Rs 2500) - Specify Article","Other (See comments)"],
			"upcharge" : [0,2500,0] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 22,
			"name": "LINING SKU",
            "dependentName" : "LINING FABRIC",
            "type" : "combo",
            "reference" : "liningsku",
			"upcharge" : [] ,
			"upcharge percentage" : [],
			"in_factory" : "yes"
			
		},
		{
			"id": 23,
			"name": "PICK STITCH",
			 "type" : "option",
			"values" : ["None","Yes (Standard) - (Rs 300)"],
			"upcharge" : [0,300] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 24,
			"name": "TRAVELFLEX",
			 "type" : "option",
			"values" : ["NO","YES (Rs 3000)"],
			"upcharge" : [0,3000] ,
			"upcharge percentage" : []
			
		},
		{
			"id": 25,
			"name": "POCKET SQUARE",
			 "type" : "option",
			"values" : ["GOLD","SAME AS LINING FABRIC","OTHER SEE COMMENTS"],
			"upcharge" : [] ,
			"upcharge percentage" : []
			
		}, {
			"id": 29,
			"name": "FLAT PIPING",
			"type" : "option",
			"values" : ["YES","NO"],
			"upcharge" : [500,0] ,
			"upcharge percentage" : []
		}
		]
	}
]' as json);
  end if;
  
  
END;

$function$;

ALTER FUNCTION public."GetFabricDesignParamsV3"(integer)
    OWNER TO tailorman_db;

----------------------------------------------------

-- Adding customer_fit_on and customer_delivery date changes


alter table b_order_item add column customer_fit_on_date date;
 alter table b_order_item add column customer_delivery_date date;

CREATE OR REPLACE FUNCTION public."UpdateOrderItem"(
	in_order_id integer,
	in_order_item_id integer,
	in_style_id integer,
	in_workflow_id integer,
	in_sku_id integer,
	in_item_type_id integer,
	in_mrp double precision,
	in_qty integer,
	in_finish_type integer,
	in_fit_on_date date,
	in_delivery_date date,
	in_comment character varying,
	in_profile_id integer,
	in_priority_id integer,
	in_display_name character varying,
	in_upcharge json,
	in_taxes json,
	in_discount_type integer,
	in_discount_value double precision,
	in_order_flag integer,
	in_bill_amount double precision,
	in_upcharge_amount double precision,
	in_delivery_upcharge_amount double precision,
	in_discount_amount double precision,
	in_discount_comment character varying,
	in_workflow_start_stage_id integer,
    in_customer_fit_on_date date,
    in_customer_delivery_date date)
RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

DECLARE
var_order_item_id integer;
var_start_stage_id integer;
BEGIN
if in_order_flag =2 then
    var_start_stage_id :=0;
else
var_start_stage_id :=1;
end if;
if in_workflow_start_stage_id  IS NOT NULL then
var_start_stage_id:= in_workflow_start_stage_id;
end if;

update b_order_item set (
            style_id , sku_id, item_type_id,
            mrp , qty , finish_type , fit_on_date , delivery_date ,comment , profile_id,priority_id,display_name,upcharge , taxes  ,discount_type, discount,order_flag,bill_amount,
            upcharge_amount,
      delivery_upcharge_amount, discount_amount,discount_comment,customer_fit_on_date,customer_delivery_date)
   = ( in_style_id,  in_sku_id, in_item_type_id,
            in_mrp , in_qty , in_finish_type , in_fit_on_date , in_delivery_date,in_comment,in_profile_id,in_priority_id,in_display_name,in_upcharge ,
   in_taxes  ,   in_discount_type,  in_discount_value ,in_order_flag,in_bill_amount,in_upcharge_amount,
     in_delivery_upcharge_amount, in_discount_amount,in_discount_comment,in_customer_fit_on_date,in_customer_delivery_date)
            where order_id= in_order_id and order_item_id =in_order_item_id and workflow_id =in_workflow_id;

update b_item_wf_stage s set current_stage_flag ='N'
        where s.workflow_id=in_workflow_id
        and s.order_item_id=in_order_item_id;

        update b_item_wf_stage s
            set profile_id=in_profile_id , comment=in_comment ,current_stage_flag ='Y' , created_time=now()
        where s.workflow_id=in_workflow_id and s.workflow_stage_id=var_start_stage_id
        and s.order_item_id=in_order_item_id;
        if not found then

        insert into b_item_wf_stage(workflow_id ,
                     	   workflow_stage_id ,
                     	   order_item_id ,
                     	   profile_id ,
                     	   comment ,
                     	   user_id  ,
                     	   created_time ) values

                     	   (in_workflow_id ,
                     	   var_start_stage_id ,
                     	   in_order_item_id ,
                     	   in_profile_id ,
                     	   in_comment ,
                     	   (select user_id from b_order where order_id=in_order_id) ,
                     	   now()

                     	   );

        end if;
           
return true ;
END;

$function$;


CREATE OR REPLACE FUNCTION public."SaveOrderItem"(
	in_order_id integer,
	in_style_id integer,
	in_workflow_id integer,
	in_sku_id integer,
	in_item_type_id integer,
	in_mrp double precision,
	in_qty integer,
	in_finish_type integer,
	in_fit_on_date date,
	in_delivery_date date,
	in_comment character varying,
	in_profile_id integer,
	in_priority_id integer,
	in_display_name character varying,
	in_workflow_start_stage_id integer,
    in_customer_fit_on_date date,
    in_customer_delivery_date date)
RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

 
DECLARE
var_order_item_id integer;
BEGIN 
select nextval ('b_order_item_order_item_id_seq') into var_order_item_id;
INSERT INTO b_order_item(
            order_item_id, order_id, style_id, workflow_id, sku_id, item_type_id, 
             mrp , qty , finish_type , fit_on_date , delivery_date ,comment , profile_id,priority_id,display_name,customer_fit_on_date,customer_delivery_date)
    VALUES (var_order_item_id, in_order_id, in_style_id, in_workflow_id, in_sku_id, in_item_type_id, 
             in_mrp , in_qty , in_finish_type , in_fit_on_date , in_delivery_date,in_comment,in_profile_id,in_priority_id,in_display_name,in_customer_fit_on_date,in_customer_delivery_date);

	if exists (select 1 from m_item_type where item_type_id =in_item_type_id and mtm_flag='Y') then
				insert into b_item_wf_stage(workflow_id ,
						    workflow_stage_id ,
						    order_item_id ,
						    profile_id ,
						    comment ,
						    user_id  ,
						    created_time ) values

						    (in_workflow_id ,
						    in_workflow_start_stage_id ,
						    var_order_item_id ,
						    in_profile_id ,
						    in_comment ,
						    (select user_id from b_order where order_id=in_order_id) ,
						    now()

						    );
	end if;

return var_order_item_id ;
END;

$function$;
    


DROP FUNCTION public."GetOrderItemListV2"(
	in_order_id integer);

CREATE OR REPLACE FUNCTION public."GetOrderItemListV2"(
	in_order_id integer)
RETURNS TABLE(order_item_id integer, order_id integer, workflow_id integer, sku_id integer, item_type_id integer, mrp double precision, qty integer, finish_type_id integer, fit_on_date date, delivery_date date, comment character varying, profile_id integer, priority_id integer, display_name character varying, product_sku character varying, sku character varying, fabric_description character varying, item_type character varying, finish_type character varying, priority character varying, block character varying, item_size character varying, upcharge json, taxes json, discount_value double precision, discount_type integer, order_flag integer, bill_amount double precision, pickup_location character varying, discount_comment character varying, hsn_code integer, discount_amount double precision,customer_delivery_date date,customer_fit_on_date date)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 
declare
var_block character varying ;
var_item_size character varying ;

BEGIN 
return query 
SELECT i.order_item_id, i.order_id, i.workflow_id, i.sku_id, i.item_type_id, 
i.mrp, i.qty, i.finish_type,i.fit_on_date, i.delivery_date, 
i.comment, (select s.profile_id from b_item_wf_stage s ,b_workflow_stage ws where s.workflow_stage_id=ws.stage_id and s.order_item_id=i.order_item_id and s.current_stage_flag='Y' limit 1), i.priority_id,i.display_name , f.supplier_product_code , f.sku_code, f.name, it.descr ,ft.code ,p.code ,var_block, var_item_size,
i.upcharge , i.taxes ,i.discount,i.discount_type ,i.order_flag , i.bill_amount,(CASE WHEN i.pickup_id IS NOT NULL THEN (select sl.address from m_store sl where sl.store_id = i.pickup_id) ELSE (CASE WHEN i.delivery_id IS NOT NULL THEN (select address from m_customer_addresses where m_customer_addresses_id =i.delivery_id) ELSE '' END) END) as pickup_location,
i.discount_comment, f.hsn_code,i.discount_amount,i.customer_delivery_date,i.customer_fit_on_date
FROM public.b_order_item i 
inner join m_fabric f on i.sku_id=f.fabric_id 
inner join m_item_type it on i.item_type_id = it.item_type_id
left join m_finish_type ft on i.finish_type = ft.finish_type_id
left join m_priority_type p on i.priority_id = p.priority_type_id
where i.order_Id=in_order_id 
;

END;

$function$;

ALTER FUNCTION public."GetOrderItemListV2"(integer)
    OWNER TO tailorman_db;


--61396 

CREATE OR REPLACE FUNCTION public."GetSKUSaleDetails"(
	in_product_sku_code character varying)
RETURNS TABLE(fabric_id integer, fabric_sku_code character varying, name character varying, allow_custom_flag integer, allow_mtm_flag integer, allow_std_flag integer, mrp double precision, product_sku_code character varying, supplier_price double precision, fabric_width double precision, fabric_image_url character varying, fabric_lead_time double precision, is_bundled character varying, bundled_sku_list text, item_type_id integer,code character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN 
  return query SELECT f.fabric_id,f.sku_code,f.name,f.allow_custom_flag,f.allow_mtm_flag,f.allow_std_flag,f.shirt_mrp,f.supplier_product_code,f.supplier_price,f.fabric_width,f.fabric_image_url,
  f.fabric_lead_time,f.is_bundled,f.bundled_sku_list,f.item_type_id,mi.code 
  from m_fabric f left join m_item_type mi on f.item_type_id = mi.item_type_id where f.supplier_product_code ilike  '%' || in_product_sku_code || '%' order by 1
;
END;

$function$;

ALTER FUNCTION public."GetSKUSaleDetails"(character varying)
    OWNER TO tailorman_db;


--61397

-- alter table m_customer_addresses add column address_type character varying;

------------------------------------------------

-- FUNCTION: public."GetCustomerAddressList"integer

 -- FUNCTION: public."GetCustomerAddressList"integer

 DROP FUNCTION public."GetCustomerAddressList"(integer);

CREATE OR REPLACE FUNCTION public."GetCustomerAddressList"(
	in_param integer)
RETURNS TABLE(m_customer_addresses_id integer, m_customer_id integer, address character varying, country character varying, state character varying,address_type character varying)
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
    ROWS 1000.0
AS $function$

 BEGIN return query SELECT * FROM m_customer_addresses ca where ca.m_customer_id =in_param order by m_customer_addresses_id; END; 

$function$;

ALTER FUNCTION public."GetCustomerAddressList"(integer)
    OWNER TO tailorman_db;


------------------------------------------------


-- FUNCTION: public."InsertCustomerAddress"integer, character varying, character varying

-- DROP FUNCTION public."InsertCustomerAddress"integer, character varying, character varying;

CREATE OR REPLACE FUNCTION public."InsertCustomerAddress"(
	m_customer_id integer,
	address character varying,
	address_type character varying)
RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

 DECLARE var_customer_address_id integer; 
 BEGIN select nextval ('m_customer_addresses_m_customer_addresses_id_seq') into var_customer_address_id; 
 INSERT INTO m_customer_addresses(m_customer_addresses_id, m_customer_id, address, country_code,state,address_type) 
 VALUES (var_customer_address_id, m_customer_id, address, null,null,address_type); 
 return var_customer_address_id ;
  END; 

$function$;

ALTER FUNCTION public."InsertCustomerAddress"(integer, character varying, character varying)
    OWNER TO tailorman_db;


CREATE OR REPLACE FUNCTION public."InsertCustomerAddress"(
	in_m_customer_id integer,
	in_address character varying,
	in_address_type character varying,
	in_m_customer_addresses_id integer)
RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100.0
    VOLATILE 
AS $function$

 DECLARE var_customer_address_id integer;
 BEGIN
  var_customer_address_id:=in_m_customer_addresses_id;
 update m_customer_addresses set address=in_address,m_customer_id=in_m_customer_id,address_type=in_address_type where m_customer_addresses_id=in_m_customer_addresses_id;
 if not found then 
 select nextval ('m_customer_addresses_m_customer_addresses_id_seq') into var_customer_address_id; 
 INSERT INTO m_customer_addresses(m_customer_addresses_id, m_customer_id, address, country_code,state,address_type) 
 VALUES (var_customer_address_id, in_m_customer_id, in_address, null,null,in_address_type); 
 end if;
 return var_customer_address_id ;
  END; 

$function$;


update  m_customer_addresses set address_type ='Shipping' where address_type is null





