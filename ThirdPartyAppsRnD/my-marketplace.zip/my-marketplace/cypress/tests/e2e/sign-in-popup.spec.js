/// <reference types="cypress" />

import {signInPopup} from '../../support/page_objects/signInPopup';
import signInData from '../../fixtures/signInPopup.json';

describe('Sign in Popup Test <SignInPopup>', () => {
  const {
    logo,
    banner,
    switchTabs,
    signInForm,
    signUpForm,
    agreeTermsCondTxt,
    termsPrivacy,
    rememberMeTxt,
    forgotPassTxt,
    forgotPasswordModal,
    dropdownMenu,
    resetPassModal,
  } = signInData;

  before('open application', () => {
    localStorage.clear();
    cy.goToApp();
  });

  it('Open SignIn Popup and Verify Banner', () => {
    signInPopup.getSignInButton().click({force: true});
    signInPopup.getSignInModal().should('be.visible').wait(1000);

    signInPopup
      .getBannerImage()
      .and('have.css', 'background-image', `url("${banner.image}")`);

    signInPopup
      .getBannerContent()
      .find('img')
      .first()
      .should('be.visible')
      .should('have.attr', 'src', logo)
      .siblings('h3')
      .and('have.text', banner.heading);

    signInPopup
      .getBannerContent()
      .find('h5')
      .should('have.text', banner.poweredBy)
      .find('img')
      .should('be.visible')
      .and('have.attr', 'src', logo);
  });

  it('Verify Sign Up Form Fields', () => {
    signInPopup
      .getSignUpTab()
      .should('be.visible')
      .and('have.text', switchTabs[1])
      .click()
      .and('have.class', 'active');
    cy.wait(500);
    signInPopup
      .getSignUpForm()
      .should('be.visible')
      .find('[data-cy=sign-up-form-item]')
      .each(($el, idx) => {
        const {placeholder} = signUpForm[idx];
        cy.wrap($el)
          .find('input')
          .should('have.attr', 'placeholder', placeholder);
      });

    signInPopup
      .getAgreeTermsCond()
      .should('be.visible')
      .and('not.be.checked')
      .find('label > span')
      .not('.ant-checkbox')
      .and('have.text', agreeTermsCondTxt);

    signInPopup
      .getFormSignUpBtn()
      .should('be.visible')
      .find('span')
      .and('have.text', switchTabs[1]);

    signInPopup.getSignUpTermsPrivacy().each(($el, idx) => {
      const {text, href, target} = termsPrivacy[idx];
      cy.wrap($el)
        .should('have.text', text)
        .and('have.attr', 'href', href)
        .and('have.attr', 'target', target);
    });
  });

  it('Verify Sign In Form Fields', () => {
    signInPopup
      .getSignInTab()
      .should('be.visible')
      .and('have.text', switchTabs[0])
      .click()
      .and('have.class', 'active');
    cy.wait(500);
    signInPopup
      .getSignInForm()
      .should('be.visible')
      .children('.ant-form-item')
      .each(($el, idx) => {
        const {placeholder, inputType} = signInForm[idx];
        cy.wrap($el)
          .find('input')
          .should('have.attr', 'placeholder', placeholder)
          .and('have.attr', 'type', inputType);
      });

    signInPopup
      .getRememberMeCheckbox()
      .should('be.visible')
      .and('not.be.checked')
      .find('label > span')
      .not('.ant-checkbox')
      .and('have.text', rememberMeTxt);

    signInPopup
      .getRememberMeCheckbox()
      .find('input.ant-checkbox-input')
      .check()
      .should('be.checked');

    signInPopup
      .getForgotPassBtn()
      .should('be.visible')
      .find('span')
      .and('have.text', forgotPassTxt);

    signInPopup
      .getFormSignInBtn()
      .should('be.visible')
      .find('span')
      .and('have.text', switchTabs[0]);
  });

  it('User SignIn', () => {
    // const email = Cypress.env('email');
    // const password = Cypress.env('password');
    // signInPopup.getSignInForm().find('[data-cy=sign-in-email]').type(email);
    // signInPopup
    //   .getSignInForm()
    //   .find('[data-cy=sign-in-password]')
    //   .type(password);
    // signInPopup.getFormSignInBtn().click({force: true});
    cy.login();
    
    cy.server();
    cy.intercept('POST', '**/login').as('login');
    cy.intercept('GET', '**/student_details*').as('userDetails');

    cy.wait(['@login', '@userDetails']).spread((login, userDetails) => {
      const {token} = JSON.parse(window.localStorage.getItem('auth')) || {};
      expect(token).to.equal(login?.response?.body?.access);
      const user = userDetails.response.body;
      let profileSrc = signInData?.defaultProfileImage;
      if (user?.photo) {
        profileSrc = `${signInData?.profileImageBasepath}${user.photo}.png`;
      }
      signInPopup
        .getHeaderUserProfile()
        .should('exist')
        .and('be.visible')
        .find('[data-cy=header-user-name]')
        .should('have.text', `${user.first_name} ${user.last_name}`);

      signInPopup
        .getHeaderUserProfile()
        .find('img')
        .should('have.attr', 'src', profileSrc);
    });
  });

  it('User dropdown', () => {
    signInPopup
      .getHeaderUserProfile()
      .find('[data-cy=header-arrowdown]')
      .realHover()
      .wait(500);

    signInPopup
      .getHeaderDropdown()
      .should('be.visible')
      .children()
      .each(($el, idx) => {
        const {path, text} = dropdownMenu[idx];
        cy.wrap($el).should('have.text', text);
        if (path) {
          cy.wrap($el).find('a').should('have.attr', 'href', path);
        }
      });
  });

  it('User SignOut', () => {
    // signInPopup
    //   .getHeaderUserProfile()
    //   .find('[data-cy=header-arrowdown]')
    //   .realHover()
    //   .wait(500);

    // signInPopup.getLogoutBtn().click({force: true});
    cy.logout();

    signInPopup.getHeaderUserProfile().should('not.exist');

    signInPopup.getSignInButton().should('exist').and('be.visible');
  });

  it('Verify Forgot Password Fields', () => {
    signInPopup.getSignInButton().click({force: true});
    signInPopup.getSignInModal().should('be.visible').wait(1000);
    signInPopup.getForgotPassBtn().click();

    signInPopup
      .getForgotPassModal()
      .should('exist')
      .and('be.visible')
      .wait(1000);

    signInPopup
      .getForgotPassHeading()
      .should('have.text', forgotPasswordModal.heading)
      .siblings('[data-cy=forgot-pass-description]')
      .and('have.text', forgotPasswordModal.description);

    signInPopup
      .getForgotPassEmailForm()
      .should('be.visible')
      .find('label')
      .and('have.text', forgotPasswordModal.emailForm.label)
      .parent()
      .siblings()
      .find('input')
      .and(
        'have.attr',
        'placeholder',
        forgotPasswordModal.emailForm.placeholder,
      );
  });

  it('Verify forgot password submission', () => {
    const email = Cypress.env('email');
    signInPopup.getForgotPassModal().should('be.visible').wait(1000);
    signInPopup.getForgotPassEmailForm().type(email);
    signInPopup.getForgotPassSubmitBtn().click();

    const resetPassDesc = `${resetPassModal.description.pre}${email}${resetPassModal.description.post}`;

    cy.intercept('POST', '**/forgot_password').as('forgotPassword');
    cy.wait('@forgotPassword').then(res => {
      const forgotPassRes = res.response;
      expect(forgotPassRes?.statusCode).to.equal(200);
      expect(forgotPassRes?.body?.success).to.equal(
        resetPassModal.responseSuccMsg,
      );

      signInPopup
        .getResetPassHeading()
        .should('have.text', resetPassModal.heading);

      signInPopup.getResetPassDesc().should('have.text', resetPassDesc);

      signInPopup
        .getResetPassFooter()
        .find('[data-cy=reset-footer-pre]')
        .should('have.text', resetPassModal.footer.pre)
        .siblings('[data-cy=reset-footer-post]')
        .and('have.text', resetPassModal.footer.post)
        .find('[data-cy=resend-email-btn]')
        .and('have.css', 'color', resetPassModal.footer.resendBtnColor);

      // close Reset Password popup
      signInPopup
        .getResetPassHeading()
        .parent()
        .siblings('button')
        .click({force: true})
        .wait(500);

      // Return to login page from forgot password page
      signInPopup.getReturnToLoginPage().click();
      cy.get('.ant-modal-close-x').click();
    });
  });
});
