/// <reference types="cypress" />

import {homePage} from '../../support/page_objects/home';
import homePageData from '../../fixtures/home.json';

describe('Home Test <Home>', () => {
  const {
    bannerData: {heading, description},
    cardsData,
    pageHeading,
  } = homePageData;
  before('open application', () => {
    cy.goToApp();
  });

  it('Banner', () => {
    homePage
      .getBanner()
      .find('h1')
      .should('have.text', heading)
      .siblings('h5')
      .and('contain', description)
      .children('span')
      .and('have.text', 'TM');
  });

  it('Resouce Cards', () => {
    homePage
      .getPageHeading()
      .should('be.visible')
      .and('have.text', pageHeading);

    homePage.getResourceCards().should('be.visible').should('have.length', 3);

    homePage.getResourceCards().each((el, index) => {
      const $el = cy.wrap(el);
      const {
        heading,
        description,
        btnText,
        selectedColor,
        imageSrc,
      } = cardsData[index];
      $el
        .click()
        .should('have.class', 'active')
        .and('have.css', 'border', `1px solid ${selectedColor}`);

      $el
        .find('h4')
        .and('have.text', heading)
        .siblings('p')
        .should('have.text', description)
        .siblings('span')
        .should('have.text', btnText);

      $el
        .siblings('img')
        .should('be.visible')
        .and('have.length', 1)
        .and('have.attr', 'src', imageSrc);

      $el.click();
      cy.get('[data-cy=resource-subcards]').should('not.exist');
      // homePage.getResourceSubCards().should('not.exist');
    });
  });

  it('Resource SubCards', () => {
    homePage.getResourceCards().each((el, index) => {
      const $el = cy.wrap(el);
      const {hoverBoxShadow, subCardsData} = cardsData[index];
      $el.click({waitForAnimations: false});
      homePage
        .getResourceSubCards()
        .should('be.visible')
        .and('have.length', subCardsData?.length);

      homePage.getResourceSubCards().each((subCard, idx) => {
        const $subCard = cy.wrap(subCard);
        $subCard
          .find('h3')
          .should('have.text', subCardsData[idx].heading)
          .next()
          .and('have.text', subCardsData[idx].description);

        $subCard
          .siblings('img')
          .should('be.visible')
          .and('have.length', 1)
          .and('have.attr', 'src', subCardsData[idx].imageSrc);

        $subCard
          .parent('li')
          .realHover()
          .wait(500)
          .should('have.css', 'box-shadow', hoverBoxShadow);
      });
    });
  });
});
