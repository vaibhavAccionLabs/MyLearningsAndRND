/// <reference types="cypress" />

import {navigateResources, checkBreadcrumb} from '../../support/utils/common';
import {findOpportunitiesPage} from '../../support/page_objects/findOpportunities';
import findOpportunitiesData from '../../fixtures/findOpportunities.json';

describe('Find Opportunities Test <PartnersList>', () => {
  const {
    bannerData,
    breadcrumbData,
    filtersFormStaticData,
  } = findOpportunitiesData;

  before('open application', () => {
    localStorage.clear();
    cy.goToApp();
  });

  it('Navigate to Find Opportunites Page and Test URL', () => {
    navigateResources(5);
    cy.location().should(loc => {
      expect(loc.pathname).to.eq('/business-partners');
    });
  });

  it('Open Find Opportunities and Verify Banner', () => {
    findOpportunitiesPage
      .getBanner()
      .find('h1')
      .and('have.text', bannerData.title)
      .siblings('h3')
      .and('have.text', bannerData.subTitle);
  });

  it('Breadcrumb', () => {
    checkBreadcrumb(breadcrumbData);
  });

  it('Filter Static Info', () => {
    findOpportunitiesPage
      .getFilterContainer()
      .should('be.visible')
      .find('h2')
      .and('have.text', filtersFormStaticData.heading);

    findOpportunitiesPage
      .getOpportunitiesFilterSubmit()
      .and('have.text', filtersFormStaticData.searchBtnTxt);
  });

  it('National Jobs Filter Labels', () => {
    findOpportunitiesPage
      .getOpportunitiesFilterForm()
      .children('[data-cy=opportunities-filter-form-item]')
      .each((ele, ind) => {
        const {label} = filtersFormStaticData.NationalFormData[ind];
        cy.wrap(ele).find('label').should('have.text', label);
      });
  });
});
