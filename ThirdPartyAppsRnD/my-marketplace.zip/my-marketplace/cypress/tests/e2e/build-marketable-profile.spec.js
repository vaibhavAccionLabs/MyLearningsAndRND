/// <reference types="cypress" />

import {buildProfilePage} from '../../support/page_objects/buildMarketableProfile';
import {signInPopup} from '../../support/page_objects/signInPopup';
import {
  navigateResources,
  checkSignInPopup,
  checkBreadcrumb,
} from '../../support/utils/common';
import screenData from '../../fixtures/buildMarketableProfile.json';

describe('Build Marketable Profile Test <BMP>', () => {
  const {
    bannerData,
    breadcrumb,
    contentHeading,
    headingColor,
    profileContent,
    startBuildingProfileData,
  } = screenData;

  before('open application', () => {
    cy.goToApp();
  });

  it('Navigate to Build Marketable Page and Verify URL', () => {
    navigateResources(2);
    cy.location('pathname').should('eq', '/build/student-profile');
  });

  it('Banner', () => {
    const {heading, subHeading, btnTxt} = bannerData;
    buildProfilePage
      .getBuildProfileBanner()
      .should('be.visible')
      .find('h1')
      .and('have.text', heading)
      .siblings('h5')
      .and('have.text', subHeading)
      .siblings('button')
      .and('have.text', btnTxt)
      .click();

    checkSignInPopup();
  });

  it('Breadcrumb', () => {
    checkBreadcrumb(breadcrumb);
  });

  it('Build Profile Content', () => {
    buildProfilePage
      .getBuildProfileContainer()
      .find('h1')
      .first()
      .should('be.visible')
      .and('have.text', contentHeading);

    const BuildProfileContent = buildProfilePage.getBuildProfileContent();

    BuildProfileContent.should('be.visible').and('have.length', 3);

    BuildProfileContent.each((ele, index) => {
      const {heading, bulletpoints, images} = profileContent[index];
      const $ele = cy.wrap(ele);
      $ele
        .find('h4')
        .should('have.text', heading)
        .find('span')
        .and('have.css', 'color', headingColor);

      cy.wrap(ele)
        .find('ul > li')
        .should('have.length', bulletpoints.length)
        .each((liEle, liInd) => {
          cy.wrap(liEle).should('have.text', bulletpoints[liInd]);
        });

      const imageEleAttr =
        index === 1 ? 'profile-left-image' : 'profile-right-image';
      const $imagesEle = cy
        .wrap(ele)
        .find(`[data-cy=${imageEleAttr}]`)
        .children()
        .should('have.length', index === 1 ? 1 : 2);

      $imagesEle.each((el, i) => {
        cy.wrap(el)
          .should('be.visible')
          .and('have.attr', 'src', images[i])
          .and('have.attr', 'alt');
      });
    });
  });

  it('Start Building Profile Button', () => {
    const {heading, btnTxt} = startBuildingProfileData;
    buildProfilePage
      .getBuildingProfileBtn()
      .should('be.visible')
      .find('h1')
      .and('have.text', heading)
      .siblings('button')
      .and('have.text', btnTxt)
      .click();

    // checkSignInPopup();
  });

  it('Sign In after clicking start building your profile', () => {
    signInPopup.getSignInModal().should('be.visible');
    cy.login();

    cy.location('pathname').should('eq', '/settings/profile');
    cy.logout();
  });

});
