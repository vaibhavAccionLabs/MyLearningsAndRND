/// <reference types="cypress" />

import {discoverInterestPage} from '../../support/page_objects/discoverInterest';
import {
  navigateResources,
  checkSignInPopup,
  checkBreadcrumb,
} from '../../support/utils/common';
import careerData from '../../fixtures/discoverInterest.json';

describe('Discover Interest Page Test <DiscoverInterest>', () => {
  const {
    bannerData,
    breadcrumb,
    headingContent,
    surveyQuestion,
    surveyContent,
    takeSurvey,
    disclaimer,
  } = careerData;

  before('open application', () => {
    cy.goToApp();
  });

  it('Navigate to Discover Your Interest Page and Verify URL', () => {
    navigateResources(1);
    cy.location('pathname').should('eq', '/survey');
  });

  it('Banner', () => {
    discoverInterestPage
      .getBanner()
      .should('be.visible')
      .find('h1')
      .and('have.text', bannerData.heading)
      .siblings('h4')
      .and('have.text', bannerData.subHeading)
      .siblings('button')
      .and('have.text', bannerData.btnTxt)
      .click();

    checkSignInPopup();
  });

  it('Breadcrumb', () => {
    checkBreadcrumb(breadcrumb);
  });

  it('Heading Content', () => {
    discoverInterestPage
      .getHeadingContent()
      .find('h4')
      .should('have.text', headingContent.heading)
      .siblings('p')
      .and('have.text', headingContent.description);

    discoverInterestPage
      .getHeadingContent()
      .find('img')
      .should('be.visible')
      .and('have.attr', 'src', headingContent.image)
      .and('have.attr', 'alt');
  });

  it('Survey Content', () => {
    discoverInterestPage
      .getSurveyQuestion()
      .should('be.visible')
      .and('have.text', surveyQuestion);

    discoverInterestPage.getSurveyContent().each((ele, ind) => {
      cy.wrap(ele)
        .find('[data-cy=survey-list]')
        .should('have.text', surveyContent[ind].text);

      cy.wrap(ele)
        .find('img')
        .first()
        .should('have.attr', 'src', surveyContent[ind].image)
        .and('have.attr', 'alt');
    });
  });

  it('Take Survey', () => {
    discoverInterestPage
      .getTakeSurveyContainer()
      .find('h2')
      .should('have.text', takeSurvey.heading)
      .siblings('p')
      .and('have.text', takeSurvey.timeRequiredText)
      .siblings('button')
      .and('have.text', takeSurvey.btnText)
      .click();

    checkSignInPopup();
  });

  it('Disclaimer', () => {
    discoverInterestPage
      .getDisclaimer()
      .should('be.visible')
      .and('have.text', disclaimer);
  });
});
