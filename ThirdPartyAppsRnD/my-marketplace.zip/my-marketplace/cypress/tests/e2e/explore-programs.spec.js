/// <reference types="cypress" />

import {exploreProgramsPage} from '../../support/page_objects/explorePrograms';
import {
  navigateResources,
  checkBreadcrumb,
  verifyImage,
  checkCorouselVisibility,
  checkCarouselFunctionality,
} from '../../support/utils/common';
import screenData from '../../fixtures/explorePrograms.json';

describe('Explore Programs Test <ExplorePrograms>', () => {
  const {breadcrumb, programByCareer, newestPrograms} = screenData;
  let careerProgResp, newestProgResp;

  before('open application', () => {
    cy.goToApp();
  });

  it('Navigate to Explore Programs Page and Get Programs Data', () => {
    navigateResources(0);
    cy.location('pathname').should('eq', '/directory/paths-list');

    cy.intercept('GET', '**/cluster-v2').as('careerPrograms');
    cy.intercept('GET', '**/pathways-v2/*').as('newestPrograms');
    cy.wait(['@careerPrograms', '@newestPrograms']).spread(
      (careerProg, newestProg) => {
        careerProgResp = careerProg?.response;
        newestProgResp = newestProg?.response;
      },
    );
  });

  it('Breadcrumb', () => {
    checkBreadcrumb(breadcrumb);
  });

  it('Programs By Career section', () => {
    const {heading} = programByCareer;
    exploreProgramsPage
      .getProgramsByCareerSec()
      .find('h2')
      .should('have.text', heading);

    checkCorouselVisibility('[data-cy=programs-by-career]', 3);
    checkCarouselFunctionality('[data-cy=programs-by-career]', 3);

    const filteredResp = careerProgResp?.body?.filter(
      e => e?.active_path_count,
    );

    exploreProgramsPage
      .getProgramsByCareerList()
      .should('be.visible')
      .and('have.length', filteredResp.length)
      .each(($el, idx) => {
        const {cluster_name, cluster_card_url} = filteredResp[idx];
        cy.wrap($el)
          .find('div')
          .should('have.text', cluster_name)
          .siblings('img')
          .then($img => {
            verifyImage($img, cluster_card_url);
          });
      });
  });

  it('Newest Programs section', () => {
    const {
      body: {path_details},
    } = newestProgResp;
    const {heading, viewAllBtn, defaultCardImg, certifiedIcon} = newestPrograms;

    exploreProgramsPage
      .getNewestProgramsSec()
      .find('h2')
      .should('have.text', heading)
      .siblings('a')
      .should('have.text', viewAllBtn.text)
      .and('have.attr', 'href', viewAllBtn.path);

    checkCorouselVisibility('[data-cy=newest-programs]', 4);
    checkCarouselFunctionality('[data-cy=newest-programs]', 4); //need to pass parent element and default visible number

    exploreProgramsPage
      .getNewestProgramsList()
      .should('be.visible')
      .and('have.length', path_details.length)
      .each(($el, idx) => {
        const {
          award_type_name,
          banner_cloudinary,
          title,
          institute_details: {name},
        } = path_details[idx];

        let cardImgUrl = defaultCardImg;

        if (banner_cloudinary) {
          cardImgUrl = banner_cloudinary;
        }
        cy.wrap($el)
          .find('[data-cy=card-image]')
          .then($img => {
            verifyImage($img, cardImgUrl);
          });

        cy.wrap($el)
          .find('h4')
          .should('have.text', title)
          .siblings('p')
          .and('have.text', name)
          .siblings('h5')
          .and('have.text', award_type_name)
          .find('img')
          .and('have.attr', 'src', certifiedIcon)
          .and('have.attr', 'alt')
          .and('not.be.empty');
      });
  });
});
