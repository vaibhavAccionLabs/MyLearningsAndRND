/// <reference types="cypress" />

import {homePage} from '../../support/page_objects/home';
import homePageData from '../../fixtures/home.json';

describe('Footer Test <Footer>', () => {
  const {
    logoImageSrc,
    footerData,
    resourcesTxt,
    resourcesLinks,
    aboutTxt,
    aboutPath,
  } = homePageData;

  before('open application', () => {
    cy.goToApp();
  });

  it('Descrtiption and Logo Image', () => {
    const $footer = homePage.getFooter();
    $footer
      .find('[data-cy=footer-description]')
      .should('be.visible')
      .and('have.text', footerData.description);

    $footer
      .siblings('img')
      .should('be.visible')
      .and('have.length', 1)
      .and('have.attr', 'src', logoImageSrc);
  });

  it('Social Media', () => {
    homePage
      .getFooter()
      .find('[data-cy=footer-connect-text]')
      .should('be.visible')
      .and('have.text', footerData.connectText);

    homePage
      .getSocialMediaIcons()
      .should('be.visible')
      .and('have.length', 3)
      .each((ele, idx) => {
        cy.wrap(ele)
          .find('a')
          .should('have.attr', 'href', footerData.connectOptions[idx]?.path)
          .children('img')
          .should('be.visible')
          .and('have.length', 1)
          .and('have.attr', 'src', footerData.connectOptions[idx]?.imageSrc)
          .and('have.attr', 'alt');
      });
  });

  it('Resource Links', () => {
    homePage.getFooterResourcesHeader().should('have.text', resourcesTxt);

    homePage
      .getFooterResourcesLinks()
      .should('be.visible')
      .and('have.length', 8);

    homePage.getFooterResourcesLinks().each((el, idx) => {
      const {path, title} = resourcesLinks[idx];
      cy.wrap(el)
        .find('a')
        .should('have.attr', 'href', path)
        .children('span')
        .should('have.length', 1)
        .and('have.text', title);
    });
  });

  it('About Link', () => {
    homePage
      .getFooterAboutLink()
      .should('have.attr', 'href', aboutPath)
      .and('have.attr', 'target', '_blank')
      .children('h5')
      .should('have.text', aboutTxt);
  });

  it('Copyright and Terms & Conditions', () => {
    const $ele = homePage.getFooterCopyright();
    $ele.should('be.visible').and('have.text', footerData.copyrightText);

    $ele.find('a').then(ele => {
      cy.wrap(ele)
        .first()
        .should('have.attr', 'href', footerData.termsOfUsePath);

      cy.wrap(ele)
        .last()
        .should('have.attr', 'href', footerData.privacyPolicyPath);
    });
  });
});
