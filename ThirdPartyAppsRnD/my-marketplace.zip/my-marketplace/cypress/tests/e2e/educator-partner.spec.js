/// <reference types="cypress" />

import {partnerPage} from '../../support/page_objects/partners';
import {
  navigateResources,
  checkWelcomeAboardFields,
  checkBreadcrumb,
} from '../../support/utils/common';
import educatorData from '../../fixtures/educatorPartner.json';

describe('Education Partner Test <EduPartner>', () => {
  const {
    bannerData,
    breadcrumb,
    partnerContent,
    additionalContent,
    welcomeAboardModal,
  } = educatorData;

  before('open application', () => {
    cy.goToApp();
  });

  it('Navigate to Education Partner Page and Verify URL', () => {
    navigateResources(7);
    cy.location().should(loc => {
      expect(loc.pathname).to.eq('/business-partners/apply');
      expect(loc.search).to.eq('?partnerType=educator');
    });
  });

  it('Banner', () => {
    const {image, heading, subHeading, btnTxt} = bannerData;
    partnerPage
      .getPartnerBanner()
      .should('be.visible')
      .and(
        'have.attr',
        'style',
        `background: url("${image}") center top no-repeat;`,
      );

    partnerPage
      .getPartnerBanner()
      .find('h1')
      .and('have.text', heading)
      .siblings('h4')
      .and('have.text', subHeading)
      .siblings('button')
      .and('have.text', btnTxt)
      .click();

    partnerPage
      .getWelcomeAboardModal()
      .should('be.visible')
      .find('button.ant-modal-close')
      .click();
  });

  it('Breadcrumb', () => {
    checkBreadcrumb(breadcrumb);
  });

  it('Educator Partner Content', () => {
    partnerPage
      .getEducatorPartnerContent()
      .should('be.visible')
      .should('have.length', 3);

    partnerPage
      .getEducatorPartnerContent()
      .not('[data-cy=partner-access]')
      .each((el, index) => {
        const $mainSection = cy.wrap(el);
        $mainSection.should(
          'have.class',
          index === 0 ? 'leftSide_align' : 'rightSide_align',
        );
        const subSecData = partnerContent[index].subSection;
        $mainSection
          .children()
          .should('have.length', 4)
          .each((child, idx) => {
            const $child = cy.wrap(child);
            if (idx === 0) {
              $child
                .should('have.class', 'main-section')
                .find('h2')
                .should('have.text', partnerContent[index].heading)
                .siblings('p')
                .should('have.text', partnerContent[index].description);
            } else {
              $child
                .should('have.class', 'sub-section')
                .find('h3')
                .should('have.text', subSecData[idx - 1].heading)
                .siblings('p')
                .should('have.text', subSecData[idx - 1].description);

              const imgParent = cy.wrap(child);
              imgParent
                .find('img')
                .should('be.visible')
                .and('have.length', 1)
                .and('have.attr', 'src', subSecData[idx - 1].image)
                .and('have.attr', 'alt');
            }
          });
      });
  });

  it('Educator Partner Access', () => {
    const {heading, description, btnTxt} = additionalContent;
    partnerPage
      .getEducatorPartnerAccess()
      .find('h2')
      .and('have.text', heading)
      .siblings('p')
      .and('have.text', description)
      .siblings('button')
      .and('have.text', btnTxt)
      .click({force: true});
  });

  it('Verify Educator Partner Request Form Fields', () => {
    checkWelcomeAboardFields(welcomeAboardModal);
  });
});
