/// <reference types="cypress" />

import {partnerPage} from '../../support/page_objects/partners';
import {
  navigateResources,
  checkWelcomeAboardFields,
  checkBreadcrumb,
} from '../../support/utils/common';
import employerData from '../../fixtures/employerPartner.json';

describe('Employer Partner Page Test <EmpPartner>', () => {
  const {
    bannerData,
    breadcrumb,
    partnerContent,
    additionalContent,
    welcomeAboardModal,
  } = employerData;

  before('open application', () => {
    cy.goToApp();
  });

  it('Navigate to Employer Partner Page and Test URL', () => {
    navigateResources(6);
    cy.location().should(loc => {
      expect(loc.pathname).to.eq('/business-partners/apply');
      expect(loc.search).to.eq('?partnerType=employer');
    });
  });

  it('Banner', () => {
    partnerPage
      .getPartnerBanner()
      .should('be.visible')
      .and(
        'have.attr',
        'style',
        `background: url("${bannerData.image}") center top no-repeat;`,
      );

    partnerPage
      .getPartnerBanner()
      .find('h1')
      .and('have.text', bannerData.heading)
      .siblings('h4')
      .and('have.text', bannerData.subHeading)
      .siblings('button')
      .and('have.text', bannerData.btnTxt)
      .click();

    partnerPage
      .getWelcomeAboardModal()
      .should('be.visible')
      .find('button.ant-modal-close')
      .click();
  });

  it('Breadcrumb', () => {
    checkBreadcrumb(breadcrumb);
  });

  it('Employer Partner Content', () => {
    partnerPage
      .getEducatorPartnerContent()
      .should('be.visible')
      .should('have.length', partnerContent.length + 1);

    partnerPage
      .getEducatorPartnerContent()
      .not('[data-cy=partner-access]')
      .each((el, index) => {
        cy.wrap(el)
          .and('have.class', index === 0 ? 'leftSide_align' : 'rightSide_align')
          .find('h2')
          .and('have.text', partnerContent[index].heading)
          .siblings('p')
          .and('have.text', partnerContent[index].description);

        const subSecData = partnerContent[index].subSection;
        cy.wrap(el)
          .find('.sub-section')
          .should('have.length', subSecData.length)
          .each((subSection, subSecInd) => {
            cy.wrap(subSection)
              .find('h3')
              .and('have.text', subSecData[subSecInd].heading)
              .siblings('p')
              .and('have.text', subSecData[subSecInd].description);

            cy.wrap(subSection)
              .find('img')
              .should('be.visible')
              .and('have.length', 1)
              .and('have.attr', 'src', subSecData[subSecInd].image)
              .and('have.attr', 'alt');
          });
      });
  });

  it('Employer Partner Access', () => {
    partnerPage
      .getEducatorPartnerAccess()
      .find('h2')
      .and('have.text', additionalContent.heading)
      .siblings('p')
      .and('have.text', additionalContent.description)
      .siblings('button')
      .and('have.text', additionalContent.btnTxt)
      .click();
  });

  it('Verify Employer Partner Request Form Fields', () => {
    checkWelcomeAboardFields(welcomeAboardModal);
  });
});
