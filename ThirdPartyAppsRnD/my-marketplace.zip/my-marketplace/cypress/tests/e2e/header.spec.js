/// <reference types="cypress" />

import {homePage} from '../../support/page_objects/home';
import {signInPopup} from '../../support/page_objects/signInPopup';
import {checkSignInPopup} from '../../support/utils/common';
import homePageData from '../../fixtures/home.json';

describe('Header Test <Header>', () => {
  const {
    logoImageSrc,
    headerData,
    resourcesTxt,
    resourcesLinks,
    globalSearch,
  } = homePageData;
  before('open application', () => {
    cy.goToApp();
  });

  it('Header Logo', () => {
    homePage
      .getHeader()
      .find('[data-cy=header-logo]')
      .find('a')
      .should('have.attr', 'href', '/')
      .find('span')
      .should('be.visible')
      .and(
        'have.attr',
        'style',
        `background: url("${logoImageSrc}") left top no-repeat;`,
      );
  });

  it('Global Search', () => {
    homePage
      .getGlobalSeach()
      .should('be.visible')
      .find('input')
      .and('have.attr', 'placeholder', globalSearch.placeHolder)
      .siblings()
      .find('button')
      .and('have.class', 'ant-input-search-button');
  });

  it('Resources Link', () => {
    homePage
      .getHeader()
      .find('[data-cy=header-resources] span')
      .should('have.text', resourcesTxt)
      .realHover();

    const $headerResLinks = homePage.getHeaderResourcesLinks();
    $headerResLinks.should('be.visible').and('have.length', 9);

    $headerResLinks.each((el, idx) => {
      const {path, title, target} = resourcesLinks[idx];
      const $ele = cy.wrap(el);
      $ele.find('a').should('have.attr', 'href', path).and('have.text', title);

      if (target) {
        $ele.should('have.attr', 'target', target);
      }
    });
  });

  it('Sign In Button', () => {
    signInPopup.getSignInModal().should('not.exist');

    signInPopup
      .getSignInButton()
      .should('be.visible')
      .find('span')
      .and('have.text', headerData.signInText)
      .click();

    checkSignInPopup();
  });
});
