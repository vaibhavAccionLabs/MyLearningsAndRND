import {homePage} from '../page_objects/home';
import {signInPopup} from '../page_objects/signInPopup';
import {partnerPage} from '../page_objects/partners';

import {carousel} from '../../fixtures/explorePrograms.json';

export const navigateResources = linkIndex => {
  homePage
    .getHeader()
    .find('[data-cy=header-resources] span')
    .realHover()
    .wait(300);
  homePage
    .getHeaderResourcesLinks()
    .eq(linkIndex)
    .find('a')
    .click({force: true});
};

export const checkSignInPopup = () => {
  signInPopup
    .getSignInModal()
    .should('exist')
    .and('be.visible')
    .parent()
    .siblings('.ant-modal-close')
    .click()
    .should('not.exist');
};

export const checkWelcomeAboardFields = data => {
  partnerPage.getWelcomeAboardModal().should('be.visible');
  partnerPage
    .getWelcomeAboardHeading()
    .and('have.text', data.heading)
    .siblings('[data-cy=welcome-aboard-desc]')
    .and('have.text', data.description);
  partnerPage
    .getWelcomeAboardForm()
    .children('[data-cy=welcome-aboard-form-item]')
    .each(($el, index) => {
      const {label, placeholder} = data.formData[index];
      cy.wrap($el).find('label').should('have.text', label);
      if (Array.isArray(placeholder)) {
        cy.wrap($el)
          .find('input')
          .each(($e, idx) =>
            cy.wrap($e).should('have.attr', 'placeholder', placeholder[idx]),
          );
      } else {
        cy.wrap($el)
          .find('input')
          .should('have.attr', 'placeholder', placeholder);
      }
    });
  partnerPage.getWelcomeAboardSubmit().should('have.text', data.submitBtn);
  partnerPage.getWelcomeAboardModal().find('button.ant-modal-close').click();
};

export const checkBreadcrumb = breadcrumb => {
  const $element = cy.get('[data-cy=breadcrumb] > div').children();
  if (breadcrumb && Array.isArray(breadcrumb) && breadcrumb.length) {
    $element.should('be.visible').and('have.length', breadcrumb.length);
    $element.each(($el, index) => {
      const {text, path} = breadcrumb[index];
      cy.wrap($el).find('span').first().should('have.text', text);
      if (path) {
        $element.find('a').should('have.attr', 'href', path);
      }
    });
  }
};

export const verifyImage = ($el, uri) => {
  cy.wrap($el).should('have.attr', 'alt').and('not.be.empty');
  cy.wrap($el).should('have.attr', 'src').and('contain', uri);
};

export const checkCorouselVisibility = (parentEle, defaultColumnCount) => {
  cy.get(parentEle)
    .find('.slick-track')
    .children()
    .its('length')
    .then(actualColumns => {
      if (actualColumns > defaultColumnCount) {
        cy.get(parentEle)
          .find('[data-cy=carousel-left-arrow]')
          .and('be.visible')
          .and('have.css', 'cursor', 'not-allowed')
          .and('have.attr', 'src', carousel.leftArrow.img)
          .and('have.attr', 'alt', carousel.leftArrow.altText)
          .siblings('[data-cy=carousel-right-arrow]')
          .and('be.visible')
          .and('have.attr', 'src', carousel.rightArrow.img)
          .and('have.attr', 'alt', carousel.rightArrow.altText);
      } else {
        cy.get(parentEle)
          .find('[data-cy=carousel-left-arrow]')
          .should('not.exist');
        cy.get(parentEle)
          .find('[data-cy=carousel-right-arrow]')
          .should('not.exist');
      }
    });
};

export const checkCarouselFunctionality = (parentEle, defaultColumnCount) => {
  cy.get(parentEle)
    .find('.slick-track')
    .children()
    .its('length')
    .then(actualColumns => {
      if (actualColumns > defaultColumnCount) {
        cy.get(parentEle)
          .find('.slick-slide')
          .then(ele => {
            cy.wrap(ele)
              .filter('.slick-active')
              .should('have.length', defaultColumnCount)
              .and('be.visible');
          });

        cy.get(parentEle)
          .find('.slick-slide')
          .not('.slick-active')
          .each(ele => {
            cy.get(parentEle)
              .find('[data-cy=carousel-right-arrow]')
              .click({force: true});
            cy.wait(700);
            cy.wrap(ele).should('be.visible');
          });

        cy.get(parentEle)
          .find('[data-cy=carousel-right-arrow]')
          .should('have.css', 'cursor', 'not-allowed');
      }
    });
};
