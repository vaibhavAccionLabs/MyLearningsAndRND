class homePage_Selectors {
  // header
  getHeader = () => cy.get('.outsideHeader');

  getHeaderResourcesLinks = () =>
    cy.get('[data-cy=header-resources-links]').children('li');

  getGlobalSeach = () => cy.get('[data-cy=global-search]');

  // banner
  getBanner = () => cy.get('.wrapper.homepage header');

  //main body
  getPageHeading = () => cy.get('[data-cy=body-heading]');

  getResourceCards = () => cy.get('ul.resources_card').children();

  getResourceSubCards = () => cy.get('[data-cy=resource-subcards]').children();

  //footer
  getFooter = () => cy.get('.footerContainer');

  getSocialMediaIcons = () => cy.get('[data-cy=media-icons]').children();

  getFooterResourcesHeader = () => cy.get('[data-cy=footer-resources]');

  getFooterResourcesLinks = () =>
    cy.get('[data-cy=footer-resources-links]').children('li');

  getFooterAboutLink = () => cy.get('[data-cy=footer-about]').parent();

  getFooterCopyright = () => cy.get('[data-cy=footer-copyright]');
}

export const homePage = new homePage_Selectors();
