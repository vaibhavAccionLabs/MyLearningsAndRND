class buildMarketableProfile_Selectors {
    getBuildProfileBanner = () => cy.get('[data-cy=build-profile-banner]');

    getBuildProfileContainer = () => cy.get('[data-cy=build-profile-container]');

    getBuildProfileContent = () => cy.get('[data-cy=build-profile-content]');

    getBuildingProfileBtn = () => cy.get('[data-cy=start-building-profile-btn]');
}

export const buildProfilePage = new buildMarketableProfile_Selectors();