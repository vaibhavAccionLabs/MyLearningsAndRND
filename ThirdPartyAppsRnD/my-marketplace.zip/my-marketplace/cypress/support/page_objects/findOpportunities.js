class findOpportunities_Selectors {
  getBanner = () => cy.get('[data-cy=open-jobs-banner');

  getMobileFilterContainer = () => cy.get('[data-cy=mobile-filter-container]');

  getFilterContainer = () => cy.get('[data-cy=filter-container]');

  getFilteredContent = () => cy.get('[data-cy=filtered-content]');

  getOpportunitiesFilterForm = () =>
    cy.get('[data-cy=opportunities-filter-form]');

  getOpportunitiesFilterSubmit = () =>
    cy.get('[data-cy=opportunities-filter-submit-btn]');
}

export const findOpportunitiesPage = new findOpportunities_Selectors();
