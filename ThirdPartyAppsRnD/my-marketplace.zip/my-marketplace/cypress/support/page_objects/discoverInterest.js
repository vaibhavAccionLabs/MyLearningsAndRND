class discoverInterestPage_Selectors {
    getBanner = () => cy.get('[data-cy=discover-interest-banner]');
    
    getHeadingContent = () => cy.get('[data-cy=career-heading-content]');

    getSurveyQuestion = () => cy.get('[data-cy=survey-question]');

    getSurveyContent = () => cy.get('[data-cy=curve-effect-cont]');

    getTakeSurveyContainer = () => cy.get('[data-cy=take-survey-cont]');

    getDisclaimer = () => cy.get('[data-cy=survey-disclaimer]');
}

export const discoverInterestPage = new discoverInterestPage_Selectors();
