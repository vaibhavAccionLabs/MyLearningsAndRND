class SignIn_Selectors {
  getSignInButton = () => cy.get('[data-cy=sign-in-btn]');

  getSignInModal = () => cy.get('[data-cy=sign-in-modal]');

  getBannerImage = () => cy.get('[data-cy=sign-in-banner-img]');

  getBannerContent = () => cy.get('[data-cy=sign-in-banner-content]');

  getSignInTab = () => cy.get('[data-cy=signin-tab]');

  getSignUpTab = () => cy.get('[data-cy=signup-tab]');

  getSignInForm = () => cy.get('[data-cy=sign-in-form]');

  getSignUpForm = () => cy.get('[data-cy=sign-up-form]');

  getAgreeTermsCond = () => cy.get('[data-cy=agree-terms-conditions]');

  getFormSignUpBtn = () => cy.get('[data-cy=form-sign-up]');

  getSignUpTermsPrivacy = () => cy.get('[data-cy=sign-up-terms-privacy]').children('a');

  getRememberMeCheckbox = () => cy.get('[data-cy=remember-me]');

  getForgotPassBtn = () => cy.get('[data-cy=forgot-password]');

  getForgotPassModal = () => cy.get('[data-cy=forgot-password-popup]');

  getForgotPassHeading = () => cy.get('[data-cy=forgot-pass-heading]');

  getForgotPassEmailForm = () => cy.get('[data-cy=forgot-pass-email]');

  getReturnToLoginPage = () => cy.get('[data-cy=return-to-login-page]');

  getForgotPassSubmitBtn = () => cy.get('[data-cy=forgot-pass-submit-btn]');

  getFormSignInBtn = () => cy.get('[data-cy=form-sign-in]');

  getHeaderUserProfile = () => cy.get('[data-cy=header-user-profile]');

  getHeaderDropdown = () => cy.get('[data-cy=header-dropdown-menu]');

  getLogoutBtn = () => cy.get('[data-cy=header-menuitem-logout]');

  getResetPassHeading = () => cy.get('[data-cy=reset-pass-heading]');

  getResetPassDesc = () => cy.get('[data-cy=reset-pass-desc]');

  getResetPassFooter = () => cy.get('[data-cy=reset-pass-footer]');
}

export const signInPopup = new SignIn_Selectors();
