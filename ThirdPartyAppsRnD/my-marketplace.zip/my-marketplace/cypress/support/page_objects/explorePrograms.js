class Explore_Programs_Selectors {
    getProgramsByCareerSec = () => cy.get('[data-cy=programs-by-career]');

    getProgramsByCareerList = () => cy.get('[data-cy=program-by-career-element]');

    getNewestProgramsSec = () => cy.get('[data-cy=newest-programs]');

    getNewestProgramsList = () => cy.get('[data-cy=newest-programs-element]');
}

export const exploreProgramsPage = new Explore_Programs_Selectors();