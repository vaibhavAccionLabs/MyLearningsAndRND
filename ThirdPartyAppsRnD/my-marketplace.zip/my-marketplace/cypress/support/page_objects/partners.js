class partnerPage_Selectors {
  getPartnerBanner = () => cy.get('[data-cy=partners-banner]');

  getEducatorPartnerContent = () =>
    cy.get('[data-cy=partner-content]').children();

  getEducatorPartnerAccess = () => cy.get('[data-cy=partner-access]');

  getWelcomeAboardModal = () => cy.get('[data-cy=welcome-aboard-form]').parents('.ant-modal-content');

  getWelcomeAboardHeading = () => cy.get('[data-cy=welcome-aboard-heading]');
  
  getWelcomeAboardForm = () => cy.get('[data-cy=welcome-aboard-form]');

  getWelcomeAboardSubmit = () => cy.get('[data-cy=welcome-aboard-submit-btn]');
}

export const partnerPage = new partnerPage_Selectors();
