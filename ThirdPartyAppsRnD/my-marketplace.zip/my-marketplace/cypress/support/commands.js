import {signInPopup} from '../support/page_objects/signInPopup';
// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

Cypress.Commands.add('goToApp', () => {
  const isInteractive = Cypress.config('isInteractive');
  cy.location('pathname').then(path => {
    if ((isInteractive && path === 'blank') || !isInteractive) {
      cy.visit('/');
    }
  });
});

Cypress.LocalStorage.clear = (keys, ls, rs) => {
  return;
};

Cypress.Commands.add('login', () => {
  const email = Cypress.env('email');
  const password = Cypress.env('password');
  signInPopup
    .getSignInForm()
    .find('[data-cy=sign-in-email]')
    .clear()
    .type(email);
  signInPopup
    .getSignInForm()
    .find('[data-cy=sign-in-password]')
    .clear()
    .type(password);
  signInPopup.getFormSignInBtn().click({force: true});
});

Cypress.Commands.add('logout', () => {
  signInPopup
    .getHeaderUserProfile()
    .find('[data-cy=header-arrowdown]')
    .realHover()
    .wait(500);
  signInPopup.getLogoutBtn().click({force: true});
});

// This can be used for login without UI elements and set localstorage
// This is for future reference
// Cypress.Commands.add('login', (username, password) => {
//   cy.request({
//     method: 'POST',
//     url: 'https://gps-v2.goeducate.com/qa/api/v2/login',
//     body: {
//       username: username,
//       password: password,
//     },
//   })
//     .its('body')
//     .then(body => {
//       localStorage.setItem('auth', JSON.stringify(body));
//     });
// });

// let LOCAL_STORAGE_MEMORY = {};
// Cypress.Commands.add('saveLocalStorageCache', () => {
//   Object.keys(localStorage).forEach(key => {
//     LOCAL_STORAGE_MEMORY[key] = localStorage[key];
//   });
// });

// Cypress.Commands.add('restoreLocalStorageCache', () => {
//   Object.keys(LOCAL_STORAGE_MEMORY).forEach(key => {
//     console.log('restored and set', key, LOCAL_STORAGE_MEMORY[key]);
//     localStorage.setItem(`${key}_new`, LOCAL_STORAGE_MEMORY[key]);
//   });
// });

// Cypress.Commands.add('clearLocalStorageCache', () => {
//   localStorage.clear();
//   LOCAL_STORAGE_MEMORY = {};
// });
