// ***********************************************************
// This example support/index.js is processed and
// loaded automatically before your test files.
//
// This is a great place to put global configuration and
// behavior that modifies Cypress.
//
// You can change the location of this file or turn off
// automatically serving support files with the
// 'supportFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/configuration
// ***********************************************************

//refrence links::
//https://www.bigbinary.com/learn-qa-automation-using-cypress/cypress-best-practices
//https://www.tutorialspoint.com/cypress/index.htm
//https://www.toolsqa.com/cypress-tutorial/

// Import commands.js using ES2015 syntax:
import 'cypress-dark';
import 'cypress-real-events/support';
import './commands';
// Alternatively you can use CommonJS syntax:
// require('./commands')

