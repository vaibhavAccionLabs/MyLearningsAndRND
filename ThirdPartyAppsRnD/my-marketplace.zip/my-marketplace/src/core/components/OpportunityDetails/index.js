import {Tag, Button} from 'antd';
import isArray from 'lodash/isArray';
import ReactPlayer from 'react-player/lazy';
import {capitalizeFirstLetter, numberInUSFormat} from 'core/utils';
import {
  heartPurpleBorder,
  greenHeart,
  whitetick,
  iconPlay,
} from 'assets/images';
import {RelatedPrograms} from 'core/components';
import './style.less';

const Overview = ({
  details = {},
  isMobileView,
  OpportunityApply,
  OpportunitySave,
  savedOpportunities,
  AppliedOpportunities,
}) => {
  const {
    opportunity_type,
    title,
    description,
    job_type,
    pay_type,
    range_from,
    range_to,
    range_frequency,
    location_type,
    skills = [],
    ed_level_deal_breaker,
    min_education_level,
    benefits = [],
    contact_name,
    email,
    city,
    state,
    opportunity_id,
    qualifying_programs = {},
    job_culture_media,
  } = details || {};

  const formatString = str => str?.replace(/[\W_]/g, ' ');

  const salaryValidation = () => {
    let isValid = false;
    if (
      (pay_type === 'range' && range_from && range_to) ||
      (pay_type === 'up_to' && range_to) ||
      ((pay_type === 'starting_at' || pay_type === 'exact_rate') && range_from)
    ) {
      isValid = true;
    }
    return isValid;
  };

  const getPayDetails = () => {
    let PayDetails = 'Salary:';
    if (salaryValidation() && pay_type) {
      const PAY_TYPE = pay_type.toLowerCase();
      if (PAY_TYPE === 'range') {
        PayDetails = PayDetails.substring(0, PayDetails.length - 1) + ' Range:';
      } else if (PAY_TYPE === 'starting_at' || PAY_TYPE === 'up_to') {
        PayDetails += ` ${capitalizeFirstLetter(formatString(pay_type))}`;
      }

      const Frequency = capitalizeFirstLetter(formatString(range_frequency));

      switch (PAY_TYPE) {
        case 'exact_rate':
        case 'starting_at': {
          PayDetails += ` $${numberInUSFormat(range_from)} ${Frequency}`;
          break;
        }
        case 'up_to': {
          PayDetails += ` $${numberInUSFormat(range_to)} ${Frequency}`;
          break;
        }
        default: {
          PayDetails += ` $${numberInUSFormat(
            range_from,
          )} - $${numberInUSFormat(range_to)} ${Frequency}`;
        }
      }
    } else {
      PayDetails += `: Not Available`;
    }
    return PayDetails;
  };

  const getLocation = () => {
    let location = '-';
    location = `${city}, ${state}`;
    return location_type && location_type.toLowerCase() === 'remote'
      ? location_type
      : location;
  };

  const opportunitySaved = () => {
    if (savedOpportunities && savedOpportunities.data) {
      const exists = savedOpportunities.data.filter(
        i => i.bp_opportunity_id === opportunity_id,
      );
      if (exists[0]) return true;
    }
    return false;
  };

  const opportunityApplied = () => {
    if (AppliedOpportunities && AppliedOpportunities.data) {
      const exists = AppliedOpportunities.data.filter(
        i => i.bp_opportunity_id === opportunity_id,
      );
      if (exists[0]) return true;
    }
    return false;
  };

  return (
    <div className='opportunity-overview justify-content-between contentContainer'>
      <div className='d-block'>
        <div className='d-flex  justify-content-between '>
          <div id='type'>
            <h3>Opportunity Type</h3>
            <p className='color-value capitalize'>{opportunity_type || '-'}</p>
          </div>
          <div className='d-flex justify-content-between'>
            <Actions
              applied={opportunityApplied()}
              saved={opportunitySaved()}
              OpportunityApply={OpportunityApply}
              OpportunitySave={OpportunitySave}
            />
          </div>
        </div>
        <div id='title'>
          <h3>Title</h3>
          <p className='color-value capitalize'>{title || '-'}</p>
        </div>
        <div id='location'>
          <h3>Location(s)</h3>
          <p className='capitalize'>{getLocation()}</p>
        </div>
        <div id='details'>
          <h3>Details</h3>
          <p className='capitalize'>
            {job_type ? formatString(job_type) : '-'}
          </p>
          <p>{getPayDetails()}</p>
        </div>
        <div id='description'>
          <h3>Full Job Description</h3>
          <div
            className='description'
            dangerouslySetInnerHTML={{__html: description}}
          />
        </div>
        <div id='culture'>
          <h3>Company Culture</h3>
          <div className='d-flex video-player-section justify-content-start '>
            {isArray(job_culture_media) && job_culture_media.length > 0 ? (
              job_culture_media.map((item, index) => (
                <ReactPlayer
                  key={index}
                  url={item}
                  className='video-player-local'
                  style={{backgroundColor: '#000', marginRight: '20px'}}
                  controls
                  muted
                  playing
                  light
                  width={320}
                  height={240}
                  playIcon={<img src={iconPlay} alt='play' />}
                />
              ))
            ) : (
              <span>No video available</span>
            )}
          </div>
        </div>
        <div className='skills'>
          <div className='header-with-color-label'>
            <h3>Skills</h3>
            <div className='color-label'>
              <div className='pink' />
              <h4 className='label'>Must Haves</h4>
            </div>
            <div className='color-label'>
              <div className='purple' />
              <h4 className='label'>Preferred</h4>
            </div>
          </div>
          <div className='skills-container'>
            {skills && isArray(skills) && skills.length > 0 ? (
              skills
                .sort((skill1, skill2) => (skill1.skills_deal_breaker ? -1 : 1))
                .map(
                  ({skills, skills_deal_breaker, min_year}, idx) =>
                    skills && (
                      <Tag
                        key={`skill - ${idx} `}
                        className={`skill-tag ${
                          skills_deal_breaker ? 'deal-breaker' : ''
                        } `}>
                        <span>{`${skills} (${min_year} ${
                          min_year == '1' ? 'yr' : 'yrs'
                        })`}</span>
                      </Tag>
                    ),
                )
            ) : (
              <p>Not Available</p>
            )}
          </div>
        </div>
        <div className='skills education'>
          <div className='header-with-color-label'>
            <h3>Education</h3>
            <div className='color-label'>
              <div className='pink' />
              <h4 className='label'>Must Haves</h4>
            </div>
            <div className='color-label'>
              <div className='blue' />
              <h4 className='label'>Preferred</h4>
            </div>
          </div>
          <div className='education-container'>
            {min_education_level ? (
              <Tag
                key='education'
                className={`education-tag ${
                  ed_level_deal_breaker ? 'deal-breaker' : ''
                } `}>
                <span>{min_education_level}</span>
              </Tag>
            ) : (
              <p>Not Available</p>
            )}
          </div>
        </div>
        <div id='benefits'>
          <h3>Benefits</h3>
          {benefits && isArray(benefits) && benefits.length > 0 ? (
            <ul className='benefits-container list_blueDot'>
              {benefits.map(
                (benefit, idx) =>
                  benefit && (
                    <li key={`benefit-${idx}`} className='benefit'>
                      <span className='capitalize'>
                        {formatString(benefit)}
                      </span>
                    </li>
                  ),
              )}
            </ul>
          ) : (
            <p>Not Available</p>
          )}
        </div>
        {(contact_name || email) && (
          <div id='contact'>
            <h3>Contact</h3>
            <div className='contacts-container'>
              {contact_name && (
                <p key='contact-name' className='color-value capitalize'>
                  <span>{contact_name || 'Name: Not Available'}</span>
                </p>
              )}
              {email && (
                <p key='contact-email' className='color-value'>
                  <span>{email || 'Email: Not Available'}</span>
                </p>
              )}
            </div>
          </div>
        )}

        <Actions
          applied={opportunityApplied()}
          saved={opportunitySaved()}
          OpportunityApply={OpportunityApply}
          OpportunitySave={OpportunitySave}
        />
        <div className='related-programs mt-4 contentContainer'>
          <h3>Pathways Related to {title}</h3>
          <RelatedPrograms
            data={qualifying_programs}
            isMobileView={isMobileView}
          />
        </div>
      </div>
    </div>
  );
};

const Actions = ({
  applied = false,
  saved = false,
  OpportunityApply,
  OpportunitySave,
}) => (
  <>
    <div className='job_opp_button'>
      {applied ? (
        <Button
          type='primary'
          style={{cursor: 'default'}}
          className='px-4 mr-2 d-inline-block green-btn'
          icon={<img src={whitetick} />}>
          Applied
        </Button>
      ) : (
        <Button type='primary' className='mr-2' onClick={OpportunityApply}>
          Apply
        </Button>
      )}
      {!applied &&
        (saved ? (
          <Button
            type='primary'
            shape='circle'
            style={{cursor: 'default'}}
            className='heartRating'
            icon={<img src={greenHeart} alt='heart' />}
          />
        ) : (
          <Button
            type='primary'
            shape='circle'
            className='heartRating save'
            icon={<img src={heartPurpleBorder} alt='heart' />}
            onClick={OpportunitySave}
          />
        ))}
    </div>
  </>
);

export default Overview;
