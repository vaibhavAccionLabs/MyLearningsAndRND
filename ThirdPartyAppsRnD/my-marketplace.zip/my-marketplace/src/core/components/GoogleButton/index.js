import {Button, message} from 'antd';
import GoogleLogin from 'react-google-login';
import {GoogleOutlined} from '@ant-design/icons';

import {GOOGLE_CLIENT_ID} from 'config';
import {signingInTexts} from 'data/auth';

const {error, success} = message;

const GoogleButton = () => {
  const responseGoogle = response => {
    console.log('RESPONSE::', response);
    if (response?.error) {
      error(response.error);
      return;
    }
    if (response) {
      console.log(response?.getBasicProfile());
    }
  };

  return (
    <GoogleLogin
      clientId={GOOGLE_CLIENT_ID}
      buttonText='Login With Google' //fallback
      render={renderProps => (
        <Button
          className='googleBtn'
          block
          icon={<GoogleOutlined />}
          onClick={renderProps.onClick}
          disabled={renderProps.disabled}
          data-cy='form-google-sign-in'>
          {signingInTexts.googleBtnTxt || ''}
        </Button>
      )}
      onSuccess={responseGoogle}
      onFailure={responseGoogle}
      cookiePolicy='single_host_origin'
    />
  );
};

export default GoogleButton;
