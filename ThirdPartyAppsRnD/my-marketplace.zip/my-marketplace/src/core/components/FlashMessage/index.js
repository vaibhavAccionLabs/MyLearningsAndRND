import style from './style.module.less';

function FlashMessage({message}) {
  return <div className={style.flash_message}>{message}</div>;
}

export default FlashMessage;
