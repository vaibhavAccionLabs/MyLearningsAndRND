import {AutoComplete, Input, Row, Col, Typography} from 'antd';
import {CloseOutlined, ClockCircleFilled} from '@ant-design/icons';

export default function SearchComponent({
  results,
  loading,
  onEnter,
  onSearch,
  onSelect,
  searchKey,
  placeholder,
  floatingHeader,
  globalSearchHistory,
  deleteGlobalSearchHistoryItem,
}) {
  const renderTitle = title => <span className='title-type'>{title}</span>;
  const renderItem = title => ({
    value: title,
    label: (
      <Row>
        <Col span={1}>
          <ClockCircleFilled className='history-icon' />
        </Col>
        <Col span={22}>
          <Typography.Paragraph ellipsis className='title-main' title={title}>
            {title}
          </Typography.Paragraph>
        </Col>
        <Col span={1}>
          <CloseOutlined
            onClick={event => deleteGlobalSearchHistoryItem(title, event)}
          />
        </Col>
      </Row>
    ),
  });
  const showSearchHistory =
    Array.isArray(globalSearchHistory) &&
    globalSearchHistory.length &&
    !searchKey;
  return (
    <div
      className={`d-block global-search text-center ${
        floatingHeader ? 'floating-global-search' : ''
      }`}
      data-cy='global-search'>
      <div className='path-search-grp careerSearch mt-1'>
        <AutoComplete
          className='s-auto-complete'
          maxLength={100}
          options={
            showSearchHistory
              ? [
                  {
                    label: renderTitle('Recent Searches'),
                    options: globalSearchHistory.map(text => renderItem(text)),
                  },
                ]
              : results
          }
          dropdownClassName='path-s-au-dropdown'
          onSelect={onSelect}
          onSearch={onSearch}>
          <Input.Search
            placeholder={placeholder || ''}
            onPressEnter={onEnter}
            onSearch={onEnter}
            loading={loading}
          />
        </AutoComplete>
      </div>
    </div>
  );
}
