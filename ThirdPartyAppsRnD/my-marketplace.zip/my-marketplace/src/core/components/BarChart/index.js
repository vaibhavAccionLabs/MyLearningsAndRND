import BarChart from './BarChart';
import MultiBarChart from './MultiBarChart';
export default BarChart;
export {MultiBarChart};
