import React from 'react';
import {Row, Col, Icon} from 'antd';
import {useDrag} from 'react-dnd';

import {isNumber} from 'core/utils';

const style = {
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
};

const MANDATORY_FIELDS = ['course_id', 'title', 'description', 'units'];

const CourseItem = ({
  //updateRequiredCourse,
  data = {},
  onClick,
  deleteCourse,
  courseIndex,
  stopDrag,
}) => {
  const checkAllRequiredInfo = () => {
    for (let i = 0; i < MANDATORY_FIELDS.length; i++) {
      const FIELD = MANDATORY_FIELDS[i];
      if (
        data[FIELD] === undefined ||
        data[FIELD] === '' ||
        data[FIELD] === null
      ) {
        if (isNumber(data[FIELD]) && data[FIELD] == 0) {
          continue;
        }
        return false;
      }
    }
    return true;
  };
  const [{isDragging}, drag] = useDrag({
    item: {data, type: 'COURSE_ITEM'},
    canDrag: () => {
      if (stopDrag) {
        return false;
      }
      return checkAllRequiredInfo();
    },
    end: (item, monitor) => {
      const dropResult = monitor.getDropResult();
    },
    collect: monitor => ({
      isDragging: monitor.isDragging(),
    }),
  });
  const isDragable = checkAllRequiredInfo();
  const opacity = isDragging ? 0.4 : 1;
  const cursor =
    (isDragable && (isDragging ? 'grabbing' : 'grab')) || 'pointer';

  return (
    <div
      ref={drag}
      style={{opacity, cursor}}
      onClick={() => !isDragable && onClick && onClick(data)}>
      <Row className='courseHeader courseItem'>
        <Col
          span={deleteCourse ? 18 : 20}
          style={{...style}}
          title={data && data.course_id}
          className='course-id'>
          {!isDragable && <span className='icon-icuparrow' />}
          {data && data.course_id}
        </Col>
        <Col span={4} className='course-units'>
          {(data && data.units) || '-'}
        </Col>
        {deleteCourse && (
          <Col span={2}>
            <Icon
              onClick={() => deleteCourse(courseIndex)}
              type='delete'
              style={{cursor: 'pointer'}}
            />
          </Col>
        )}
      </Row>
    </div>
  );
};
export default CourseItem;
