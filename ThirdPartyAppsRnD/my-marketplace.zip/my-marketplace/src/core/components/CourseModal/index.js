import {Button, Modal, Row, Col} from 'antd';

const CourseModal = ({visible, onModalClose, data}) => {
  const {
    course_id,
    description,
    units,
    course_instruction_type_1,
    num_of_hours_1,
    course_instruction_type_2,
    num_of_hours_2,
    transferable,
    skills_learned,
    pre_requisites,
    co_requisites,
    course_top_code,
    credit_status,
    learning_outcomes,
    course_notes,
    catalog_title,
  } = data || {};

  const InstituteName = data?.institution_name || data?.institute_name;
  const CourseName = data?.course_name || data?.title;

  return (
    <Modal
      title='Course Details'
      centered
      className='coursepopup'
      visible={visible}
      onOk={() => onModalClose(false)}
      onCancel={() => onModalClose(false)}
      footer={
        [
          // Not Required for the Production NOW, Will be used in future
          // <Button
          //   key='courseHub'
          //   type='primary'
          //   onClick={() => onModalClose(false)}>
          //   GO TO COURSE HUB
          // </Button>,
        ]
      }>
      {InstituteName && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>School :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {InstituteName || '-'}
          </Col>
        </Row>
      )}
      {course_id && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Course ID :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {course_id || '-'}
          </Col>
        </Row>
      )}
      {CourseName && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Course Title : </h5>
          </Col>
          <Col xs={16} sm={18}>
            {CourseName || '-'}
          </Col>
        </Row>
      )}
      {description && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Course Description :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {description || '-'}
          </Col>
        </Row>
      )}
      {units && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>No of Units : </h5>
          </Col>
          <Col xs={16} sm={18}>
            {units || '-'}
          </Col>
        </Row>
      )}
      {course_instruction_type_1 && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Course Instruction Type I :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {course_instruction_type_1 || '-'}
          </Col>
        </Row>
      )}
      {num_of_hours_1 && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>No of Hours I :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {num_of_hours_1 || '-'}
          </Col>
        </Row>
      )}
      {course_instruction_type_2 && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Course Instruction Type II :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {course_instruction_type_2 || '-'}
          </Col>
        </Row>
      )}
      {num_of_hours_2 && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>No of Hours II :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {num_of_hours_2 || '-'}
          </Col>
        </Row>
      )}
      {transferable && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Transfer Type:</h5>
          </Col>
          <Col xs={16} sm={18}>
            {transferable || '-'}
          </Col>
        </Row>
      )}
      {skills_learned?.length > 0 && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Skills Learned :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {skills_learned.toString() || '-'}
          </Col>
        </Row>
      )}
      {pre_requisites?.length > 0 && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Pre-requisite(s) :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {pre_requisites.toString() || '-'}
          </Col>
        </Row>
      )}
      {co_requisites?.length > 0 && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Co-requisite(s) :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {data.co_requisites.toString() || '-'}
          </Col>
        </Row>
      )}
      {course_top_code && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Course Top Code :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {course_top_code || '-'}
          </Col>
        </Row>
      )}
      {credit_status && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Credit Status :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {credit_status || '-'}
          </Col>
        </Row>
      )}
      {learning_outcomes && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Learning Outcomes :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {learning_outcomes || '-'}
          </Col>
        </Row>
      )}
      {course_notes && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Course Notes :</h5>
          </Col>
          <Col xs={16} sm={18}>
            {course_notes || '-'}
          </Col>
        </Row>
      )}
      {catalog_title && (
        <Row>
          <Col xs={8} sm={6} className='text-right pr-3'>
            <h5>Catalog Title : </h5>
          </Col>
          <Col xs={16} sm={18}>
            {catalog_title || '-'}
          </Col>
        </Row>
      )}
    </Modal>
  );
};

export default CourseModal;
