import React, {useEffect} from 'react';
import {getCardImgSet, getLogo} from 'core/utils';
import {ErrorBoundary} from 'core/components';

import {noPathwayBanner, noCollageLogo} from 'assets/images';

const LazyImage = ({
  imageType = 'card',
  renderSrcSet,
  type,
  src,
  className = '',
  defaultImage = noPathwayBanner,
  alt = 'banner',
  dataSrcSet,
  dataSrc,
  sizes = `(max-width: 480px) 240px, (max-width: 980px) 480px, 960px`,
}) => {
  useEffect(() => {
    document.addEventListener(
      'error',
      function (e) {
        if (e.target.nodeName == 'IMG') {
          e.target.src = defaultImage;
        }
      },
      true,
    );
    return () => {};
  }, [defaultImage]);

  if (imageType === 'card' && renderSrcSet) {
    const IMG = getCardImgSet(src, type);
    return (
      <ErrorBoundary nameOfComponent='core-lazyimage'>
        <img
          src={IMG?.defaultImage}
          //data-sizes='auto'
          data-src={IMG?.normalImage}
          alt={alt}
          className={`lazyload blur-up ${className}`}
          data-srcset={IMG?.srcSet}
          sizes={sizes}
          data-cy='card-image'
        />
      </ErrorBoundary>
    );
  }

  if (imageType === 'logo') {
    const IMG_SOURCE = getLogo(src);
    return (
      <ErrorBoundary nameOfComponent='core-lazyimage'>
        <img
          src={defaultImage || noCollageLogo}
          data-src={IMG_SOURCE}
          alt={alt || 'logo'}
          className={`lazyload blur-up ${className}`}
        />
      </ErrorBoundary>
    );
  }

  if (dataSrcSet && sizes) {
    return (
      <ErrorBoundary nameOfComponent='core-lazyimage'>
        <img
          src={src}
          // data-sizes='auto'
          data-src={dataSrc}
          alt={alt}
          className={`lazyload blur-up ${className}`}
          data-srcset={dataSrcSet}
          sizes={sizes}
        />
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary nameOfComponent='core-lazyimage'>
      <img
        src={defaultImage}
        data-src={src}
        alt={alt}
        className={`lazyload blur-up ${className}`}
      />
    </ErrorBoundary>
  );
};

export default LazyImage;
