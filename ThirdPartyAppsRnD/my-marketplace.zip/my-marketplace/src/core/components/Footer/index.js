import {Fragment} from 'react';
import {connect} from 'react-redux';
import {Link} from 'react-router-dom';
import {Row, Col, Button, Typography} from 'antd';
import jp from 'jsonpath';
import {isObject, isArray, isEmpty} from 'lodash';

import {
  CORPORATE_DOMAIN,
  FooterLinks,
  FooterSocialLinks,
  FooterMenu,
} from 'config';

import {useAuth} from 'core/hooks';
import {getLogo, combineMenuLinksToOneBlock} from 'core/utils';
import {ErrorBoundary} from 'core/components';

import {openLoginScreen} from 'redux/modules/auth';

import {pdflogo, goEducateLogo} from 'assets/images';
import {
  primaryText,
  stayConnectedText,
  poweredByText,
  copyrightText,
  navigationMenus,
  footerMenuTexts,
} from 'data/footer';
import './style.less';

const FooterColumns = ({title, children}) => (
  <Col lg={6} xs={24} sm={24} md={12}>
    <Typography.Title level={5} data-cy='footer-resources'>
      {title}
    </Typography.Title>
    <ul className='footerLink' data-cy='footer-resources-links'>
      {children}
    </ul>
  </Col>
);

const FooterLists = ({
  name,
  target,
  link,
  mediaIcons,
  checkAuth,
  handleRedirect,
}) => {
  if (mediaIcons) {
    return (
      <li>
        {mediaIcons?.map(({name: _name, link, target: _target, mediaIcon}) => (
          <Button href={link} key={`footer-list-icon${_name}`} target={_target}>
            <img src={mediaIcon} alt={_name} />
          </Button>
        ))}
      </li>
    );
  }
  return (
    <li>
      {link && checkAuth ? (
        <Button
          onClick={() => handleRedirect(link, target, checkAuth)}
          href={!checkAuth ? link : null}
          target={!checkAuth ? target : null}>
          {name}
        </Button>
      ) : link ? (
        <Link to={link} className='ant-btn'>
          <span>{name}</span>
        </Link>
      ) : (
        <span>{name}</span>
      )}
    </li>
  );
};
const menuLength = FooterMenu?.length - 1 || 0;
const separator = ' | ';

const Footer = props => {
  const [token] = useAuth();
  const {openLoginScreen, data} = props;
  const redirect = (path, target) => window.open(path, target);
  const pathNavigateTo = (path, target, checkAuth) => {
    if (checkAuth) {
      token
        ? redirect(path, target)
        : openLoginScreen({
            callback: () => redirect(path, target),
          });
      return;
    }
    redirect(path, target);
  };

  let footerLogoSrc = goEducateLogo,
    address = '';

  // Override based on instance
  if (data?.institution_id) {
    footerLogoSrc = getLogo(data.logo_cloudinary);

    const addressArr =
      data?.physical_address &&
      isObject(data.physical_address) &&
      !isEmpty(data.physical_address) &&
      jp.query(data, '$.physical_address.*').filter(val => val !== null);

    address =
      addressArr &&
      isArray(addressArr) &&
      !isEmpty(addressArr) &&
      `${addressArr.slice(0, -1).join(', ')}, ${
        addressArr[addressArr.length - 1]
      }`;
  }

  let MenuItemsDisplay = combineMenuLinksToOneBlock(FooterLinks);

  return (
    <ErrorBoundary nameOfComponent='core-footer'>
      <footer>
        <div className='footerContainer'>
          <Row justify='space-between'>
            <Col xs={24} sm={24} md={12} lg={10}>
              <img
                src={footerLogoSrc}
                alt='footer logo'
                className={`img-fluid footerLogo ${
                  data?.institution_id ? '' : 'goEducate_Logo'
                }`}
              />
              {!data?.institution_id ? (
                <>
                  <p
                    className={'footer__description-text mt-2 mb-4'}
                    data-cy='footer-description'>
                    {primaryText || ''}
                  </p>
                  <p
                    className={'footer__connect-text'}
                    data-cy='footer-connect-text'>
                    {stayConnectedText || ''}
                  </p>
                  <ul
                    className='footerLink webScreen d-flex mb-2'
                    data-cy='media-icons'>
                    {FooterSocialLinks?.map(
                      ({name, link, target, mediaIcon}) => (
                        <li key={`footer-social-link${name}`}>
                          <Button href={link} target={target}>
                            <img src={mediaIcon} alt={name} />
                          </Button>
                        </li>
                      ),
                    )}
                  </ul>
                </>
              ) : (
                <>
                  <p className={'footer__description-text'}>{address || ''}</p>
                  <a
                    className='footer__description-text'
                    target='_blank'
                    rel='noopener noreferrer'
                    href={data?.web_url}>
                    {data?.web_url || ''}
                  </a>
                  <p className='footer__description-text pwd'>
                    {poweredByText || ''}
                    <img
                      src={pdflogo}
                      alt='footerlogosml'
                      className='poweredLogo'
                    />
                  </p>
                </>
              )}
            </Col>
            {MenuItemsDisplay?.map(({links, key: navKey}) => {
              const {[navKey]: {title = '', ...rest} = {}} =
                navigationMenus || {};
              return (
                title?.toLowerCase() === 'resources' && (
                  <FooterColumns title={title} key={`footer-list-${title}`}>
                    {links.map(({key, mediaIcons, target, link, checkAuth}) => {
                      const {[key]: {name} = {}} = rest || {};
                      return (
                        <FooterLists
                          key={`footer-list-${title}-${name}`}
                          instanceData={data}
                          name={name}
                          target={target}
                          checkAuth={checkAuth}
                          link={link}
                          mediaIcons={mediaIcons}
                          handleRedirect={pathNavigateTo}
                        />
                      );
                    })}
                  </FooterColumns>
                )
              );
            })}
          </Row>
          <Row className='soc_mobScreen'>
            <p className={'footer__connect-textmobile'}>
              {stayConnectedText || ''}
            </p>
            <ul className='footerLink  d-flex mb-2'>
              {FooterSocialLinks?.map(({name, link, target, mediaIcon}) => (
                <li key={`footer-social-link${name}`}>
                  <Button href={link} target={target}>
                    <img src={mediaIcon} alt={name} />
                  </Button>
                </li>
              ))}
            </ul>
          </Row>
          <Row>
            <p className='footer__copyright-txt' data-cy='footer-copyright'>
              {copyrightText && `${copyrightText + separator}`}
              {FooterMenu?.map(({path, target, key}, idx) => {
                const {[key]: {secondaryName = ''} = {}} =
                  footerMenuTexts || {};
                return (
                  idx > 1 && (
                    <Fragment key={`__${secondaryName}__`}>
                      {path ? (
                        <Link to={path}>{secondaryName}</Link>
                      ) : (
                        <span>{secondaryName}</span>
                      )}
                      {idx < menuLength && separator}
                    </Fragment>
                  )
                );
              })}
            </p>
          </Row>
        </div>
      </footer>
    </ErrorBoundary>
  );
};

const mapStateToProps = () => ({});

export default connect(mapStateToProps, {openLoginScreen})(Footer);
