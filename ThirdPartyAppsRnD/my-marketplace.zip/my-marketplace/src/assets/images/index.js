import pdflogo from './logo_GoEducate.svg';
import logo from './logo_Goeducatewhite.svg';
import pdfaward from './award.png';
import pdfarrow from './arrow.png';
import icontrophy from './trophy.svg';
import iconarrowPointer from './arrow.png';
import iconPlay from './icons/videoicon.svg';
import breadcrumbArrow from './icons/breadcrumbarrow.svg';
import emailSuccess from './icons/greentick_success.svg';

const BASE_URL =
  'https://res.cloudinary.com/goeducate-inc/image/upload/q_auto/gps-graphics';

const textloading = `${BASE_URL}/text_loading_lro0pg.gif`;
const avatar = `${BASE_URL}/avatarwhite_hoy93g.png`;
const avatarGray = `${BASE_URL}/avatarblack_tcinoc.png`;
const defaultbannerjob = `${BASE_URL}/banner/defaultbannerjob_mtukkl.jpg`;

const iconbellGray = `${BASE_URL}/icons/notificationbellblackgrey_omsf35.svg`;
const iconbellWhite = `${BASE_URL}/icons/notificationbell_midasx.svg`;
const iconremove = `${BASE_URL}/icons/icon_remove_osm5vj.svg`;
const iconmail = `${BASE_URL}/icons/mailicon_ixuhrn.svg`;
const iconplus = `${BASE_URL}/icons/icon_plus_jlgkpv.svg`;
const explorePathSearch = `${BASE_URL}/icons/explorepathicon_bttj9o.svg`;

const heartPurpleBorder = `${BASE_URL}/icons/heartpurpleborder_fnjirz.svg`;
const heartWhite = `${BASE_URL}/icons/heartwhite_l0fpoo.svg`;
const searchPurple = `${BASE_URL}/icons/searchpurple_czfywo.svg`;
const arrowdown = `${BASE_URL}/icons/whitearrow_zeb9nc.svg`;
const skillCertify = `${BASE_URL}/icons/certificatetickicon_qfufkb.svg`;
const blueStar = `${BASE_URL}/icons/bluestar_od8wll.svg`;
const awardtype = `${BASE_URL}/icons/awardtypeicon_rqdghf.svg`;
const awardTypeWhite = `${BASE_URL}/icons/awardwhiteicon_qfx9vr.svg`;
const locationBlue = `${BASE_URL}/locationblueico_d7ztcr.svg`;

const defaultoccupation = `${BASE_URL}/occupationdefaultimg_vvro4e.jpg`;
const greenHeart = `${BASE_URL}/icons/greenheart_usza3k.svg`;
const editpurple = `${BASE_URL}/icons/editpurple_rkziek.svg`;
const arrowpurple = `${BASE_URL}/icons/arrowpurple_ypgdba.svg`;

const compare_pathIcon = `${BASE_URL}/icons/compare_dash_pfxniu.svg`;
const photoCam = `${BASE_URL}/icons/photoicon_iyhpfj.svg`;
const deleteIcon = `${BASE_URL}/icons/deleteicond_battxh.svg`;
const whitetick = `${BASE_URL}/icons/whitetick_gjwybe.svg`;
const clockgrey = `${BASE_URL}/icons/clockgrey_yz2pbx.svg`;

const mobileIcon = `${BASE_URL}/icons/mobileicon_qkozvo.svg`;
const successTick = `${BASE_URL}/icons/successtick_xjwolo.svg`;
const warningIcon = `${BASE_URL}/icons/warningicon_kpgjsn.svg`;
const maplocation = `${BASE_URL}/icons/locationgrey_okew9a.svg`;

const noCollageLogo = `${BASE_URL}/defaultlogoimage_jn0gk9.svg`;
const noPathwayBanner = `${BASE_URL}/no_pathway_banner_siitlk.jpg`;
const noSearchResults = `${BASE_URL}/icons/nosearchicon_gc9vgt.svg`;
const noEvents = `${BASE_URL}/icons/noevents_lajdmj.svg`;
const noSurveyIcon = `${BASE_URL}/icons/nosurveyicon_tmrryo.svg`;
const noBpIcon = `${BASE_URL}/icons/nooccupationicon_i8mdse.svg`;

const carrerOneStop = `${BASE_URL}/career-stop_j1unmj.png`;
const brightIcon = `${BASE_URL}/icons/bright_sun_med_amu8fs.png`;
const avgIcon = `${BASE_URL}/icons/avg_small_v21dn2.png`;
const belowIcon = `${BASE_URL}/icons/below_small_p06ooq.png`;
const hotTechnology = `${BASE_URL}/icons/hotTechnology_fdzrfq.svg`;
const onetinit = `${BASE_URL}/icons/onet-in-it_nfsfuy.svg`;
const outlookbright = `${BASE_URL}/icons/outlook_bright_huge_npdple.png`;
const outlookaverage = `${BASE_URL}/icons/outlook_avg_huge_ryumu8.png`;
const outlookbelow = `${BASE_URL}/icons/outlook_below_huge_gsejya.png`;
const statemap = `${BASE_URL}/icons/statemap_h8jte2.svg`;
const localsalaryinfo = `${BASE_URL}/icons/localsalaryinfo_rpgifm.svg`;
const haticon = `${BASE_URL}/icons/haticon_vqimwg.svg`;
const salarychart = `${BASE_URL}/salary_chart_ftv1oq.png`;
const defaultbannerprofile = `${BASE_URL}/defaultbannerprofile_bsuyvy.jpg`;

const carouselLeftArrow = `${BASE_URL}/icons/arrowleft_w0grga.svg`;
const carouselRightArrow = `${BASE_URL}/icons/arrowright_zv59ya.svg`;

const dash_home = `${BASE_URL}/icons/homegrey_hoxekv.svg`;
const dash_profile = `${BASE_URL}/icons/profilegrey_nnvpl4.svg`;
const dash_education = `${BASE_URL}/icons/educationgrey_xbyaid.svg`;
const dash_workforce = `${BASE_URL}/icons/workforcegrey_oqyma8.svg`;
const dash_skill = `${BASE_URL}/icons/skillsgrey_un1pcb.svg`;
const dash_event = `${BASE_URL}/icons/eventsgrey_at83k7.svg`;

const facebook = `${BASE_URL}/icons/facebook_a7gfpm.svg`;
const instagram = `${BASE_URL}/icons/instagram_mdvl3g.svg`;
const black_instagram = `${BASE_URL}/icons/insta_logo_black_q1wwc2.svg`;
const color_instagram = `${BASE_URL}/icons/insta__logo_color_kczxcz.svg`;
const black_medium = `${BASE_URL}/icons/medium_black_ihauug.svg`;
const color_medium = `${BASE_URL}/icons/medium_color_pktbyd.svg`;
const black_tiktok = `${BASE_URL}/icons/tiktok_black_npgxow.svg`;
const color_tiktok = `${BASE_URL}/icons/tiktok_color_ic1tgv.svg`;
const linkedin = `${BASE_URL}/icons/linkedin_rnchgt.svg`;
const white_facebook = `${BASE_URL}/icons/Facebookwhite_qwlfn4.svg`;
const white_twitter = `${BASE_URL}/icons/twitterwhite_c60onw.svg`;
const white_linkedin = `${BASE_URL}/icons/LinkedInwhite_epbzmp.svg`;
const goEducateLogoWhite = `${BASE_URL}/logo_Goeducatewhite_v9xu3k.svg`;
const goEducateLogo = `${BASE_URL}/goeducatelogo_orignal_k3rxvx.svg`;
const resourceCard1 = `${BASE_URL}/banner/resource1image_h0059g.jpg`;
const resourceCard2 = `${BASE_URL}/banner/h_discover_interests_ji1rgj.svg`;
const resourceCardStudentExplore = `${BASE_URL}/banner/h_job_seeker_k690l7.svg`;
const resourceCardJobSeeker = `${BASE_URL}/banner/h_student_zwbhfl.svg`;
const resourceCardBuildProfile = `${BASE_URL}/banner/h_marketable_profile_x5eqq3.svg`;
const resourceCardSearchevents = `${BASE_URL}/banner/h_search_events_yqw9wf.svg`;
const resourceCardCareer = `${BASE_URL}/banner/h_checkout_careers_ob0hzi.svg`;
const resourceCardLocalJobOpp = `${BASE_URL}/banner/h_find_open_jobs_l6wrvp.svg`;
const resourceCardExplorePrograms = `${BASE_URL}/banner/h_explore_programs_cpohux.svg`;
const studentBanner = `${BASE_URL}/banner/student_banner_xbyzda.jpg`;
const studentthumb1 = `${BASE_URL}/banner/makeprofile_m90yu7.png`;
const studentthumb2 = `${BASE_URL}/banner/findintern_ztilef.jpg`;
const studentthumb3 = `${BASE_URL}/banner/tellpeople_nsgcdh.jpg`;
const semiCircle = `${BASE_URL}/semicircles_u7u3kd.png`;
const survey1 = `${BASE_URL}/banner/survey_1_wuexor.jpg`;
const survey2 = `${BASE_URL}/banner/survey_2_ewueru.jpg`;
const survey3 = `${BASE_URL}/banner/survey_3_l6kbbh.jpg`;
const surveyBig = `${BASE_URL}/banner/survey_big_govg5t.jpg`;
const surveyCircle = `${BASE_URL}/banner/survey_small_circle_hu5kdk.svg`;
const defaultEvent = `${BASE_URL}/defaulteventimage_qdqytk.jpg`;
const instanceerroricon = `${BASE_URL}/icons/erroricon_pxquqy.svg`;
const resourceCardPartner = `${BASE_URL}/banner/i_am_a_partner_lph4lr.svg`;
const resourceCardEmployerPartner = `${BASE_URL}/banner/employer_partner_pvl7wa.svg`;
const resourceCardEducationPartner = `${BASE_URL}/banner/Education_PARTNER_j4ooqf.svg`;
const resourceBannerFutureWorkforce = `${BASE_URL}/banner/employerpartnerbanner_lkvglx.jpg`;
const resourceBannerEducationPartner = `${BASE_URL}/banner/partner_banner_vzfjqp.jpg`;
const clusterBanner = `${BASE_URL}/banner/pathway_default_banner_rspazn.jpg`;

export {
  avgIcon,
  belowIcon,
  pdflogo,
  goEducateLogo,
  goEducateLogoWhite,
  pdfaward,
  pdfarrow,
  logo,
  resourceCard1,
  resourceCard2,
  facebook,
  instagram,
  linkedin,
  arrowdown,
  skillCertify,
  blueStar,
  awardtype,
  awardTypeWhite,
  locationBlue,
  noSearchResults,
  noPathwayBanner,
  noCollageLogo,
  iconbellGray,
  iconbellWhite,
  iconmail,
  icontrophy,
  iconarrowPointer,
  iconremove,
  iconplus,
  iconPlay,
  explorePathSearch,
  brightIcon,
  defaultbannerprofile,
  outlookbright,
  outlookaverage,
  outlookbelow,
  hotTechnology,
  onetinit,
  statemap,
  localsalaryinfo,
  haticon,
  salarychart,
  avatar,
  avatarGray,
  defaultbannerjob,
  successTick,
  warningIcon,
  maplocation,
  carrerOneStop,
  dash_profile,
  dash_home,
  dash_education,
  dash_workforce,
  dash_event,
  dash_skill,
  white_facebook,
  white_twitter,
  white_linkedin,
  editpurple,
  arrowpurple,
  defaultoccupation,
  textloading,
  compare_pathIcon,
  photoCam,
  deleteIcon,
  studentBanner,
  studentthumb1,
  studentthumb2,
  studentthumb3,
  semiCircle,
  whitetick,
  instanceerroricon,
  searchPurple,
  heartPurpleBorder,
  heartWhite,
  resourceCardCareer,
  resourceCardLocalJobOpp,
  resourceCardStudentExplore,
  resourceCardExplorePrograms,
  resourceCardJobSeeker,
  resourceCardBuildProfile,
  resourceCardSearchevents,
  surveyBig,
  survey1,
  survey2,
  survey3,
  surveyCircle,
  clockgrey,
  defaultEvent,
  mobileIcon,
  noEvents,
  noSurveyIcon,
  noBpIcon,
  greenHeart,
  resourceCardPartner,
  resourceCardEmployerPartner,
  resourceCardEducationPartner,
  resourceBannerFutureWorkforce,
  resourceBannerEducationPartner,
  carouselLeftArrow,
  carouselRightArrow,
  color_instagram,
  color_medium,
  color_tiktok,
  black_instagram,
  black_medium,
  black_tiktok,
  clusterBanner,
  breadcrumbArrow,
  emailSuccess,
};
