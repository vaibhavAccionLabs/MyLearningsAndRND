// Get All mdoules here for AppRoutes Linking
import {
  Home,
  Search,
  Pathways,
  //ComparePaths,
  Occupation,
  Programs,
  JobOpportunites,
  BusinessPartners,
  LocalSalary,
  Jobs,
  Settings,
  Dashboard,
  Profile,
  ProfilePreview,
  Education,
  Skills,
  Workforce,
  MyEvents,
  ResetPassword,
  StudentProfile,
  Directory,
  PathsList,
  CareerDestination,
  Events,
  Survey,
  MySurvey,
  SurveyHome,
  BecomeAPartner,
  PartnerDetails,
  PartnersList,
  TermsOfUse,
  PrivacyPolicy,
  Verify,
} from 'app/modules';

import {
  facebook,
  instagram,
  linkedin,
  dash_home,
  dash_profile,
  dash_education,
  dash_workforce,
  dash_event,
  dash_skill,
  resourceCardCareer,
  resourceCardLocalJobOpp,
  resourceCardStudentExplore,
  resourceCardExplorePrograms,
  resourceCardJobSeeker,
  resourceCardBuildProfile,
  resourceCardSearchevents,
  resourceCard2,
  resourceCardPartner,
  resourceCardEmployerPartner,
  resourceCardEducationPartner,
} from 'assets/images';

//Environment Configurations
const SRM = process.env.REACT_APP_SRM;
const GPS = process.env.REACT_APP_GPS;
const CDN = process.env.REACT_APP_CDN;
const DOMAIN = process.env.REACT_APP_DOMAIN;
export const SUPPORT_MAIL = process.env.REACT_APP_SUPPORT_MAIL;
const CLOUDINARY_API = process.env.REACT_APP_CLOUDINARY_API;
export const CORPORATE_DOMAIN = process.env.REACT_APP_CORPORATE_DOMAIN;
export const HELP_WIDGET_ID = process.env.REACT_APP_HELP_WIDGET_ID;
export const UPLOAD_PRESET = process.env.REACT_APP_UPLOAD_PRESET;
export const GTAG_ID = process.env.REACT_APP_GTAG_ID;
export const IMG_CLOUDINARY =
  process.env.REACT_APP_CLOUDINARY_API_GET + 'image/upload';
export const CAREER_ONE_STOP_IMAGE_BASE_PATH =
  'https://cdn.careeronestop.org/OccVids/OccupationVideos/';

export const JSON_HEADER = {'Content-Type': 'application/json'};
export const JWT_HEADER = token => ({Authorization: `Bearer ${token}`});
export const GOOGLE_CLIENT_ID = process.env.REACT_APP_GOOGLE_CLIENT_ID;
export const DEFAULT_PAGE_SIZE = 12;

export const API = {
  srm: {
    acheivement_options: `${SRM}/gps/acheivement-options/`,
    compare_path: `${GPS}/v2/compare_path/`,
    courses: `${SRM}/gps/courses/`,
    clusters: `${SRM}/gps/cluster-v2/`,
    gened_options: `${SRM}/gps/gened/`,
    institute: `${SRM}/gps/institute/`,
    job_zone_details: `${SRM}/gps/job_zone_details/`,
    job_boards: `${SRM}/gps/career_one_stop`,
    local_jobs: `${SRM}/gps/business-partner/jobs/`,
    applied_jobs: `${SRM}/business_partner/jobs/`,
    occupations: `${SRM}/gps/occupation/`,
    occupation_roles: `${SRM}/gps/occupation-roles/`,
    occupation_subscribe: `${SRM}/subscribe/`,
    onboarding_path: `${SRM}/gps/onboarding-path`,
    onboarding_type: `${SRM}/onboarding-type`,
    pathways: `${SRM}/gps/pathways-v2/`,
    pathway_details: `${SRM}/gps/publish-v1/`,
    pathway_planner: `${SRM}/pathway-planner/`,
    program: `${SRM}/gps/program/`,
    program_duration: `${SRM}/gps/program-duration/`,
    programs: `${SRM}/gps/business-partner/program`,
    opportunity: `${SRM}/gps/business-partner/opportunity/`,
    search_path_occupation: `${SRM}/gps/search_path_occupation/`,
    program_of_study_list: `${SRM}/gps/pos-path`,
    skills: `${SRM}/gps/skills/`,
    student_survey: `${SRM}/student-survey/`,
    signed_programs: `${SRM}/business_partner/program/sign-up`,
    license: `${SRM}/gps/license/`,
    occupation_rank: `${SRM}/gps/occupation-rank`,
    programs_by_career: `${SRM}/gps/cluster-v2`,
    upcoming_events: `${SRM}/gps/outreach/v1/event-detail`,
    my_signedup_events: `${SRM}/gps/outreach/v1/student-signedup-event-detail`,
    event_signup: `${SRM}/outreach/v1/event_signup`,
    business_partners: `${SRM}/gps/gps-partner`,
    become_business_partner: `${SRM}/gps/institute_request`,
    global_search: `${SRM}/gps/global_suggest`,
  },
  gps: {
    awards_leadership: `${GPS}/v2/awards_leadership`,
    citizenship: `${GPS}/citizenship/`,
    confirm_forgot_password: `${GPS}/v2/confirm_forgot_password`,
    compare_paths: `${GPS}/v2/compare_path`,
    ethnicity: `${GPS}/race_ethnicity/`,
    education: `${GPS}/v2/education`,
    forgot_password: `${GPS}/v2/forgot_password`,
    login: `${GPS}/v2/login`,
    native_language: `${GPS}/nativelanguage/`,
    refresh_token: `${GPS}/v2/refresh_token/`,
    reset_password: `${GPS}/v2/reset_password/`,
    signup: `${GPS}/v2/signup`,
    confirm_user_account: `${GPS}/v2/confirm_user_account/`,
    states: `${GPS}/state`,
    student_onboard: `${GPS}/v2/student_onboard`,
    student_profile: `${GPS}/v2/student_profile`,
    share_student_profile: `${GPS}/v2/share_student_profile`,
    student_details: `${GPS}/v2/student_details`,
    student_seeking: `${GPS}/student_seeking`,
    student_skills: `${GPS}/v2/student_skill`,
    student_award_type: `${GPS}/student_award_type`,
    assessment_questions: `${GPS}/assessment_questions/`,
    student_cis: `${GPS}/v2/student_cis`,
    save_path: `${GPS}/v2/save_path`,
    volunteer_experience: `${GPS}/v2/volunteer_experience`,
    work_experience: `${GPS}/v2/work_experience`,
    image_upload: `${CLOUDINARY_API}image/upload`,
    opportunity: `${GPS}/v2/bp_opportunity_apply/`,
    public_insight_jobs: `${GPS}/v2/public_insight_jobs/`,
  },
};

export const AppRoutes = [
  {
    key: 'home',
    path: '/',
    component: Home,
    exact: true,
  },
  {
    key: 'reset-password',
    path: '/reset-password',
    component: ResetPassword,
    exact: true,
  },
  {
    key: 'verify',
    path: '/verify',
    component: Verify,
    exact: true,
  },
  {
    key: 'search',
    path: '/search',
    component: Search,
    exact: false,
  },
  // {
  //   key: 'compare',
  //   path: '/compare-paths',
  //   component: ComparePaths,
  //   exact: false,
  // },
  {
    key: 'pathway',
    path: '/pathway/:collegeName/:pathName/:awardType/:programUuid',
    component: Pathways,
    exact: false,
  },
  {
    key: 'occupation',
    path: '/occupation',
    component: Occupation,
    exact: false,
  },
  {
    key: 'programs',
    path: '/programs/:programId/:institutionName?',
    component: Programs,
    exact: false,
  },
  {
    key: 'job-opportunities',
    path: '/job-opportunities',
    component: JobOpportunites,
    exact: false,
  },
  {
    key: 'check-out-careers',
    path: '/occupations',
    component: CareerDestination,
    exact: false,
  },
  {
    key: 'local-salary',
    path: '/local-salary',
    component: LocalSalary,
    exact: false,
  },
  {
    key: 'jobs',
    path: '/job/:jobType/:jobId/:institutionName?',
    component: Jobs,
    exact: false,
  },
  {
    key: 'student-profile',
    path: '/build/student-profile',
    component: StudentProfile,
    exact: false,
  },
  {
    key: 'events',
    path: '/events',
    component: Events,
    exact: false,
  },
  {
    key: 'business-partners',
    path: '/business-partners',
    component: BusinessPartners,
    exact: false,
    subModules: [
      {
        key: 'business-partners-list',
        path: '/',
        component: PartnersList,
        exact: true,
        label: 'Discover Career Interests',
      },
      {
        key: 'become-a-business-partner',
        path: '/apply',
        component: BecomeAPartner,
        exact: true,
        label: 'Become an Employer Partner',
      },
      {
        key: 'business-partner-details',
        path: '/:bpName',
        component: PartnerDetails,
        exact: true,
        label: 'Discover Career Interests',
      },
    ],
  },
  {
    key: 'survey',
    path: '/survey',
    component: Survey,
    exact: false,
    subModules: [
      {
        key: 'my-survey-home',
        path: '/',
        component: SurveyHome,
        exact: true,
        label: 'Discover Career Interests',
      },
      {
        key: 'my-survey',
        path: '/my-survey',
        component: MySurvey,
        protected: true,
        exact: true,
        label: 'Discover Career Interests',
      },
    ],
  },
  {
    key: 'settings',
    path: '/settings',
    component: Settings,
    exact: false,
    protected: true,
    subModules: [
      {
        key: 'dashboard',
        path: '/dashboard',
        component: Dashboard,
        exact: true,
        label: 'My Dashboard',
        icon: dash_home,
      },
      {
        key: 'profile',
        path: '/profile',
        component: Profile,
        exact: true,
        label: 'My Profile',
        icon: dash_profile,
      },
      {
        key: 'education',
        path: '/education',
        component: Education,
        exact: true,
        label: 'My Education',
        icon: dash_education,
      },
      {
        key: 'skills',
        path: '/skills',
        component: Skills,
        exact: true,
        label: 'My Skills',
        icon: dash_skill,
      },
      {
        key: 'workforce',
        path: '/workforce',
        component: Workforce,
        exact: true,
        label: 'My Workforce',
        icon: dash_workforce,
      },
      {
        key: 'events',
        path: '/events',
        component: MyEvents,
        exact: true,
        label: 'My Events',
        icon: dash_event,
      },
      {
        key: 'preview',
        path: '/profile/preview',
        component: ProfilePreview,
        protected: true,
        exact: true,
      },
    ],
  },
  {
    key: 'profilePreview',
    path: '/profile/preview/:userName',
    component: ProfilePreview,
    exact: true,
  },
  {
    key: 'directory',
    path: '/directory',
    component: Directory,
    exact: false,
    subModules: [
      {
        key: 'paths-list',
        path: '/paths-list',
        component: PathsList,
        exact: true,
        label: 'Explore Career Pathways',
      },
    ],
  },
  {
    key: 'terms-of-use',
    path: '/terms-of-use',
    component: TermsOfUse,
    exact: true,
  },
  {
    key: 'privacy-policy',
    path: '/privacy-policy',
    component: PrivacyPolicy,
    exact: true,
  },
];

export const HeaderMenu = [
  {
    key: 'DASHBOARD',
    to: '/settings',
  },
  {
    key: 'LOGOUT',
  },
];

export const FooterMenu = [
  {
    key: 'ABOUT_US',
    path: DOMAIN,
    target: '_blank',
  },
  {
    key: 'CONTACT_US',
    path: `mailto:${SUPPORT_MAIL}`,
    target: '_self',
  },
  {
    key: 'ADDRESS',
  },
  {
    key: 'TERMS',
    path: `/terms-of-use`,
    target: '_blank',
  },
  {
    key: 'PRIVACY',
    path: `/privacy-policy`,
    target: '_blank',
  },
];

export const FooterSocialLinks = [
  {
    mediaIcon: linkedin,
    name: 'linkedin',
    link: 'https://www.linkedin.com/company/goeducate/',
    target: '_blank',
  },
  {
    mediaIcon: instagram,
    name: 'instagram',
    link: 'https://www.instagram.com/goeducateinc/',
    target: '_blank',
  },
  {
    mediaIcon: facebook,
    name: 'facebook',
    link: 'https://www.facebook.com/GoEducate-Inc-130365025434596',
    target: '_blank',
  },
];

export const MainMenu = [
  {
    key: 'explore_programs',
    path: '/',
    label: 'Explore Programs',
  },
  {
    key: 'discover_careers',
    path: '/occupations',
    label: 'Discover Careers',
  },
  {
    key: 'find_opportunites',
    path: '/business-partners?type=local_jobs',
    label: 'Find Opportunities',
  },
  {
    key: 'search_events',
    path: '/events',
    label: 'Search Events',
  },
];
export const FooterLinks = [
  {
    key: 'RESOURCES',
    links: [
      {
        key: 'EXPLORE_PROGRAMS',
        link: '/',
        target: '_blank',
      },
      {
        key: 'DISCOVER_INTERESTS',
        link: '/survey',
        target: '_blank',
      },
      {
        key: 'MARKETABLE_PROFILE',
        link: '/build/student-profile',
        target: '_blank',
      },
      {
        key: 'SEARCH_EVENTS',
        link: '/events',
        target: '_blank',
      },
      {
        key: 'CAREERS',
        link: '/occupations',
        target: '_blank',
      },
      {
        key: 'FIND_OPPORTUNITIES',
        link: '/business-partners?type=local_jobs',
        target: '_blank',
      },
      {
        key: 'ABOUT',
        link: CORPORATE_DOMAIN,
        target: '_blank',
        anchor: true,
      },
    ],
  },
  {
    key: 'BECOMEAPARTNER',
    links: [
      {
        key: 'EMPLOYER_PARTNER',
        link: '/business-partners/apply?partnerType=employer',
        target: '_blank',
        display: true,
      },
      {
        key: 'EDUCATION_PARTNER',
        link: '/business-partners/apply?partnerType=educator',
        target: '_blank',
        display: true,
      },
    ],
  },
];

// 'key' below is the card key in home.json
export const HomePageResources = [
  {
    key: 'STUDENT',
    imgSrc: resourceCardStudentExplore,
    subResources: [
      {
        key: 'EXPLORE_PROGRAMS',
        imgSrc: resourceCardExplorePrograms,
        path: '/',
        alsoDispInDashboard: true,
      },
      {
        key: 'CHECK_OUT_CAREERS',
        imgSrc: resourceCardCareer,
        path: '/occupations',
        alsoDispInDashboard: true,
      },
      {
        key: 'DISCOVER_INTERESTS',
        imgSrc: resourceCard2,
        path: '/survey',
        alsoDispInDashboard: true,
      },
    ],
  },
  {
    key: 'JOBSEEKER',
    imgSrc: resourceCardJobSeeker,
    subResources: [
      {
        key: 'FIND_OPPORTUNITIES',
        imgSrc: resourceCardLocalJobOpp,
        path: '/business-partners?type=local_jobs',
        alsoDispInDashboard: true,
      },
      {
        key: 'MARKETABLE_PROFILE',
        imgSrc: resourceCardBuildProfile,
        path: '/build/student-profile',
        alsoDispInDashboard: false,
      },
      {
        key: 'SEARCH_EVENTS',
        imgSrc: resourceCardSearchevents,
        path: '/events',
        alsoDispInDashboard: true,
      },
    ],
  },
  {
    key: 'PARTNER',
    imgSrc: resourceCardPartner,
    subResources: [
      {
        key: 'EMPLOYER_PARTNER',
        imgSrc: resourceCardEmployerPartner,
        path: '/business-partners/apply?partnerType=employer',
        alsoDispInDashboard: false,
      },
      {
        key: 'EDUCATION_PARTNER',
        imgSrc: resourceCardEducationPartner,
        path: '/business-partners/apply?partnerType=educator',
        alsoDispInDashboard: false,
      },
    ],
  },
];

export const LanguageMenu = [
  {
    key: 'ENGLISH',
    label: 'English',
    value: 'en',
  },
  {
    key: 'GERMAN',
    label: 'Deutsch',
    value: 'de',
  },
  {
    key: 'SPANISH',
    label: 'Español',
    value: 'es',
  },
];
