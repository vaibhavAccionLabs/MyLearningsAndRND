import React, {useEffect} from 'react';
import {useHistory, Link} from 'react-router-dom';
import {connect} from 'react-redux';
import {message, Menu} from 'antd';

import {
  useAuth,
  useInstance,
  usePrevious,
  useAutoTabLoginLogout,
  useWindowWidth,
} from 'core/hooks';
import {
  FloatingHeader,
  Footer,
  FlashMessage,
  RequestErrorLoader,
  ErrorBoundary,
  ErrorPage,
  GlobalSearch,
  GoogleButton,
} from 'core/components';

import {Login} from './modules';
import Routes from './Routes';

import {fetchUserData} from 'redux/modules/profile';
import {getMessage, getLang} from 'redux/modules/general';
import {MainMenu} from 'config';

import './App.less';

//Toast Message configuration
message.config({
  maxCount: 1,
});

const App = ({fetchUserData, flashMessage, lang}) => {
  const WINDOW = window;
  let displayMenuBar = false;
  let defaultMenuSelectedKey = [MainMenu[0].key];
  // Generic Hooks
  useAutoTabLoginLogout();
  useWindowWidth();
  const {request, error, data} = useInstance();
  const [token, user] = useAuth();
  const prevState = usePrevious({token});

  const {message: customMessage, displayMessage} = flashMessage;
  const history = useHistory();
  const {
    location,
    location: {pathname, search},
  } = history;
  let dynamicClassName = 'homepage';
  let hideHeaderFooter = false,
    hideGlobalSearch = false;

  if (pathname) {
    //dynamicClassName = pathname.replace(/[/]/g, ' ');
    dynamicClassName = pathname.split('/')[1] || 'homepage';
    if (pathname.includes('/profile/preview')) {
      hideHeaderFooter = true;
      hideGlobalSearch = true;
    }

    MainMenu.forEach(({path, key}) => {
      let PATH = path;
      if (path.includes('?')) {
        const idx = path.indexOf('?');
        PATH = PATH.substring(0, idx);
      }
      if (PATH === pathname && !search.includes('?event_id')) {
        displayMenuBar = true;
        defaultMenuSelectedKey = [key];
      }
    });
  }

  WINDOW.dataLayer.push({event: 'pageview'});

  useEffect(() => {
    if ((!prevState || (prevState && !prevState.token)) && token) {
      fetchUserData();
    }
  }, [fetchUserData, token]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  // checking for valid instance
  if (error) {
    return <ErrorPage />;
  }

  return (
    <RequestErrorLoader displaySplash body={{request, data}}>
      {displayMessage && customMessage && (
        <FlashMessage message={customMessage} />
      )}

      {/* Need to check instance first */}

      {!request && (
        <ErrorBoundary
          nameOfComponent='root-of-application'
          typeOfUi='fullPage'>
          <div className={`App ${lang}`}>
            <FloatingHeader data={data} hideHeaderFooter={hideHeaderFooter}>
              {!hideGlobalSearch && <GlobalSearch floatingHeader />}
            </FloatingHeader>
            {displayMenuBar && (
              <div className='mob_home_prog_menu'>
                <Menu
                  mode='horizontal'
                  className='home_prog_menu contentContainer'
                  selectedKeys={defaultMenuSelectedKey}>
                  {MainMenu.map(({key, label, path}) => (
                    <Menu.Item key={key}>
                      <Link to={path}> {label} </Link>
                    </Menu.Item>
                  ))}
                </Menu>
              </div>
            )}
            <GoogleButton />
            <div className={`wrapper ${dynamicClassName}`}>
              <Routes />
              {!hideHeaderFooter && <Footer data={data} />}
            </div>
            <Login />
          </div>
        </ErrorBoundary>
      )}
      {/* <div>404 Error window if no instance available..</div> */}
    </RequestErrorLoader>
  );
};

const mapStateToProps = state => ({
  flashMessage: getMessage(state),
  lang: getLang(state),
});

export default connect(mapStateToProps, {fetchUserData})(App);
