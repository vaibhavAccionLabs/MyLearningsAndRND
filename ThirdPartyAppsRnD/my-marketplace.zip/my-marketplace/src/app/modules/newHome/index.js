import {Row, Col, Layout} from 'antd';
import {connect} from 'react-redux';
import {getAppConfig} from 'redux/modules/general';
import {getBanner} from 'core/utils';
import {useInstance} from 'core/hooks';
import {Header} from 'core/components';
import {PathsList} from 'app/modules/directory/subModules';

import HOME_DATA from 'data/home';

import './style.less';
const {Content} = Layout;

const Home = props => {
  const {data: instanceData} = useInstance();

  const {career} = HOME_DATA[props?.appConfig?.lang || 'en'] || HOME_DATA['en'];

  const getBannerImageStyle = () => {
    let headerStyle = {};
    if (instanceData?.institution_id && instanceData?.banner_cloudinary) {
      headerStyle = {
        backgroundImage: `url(${getBanner(instanceData?.banner_cloudinary, {
          width: props?.appConfig?.isMobileView ? window.screen.width : '1300',
          height: 380,
          quality: 80,
        })})`,
      };
    }
    return headerStyle;
  };

  const getBannerTitle = () => {
    let BannerTitle = career.heading;
    // if (instanceData?.institution_id && instanceData?.tagline) {
    //   BannerTitle = instanceData?.tagline;
    // }
    return BannerTitle;
  };

  return (
    <>
      <Header
        className={instanceData?.banner_cloudinary ? 'college_banner' : ''}
        style={getBannerImageStyle()}>
        <div className='overlay'></div>
        <Row className='header_bannerText' justify='center' align='middle'>
          <Col xs={24} sm={24} md={24} lg={24}>
            <h1 dangerouslySetInnerHTML={{__html: getBannerTitle() || ''}}></h1>
            <h5
              className='pb-3'
              dangerouslySetInnerHTML={{__html: career.desc || ''}}
            />
          </Col>
        </Row>
      </Header>
      <Content>
        <PathsList />
      </Content>
    </>
  );
};
const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
});

export default connect(mapStateToProps, {})(Home);
