import {AppBreadcrumb} from 'core/components';
import termsData from 'data/terms.json';

import style from './style.module.less';

const Description = ({desc}) => {
  if (desc && Array.isArray(desc)) {
    return desc.map((el, idx) => {
      if (el && Array.isArray(el)) {
        return (
          <ul className={style.num_list} key={`ul-${idx}`}>
            {el.map((e, mainIdx) => {
              if (e && Array.isArray(e)) {
                return (
                  <ul className={style.alpha_list} key={`ul-in-${mainIdx}`}>
                    {e.map((elem, subIdx) => (
                      <li key={`sub-list-${mainIdx}-${subIdx}`}>{elem}</li>
                    ))}
                  </ul>
                );
              } else {
                return <li key={`list-${mainIdx}`}>{e}</li>;
              }
            })}
          </ul>
        );
      } else {
        return <p key={`in-para-${idx}`}>{el}</p>;
      }
    });
  }
  return <p>{desc}</p>;
};

const TermsOfUse = () => (
  <div className={style.terms_Condition}>
    <div className={`${style.banner}`}>
      <h1>{termsData.bannerHeading}</h1>
    </div>
    <AppBreadcrumb
      dataList={[
        {
          name: termsData.breadcrumbData,
        },
      ]}
    />
    <div className={`contentContainer mt-4 mb-5 ${style.mobContainer}`}>
      {termsData.content.map(({header, description}, idx) => (
        <div key={`cont-${idx}`}>
          <h3 key={`h-${idx}`}>{header}</h3>
          <Description desc={description} />
        </div>
      ))}
    </div>
  </div>
);

export default TermsOfUse;
