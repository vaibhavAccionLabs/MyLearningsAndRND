import {lazy} from 'react';

import {
  Dashboard,
  Profile,
  Education,
  Skills,
  Workforce,
  MyEvents,
  ProfilePreview,
} from './settings/subModules';
import {PathsList} from './directory/subModules';
import {MySurvey, SurveyHome} from './survey/subModules';
import {
  BecomeAPartner,
  PartnerDetails,
  PartnersList,
} from './business-partners/submodules';

import {retry} from 'core/utils';

const Login = lazy(() => retry(() => import('./auth')));
const Home = lazy(() => retry(() => import('./newHome')));
const Search = lazy(() => retry(() => import('./search')));
const Pathways = lazy(() => retry(() => import('./pathways')));
const ComparePaths = lazy(() => retry(() => import('./compare')));
const Occupation = lazy(() => retry(() => import('./occupation')));
const Programs = lazy(() => retry(() => import('./programs')));
const JobOpportunites = lazy(() => retry(() => import('./job-opportunities')));
const LocalSalary = lazy(() => retry(() => import('./local-salary')));
const Jobs = lazy(() => retry(() => import('./jobs')));
const Settings = lazy(() => retry(() => import('./settings')));
const Directory = lazy(() => retry(() => import('./directory')));
const Verify = lazy(() => retry(() => import('./verify')));
const CareerDestination = lazy(() =>
  retry(() => import('./career-destination')),
);
const ResetPassword = lazy(() =>
  retry(() => import('./auth/components/ResetPassword')),
);
const StudentProfile = lazy(() => retry(() => import('./student-profile')));
const Events = lazy(() => retry(() => import('./events')));
const Survey = lazy(() => retry(() => import('./survey')));
const BusinessPartners = lazy(() => retry(() => import('./business-partners')));
const TermsOfUse = lazy(() => retry(() => import('./terms')));
const PrivacyPolicy = lazy(() => retry(() => import('./policy')));

export {
  Login,
  Home,
  Search,
  Pathways,
  ComparePaths,
  Occupation,
  Programs,
  JobOpportunites,
  LocalSalary,
  Jobs,
  Events,
  BusinessPartners,
  Settings,
  //Settings SubModules
  Dashboard,
  Profile,
  ProfilePreview,
  Education,
  Skills,
  Workforce,
  MyEvents,
  ResetPassword,
  StudentProfile,
  Directory,
  CareerDestination,
  // Directory SubModules
  PathsList,
  Survey,
  MySurvey,
  SurveyHome,
  //BusinessPartner SubModules
  BecomeAPartner,
  PartnerDetails,
  PartnersList,
  //Org
  TermsOfUse,
  PrivacyPolicy,
  Verify,
};
