import React, {useState, useEffect} from 'react';
import {connect} from 'react-redux';
import {useHistory} from 'react-router-dom';
import {isArray, isObject, isEmpty} from 'lodash';

import {Row, Col, Input, Button, Tooltip, Popover, message} from 'antd';
import {InfoCircleFilled} from '@ant-design/icons';
import {queryStringParse} from 'core/utils';
import jp from 'jsonpath';

import {useAuth} from 'core/hooks';
import {
  AppBreadcrumb,
  PathCard,
  RequestErrorLoader,
  ErrorBoundary,
} from 'core/components';
import {SchoolDetails} from './components';

import {getAppConfig} from 'redux/modules/general';
import {openLoginScreen} from 'redux/modules/auth';
import {
  saveComparison,
  clearComparePaths,
  getPathsToCompare,
  removePathFromCompare,
  getComparePathDetails,
  fetchComparedPathDetails,
} from 'redux/modules/pathways';

import PathwayModule from 'data/pathway';
import {explorePathSearch} from 'assets/images';

import compareStaticData from 'data/compare.json';

import './comparepath.less';

const TooltipContent = () => <p>{PathwayModule.CTEStatus}</p>;
const {warning, success, error} = message;
const rowsData = [
  {
    label: compareStaticData.rowsData.pathLabel,
    path: '$.institute_details.name',
    component: PathCard,
  },
  {
    label: compareStaticData.rowsData.schoolLabel,
    path: '$.institute_details.name',
    component: SchoolDetails,
  },
  {
    label: compareStaticData.rowsData.awardTypeLabel,
    path: '$.award_type_name',
  },
  {
    label: compareStaticData.rowsData.timeToCompleteLabel,
    path: '$.program_duration',
    render: value => `${value} Years`,
  },
  {
    label: compareStaticData.rowsData.cteStatusLabel,
    info: TooltipContent,
    path: '$.cte',
    render: value => (value ? 'Yes' : 'No'),
  },
  {
    label: compareStaticData.rowsData.minGPALabel,
    path: '$.min_gpa',
  },
  {
    label: compareStaticData.rowsData.coursesLabel,
    path: '$.total_courses',
  },
];

const ComparisonPage = ({
  comparePathsList,
  saveComparison,
  openLoginScreen,
  removePathFromCompare,
  isLoading,
  clearComparePaths,
  fetchComparedPathDetails,
  appConfig: {isMobileView},
}) => {
  const history = useHistory();
  const [token, user] = useAuth();
  const {
    location: {search},
  } = history;
  const {comparison_title} = queryStringParse(search);
  const param_comparison_title =
    comparison_title && decodeURIComponent(comparison_title);
  const [comparisonTitle, setComparisonTitle] = useState('');
  const breadcrumbList = [{name: 'Compare Paths'}];
  const MyEdBreadcrumbList = [
    {
      name: 'Profile Dashboard',
      path: '/settings/dashboard',
    },
    {
      name: 'My Education',
      path: '/settings/education',
    },
    {name: 'Compare Paths Detail'},
  ];
  const pathLength = (comparePathsList && comparePathsList.length) || 0;

  const onRemovePathToCompare = pathData => {
    removePathFromCompare(pathData);
  };

  const onComparisonTitleChange = e => setComparisonTitle(e.target.value);

  //const onGoBack = () => history.goBack();

  const onSaveComparison = async () => {
    if (comparisonTitle) {
      if (pathLength < 2) {
        warning(PathwayModule.PathsValidationMsg);
        return;
      }
      if (token) {
        await saveComparison(comparisonTitle, res => {
          if (res) {
            warning(res);
          } else {
            onComparisonTitleChange({target: {value: ''}});
            success(PathwayModule.SaveComparePathSuccess);
          }
        });
      } else {
        openLoginScreen({
          callback: async () => {
            await saveComparison(comparisonTitle);
          },
        });
      }
    } else {
      warning(PathwayModule.ComparisonTitleValidationMsg);
    }
  };

  useEffect(() => {
    if (!token && comparison_title) {
      history.push('/compare-paths');
    }
    token &&
      comparison_title &&
      fetchComparedPathDetails(comparison_title, res => {
        if (res) {
          error(res);
        }
      });

    return () => {
      setComparisonTitle('');
      clearComparePaths();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  //Todo: will remove in future
  const cellSize = pathLength === 3 ? 6 : pathLength === 2 ? 8 : 12;
  const lgGridSize =
    pathLength === 3 ? 24 : pathLength === 2 ? 15 : pathLength === 1 ? 12 : 12;
  const mdGridSize =
    pathLength === 3 ? 24 : pathLength === 2 ? 18 : pathLength === 1 ? 16 : 12;
  const lgExpSize =
    pathLength === 3 ? 6 : pathLength === 2 ? 9 : pathLength === 0 ? 24 : 12;
  const mdExpSize =
    pathLength === 3 ? 6 : pathLength === 2 ? 6 : pathLength === 0 ? 24 : 8;

  return (
    <>
      <RequestErrorLoader body={{request: isLoading}}>
        <div className='comparison-container contentContainer'>
          <div className='comparison-actions-container'>
            <h1>{compareStaticData.heading}</h1>
            <div className='comparisonSection'>
              {!param_comparison_title ? (
                <>
                  <Input
                    size='large'
                    disabled={!pathLength}
                    placeholder={compareStaticData.placeholder}
                    className='comparison-title'
                    value={comparisonTitle}
                    onChange={e => onComparisonTitleChange(e)}
                  />
                  <span>*</span>
                </>
              ) : (
                <h3 className='comparison-title-label'>
                  {param_comparison_title}
                </h3>
              )}
              <p className='comparison-title-description'>
                {pathLength} {compareStaticData.itemsSelectedTxt}
              </p>
            </div>
            <div className='d-block text-center'>
              {!param_comparison_title && (
                <Button
                  type='primary'
                  onClick={onSaveComparison}
                  disabled={!pathLength}>
                  {compareStaticData.saveBtnTxt}
                </Button>
              )}
            </div>
          </div>
        </div>
        {/* <AppBreadcrumb
          dataList={
            param_comparison_title ? MyEdBreadcrumbList : breadcrumbList
          }
        /> */}
        <div className='gridContainer contentContainer'>
          <ErrorBoundary
            nameOfComponent='module-compare-paths'
            typeOfUi='subPage'>
            <Row>
              {pathLength > 0 && (
                <Col
                  xs={pathLength <= 2 ? 18 : 24}
                  sm={24}
                  md={mdGridSize}
                  lg={lgGridSize}>
                  {rowsData.map((row, index) => (
                    <Row key={index}>
                      <Col
                        xs={cellSize}
                        sm={cellSize}
                        md={cellSize}
                        lg={cellSize}
                        className='border-r-b-1 gridLabelContainer'>
                        <div>
                          {row.label}
                          {row.info && (
                            <span>
                              <Popover
                                content={row.info}
                                overlayClassName='popover_status'
                                title=''
                                trigger={isMobileView ? 'click' : 'hover'}>
                                <InfoCircleFilled className='CTEStatusIcon' />
                              </Popover>
                              {/* <Tooltip placement='bottomLeft' title={row.info}>
                                <Button>
                                  <InfoCircleFilled className='CTEStatusIcon' />
                                </Button>
                              </Tooltip> */}
                            </span>
                          )}
                        </div>
                      </Col>
                      {comparePathsList &&
                        isArray(comparePathsList) &&
                        !isEmpty(comparePathsList) &&
                        comparePathsList.map((comparePath, index) => {
                          const data =
                            comparePath &&
                            isObject(comparePath) &&
                            jp.query(comparePath, row.path);
                          return (
                            <Col
                              key={`award-type-${index}`}
                              xs={cellSize}
                              sm={cellSize}
                              md={cellSize}
                              lg={cellSize}
                              className='border-r-b-1 gridValueContainer'>
                              {row.component ? (
                                param_comparison_title ? (
                                  <row.component
                                    target='_blank'
                                    enableNavigation
                                    data={comparePath}
                                    key={`comparePathCard-${index}`}
                                  />
                                ) : (
                                  <row.component
                                    target='_blank'
                                    enableNavigation
                                    data={comparePath}
                                    key={`comparePathCard-${index}`}
                                    onClosePath={onRemovePathToCompare}
                                  />
                                )
                              ) : (
                                data &&
                                data.map(value =>
                                  row.render ? row.render(value) : value || '-',
                                )
                              )}
                            </Col>
                          );
                        })}
                    </Row>
                  ))}
                </Col>
              )}
              {pathLength <= 2 && !param_comparison_title ? (
                <Col
                  xs={6}
                  sm={24}
                  md={mdExpSize}
                  lg={lgExpSize}
                  className='border-r-b-1 explorePathGrid'>
                  <div>
                    <img src={explorePathSearch} alt='path search' />
                    <p className='py-3 mb-0'>
                      {compareStaticData.addMorePathsLabel}
                    </p>
                    <Button
                      style={{width: '100%'}}
                      className='btn-transparent'
                      onClick={() => history.push('/')}>
                      {compareStaticData.exploreBtnTxt}
                    </Button>
                  </div>
                </Col>
              ) : null}
            </Row>
          </ErrorBoundary>
        </div>
      </RequestErrorLoader>
    </>
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  isLoading: getComparePathDetails(state).request,
  isComparePathSavedError: getComparePathDetails(state).error,
  comparePathsList: getPathsToCompare(state),
});

export default connect(mapStateToProps, {
  saveComparison,
  openLoginScreen,
  clearComparePaths,
  removePathFromCompare,
  fetchComparedPathDetails,
})(ComparisonPage);
