import SchoolDetails from './SchoolDetails';

export {SchoolDetails};
