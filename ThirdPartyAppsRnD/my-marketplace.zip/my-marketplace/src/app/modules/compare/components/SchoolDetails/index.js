import jp from 'jsonpath';
import {isObject, isArray, isEmpty} from 'lodash';
import {ErrorBoundary} from 'core/components';

const SchoolDetails = ({data}) => {
  const schoolData =
    data && isObject(data) && jp.query(data, '$.institute_details.address.*');
  let cityNZip = '';
  let state = '';
  return (
    <ErrorBoundary nameOfComponent='mod-comp-comparepaths-school-details'>
      <h4>{data && data.institute_details && data.institute_details.name}</h4>
      {isArray(schoolData) &&
        !isEmpty(schoolData) &&
        schoolData.forEach((d, idx) => {
          if (d && idx < 3) {
            return <p key={`school-data-${idx}`}>{d}</p>;
          } else if (d && (idx === 3 || idx === 5)) {
            cityNZip += `${d}, `;
          } else if (d && idx === 4) {
            state = d;
          }
        })}
      <p key='city-Zip'>{cityNZip}</p>
      {state ? <p key='state'>{state}</p> : null}
    </ErrorBoundary>
  );
};

export default SchoolDetails;
