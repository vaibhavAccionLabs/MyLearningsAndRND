import React, {useEffect, useState} from 'react';
import {connect} from 'react-redux';
import {useHistory} from 'react-router-dom';

import {getAppConfig} from 'redux/modules/general';
import {openLoginScreen} from 'redux/modules/auth';

import {
  getJobZoneDetails,
  getOccupationRoles,
  saveOccupationRates,
  fetchOccupationRoles,
  fetchJobZoneDetails,
  getOccupationDetails,
  fetchOccupationDetails,
  subscribeForOccupation,
  getSubscribedOccupation,
  unSubscribeForOccupation,
  fetchSubscribedOccupation,
  resetSubscribedOccupation,
} from 'redux/modules/occupation';

import {
  fetchLocalJobs,
  fetchJobBoards,
  fetchPublicInsightJobs,
  getLocalJobs,
  getJobBoards,
  getPublicInsightJobs,
  clearLocalJobs,
  clearJobBoards,
  clearPublicInsightJobs,
} from 'redux/modules/jobs';

import {
  fetchPrograms,
  getPrograms,
  clearPrograms,
} from 'redux/modules/programs';

import {
  AppBreadcrumb,
  CustomTabs,
  NoResults,
  RequestErrorLoader,
} from 'core/components';
import {queryStringParse} from 'core/utils';

import {
  CareerOverview,
  EmploymentOpportunites,
  RelatedPathways,
  CareerEvents,
} from './components';

import {Banner} from './sharedComponents';

import occupationData from 'data/occupation.json';

import './search.less';

const Occupation = props => {
  const {
    resetSubscribedOccupation,
    fetchOccupationDetails,
    fetchJobZoneDetails,
    occupationDetails,
    jobZoneDetails,
  } = props;
  const [activeTab, setActiveTab] = useState('career_overview');
  const history = useHistory();
  const {
    location: {pathname, search},
  } = history;

  const params = queryStringParse(search);

  useEffect(() => {
    const {query, activetab} = params || {};
    //encodeURIComponent(query)
    fetchOccupationDetails(query);
    activetab ? setActiveTab(activetab) : setActiveTab('career_overview');

    if (!jobZoneDetails.data) {
      fetchJobZoneDetails();
    }
    return () => {
      resetSubscribedOccupation();
    };
  }, [params.query]); // eslint-disable-line react-hooks/exhaustive-deps

  const onEmploymentTypeChange = value => {
    const {query, activetab} = params || {};
    history.push(
      `${pathname}?query=${query}&activetab=${activetab}&type=${value}`,
    );
  };

  const tabs = [
    {
      title: occupationData.tabs.careerOverviewTitle,
      key: 'career_overview',
      children: <CareerOverview {...props} />,
    },
    {
      title: occupationData.tabs.relatedPathTitle,
      key: 'programs',
      children: <RelatedPathways {...props} params={params} />,
    },
    {
      title: occupationData.tabs.employeeOpprtTitle,
      key: 'employment_opportunites',
      children: (
        <EmploymentOpportunites
          {...props}
          onChange={onEmploymentTypeChange}
          params={params}
        />
      ),
    },
    {
      title: occupationData.tabs.eventsTitle,
      key: 'events',
      children: <CareerEvents {...props} params={params} />,
    },
  ];

  const onTabChange = tabName => {
    const {query} = params || {};
    setActiveTab(tabName);
    history.push(`${pathname}?query=${query}&activetab=${tabName}`);
  };

  const no_query =
    !params?.query || params?.query === 'null' || params?.query === 'undefined';
  return (
    <>
      <AppBreadcrumb dataList={occupationData.breadcrumbData} />
      <RequestErrorLoader
        txt={occupationData.loadingOccupTxt}
        body={{
          ...occupationDetails,
          data: occupationDetails?.data?.occupation_details || {},
        }}
        overideNoDataContainer={
          <NoResults
            heading={
              no_query
                ? occupationData.getStartedTxt
                : occupationData.noDataAvailableTxt
            }
            subHeading={
              no_query
                ? occupationData.typeInSearchTxt
                : occupationData.searchDiffOccTxt
            }
          />
        }>
        {occupationDetails && !occupationDetails.error && (
          <>
            <Banner {...props} />
            {
              <div className='pathways-tabs contentContainer occupation_tabs px-4 py-2'>
                <CustomTabs
                  onChange={onTabChange}
                  activeKey={activeTab}
                  tabsList={tabs}
                />
              </div>
            }
          </>
        )}
      </RequestErrorLoader>
    </>
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  occupationDetails: getOccupationDetails(state),
  jobZoneDetails: getJobZoneDetails(state),
  programs: getPrograms(state),
  localJobs: getLocalJobs(state),
  jobBoards: getJobBoards(state),
  publicInsightJobs: getPublicInsightJobs(state),
  occupationRoles: getOccupationRoles(state),
  subscribedOccupation: getSubscribedOccupation(state),
});

export default connect(mapStateToProps, {
  fetchOccupationDetails,
  fetchJobZoneDetails,
  fetchPrograms,
  fetchLocalJobs,
  fetchJobBoards,
  fetchPublicInsightJobs,
  resetSubscribedOccupation,
  clearPrograms,
  clearLocalJobs,
  clearJobBoards,
  clearPublicInsightJobs,
  openLoginScreen,
  saveOccupationRates,
  fetchOccupationRoles,
  subscribeForOccupation,
  unSubscribeForOccupation,
  fetchSubscribedOccupation,
})(Occupation);
