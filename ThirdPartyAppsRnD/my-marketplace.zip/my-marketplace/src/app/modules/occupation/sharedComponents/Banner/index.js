import {useState, useEffect, memo} from 'react';
import {Button, Popconfirm, Spin, Tooltip, message} from 'antd';

import {heartPurpleBorder, heartWhite} from 'assets/images';

import {WrapText, LazyImage, ErrorBoundary} from 'core/components';
import {RateMyInterest} from '../../components';
import {useAuth} from 'core/hooks';

import occupationData from 'data/occupation.json';

import './style.less';

const occupationVideoEndPoint =
  'https://cdn.careeronestop.org/OccVids/OccupationVideos/';

const Banner = ({
  occupationRoles,
  openLoginScreen,
  occupationDetails = {},
  saveOccupationRates,
  fetchOccupationRoles,
  subscribedOccupation,
  subscribeForOccupation,
  unSubscribeForOccupation,
  fetchSubscribedOccupation,
  appConfig: {isMobileView} = {},
}) => {
  const [token, user] = useAuth();
  const [showRateOccupation, setShowRateOccupation] = useState(false);
  const {subscribeRequest, request: getSuscribeReq} =
    subscribedOccupation || {};
  const {data: {occupation_details, occupation_uuid} = {}, request} =
    occupationDetails || {};
  const {occupation_title, also_called, video_details} =
    occupation_details || {};
  const also_called_data =
    Array.isArray(also_called) && also_called.length > 0
      ? also_called.join(', ')
      : '-';
  const {VideoCode} = video_details && video_details[0] ? video_details[0] : {};

  useEffect(() => {
    if (token && !occupationDetails?.request && occupationDetails?.data) {
      fetchOccupationRoles(occupationDetails?.data?.occupation_onnet);
      fetchSubscribedOccupation();
    }
  }, [token, occupationDetails]); // eslint-disable-line react-hooks/exhaustive-deps

  const openRateOccupation = () => {
    if (token) {
      setShowRateOccupation(true);
    } else {
      openLoginScreen({
        callback: async () => setShowRateOccupation(true),
      });
    }
  };

  const isOccupationSubscribed = () => {
    const {data} = subscribedOccupation || {};
    if (Array.isArray(data)) {
      const exists = data.filter(i => i.occupation_id === occupation_uuid);
      if (exists[0]) return true;
      return false;
    } else return false;
  };

  const onSaveOccupationInterest = (score, callback) => {
    const {data: {occupation_uuid} = {}} = occupationDetails || {};
    if (occupation_uuid && score) {
      const data = {occupation_uuid, score};
      saveOccupationRates(data, res => {
        message.success(occupationData.interestSavedTxt);
        callback && callback(res);
        setShowRateOccupation(false);
      });
    }
  };

  const subscribeOccupation = async () => {
    const {data: {occupation_uuid, occupation_onnet} = {}} =
      occupationDetails || {};
    const body = {
      occupation_uuid,
      onnet: occupation_onnet,
    };
    await subscribeForOccupation(body);
    fetchSubscribedOccupation();
  };

  const onOccupationSubscribe = () => {
    if (token) {
      subscribeOccupation();
    } else {
      openLoginScreen({
        callback: async () => {
          subscribeOccupation();
        },
      });
    }
  };

  const unSubscribeOccupation = async () => {
    const {data: {occupation_uuid} = {}} = occupationDetails || {};
    const {data = []} = subscribedOccupation || {};
    const d = data?.filter(i => i?.occupation_id === occupation_uuid);
    if (d && d[0]) {
      await unSubscribeForOccupation(d[0].uuid);
      fetchSubscribedOccupation();
    }
  };

  return (
    <ErrorBoundary nameOfComponent='mod-comp-occupation-banner'>
      <div className='occ-banner contentContainer'>
        {
          <div className='occ-banner-container'>
            <div className='r-container r-container_web'>
              <div className='video'>
                <Spin spinning={request} wrapperClassName='image_rerender'>
                  {!request && (
                    <LazyImage
                      src={`${occupationVideoEndPoint}${VideoCode}.jpg`}
                      alt='video-thumb'
                    />
                  )}
                </Spin>
                <div className='web-container'>
                  <div className='title pt-2'>{occupation_title}</div>
                  <div className='desc'>
                    <span className='lbl'>{occupationData.alsoCalledTxt}:</span>
                    <WrapText
                      text={also_called_data}
                      length={70}
                      className='vl'
                      title={occupation_title}
                      isMobileView={isMobileView}
                    />
                  </div>
                  <div className='actions'>
                    <Button
                      className='btn btn-blue-outer'
                      onClick={openRateOccupation}>
                      {occupationData.careerInterestScoreTxt}
                    </Button>
                    {subscribeRequest || getSuscribeReq ? (
                      <Button loading shape='circle' />
                    ) : isOccupationSubscribed() ? (
                      <Popconfirm
                        okText={occupationData.yesTxt}
                        cancelText={occupationData.noTxt}
                        className='occ-pop-confirm'
                        title={occupationData.confirmModalTitle}
                        onConfirm={unSubscribeOccupation}>
                        <Button
                          type='primary'
                          shape='circle'
                          icon={<img src={heartWhite} alt='heart' />}
                          className='green-btn heartRating subscribed'
                          loading={subscribeRequest || getSuscribeReq}
                          disabled={subscribeRequest || getSuscribeReq}
                        />
                      </Popconfirm>
                    ) : (
                      <Tooltip placement='bottomLeft' title='Subscribe'>
                        <Button
                          type='primary'
                          shape='circle'
                          className='heartRating'
                          onClick={onOccupationSubscribe}
                          icon={<img src={heartPurpleBorder} alt='heart' />}
                          loading={subscribeRequest || getSuscribeReq}
                          disabled={subscribeRequest || getSuscribeReq}
                        />
                      </Tooltip>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className='r-container r-container_mob'>
              <div className='d-flex justify-content-center w-100'>
                <div className='video'>
                  <Spin spinning={request} wrapperClassName='image_rerender'>
                    {!request && (
                      <LazyImage
                        src={`${occupationVideoEndPoint}${VideoCode}.jpg`}
                        alt='video-thumb'
                      />
                    )}
                  </Spin>
                </div>
                <div className='title pt-2'>{occupation_title}</div>
              </div>
            </div>
            <div className='r-container r-container_mob'>
              <div className='desc'>
                <span className='lbl'>{occupationData.alsoCalledTxt}:</span>
                <WrapText
                  text={also_called_data}
                  length={70}
                  className='vl'
                  title={occupation_title}
                />
              </div>
              <div className='actions'>
                <Button
                  className='btn btn-blue-outer'
                  onClick={openRateOccupation}>
                  {occupationData.careerInterestScoreTxt}
                </Button>
                {subscribeRequest || getSuscribeReq ? (
                  <Button loading shape='circle' />
                ) : isOccupationSubscribed() ? (
                  <Popconfirm
                    okText={occupationData.yesTxt}
                    cancelText={occupationData.noTxt}
                    className='occ-pop-confirm'
                    title={occupationData.confirmModalTitle}
                    onConfirm={unSubscribeOccupation}>
                    <Button
                      type='primary'
                      shape='circle'
                      icon={<img src={heartWhite} alt='heart' />}
                      className='green-btn heartRating subscribed'
                      loading={subscribeRequest || getSuscribeReq}
                      disabled={subscribeRequest || getSuscribeReq}
                    />
                  </Popconfirm>
                ) : (
                  <Tooltip placement='bottomLeft' title='Subscribe'>
                    <Button
                      type='primary'
                      shape='circle'
                      className='heartRating'
                      onClick={onOccupationSubscribe}
                      icon={<img src={heartPurpleBorder} alt='heart' />}
                      loading={subscribeRequest || getSuscribeReq}
                      disabled={subscribeRequest || getSuscribeReq}
                    />
                  </Tooltip>
                )}
              </div>
            </div>
          </div>
        }
      </div>

      {showRateOccupation && (
        <RateMyInterest
          occupationRoles={occupationRoles}
          onSaveOccupationInterest={onSaveOccupationInterest}
          onCancel={() => setShowRateOccupation(false)}
          occupationDetails={occupationDetails}
        />
      )}
    </ErrorBoundary>
  );
};

export default memo(Banner);
