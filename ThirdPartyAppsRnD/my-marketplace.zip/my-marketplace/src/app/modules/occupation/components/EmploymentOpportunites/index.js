import {useState, useEffect} from 'react';
import {Row, Col, Form, Badge, Button} from 'antd';
import {FilterOutlined} from '@ant-design/icons';
import isEmpty from 'lodash/isEmpty';
import isObject from 'lodash/isObject';
import isBoolean from 'lodash/isBoolean';

import {useEnableDisableScroll} from 'core/hooks';
import {
  RequestErrorLoader,
  ErrorBoundary,
  NoResults,
  PathCard,
  SearchResultsCounter,
} from 'core/components';

//Local Components
import FiltersForm from './FiltersForm';
import Sorter from './Sorter';
import DataGrid from './DataGrid';
import Types from './Types';

import {employOpportData} from 'data/occupation.json';

const config = {
  type: 'appliedWorkforce',
  nameLabel: 'Company: ',
};

const EmploymentOpportunites = props => {
  const {
    params,
    onChange,
    occupationDetails,
    fetchPrograms,
    fetchLocalJobs,
    fetchJobBoards,
    //fetchPublicInsightJobs,
    programs,
    localJobs,
    jobBoards,
    publicInsightJobs,
    clearPrograms,
    clearLocalJobs,
    clearJobBoards,
    //clearPublicInsightJobs,
    isBusinessPartner,
    businessPartnerName,
    appConfig: {isMobileView},
    onCareerChange,
    onlyLocal,
    gridView = true,
    //stopFilterScrollOnMobile,
    history,
  } = props;

  const {
    location: {pathname},
  } = history;

  const [form] = Form.useForm();
  const {
    isFilterVisible,
    onFilterClick,
    setIsFilterVisible,
  } = useEnableDisableScroll();

  const isRelevant = pathname === '/search' && params?.query;
  const defaultSortByValue = isRelevant ? 'relevant' : 'date_desc';

  const [reqParams, setReqParams] = useState({
    occupation_id: occupationDetails?.data?.occupation_uuid,
    occupation_onnet: occupationDetails?.data?.occupation_onnet,
    occupation_name: occupationDetails?.data?.occupation_name,
    company_name: isBusinessPartner ? businessPartnerName : null,
    type: isBusinessPartner || onlyLocal ? 'local_jobs' : 'job_boards',
    gsearch: params?.query,
    sort: defaultSortByValue,
    days: 7,
    page: 1,
    location_type: 'all',
    loadMore: false,
  });

  const [filters, setFilters] = useState({});

  const TotalRecords =
    (programs?.data && programs.data.no_of_records) ||
    (localJobs?.data && localJobs.data.no_of_records) ||
    (publicInsightJobs?.data && publicInsightJobs.data.no_of_records) ||
    (jobBoards?.data && jobBoards.data.Jobcount) ||
    0;

  const apiCall = (type, Obj, filters = null) => {
    if (type === 'local_jobs') {
      fetchLocalJobs(Obj, filters);
      return;
    }
    if (type === 'job_boards') {
      fetchJobBoards(Obj, filters);
      //fetchPublicInsightJobs(Obj, filters);
      return;
    }
    fetchPrograms(Obj, filters);
  };

  const clearReducer = type => {
    if (type === 'local_jobs') {
      clearLocalJobs();
      return;
    }
    if (type === 'job_boards') {
      clearJobBoards();
      //clearPublicInsightJobs();
      return;
    }
    clearPrograms();
  };

  useEffect(() => {
    const {
      type = isBusinessPartner || onlyLocal ? 'local_jobs' : 'job_boards',
      query,
    } = params || {};
    if (occupationDetails?.data || businessPartnerName || onlyLocal) {
      const Obj = Object.assign({}, reqParams, {
        occupation_id: occupationDetails?.data?.occupation_uuid,
        occupation_onnet: occupationDetails?.data?.occupation_onnet,
        occupation_name: occupationDetails?.data?.occupation_name,
        company_name: isBusinessPartner ? businessPartnerName : null,
        type: type,
        gsearch: query,
        sort: defaultSortByValue,
        days: 7,
        page: 1,
        page_size: 25,
        loadMore: false,
      });
      setReqParams(Obj);
      setFilters({});
      form.resetFields();
      apiCall(type, Obj);
    }
    return () => {
      clearReducer(type);
    };
  }, [occupationDetails?.data, businessPartnerName, params?.type]); // eslint-disable-line react-hooks/exhaustive-deps

  const onTypeChange = e => {
    let value = e;
    if (e && isObject(e)) {
      value = e.target.value;
    }
    onChange(value);
  };
  const onLocationChange = e => {
    let value = e;
    if (e && isObject(e)) {
      value = e.target.value;
    }
    const Obj = Object.assign({}, reqParams, {location_type: value});
    refetchData(Obj, filters);
  };

  const onFinish = values => {
    let filterApply = false;
    if (values) {
      const filterKeys = Object.keys(values);
      filterKeys.map(key => {
        if (values[key] || values[key] === '' || isBoolean(values[key])) {
          filterApply = true;
        }
      });
      if (filterApply) {
        const Obj = Object.assign({}, reqParams, {page: 1});
        setFilters(values);
        refetchData(Obj, values);
        isMobileView && setIsFilterVisible(false);
      }
    }
  };

  // to handle error conditions
  const onFinishFailed = errorInfo => {
    console.log('Failed:', errorInfo);
  };

  const onSorterChange = (key, value) => {
    const Obj = Object.assign({}, reqParams, {[key]: value, page: 1});
    refetchData(Obj, filters);
  };

  const onPageChange = page => {
    const Obj = Object.assign({}, reqParams, {page});
    refetchData(Obj, filters);
    window.scrollTo({
      top: isBusinessPartner ? 300 : 470,
      behavior: 'smooth',
    });
  };

  const onFilterReset = () => {
    const Obj = Object.assign({}, reqParams, {page: 1});
    setFilters({});
    form.resetFields();
    refetchData(Obj, null);
    isMobileView && setIsFilterVisible(false);
  };

  const refetchData = (Obj, filters) => {
    setReqParams(Obj);
    apiCall(reqParams.type, Obj, filters);
  };

  const InitialData =
    reqParams.type === 'job_boards'
      ? jobBoards
      : reqParams.type === 'local_jobs'
      ? localJobs
      : programs;

  const dataLength = InitialData?.data && InitialData.data.datalength;

  const hideLoadMore =
    InitialData?.data &&
    InitialData?.data?.data &&
    InitialData?.data?.data?.length >= InitialData?.data?.no_of_records &&
    !InitialData.request &&
    !InitialData.error;

  const loadMore = () => {
    const Obj = Object.assign(
      {},
      reqParams,
      {page: reqParams.page + 1},
      {loadMore: true},
    );
    refetchData(Obj, filters);
  };

  return (
    <ErrorBoundary
      nameOFComponent='mod-comp-opportunites-employment-opportunties'
      showDialog={true}>
      {isMobileView && (
        <>
          <Types
            onChange={onTypeChange}
            selectedValue={reqParams?.type}
            initialData={InitialData}
            isBusinessPartner={isBusinessPartner}
          />

          <span className='filterCareer'>
            <span className='w_text'>
              {employOpportData.filterByMobileHeading}
            </span>
            <Badge dot={!isEmpty(filters)}>
              <FilterOutlined onClick={onFilterClick} />
            </Badge>
          </span>
        </>
      )}
      <div className='employment-content py-4'>
        <Row>
          {isFilterVisible && (
            <Col
              xs={24}
              sm={24}
              md={6}
              lg={6}
              className='opportunity-filters px-3'>
              <FiltersForm
                {...props}
                form={form}
                reqParams={reqParams}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                filters={filters}
                onReset={onFilterReset}
                type={reqParams.type}
                isMobileView={isMobileView}
                onHideFilter={onFilterClick}
                isBusinessPartner={isBusinessPartner}
                onTypeChange={onTypeChange}
                initialData={InitialData}
                onCareerChange={onCareerChange}
                onWorkLocationChange={onLocationChange}
              />
            </Col>
          )}
          {gridView && (
            <Col xs={24} sm={24} md={18} lg={18} className='pl-3'>
              <div className='employment-data'>
                <Sorter
                  {...reqParams}
                  onChange={onSorterChange}
                  initialData={InitialData}
                  calcData={{
                    totalRecords: TotalRecords,
                    page: reqParams.page,
                    length: dataLength,
                  }}
                  isRelevant={isRelevant}
                />
                <DataGrid
                  {...props}
                  {...reqParams}
                  total={TotalRecords}
                  onChange={onPageChange}
                  initialData={InitialData}
                />
              </div>
            </Col>
          )}
        </Row>
        {!gridView && (
          <RequestErrorLoader
            body={{...InitialData, data: InitialData?.data?.data}}
            overideNoDataContainer={<NoResults />}>
            {InitialData?.data?.data && (
              <div className='pathway-opportunities-section'>
                <SearchResultsCounter
                  className='opportunities-count my-4'
                  currentLength={dataLength}
                  totalResults={TotalRecords}
                  request={InitialData?.request}
                />
                {InitialData?.data?.data.map(d => {
                  const data = {
                    banner_cloudinary: d?.job_post_thumbnail_cloudinary,
                    title: d?.title,
                    tagType: d?.opportunity_type,
                    institute_details: {
                      name: d?.institute_details?.institution_name,
                    },
                  };
                  return (
                    <PathCard
                      enableNavigation
                      data={data}
                      key={d?.opportunity_id}
                      disLogo={false}
                      config={config}
                      target
                    />
                  );
                })}
                {!hideLoadMore && (
                  <div className='text-center'>
                    <Button
                      type='primary'
                      className='events-load-more'
                      onClick={loadMore}>
                      {InitialData?.request ? 'LOADING...' : 'LOAD MORE'}
                    </Button>
                  </div>
                )}
              </div>
            )}
          </RequestErrorLoader>
        )}
      </div>
    </ErrorBoundary>
  );
};

export default EmploymentOpportunites;
