import {Radio} from 'antd';
import {employOpportData} from 'data/occupation.json';

const Types = ({onChange, selectedValue, initialData, isBusinessPartner}) => {
  const EmploymentOptions = [
    {
      title: employOpportData.employmentTypes.jobBoardsTitle,
      value: 'job_boards',
    },
    {
      title: employOpportData.employmentTypes.localJobsTitle,
      value: 'local_jobs',
    },
  ];

  if (isBusinessPartner) {
    EmploymentOptions.shift();
  }

  const setTypeValue =
    selectedValue !== 'job_boards' ? 'local_jobs' : 'job_boards';
  return (
    <div className='employment-types text-left py-2 pb-2'>
      <Radio.Group
        onChange={onChange}
        value={setTypeValue}
        disabled={initialData?.request}>
        {EmploymentOptions.map(({title, value}, idx) => (
          <Radio key={idx} value={value}>
            {title}
          </Radio>
        ))}
      </Radio.Group>
    </div>
  );
};

export default Types;
