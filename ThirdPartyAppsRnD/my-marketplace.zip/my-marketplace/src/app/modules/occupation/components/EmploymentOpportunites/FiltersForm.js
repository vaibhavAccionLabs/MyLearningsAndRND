import {useState, useEffect, useCallback} from 'react';
import {Form, Input, Button, Select, Divider} from 'antd';
import {CloseOutlined} from '@ant-design/icons';
import {FilterAutoComplete} from 'core/components';
import Types from './Types';
import {API} from 'config';
import {employOpportData} from 'data/occupation.json';

const {Option} = Select;

const TypeOptions = [
  {
    title: employOpportData.employmentTypes.jobsTitle,
    value: 'local_jobs',
  },
  {
    title: employOpportData.employmentTypes.apprenticeshipsTitle,
    value: 'apprenticeship',
  },
  {
    title: employOpportData.employmentTypes.internshipsTitle,
    value: 'internship',
  },
  {
    title: employOpportData.employmentTypes.otherTrainingTitle,
    value: 'other',
  },
];

const WorkLocationOptions = [
  {
    title: employOpportData.workLocations.allLocationsText,
    value: 'all',
  },
  {
    title: employOpportData.workLocations.oneLocationText,
    value: 'one_location',
  },
  {
    title: employOpportData.workLocations.remoteLocationsText,
    value: 'remote',
  },
  {
    title: employOpportData.workLocations.hybridLocationsText,
    value: 'hybrid',
  },
];

const RadiusData = [5, 10, 15, 25];

const Radius = ({form}) => {
  useEffect(() => {
    form.setFieldsValue({
      radius: 5,
    });
  }, [form]);

  return (
    <Form.Item label='Within' name='radius'>
      <Select dropdownClassName='search-grid' className='radiusDropdown'>
        {RadiusData.map((value, idx) => (
          <Option value={value} key={idx}>
            {`${value} Miles`}
          </Option>
        ))}
      </Select>
    </Form.Item>
  );
};

const FiltersForm = ({
  form,
  onFinish,
  onFinishFailed,
  filters,
  onReset,
  type,
  isMobileView,
  onHideFilter,
  isBusinessPartner,
  onTypeChange,
  onWorkLocationChange,
  location_type,
  initialData,
  occupationList,
  onCareerChange,
  occupationDetails,
  dispCareerList,
  onlyLocal,
  hideLabels,
  formLabel,
  //reqParams,
}) => {
  let showReset = false;
  const isLocalJob = type !== 'job_boards';
  const autocompleteURL = API.srm.opportunity;
  const [locationForm] = Form.useForm();
  const [careerForm] = Form.useForm();
  const [showRadius, setShowRadius] = useState(false);
  //const [isRemoteDisabled, setIsRemoteDisabled] = useState(false);
  const [isLocationDisabled, setIsLocationDisabled] = useState(false);
  const filterKeys = Object.keys(filters);

  if (filterKeys?.length) {
    filterKeys.map(key => {
      if (filters[key]) {
        showReset = true;
      }
    });
  }

  const resetForms = useCallback(() => {
    form.resetFields();
    locationForm.resetFields();
    careerForm.setFieldsValue({
      career_list: occupationList?.allOccupations?.occupation?.[0]?.uuid || '',
    });
  }, [careerForm, form, locationForm, occupationList]);

  const localStateReset = () => {
    setShowRadius(false);
    setIsLocationDisabled(false);
    //setIsRemoteDisabled(false);
    resetForms();
  };

  const onResetClick = () => {
    localStateReset();
    onReset();
  };

  // const onRemoteChange = e => setIsLocationDisabled(e.target.checked);

  const onLocationChange = useCallback(
    event => {
      const value = event.target.value;
      //setIsRemoteDisabled(value && isLocalJob);
      if (type === 'job_boards') {
        setShowRadius(false);
        const reg = /^\d+$/;
        if (value) {
          showReset = true;
          if (reg.test(value) && value.length >= 2) {
            // Check for number and length > 2
            setShowRadius(true);
          }
        }
      }
    },
    [type],
  );

  useEffect(() => {
    localStateReset();
  }, [type]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (occupationDetails?.data?.occupation_uuid) {
      careerForm.setFieldsValue({
        career_list: occupationDetails?.data?.occupation_uuid,
      });
    }
  }, [careerForm, occupationDetails]);

  return (
    <div className='employment-filters'>
      <h2>{formLabel || employOpportData.filterByHeading}</h2>
      {isMobileView && <CloseOutlined onClick={onHideFilter} />}

      {!isBusinessPartner && !onlyLocal && !isMobileView && (
        <Types
          onChange={onTypeChange}
          selectedValue={type}
          initialData={initialData}
          isBusinessPartner={isBusinessPartner}
        />
      )}

      {dispCareerList && (
        <Form
          form={careerForm}
          layout={hideLabels ? 'horizontal' : 'vertical'}
          name='career_filters'>
          <Form.Item
            name='career_list'
            label={!hideLabels && employOpportData.selectByCareerLabel}>
            <Select
              dropdownClassName='search-grid'
              className='radiusDropdown'
              onChange={onCareerChange}
              value={occupationDetails?.data?.occupation_uuid}>
              {occupationList?.allOccupations?.occupation?.map(
                ({onnet, name, uuid}) => (
                  <Option value={uuid} key={onnet}>
                    {name}
                  </Option>
                ),
              )}
            </Select>
          </Form.Item>
        </Form>
      )}

      {isLocalJob && (
        <>
          <Form
            layout={hideLabels ? 'horizontal' : 'vertical'}
            name='employment_filters'
            initialValues={{
              type: type || 'local_jobs',
            }}>
            <Form.Item label={employOpportData.typeByLabel} name='type'>
              <Select
                className='radiusDropdown'
                value={type}
                onChange={onTypeChange}>
                {TypeOptions.map(({title, value}) => (
                  <Option key={value} value={value}>
                    {title}
                  </Option>
                ))}
              </Select>
            </Form.Item>
          </Form>
          <Form
            layout={hideLabels ? 'horizontal' : 'vertical'}
            name='location_type_filter'>
            <Form.Item
              initialValue={location_type || WorkLocationOptions[0].value}
              label={employOpportData.workLocationLabel}
              name='location_type'>
              <Select
                className='radiusDropdown'
                onChange={onWorkLocationChange}
                value={location_type}>
                {WorkLocationOptions.map(({title, value}) => (
                  <Option key={value} value={value}>
                    {title}
                  </Option>
                ))}
              </Select>
            </Form.Item>
          </Form>
        </>
      )}
      <Divider />
      <Form
        form={form}
        layout='vertical'
        name='employment_filters'
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}>
        {!isBusinessPartner && isLocalJob ? (
          <>
            <FilterAutoComplete
              type='title'
              name='title'
              resetKey={type}
              url={autocompleteURL}
              noResultsText={employOpportData.noResultsFoundTxt}
              placeholder={employOpportData.searchByTitlePlaceholder}
              label={!hideLabels && employOpportData.searchByTitleLabel}
            />
            <FilterAutoComplete
              type='company_name'
              name='company_name'
              resetKey={type}
              url={autocompleteURL}
              noResultsText={employOpportData.noResultsFoundTxt}
              placeholder={employOpportData.searchByCompanyPlaceholder}
              label={!hideLabels && employOpportData.searchByCompanyLabel}
            />
          </>
        ) : (
          <Form.Item
            name='company_name'
            label={!hideLabels && employOpportData.searchByCompanyLabel}>
            <Input placeholder={employOpportData.searchByCompanyPlaceholder} />
          </Form.Item>
        )}

        <Form.Item
          label={!hideLabels && employOpportData.searchByLocationLabel}
          name='location'
          onChange={onLocationChange}>
          <Input
            disabled={isLocationDisabled}
            placeholder={employOpportData.searchByLocationPlaceholder}
          />
        </Form.Item>

        {showRadius && <Radius form={form} />}

        <Form.Item>
          <Button
            type='primary'
            className='btn-purple w-100 mt-3'
            htmlType='submit'>
            {employOpportData.searchBtnTxt}
          </Button>
        </Form.Item>

        {showReset && (
          <div className='reset-filters'>
            <span onClick={onResetClick}>
              {employOpportData.resetFilterBtnTxt}
            </span>
          </div>
        )}
      </Form>
    </div>
  );
};

export default FiltersForm;
