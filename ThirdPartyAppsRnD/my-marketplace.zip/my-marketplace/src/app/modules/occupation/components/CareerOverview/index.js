import React, {Fragment, useState} from 'react';
import {Row, Col, Popover} from 'antd';

import {JobOutlook, ErrorBoundary} from 'core/components';
import LocalSalaryModal from './LocalSalaryModal';

import {hotTechnology, onetinit} from 'assets/images';

import {careerOverviewData} from 'data/occupation.json';

const CareerOverview = ({
  history,
  occupationDetails: {data},
  //jobZoneDetails: {data: {job_zone} = {}},
  appConfig: {isMobileView},
}) => {
  const {
    occupation_name,
    occupation_details: {
      what_they_do,
      on_the_job,
      // education_job_zone,
      education_usually_needed,
      knowledge,
      skills,
      abilities,
      technology,
      personality: {description, element} = {},
    } = {},
  } = data || {};

  //const considerJobZone = job_zone && job_zone[education_job_zone - 1];
  const [localSalaryModal, setLocalSalaryModal] = useState(false);

  const onLocalSalaryInfoClick = () => {
    setLocalSalaryModal(true);
  };

  return (
    <ErrorBoundary
      nameOfComponent='mod-comp-occupation-career-overview'
      showDialog={true}>
      <Row gutter={[52, 8]} className='my-4'>
        <Col lg={12} md={12} sm={24} xs={24} className='overview-content'>
          <h2>{careerOverviewData.whatWouldYouDoTxt}:</h2>
          <p className='mb-4'>{what_they_do}</p>
          <h2>{careerOverviewData.onTheJobTxt}:</h2>
          <ul className='list mb-4'>
            {on_the_job &&
              Array.isArray(on_the_job) &&
              on_the_job.map((point, idx) => {
                return <li key={idx}>{point}</li>;
              })}
          </ul>
        </Col>
        <Col lg={12} md={12} sm={24} xs={24}>
          <JobOutlook
            data={data}
            history={history}
            moduleName='occupation'
            onLocalSalaryInfoClick={onLocalSalaryInfoClick}
          />
          <div className='outerBorder'>
            <div className='header'>
              <div>{careerOverviewData.educNeededTxt}</div>
            </div>
            <div className='content px-4 pt-3 pb-2 education'>
              {education_usually_needed &&
              Array.isArray(education_usually_needed) &&
              education_usually_needed.length > 0 ? (
                <div className='d-flex'>
                  <ul className='list_vertical'>
                    {education_usually_needed &&
                      Array.isArray(education_usually_needed) &&
                      education_usually_needed.map((element, idx) => (
                        <li key={`education-element-${idx}`}>{element}</li>
                      ))}
                  </ul>
                </div>
              ) : (
                <div className='NotAvailable'>
                  {careerOverviewData.noDataTxt}
                </div>
              )}
            </div>
          </div>
        </Col>
      </Row>

      <div className='d-block my-2 mt-4 knowledge'>
        <div className='layout-container'>
          <div className='mb-4 px-2 item'>
            <div className='outerBorder'>
              <div className='header'>
                <div>{careerOverviewData.knowledgeTxt}</div>
              </div>
              <div className='content px-4 pt-3 pb-2'>
                {knowledge &&
                Array.isArray(knowledge) &&
                knowledge.length > 0 ? (
                  knowledge.map(({title, element}, index) => (
                    <Fragment key={`knowledge-${index}`}>
                      <h5>{title}</h5>
                      <ul className='list'>
                        {element.map((el, idx) => (
                          <li key={`knowledge-element-${index}-${idx}`}>
                            {el}
                          </li>
                        ))}
                      </ul>
                    </Fragment>
                  ))
                ) : (
                  <div className='NotAvailable'>
                    {careerOverviewData.noDataTxt}
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className='mb-4 px-2 item'>
            <div className='outerBorder'>
              <div className='header'>
                <div>{careerOverviewData.technologyTxt}</div>
              </div>
              <div className='content px-4 pt-3 pb-2'>
                {technology &&
                Array.isArray(technology) &&
                technology.length > 0 ? (
                  <div>
                    <p>{careerOverviewData.youMightUseTxt}:</p>
                    {technology.map(({title, example}, index) => (
                      <Fragment key={`techno-${index}`}>
                        <h5>{title}</h5>
                        <ul className='list'>
                          {example &&
                            Array.isArray(example) &&
                            example.map(({name, hot_technology}, idx) => (
                              <li key={`technology-${index}-${idx}`}>
                                {name}
                                {hot_technology > 0 && (
                                  <Popover
                                    placement='bottomLeft'
                                    overlayClassName='hot-technology-pop-over'
                                    title={
                                      <div className='hot-technology-title pt-3'>
                                        <Row>
                                          <Col span={3}>
                                            <img
                                              src={hotTechnology}
                                              alt='logo'
                                              className='img-fluid hotTech mx-2'
                                              style={{width: '20px'}}
                                            />
                                          </Col>
                                          <Col span={21}>
                                            <h4>
                                              <span className='highlighter'>
                                                {name}
                                              </span>
                                              {` ${careerOverviewData.hotTechTxt}`}
                                            </h4>
                                          </Col>
                                        </Row>
                                      </div>
                                    }
                                    content={careerOverviewData.popUpContent}
                                    trigger={isMobileView ? 'click' : 'hover'}>
                                    <img
                                      src={hotTechnology}
                                      alt='logo'
                                      className='img-fluid hotTech mx-2'
                                    />
                                  </Popover>
                                )}
                              </li>
                            ))}
                        </ul>
                      </Fragment>
                    ))}
                  </div>
                ) : (
                  <div className='NotAvailable'>
                    {careerOverviewData.noDataTxt}
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className='mb-4 px-2 item'>
            <div className='outerBorder'>
              <div className='header'>
                <div>{careerOverviewData.skillsTxt}</div>
              </div>
              <div className='content px-4 pt-3 pb-2'>
                {skills && Array.isArray(skills) && skills.length > 0 ? (
                  skills.map(({title, element}, index) => (
                    <Fragment key={`skill-${index}`}>
                      <h5>{title}</h5>
                      <ul className='list'>
                        {element.map((el, idx) => (
                          <li key={`skill-element-${index}-${idx}`}>{el}</li>
                        ))}
                      </ul>
                    </Fragment>
                  ))
                ) : (
                  <div className='NotAvailable'>
                    {careerOverviewData.noDataTxt}
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className='mb-4 px-2 item'>
            <div className='outerBorder'>
              <div className='header'>
                <div>{careerOverviewData.personalityTxt}</div>
              </div>
              <div className='content px-4 pt-3 pb-2'>
                <p>{description}</p>
                {element && Array.isArray(element) && element.length > 0 ? (
                  <>
                    <p>{careerOverviewData.theyDoWellTxt}:</p>
                    <ul className='list_vertical multi-column'>
                      {element &&
                        Array.isArray(element) &&
                        element.map((el, idx) => (
                          <li key={`personality-${idx}`}>{el}</li>
                        ))}
                    </ul>
                  </>
                ) : (
                  <div className='NotAvailable'>
                    {careerOverviewData.noDataTxt}
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className='mb-4 px-2 item'>
            <div className='outerBorder'>
              <div className='header'>
                <div>{careerOverviewData.abilitiesTxt}</div>
              </div>
              <div className='content px-4 pt-3 pb-2'>
                {abilities &&
                Array.isArray(abilities) &&
                abilities.length > 0 ? (
                  abilities.map(({title, element}, index) => (
                    <Fragment key={`ability-${index}`}>
                      <h5>{title}</h5>
                      <ul className='list'>
                        {element.map((el, idx) => (
                          <li key={`ability-element-${index}-${idx}`}>{el}</li>
                        ))}
                      </ul>
                    </Fragment>
                  ))
                ) : (
                  <div className='NotAvailable'>
                    {careerOverviewData.noDataTxt}
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className='mb-4 px-2 item'>
            <div className='onet'>
              <div className='p-3'>
                <img src={onetinit} alt='logo' className='img-fluid' />
                <p>{careerOverviewData.siteInfo}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      {localSalaryModal && (
        <LocalSalaryModal
          onCancel={() => setLocalSalaryModal(false)}
          occupationName={occupation_name}
        />
      )}
    </ErrorBoundary>
  );
};

export default CareerOverview;
