//Sharable Module from Module - Events
import {Events} from 'app/modules';

const CareerEvents = props => (
  <div className='careerEvents'>
    <Events {...props} category='occupation_name' name={props?.params?.query} />
  </div>
);

export default CareerEvents;
