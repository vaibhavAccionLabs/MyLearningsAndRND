import {connect} from 'react-redux';
import {useHistory} from 'react-router-dom';

import {AppBreadcrumb, ErrorBoundary} from 'core/components';
import {useAuth} from 'core/hooks';

import {openLoginScreen} from 'redux/modules/auth';

import style from './style.module.less';
import {semiCircle} from 'assets/images';

import {
  bannerData,
  breadcrumbData,
  headingTxt,
  content,
  letsGetsStartedTxt,
  btnTxt,
} from 'data/studentProfile.json';

const StudentProfile = props => {
  const [token] = useAuth();
  const history = useHistory();

  const openProfile = () => {
    const path = '/settings/profile';
    const navigate = history.push;
    token
      ? navigate(path)
      : props.openLoginScreen({
          callback: () => navigate(path),
        });
  };

  const renderList = list => (
    <ul className={style.radiant_list}>
      {list.map((item, idx) => (
        <li key={idx}>{item}</li>
      ))}
    </ul>
  );

  const renderContent = ({title, list, align, imgSrc}, className = '', key) => (
    <div
      key={key}
      className={style.curve_effect}
      data-cy='build-profile-content'>
      {align == 'right' && imgSrc && (
        <div className={style.curve_right} data-cy='profile-left-image'>
          <img src={imgSrc} alt='thumb' />
        </div>
      )}
      <div className={`${style.employers_cnt} ${className}`}>
        <div>
          <h4
            dangerouslySetInnerHTML={{
              __html: title,
            }}
          />
          {renderList(list)}
        </div>
      </div>
      {align == 'left' && imgSrc && (
        <div
          className={`${style.curve_left} ${style.lastChild}`}
          data-cy='profile-right-image'>
          <img src={imgSrc} alt='thumb' />
          <img src={semiCircle} alt='thumb' className={style.rgt_circle} />
        </div>
      )}
    </div>
  );

  return (
    <>
      <AppBreadcrumb dataList={breadcrumbData} />

      <div className={style.student_banner} data-cy='build-profile-banner'>
        <header className={` ${style.studbanner_cnt}`}>
          <h1>{bannerData.title}</h1>
          <h5>{bannerData.subTitle}</h5>
          <button
            className='ant-btn ant-btn-primary'
            type='button'
            onClick={openProfile}>
            {bannerData.btnTxt}
          </button>
        </header>
      </div>

      <ErrorBoundary
        nameOfComponent='module-build-student-profile'
        typeOfUi='subPage'>
        <div
          className={style.student_container}
          data-cy='build-profile-container'>
          <h1>{headingTxt}</h1>
          {Object.keys(content).map(key =>
            renderContent(
              content[key],
              content[key]?.align == 'right' ? style.right : '',
              key,
            ),
          )}
          <div className='text-center' data-cy='start-building-profile-btn'>
            <h1 className='mb-2 mt-5'>{letsGetsStartedTxt}</h1>
            <button
              className='ant-btn btn-purple  mb-5'
              type='button'
              onClick={openProfile}>
              {btnTxt}
            </button>
          </div>
        </div>
      </ErrorBoundary>
    </>
  );
};

const mapStateToProps = state => ({});

export default connect(mapStateToProps, {openLoginScreen})(StudentProfile);
