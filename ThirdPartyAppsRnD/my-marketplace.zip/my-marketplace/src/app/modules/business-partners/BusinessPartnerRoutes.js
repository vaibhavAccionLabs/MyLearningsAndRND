import {SubRouter} from 'core/components';

const BusinessPartnerRoutes = ({modules}) => (
  <SubRouter modules={modules} defaultRedirection='/business-partner' />
);

export default BusinessPartnerRoutes;
