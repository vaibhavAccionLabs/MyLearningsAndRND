//Sharable Module from Module - Events
import {Events} from 'app/modules';

const PartnerEvents = props => (
  <div className='partnerEvents'>
    <Events {...props} category='bp_name' name={props?.businessPartnerName} />
  </div>
);

export default PartnerEvents;
