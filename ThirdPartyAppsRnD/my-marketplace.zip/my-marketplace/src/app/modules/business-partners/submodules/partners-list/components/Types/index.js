import {Radio} from 'antd';
import {partnersListData} from 'data/business-partners.json';

const Types = ({onChange, selectedValue, initialData}) => {
  const {
    filtersFormStaticData: {radioListLabels},
  } = partnersListData;

  const setTypeValue =
    selectedValue !== 'local_jobs' ? 'job_boards' : 'local_jobs';

  return (
    <div className='employment-types py-2 pb-4'>
      <Radio.Group
        onChange={onChange}
        value={setTypeValue}
        disabled={initialData?.request}>
        {radioListLabels.map(({label, key}, idx) => (
          <Radio key={idx} value={key}>
            {label}
          </Radio>
        ))}
      </Radio.Group>
    </div>
  );
};

export default Types;
