import {connect} from 'react-redux';

import {
  getJobBoards,
  fetchJobBoards,
  clearJobBoards,
  getPublicInsightJobs,
  fetchPublicInsightJobs,
  clearPublicInsightJobs,
} from 'redux/modules/jobs';
import {getOccupations, fetchOccupations} from 'redux/modules/occupation';
import {
  fetchBusinessPartners,
  resetBusinessPartners,
  getBusinessPartners,
} from 'redux/modules/business-partner';
import {getAppConfig} from 'redux/modules/general';

import PartnersList from './partnersList';

const BusinessPartnersList = props => <PartnersList {...props} />;

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  jobBoards: getJobBoards(state),
  occupations: getOccupations(state),
  publicInsightJobs: getPublicInsightJobs(state),
  businessPartnersList: getBusinessPartners(state),
});

export default connect(mapStateToProps, {
  fetchJobBoards,
  clearJobBoards,
  fetchOccupations,
  fetchBusinessPartners,
  resetBusinessPartners,
  fetchPublicInsightJobs,
  clearPublicInsightJobs,
})(BusinessPartnersList);
