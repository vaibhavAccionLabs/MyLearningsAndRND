import {useState, useEffect} from 'react';
import {CloseOutlined} from '@ant-design/icons';
import {Form, Input, Select, Divider, Button} from 'antd';
import debounce from 'debounce';
import {FilterAutoComplete} from 'core/components';
import Types from '../Types';
import {API} from 'config';

import {partnersListData} from 'data/business-partners.json';

const FiltersForm = ({
  type,
  form,
  filters,
  onReset,
  onFinish,
  reqParams,
  hideLabels,
  occupations,
  initialData,
  isMobileView,
  onHideFilter,
  onTypeChange,
  onFinishFailed,
  onFilterChange,
}) => {
  const [occupationData, setOccupationData] = useState(occupations?.data);

  useEffect(() => {
    if (occupations?.data) {
      setOccupationData(occupations?.data);
    }
  }, [occupations]);

  let showReset = false;
  let defOccupationValue =
    occupations?.data?.length && occupations?.data[0].occupation_onnet;
  const {filtersFormStaticData} = partnersListData;
  const filterKeys = Object.keys(filters);

  if (filterKeys?.length) {
    filterKeys.map(key => {
      if (filters[key]) {
        showReset = true;
      }
    });
  }

  const autocompleteURL = API.srm.opportunity;

  const onCareerSearch = e => {
    const {
      target: {value = ''},
    } = e || {};
    const newOccupationData = value.length
      ? occupations?.data?.filter(data =>
          data.occupation_name?.toLowerCase().includes(value.toLowerCase()),
        )
      : occupations?.data || [];

    setOccupationData(newOccupationData);
  };

  return (
    <>
      <div className='opportunities-filters'>
        <h2>{filtersFormStaticData.heading}</h2>
        {isMobileView && <CloseOutlined onClick={onHideFilter} />}
        {!isMobileView && (
          <Types
            onChange={onTypeChange}
            initialData={initialData}
            selectedValue={type}
          />
        )}
        <Form
          form={form}
          layout='vertical'
          onFinish={onFinish}
          name='opportunities_filters'
          data-cy='opportunities-filter-form'
          onFinishFailed={onFinishFailed}>
          {type !== 'local_jobs' && (
            <>
              <Form.Item
                data-cy='opportunities-filter-form-item'
                label={!hideLabels && filtersFormStaticData.searchByCareerLabel}
                name='career'>
                <Select
                  onChange={e => onFilterChange(e, 'occupation_onnet')}
                  className='radiusDropdown'
                  dropdownClassName='search-grid'
                  defaultValue={defOccupationValue}
                  placeholder={filtersFormStaticData.careerPlaceholder}
                  dropdownRender={menu => (
                    <div className='mx-2'>
                      <Input
                        placeholder={
                          filtersFormStaticData.searchCareerPlaceholder
                        }
                        allowClear
                        className='my-1'
                        onChange={debounce(onCareerSearch, 300)}
                      />
                      {menu}
                    </div>
                  )}>
                  {occupationData?.map(
                    ({occupation_onnet, occupation_name}) => (
                      <Select.Option
                        value={occupation_onnet}
                        key={occupation_onnet}>
                        {occupation_name}
                      </Select.Option>
                    ),
                  )}
                </Select>
              </Form.Item>
              <Divider />
            </>
          )}

          {type !== 'job_boards' ? (
            <FilterAutoComplete
              resetKey={type}
              url={autocompleteURL}
              dataCY='opportunities-filter-form-item'
              noResultsText={filtersFormStaticData.noResultsFoundTxt}
              type='company_name'
              name='company_name'
              placeholder={filtersFormStaticData.companyInputPlaceholder}
              label={!hideLabels && filtersFormStaticData.searchByCompanyLabel}
            />
          ) : (
            <Form.Item
              name='company_name'
              label={!hideLabels && filtersFormStaticData.searchByCompanyLabel}>
              <Input
                placeholder={filtersFormStaticData.companyInputPlaceholder}
              />
            </Form.Item>
          )}

          <Form.Item
            label={!hideLabels && filtersFormStaticData.searchByLocationLabel}
            data-cy='opportunities-filter-form-item'
            name='location'>
            <Input
              placeholder={filtersFormStaticData.locationInputPlaceholder}
            />
          </Form.Item>

          <Form.Item>
            <Button
              type='primary'
              className='btn-purple w-100'
              data-cy='opportunities-filter-submit-btn'
              htmlType='submit'>
              {filtersFormStaticData.searchBtnTxt}
            </Button>
          </Form.Item>

          {showReset && (
            <div className='reset-filters'>
              <span onClick={onReset}>
                {filtersFormStaticData.resetFilterBtnTxt}
              </span>
            </div>
          )}

          {isMobileView && (
            <div className='mobile-filter-btn'>
              <Button className='clear-all apply-mob' onClick={onHideFilter}>
                <span>{filtersFormStaticData.applyBtnTxt}</span>
              </Button>
              <Button className='btn_close apply-mob' onClick={onHideFilter}>
                <span>{filtersFormStaticData.closeBtnTxt}</span>
              </Button>
            </div>
          )}
        </Form>
      </div>
    </>
  );
};

export default FiltersForm;
