import {useState, useEffect} from 'react';
import {useHistory} from 'react-router-dom';
import {Form, Row, Col, Badge} from 'antd';
import {FilterOutlined} from '@ant-design/icons';
import isObject from 'lodash/isObject';
import isEmpty from 'lodash/isEmpty';

import {useEnableDisableScroll} from 'core/hooks';
import {AppBreadcrumb, ErrorBoundary, RibbonNavigator} from 'core/components';
import {queryStringParse} from 'core/utils';
import {FiltersForm, Types} from './components';

import LocalEmployers from './localEmployers';
import NationalJobs from './nationalJobs';

import {partnersListData} from 'data/business-partners.json';

import './style.less';

const PartnersList = props => {
  const {
    jobBoards,
    occupations,
    fetchJobBoards,
    clearJobBoards,
    fetchOccupations,
    businessPartnersList,
    fetchBusinessPartners,
    resetBusinessPartners,
    appConfig: {isMobileView},
  } = props;
  const {bannerData, breadcrumbData} = partnersListData;
  const history = useHistory();
  const {
    location: {search, pathname},
  } = history;
  const {type: paramFilterType} = queryStringParse(search);
  const defaultReqParams = {
    occupation_onnet:
      occupations?.data?.length && occupations?.data[0].occupation_onnet,
    location_type: 'all',
    sort: 'date_desc',
    page: 1,
  };
  const {isFilterVisible, onFilterClick} = useEnableDisableScroll();
  const [filters, setFilters] = useState({});
  const [reqParams, setReqParams] = useState(defaultReqParams);
  const [filterType, setFilterType] = useState(paramFilterType || 'local_jobs');

  useEffect(() => {
    setFilterType(paramFilterType || 'local_jobs');
  }, [paramFilterType]);

  useEffect(async () => {
    // check only for public insight jobs
    if (filterType === 'job_boards') {
      if (!occupations?.data?.length) {
        await fetchOccupations();
      } else {
        const Obj = {
          occupation_onnet:
            occupations?.data?.length && occupations?.data[0].occupation_onnet,
          location_type: 'all',
          sort: 'date_desc',
          page: 1,
        };
        setFilters({});
        form.resetFields();
        refetchData(Obj, {});
      }
    }
  }, [occupations?.data]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const Obj = Object.assign({}, reqParams, defaultReqParams);
    setReqParams(Obj);
    setFilters({});
    form.resetFields();
    !jobBoards?.data &&
      Obj?.occupation_onnet &&
      filterType === 'job_boards' &&
      fetchJobBoards(Obj, filters);
    return () => {
      clearJobBoards();
    };
  }, [fetchJobBoards]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const Obj = Object.assign({}, reqParams, defaultReqParams);
    setReqParams(Obj);
    setFilters({});
    form.resetFields();
    !businessPartnersList.data &&
      filterType === 'local_jobs' &&
      fetchBusinessPartners(Obj, filters);
    return () => {
      resetBusinessPartners();
    };
  }, [fetchBusinessPartners]); // eslint-disable-line react-hooks/exhaustive-deps

  const [form] = Form.useForm();

  const onTypeChange = async e => {
    let value = e;
    if (e && isObject(e)) {
      value = e.target.value;
    }
    setFilters({});
    form.resetFields();
    setFilterType(value);
    if (value === 'job_boards') {
      !occupations?.data?.length && (await fetchOccupations());
    }
    const Obj = Object.assign({}, defaultReqParams, {
      occupation_onnet:
        occupations?.data?.length && occupations?.data[0].occupation_onnet,
      location_type: 'all',
      sort: 'date_desc',
      page: 1,
    });
    setReqParams(Obj);
    apiCall(value, Obj, {});
    onFilterTypeChange(value);
  };

  const onFilterTypeChange = value => {
    history.push(`${pathname}?type=${value}`);
  };

  const apiCall = (type, Obj, filters = null, loadMore = false) => {
    if (type === 'local_jobs') {
      fetchBusinessPartners(Obj, filters, loadMore);
      return;
    }
    if (type === 'job_boards') {
      Obj?.occupation_onnet && fetchJobBoards(Obj, filters);
      return;
    }
    fetchBusinessPartners(Obj, filters, loadMore);
  };

  const refetchData = (Obj, filters, loadMore) => {
    setReqParams(Obj);
    apiCall(filterType, Obj, filters, loadMore);
  };

  const onFinish = values => {
    let filterApply = false;
    if (values) {
      const filterKeys = Object.keys(values);
      filterKeys.map(key => {
        if (values[key] || values[key] === '') {
          filterApply = true;
        }
      });
      if (filterApply) {
        const Obj = Object.assign({}, reqParams, {
          sort: 'date_desc',
          page: 1,
        });
        setFilters(values);
        if (values?.location_type) {
          Obj['location_type'] = values.location_type;
          delete values['location_type'];
        }
        if (values?.career) {
          Obj['occupation_onnet'] = values.career;
          delete values['career'];
        }
        refetchData(Obj, values);
      }
    }
  };

  // to handle error conditions
  const onFinishFailed = errorInfo => {
    console.log('Failed:', errorInfo);
  };

  const onFilterReset = () => {
    const Obj = Object.assign({}, reqParams);
    setFilters({});
    filterType === 'local_jobs'
      ? form.resetFields()
      : form.setFieldsValue({title: '', company_name: '', location: ''});
    refetchData(Obj, null);
  };

  const onFilterChange = (e, key) => {
    let value = e;
    if (e && isObject(e)) {
      value = e.target.value;
    }
    const Obj = Object.assign({}, reqParams);
    Obj[key] = value;
    refetchData(Obj, filters);
  };

  const renderFilters = () => (
    <FiltersForm
      form={form}
      type={filterType}
      filters={filters}
      onFinish={onFinish}
      reqParams={reqParams}
      onReset={onFilterReset}
      occupations={occupations}
      onTypeChange={onTypeChange}
      isMobileView={isMobileView}
      onHideFilter={onFilterClick}
      onFinishFailed={onFinishFailed}
      onFilterChange={onFilterChange}
    />
  );

  return (
    <>
      <header data-cy='open-jobs-banner' className='openJobsBanner'>
        <div className='header_bannerText'>
          <div>
            <h1>{bannerData.title}</h1>
            <h5>{bannerData.subTitle}</h5>
          </div>
        </div>
      </header>
      <RibbonNavigator
        heading='Headline Your Skills'
        btnTxt='BUILD YOUR PROFILE'
        btnPath='/build/student-profile'>
        <span>
          Build a marketable skills profile and job seeker resume and connect
          with future employers
        </span>
      </RibbonNavigator>
      {/* <AppBreadcrumb dataList={breadcrumbData} /> */}
      <div className='mx-3 my-5 mt-3'>
        <ErrorBoundary
          nameOfComponent='module-partners-list'
          typeOfUi='subPage'>
          <div className='opportunitiesContainer'>
            {isMobileView && (
              <div
                className='filter-container'
                data-cy='mobile-filter-container'>
                <Types onChange={onTypeChange} selectedValue={filterType} />
                <div className='filterUpcoming pr-3'>
                  <span className='w_text'>Filter Results</span>
                  <Badge dot={!isEmpty(filters)}>
                    <FilterOutlined onClick={onFilterClick} />
                  </Badge>
                </div>
                {isFilterVisible && (
                  <div className='enable-mobile-filter'>{renderFilters()}</div>
                )}
              </div>
            )}
            <Row>
              {!isMobileView && (
                <Col xs={24} sm={24} md={6} lg={6} data-cy='filter-container'>
                  {renderFilters()}
                </Col>
              )}
              <Col xs={24} sm={24} md={18} lg={18} className='pl-3'>
                <div className='opportunity-content' data-cy='filtered-content'>
                  {filterType === 'job_boards' ? (
                    <NationalJobs
                      refetchData={refetchData}
                      reqParams={reqParams}
                      filters={filters}
                      type={filterType}
                      {...props}
                    />
                  ) : (
                    <LocalEmployers
                      refetchData={refetchData}
                      reqParams={reqParams}
                      filters={filters}
                      {...props}
                    />
                  )}
                </div>
              </Col>
            </Row>
          </div>
        </ErrorBoundary>
      </div>
    </>
  );
};

export default PartnersList;
