import {useState, useEffect} from 'react';
import {useHistory} from 'react-router-dom';

import {queryStringParse} from 'core/utils';
import {AppBreadcrumb} from 'core/components';

import {Banner, WelcomeAboardModal} from './sharedComponents';
import {EmployerPartnerData, EducationPartnerData} from 'data/partner';

import './style.less';

const ALLOWED_PARTNER_TYPES = ['employer', 'educator'];

const EmployerPartner = () => {
  const history = useHistory();
  const {
    location: {search},
  } = history;
  const {partnerType} = queryStringParse(search);
  const [openWelcomeAboardModal, setOpenWelcomeAboardModal] = useState(false);

  const toggleWelcomeAboard = () => {
    setOpenWelcomeAboardModal(!openWelcomeAboardModal);
  };
  const isEmployer = partnerType === 'employer';

  const DATA_TYPE = isEmployer ? EmployerPartnerData : EducationPartnerData;

  useEffect(() => {
    if (!partnerType || !ALLOWED_PARTNER_TYPES.includes(partnerType)) {
      history.replace('/');
    }
  }, [history, partnerType]);

  return partnerType ? (
    <div className='employer-partner'>
      <AppBreadcrumb
        dataList={[
          {
            name: DATA_TYPE.breadcrumbText,
          },
        ]}
      />
      <Banner onBecomePartner={toggleWelcomeAboard} isEmployer={isEmployer} />
      <div
        className='employer-partner-content contentContainer'
        data-cy='partner-content'>
        {DATA_TYPE?.PartnerContent &&
          Array.isArray(DATA_TYPE?.PartnerContent) &&
          DATA_TYPE?.PartnerContent.map(
            ({heading = '', subHeading = '', subSection}, index) => (
              <div
                key={`partnerItem-${index}`}
                className={`wrapper-section px-5 ${
                  index % 2 == 0 ? 'leftSide_align' : 'rightSide_align'
                }`}>
                <div
                  className={`main-section ${
                    index % 2 == 0 ? 'rightSide_curve' : 'leftSide_curve'
                  }`}>
                  <div className='cnt'>
                    <h2>{heading}</h2>
                    <span className='divideLine'></span>
                    <p>{subHeading}</p>
                  </div>
                </div>
                {subSection &&
                  Array.isArray(subSection) &&
                  subSection.map(
                    ({image, heading = '', subHeading = ''}, idx) => (
                      <div
                        key={`subSection-${index}-${idx}`}
                        className='sub-section'>
                        <div className='left imgAlign'>
                          {index % 2 == 0 ? (
                            <img src={image} alt='sub-section-img' />
                          ) : (
                            <>
                              <h3>{heading}</h3>
                              <p>{subHeading}</p>
                            </>
                          )}
                        </div>
                        <div className='right img_rightAlign'>
                          {index % 2 == 0 ? (
                            <>
                              <h3>{heading}</h3>
                              <p>{subHeading}</p>
                            </>
                          ) : (
                            <img src={image} alt='sub-section-img' />
                          )}
                        </div>
                      </div>
                    ),
                  )}
              </div>
            ),
          )}
        <div className='employer-partner-access' data-cy='partner-access'>
          <h2>{DATA_TYPE?.AdditionalContent?.heading}</h2>
          <h3>{DATA_TYPE?.AdditionalContent?.subHeading}</h3>
          <p>{DATA_TYPE?.AdditionalContent?.description}</p>
          <button
            className='ant-btn btn-purple mt-4 mb-5'
            type='button'
            onClick={toggleWelcomeAboard}>
            {DATA_TYPE?.AdditionalContent?.btnTxt}
          </button>
        </div>
      </div>
      <WelcomeAboardModal
        isEmployer={isEmployer}
        onClose={toggleWelcomeAboard}
        visible={openWelcomeAboardModal}
      />
    </div>
  ) : (
    <></>
  );
};

export default EmployerPartner;
