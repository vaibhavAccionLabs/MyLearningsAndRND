//Sharable components from Module - Occupation
import {EmploymentOpportunites} from 'app/modules/occupation/components';

const OpenJobs = props => {
  const {businessPartnerName, params, history} = props;
  const onEmploymentTypeChange = value => {
    const {activetab} = params || {};
    history.push(
      `/business-partners/${businessPartnerName}?activetab=${activetab}&type=${value}`,
    );
  };

  return (
    <EmploymentOpportunites
      {...props}
      onChange={onEmploymentTypeChange}
      params={params}
      isBusinessPartner={true}
    />
  );
};

export default OpenJobs;
