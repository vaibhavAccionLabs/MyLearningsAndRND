import {useEffect} from 'react';
import {connect} from 'react-redux';
import {useHistory, useParams} from 'react-router-dom';

import {queryStringParse} from 'core/utils';

import {getAppConfig} from 'redux/modules/general';

import {
  fetchBusinessPartnerDetails,
  getBusinessPartnerDetails,
} from 'redux/modules/business-partner';

import {
  fetchLocalJobs,
  fetchJobBoards,
  getLocalJobs,
  getJobBoards,
  clearLocalJobs,
  clearJobBoards,
} from 'redux/modules/jobs';

import {
  fetchPrograms,
  getPrograms,
  clearPrograms,
} from 'redux/modules/programs';

import PartnerDetails from './partnerDetails';

const BusinessPartnerDetails = props => {
  const {businessPartnerDetails, fetchBusinessPartnerDetails} = props;
  const {bpName} = useParams();
  const history = useHistory();
  const {
    location: {pathname, search},
  } = history;

  const params = queryStringParse(search);

  useEffect(() => {
    if (bpName) {
      fetchBusinessPartnerDetails(bpName);
    }
  }, [bpName, fetchBusinessPartnerDetails]);

  return (
    <PartnerDetails
      {...props}
      businessPartnerName={bpName}
      params={params}
      history={history}
    />
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  businessPartnerDetails: getBusinessPartnerDetails(state),
  programs: getPrograms(state),
  localJobs: getLocalJobs(state),
  jobBoards: getJobBoards(state),
});

export default connect(mapStateToProps, {
  fetchBusinessPartnerDetails,
  fetchPrograms,
  fetchLocalJobs,
  fetchJobBoards,
  clearPrograms,
  clearLocalJobs,
  clearJobBoards,
})(BusinessPartnerDetails);
