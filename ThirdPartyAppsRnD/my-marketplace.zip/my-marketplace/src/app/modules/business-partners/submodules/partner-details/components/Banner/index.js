import {defaultbannerprofile, noCollageLogo} from 'assets/images';
import {LazyImage} from 'core/components';
import {getBanner} from 'core/utils';

const Banner = props => {
  const {
    businessPartnerDetails: {data, request},
    appConfig: {isMobileView},
  } = props;
  const {bp_details} = data || {};

  let bpData = null;
  if (bp_details && Array.isArray(bp_details) && bp_details.length) {
    bpData = bp_details[0];
  }

  return (
    !request && (
      <div className='company-detail-banner'>
        <LazyImage
          defaultImage={defaultbannerprofile}
          src={getBanner(bpData?.banner_cloudinary, {
            quality: 80,
            e_sharpen: 100,
            width: isMobileView ? window.screen.width : 1250,
            height: isMobileView ? 150 : 250,
          })}
          alt='banner'
          className='img-fluid'
        />
        <span>
          <LazyImage
            imageType='logo'
            defaultImage={noCollageLogo}
            src={bpData?.logo_cloudinary}
            alt='bp_logo'
            className='img-fluid'
          />
        </span>
      </div>
    )
  );
};

export default Banner;
