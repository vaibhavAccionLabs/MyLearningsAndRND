import {
  ErrorBoundary,
  NoBusinessPartners,
  RequestErrorLoader,
  SearchResultsCounter,
} from 'core/components';
import {calculateNoOfRecordsFetched} from 'core/utils';
import DataGrid from '../../../occupation/components/EmploymentOpportunites/DataGrid';

const NationalJobs = props => {
  const {jobBoards, refetchData, reqParams, filters, type} = props;
  const dataLength = jobBoards?.data?.datalength || 0;
  const TotalRecords = jobBoards?.data?.Jobcount || 0;
  const calcData = {
    totalRecords: TotalRecords,
    page: reqParams.page,
    length: dataLength,
  };

  const onPageChange = page => {
    const Obj = Object.assign({}, reqParams, {page});
    refetchData(Obj, filters);
    window.scrollTo({
      top: 300,
      behavior: 'smooth',
    });
  };

  return (
    <div className='my-5 mt-3'>
      <ErrorBoundary nameOfComponent='module-partners-list' typeOfUi='subPage'>
        <RequestErrorLoader
          body={{
            jobBoards,
            request: false,
          }}
          overideNoDataContainer={<NoBusinessPartners />}>
          <SearchResultsCounter
            className='bpRecordCount'
            currentLength={calculateNoOfRecordsFetched(calcData, dataLength)}
            totalResults={TotalRecords}
            request={jobBoards?.request}
          />
          <DataGrid
            {...props}
            type={type}
            {...reqParams}
            total={TotalRecords}
            onChange={onPageChange}
            initialData={jobBoards}
          />
        </RequestErrorLoader>
      </ErrorBoundary>
    </div>
  );
};

export default NationalJobs;
