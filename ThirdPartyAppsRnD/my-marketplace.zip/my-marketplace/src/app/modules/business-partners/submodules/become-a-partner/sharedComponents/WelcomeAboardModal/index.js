import {useEffect} from 'react';
import {connect} from 'react-redux';
import {Modal, Button, Form, Input, Row, Col} from 'antd';

import {CountField, ErrorBoundary} from 'core/components';
import {PATTERN} from 'core/regex';

import {successTick, warningIcon} from 'assets/images';

import {
  becomeBusinessPartner,
  getBecomeBusinessPartnerData,
  clearBecomeBusinessPartnerData,
} from 'redux/modules/business-partner';

import {WelcomeModalContent, WelcomeSuccessContent} from 'data/partner';

import style from './style.module.less';

import './style.less';

const WelcomeAboardModal = ({
  visible,
  onClose,
  isEmployer,
  becomeBusinessPartner,
  clearBecomeBusinessPartnerData,
  becomeBusinessPartnerData: {request, data, error},
}) => {
  const [form] = Form.useForm();
  const onSubmitWelcomeAboardForm = values => {
    values['ins_type'] = isEmployer ? 'Employer' : 'Institution'; // indication of partner type
    becomeBusinessPartner(values);
  };

  useEffect(() => {
    if (!visible) {
      form?.resetFields();
      if (data) {
        clearBecomeBusinessPartnerData();
      }
    }
  }, [visible]); // eslint-disable-line react-hooks/exhaustive-deps

  const WelcomeAboardSuccess = () => (
    <div className={`${style.title_container} mb-4`}>
      <img src={successTick} alt='mail icon' className='mb-4' />
      <div className={style.color_header}>{WelcomeSuccessContent?.heading}</div>
      <div className={`${style.description} ${style.bold}`}>
        {WelcomeSuccessContent?.description}
      </div>
      <Button type='primary' className={style.close_btn} onClick={onClose}>
        {WelcomeSuccessContent?.btnTxt}
      </Button>
    </div>
  );

  const WelcomeAboardForm = () => {
    const onSubmit = values => {
      onSubmitWelcomeAboardForm({...values});
    };

    const errorDisplay = () => {
      let displaySupportLink = false;
      let ERROR_MSG = WelcomeModalContent?.genericErrorMessage;
      if (data) {
        displaySupportLink = true;
        ERROR_MSG = isEmployer
          ? WelcomeModalContent?.BRNOrEmailIDErrorMessage
          : WelcomeModalContent?.AccreditingOrgOrEmailIDErrorMessage;
      }
      return error ? (
        <p className={style.error_message}>
          <img src={warningIcon} alt='warning-icon' />
          {ERROR_MSG}
          {displaySupportLink && (
            <a className={style.anchor_link}>
              {WelcomeModalContent?.supportEmail}
            </a>
          )}
        </p>
      ) : (
        <></>
      );
    };

    const partnerFormHeader = () => (
      <div className={style.title_container}>
        <div className={style.title} data-cy='welcome-aboard-heading'>
          {WelcomeModalContent?.heading}
        </div>
        <div className={style.description} data-cy='welcome-aboard-desc'>
          {WelcomeModalContent?.subHeading}
        </div>
        {errorDisplay()}
      </div>
    );

    const partnerLabel = isEmployer ? 'Company' : 'Institution';
    const formData = WelcomeModalContent.formData[partnerLabel];

    return (
      <>
        <ErrorBoundary nameOfComponent='welcome-aboard-form'>
          {partnerFormHeader()}
          <Form
            form={form}
            layout='vertical'
            onFinish={onSubmit}
            data-cy='welcome-aboard-form'>
            <Form.Item
              name='name'
              label={formData.name.label}
              className={style.field_input}
              rules={[
                {
                  required: true,
                  message: formData.name.requiredMessage,
                },
              ]}
              data-cy='welcome-aboard-form-item'>
              <CountField
                placeholder={formData.name.placeholder}
                className='f-input'
                fieldtype='Input'
                maxLength={100}
                showcount={false}
              />
            </Form.Item>
            <Form.Item
              name='address'
              label={formData.address.label}
              className={style.field_input}
              rules={[
                {
                  required: true,
                  message: formData.address.requiredMessage,
                },
              ]}
              data-cy='welcome-aboard-form-item'>
              <CountField
                placeholder={formData.address.placeholder}
                className='f-input'
                fieldtype='Input'
                maxLength={100}
                showcount={false}
              />
            </Form.Item>
            <Form.Item
              name='website'
              label={formData.website.label}
              className={style.field_input}
              rules={[
                {
                  required: true,
                  message: formData.website.requiredMessage,
                },
                {
                  pattern: PATTERN.Website,
                  message: formData.website.validationMessage,
                },
              ]}
              data-cy='welcome-aboard-form-item'>
              <Input
                className='f-input'
                size='large'
                placeholder={formData.website.placeholder}
              />
            </Form.Item>
            <div
              className={style.contact_name}
              data-cy='welcome-aboard-form-item'>
              <div>
                <label>{formData.firstName.label}</label>
              </div>
              <Row gutter={16}>
                <Col xs={24} sm={24} md={12} lg={12}>
                  <Form.Item
                    name='contact_first_name'
                    className={style.field_input}
                    rules={[
                      {
                        required: true,
                        message: formData.firstName.requiredMessage,
                      },
                    ]}>
                    <CountField
                      placeholder={formData.firstName.placeholder}
                      className='f-input'
                      fieldtype='Input'
                      maxLength={100}
                      showcount={false}
                    />
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={12} lg={12}>
                  <Form.Item
                    name='contact_last_name'
                    className={style.field_input}
                    rules={[
                      {
                        required: true,
                        message: formData.lastName.requiredMessage,
                      },
                    ]}>
                    <CountField
                      placeholder={formData.lastName.placeholder}
                      className='f-input'
                      fieldtype='Input'
                      maxLength={100}
                      showcount={false}
                    />
                  </Form.Item>
                </Col>
              </Row>
            </div>
            <Form.Item
              name='contact_email'
              label={formData.email.label}
              className={style.field_input}
              rules={[
                {
                  required: true,
                  message: formData.email.requiredMessage,
                },
                {
                  pattern: PATTERN.Email,
                  message: formData.email.validationMessage,
                },
              ]}
              data-cy='welcome-aboard-form-item'>
              <Input
                className='f-input'
                size='large'
                placeholder={formData.email.placeholder}
              />
            </Form.Item>
            <Form.Item
              name='reg_number'
              label={formData.regNumber.label}
              className={style.field_input}
              rules={[
                {
                  required: true,
                  message: formData.regNumber.requiredMessage,
                },
              ]}
              data-cy='welcome-aboard-form-item'>
              <CountField
                placeholder={formData.regNumber.placeholder}
                className='f-input'
                fieldtype='Input'
                maxLength={100}
                showcount={false}
              />
            </Form.Item>
            <Form.Item className={style.field_input}>
              <Button
                block
                key='submit'
                type='primary'
                size='large'
                loading={request}
                htmlType='submit'
                data-cy='welcome-aboard-submit-btn'>
                {WelcomeModalContent?.btnTxt}
              </Button>
            </Form.Item>
          </Form>
        </ErrorBoundary>
      </>
    );
  };

  return (
    <Modal
      footer={null}
      visible={visible}
      onCancel={onClose}
      maskClosable={false}
      className={`${style.welcome_aboard_modal} ${
        data === 'Success' ? style.form_submitted : ''
      } modal_error_handler`}
      maskStyle={{backgroundColor: '#FFF', opacity: 0.8}}>
      {data === 'Success' && !error
        ? WelcomeAboardSuccess()
        : WelcomeAboardForm()}
    </Modal>
  );
};

const mapStateToProps = state => ({
  becomeBusinessPartnerData: getBecomeBusinessPartnerData(state),
});

export default connect(mapStateToProps, {
  becomeBusinessPartner,
  clearBecomeBusinessPartnerData,
})(WelcomeAboardModal);
