import {useState, useEffect} from 'react';
import {Row, Col} from 'antd';
import {RequestErrorLoader, ErrorBoundary, CustomTabs} from 'core/components';

import './style.less';

import {
  Banner,
  Overview,
  OpenJobs,
  CareerPathways,
  PartnerEvents,
} from './components';

import {partnerDetailsData} from 'data/business-partners.json';

const PartnerDetails = props => {
  const {businessPartnerDetails, businessPartnerName, params, history} = props;
  const {tabsTitles, overviewData} = partnerDetailsData;
  const [activeTab, setActiveTab] = useState('overview');
  const tabs = [
    {
      title: tabsTitles[0],
      key: 'overview',
      children: <Overview {...props} staticData={overviewData} />,
    },
    {
      title: tabsTitles[1],
      key: 'open_jobs_and_internships',
      children: <OpenJobs {...props} />,
    },
    {
      title: tabsTitles[2],
      key: 'programs',
      children: <CareerPathways {...props} />,
    },
    {
      title: tabsTitles[3],
      key: 'events',
      children: <PartnerEvents {...props} />,
    },
  ];

  useEffect(() => {
    const {activetab} = params || {};
    activetab ? setActiveTab(activetab) : setActiveTab('overview');
  }, [params?.activetab]); // eslint-disable-line react-hooks/exhaustive-deps

  const onTabChange = tabName => {
    setActiveTab(tabName);
    history.push(
      `/business-partners/${businessPartnerName}?activetab=${tabName}`,
    );
  };

  return (
    <div className='PartnerDetails'>
      <ErrorBoundary nameOfComponent='module-bp-details' typeOfUi='subPage'>
        <RequestErrorLoader body={businessPartnerDetails}>
          <Banner {...props} />
          <div className='mx-3 pt-1 py-4 companyContent'>
            <Row className='d-flex contentContainer companydetails_tabs mt-4'>
              <Col xs={24} sm={24} md={24} lg={24} className='px-0'>
                <CustomTabs
                  onChange={onTabChange}
                  activeKey={activeTab}
                  tabsList={tabs}
                />
              </Col>
            </Row>
          </div>
        </RequestErrorLoader>
      </ErrorBoundary>
    </div>
  );
};

export default PartnerDetails;
