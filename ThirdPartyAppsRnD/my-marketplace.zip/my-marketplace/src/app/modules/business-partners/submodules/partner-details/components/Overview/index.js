const Overview = props => {
  const {
    businessPartnerDetails: {data},
    staticData,
  } = props;
  const {bp_details} = data || {};

  let bpData = null;
  let phone = '-';
  if (bp_details && Array.isArray(bp_details) && bp_details.length) {
    bpData = bp_details[0];

    // Check the country code for +1 if yes then remove code and format the phone number

    phone =
      bpData?.phone_number?.substring(0, 2) === '+1'
        ? bpData?.phone_number?.substring(2)
        : bpData?.phone_number;
    phone = phone?.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3') || '-';
  }

  return bpData ? (
    <div className='comp-detail-overview'>
      <h3>{staticData.headersText.industry}</h3>
      <h5 className='mb-3'>{bpData?.industry_sector_name || '-'}</h5>

      <h3>{staticData.headersText.locations}</h3>
      <p className='mb-3'>
        {bpData?.physical_address?.city || '-'},{' '}
        {bpData?.physical_address?.state || '-'}
      </p>

      <h3>{staticData.headersText.learnMore}</h3>
      <h5 className='mb-3'>
        <a href={bpData?.web_url} target='_blank'>
          {bpData?.web_url}
        </a>
      </h5>
      <h3>{staticData.headersText.aboutCompany}</h3>

      {/* {<p
        className='mb-3'
        dangerouslySetInnerHTML={{__html: bpData?.description}}
      />} */}

      {bpData?.overview_contents &&
        Array.isArray(bpData?.overview_contents) &&
        bpData?.overview_contents.length > 0 &&
        bpData?.overview_contents?.map(({title, value}) => {
          return (
            <>
              {/* <h3>{title}</h3> */}
              {value &&
                Array.isArray(value) &&
                value.length > 0 &&
                value.map(v => (
                  <p className='mb-3' dangerouslySetInnerHTML={{__html: v}} />
                ))}
            </>
          );
        })}

      <h3>{staticData.headersText.contactUs}</h3>
      <h4>{staticData.headersText.address}</h4>
      <h5>
        {bpData?.name}
        <br />
        {bpData?.physical_address?.address_line1},
        {bpData?.physical_address?.address_line2 && (
          <>
            <br />
            {bpData?.physical_address?.address_line2},
          </>
        )}
        <br />
        {bpData?.physical_address?.city}, {bpData?.physical_address?.state}
        &nbsp;{bpData?.physical_address?.zipcode}
      </h5>
      <h4>{staticData.headersText.email}</h4>
      <h5 className='mb-3'>{bpData?.email_id || '-'}</h5>
      <h4>{staticData.headersText.phone}</h4>
      <h5 className='mb-3'>{phone}</h5>
    </div>
  ) : (
    <></>
  );
};

export default Overview;
