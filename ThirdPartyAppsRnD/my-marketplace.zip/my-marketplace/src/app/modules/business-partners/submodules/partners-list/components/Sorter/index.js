import {Select} from 'antd';
import {partnersListData} from 'data/business-partners.json';

const {Option} = Select;

const SortData = [
  {
    title: 'Recent',
    value: 'dateasc',
  },
  {
    title: 'Oldest',
    value: 'datedesc',
  },
  {
    title: 'Ascending (A-Z)',
    value: 'titleasc',
  },
  {
    title: 'Descending (Z-A)',
    value: 'titledesc',
  },
];

const Sorter = ({sort, onChange}) => {
  const {sorterStaticData} = partnersListData;
  return (
    <div className='events-search-sorter'>
      <div>
        <span className='text-right'>
          <span className='sortby'>{sorterStaticData.heading}</span>
          <Select
            dropdownClassName='sort-grid'
            className='pl-3'
            defaultValue={sort}
            value={sort}
            onChange={value => onChange('sort', value)}>
            {SortData.map(({value, title}, idx) => (
              <Option value={value} key={idx}>
                {title}
              </Option>
            ))}
          </Select>
        </span>
      </div>
    </div>
  );
};
export default Sorter;
