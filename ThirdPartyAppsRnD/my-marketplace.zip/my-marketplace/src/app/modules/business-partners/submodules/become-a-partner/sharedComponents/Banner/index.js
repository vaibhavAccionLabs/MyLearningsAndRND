import {EmployerPartnerData, EducationPartnerData} from 'data/partner';

import {
  resourceBannerFutureWorkforce,
  resourceBannerEducationPartner,
} from 'assets/images';
import style from './style.module.less';

const Banner = ({onBecomePartner, isEmployer}) => {
  const DATA = isEmployer
    ? EmployerPartnerData?.BannerData
    : EducationPartnerData?.BannerData;
  return (
    <div
      className={`${style.employer_partner_banner}`}
      style={{
        background: `url(${
          isEmployer
            ? resourceBannerFutureWorkforce
            : resourceBannerEducationPartner
        }) no-repeat top center`,
      }}
      data-cy='partners-banner'>
      <h1>{DATA?.heading || ''}</h1>
      <h4>{DATA?.subHeading || ''}</h4>
      {DATA?.btnTxt && (
        <button className='btn-purple-outer' onClick={onBecomePartner}>
          {DATA?.btnTxt || ''}
        </button>
      )}
    </div>
  );
};

export default Banner;
