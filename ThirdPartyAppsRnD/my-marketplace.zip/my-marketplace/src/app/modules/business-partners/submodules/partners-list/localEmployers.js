import {Button} from 'antd';
import {
  ErrorBoundary,
  NoBusinessPartners,
  RequestErrorLoader,
  BusinessPartnerCard,
  SearchResultsCounter,
} from 'core/components';

import {partnersListData} from 'data/business-partners.json';

import style from './style.module.less';
import './style.less';

const LocalEmployers = ({
  businessPartnersList,
  refetchData,
  reqParams,
  filters,
}) => {
  const {loadMoreBtnText} = partnersListData;

  const {data} = businessPartnersList;
  const recordsCount = data?.bp_details?.length || 0;
  const totalCount = data?.page_details?.total_count || 0;
  const hideLoadMore =
    (data?.page_details &&
      reqParams?.page >= data?.page_details?.no_of_pages &&
      !businessPartnersList.request &&
      !businessPartnersList.error) ||
    recordsCount === totalCount ||
    totalCount <= 12;

  const loadMoreBp = () => {
    const newPage = reqParams.page + 1;
    const Obj = Object.assign({}, reqParams, {
      page: newPage,
    });
    refetchData(Obj, filters, true);
  };

  let defaultDisplay = true;
  if (businessPartnersList?.request && !(reqParams?.page > 1)) {
    defaultDisplay = false;
  }

  return (
    <div className='my-5 mt-3'>
      <ErrorBoundary nameOfComponent='module-partners-list' typeOfUi='subPage'>
        <RequestErrorLoader
          body={{
            ...businessPartnersList,
            data: businessPartnersList.data?.bp_details || [],
          }}
          overideNoDataContainer={<NoBusinessPartners />}>
          {defaultDisplay && data?.bp_details?.length > 0 && (
            <>
              <SearchResultsCounter
                className='bpRecordCount mb-3'
                currentLength={recordsCount}
                totalResults={totalCount}
                request={businessPartnersList?.request}
              />
              <div className={style.jobCard}>
                <ul>
                  {data.bp_details.map(bp => (
                    <BusinessPartnerCard
                      enableNavigation
                      data={bp}
                      key={bp?.business_partner_id}
                    />
                  ))}
                </ul>
                {!hideLoadMore && (
                  <div className='text-center pt-4 pb-3'>
                    <Button
                      type='primary'
                      className='bp-load-more'
                      onClick={loadMoreBp}>
                      {businessPartnersList?.request
                        ? loadMoreBtnText.loading
                        : loadMoreBtnText.loadMore}
                    </Button>
                  </div>
                )}
              </div>
            </>
          )}
        </RequestErrorLoader>
      </ErrorBoundary>
    </div>
  );
};

export default LocalEmployers;
