import {lazy} from 'react';
import {retry} from 'core/utils';
import {ErrorBoundary} from 'core/components';
const Search = lazy(() => retry(() => import('../../../../../search')));

const CareerPathways = props => (
  <ErrorBoundary
    nameOfComponent='mod-comp-bp-career-pathways'
    showDialog={true}>
    <Search
      isCareerPathways={true}
      businessPartnerName={props?.businessPartnerName}
    />
  </ErrorBoundary>
);

export default CareerPathways;
