import {lazy} from 'react';
import {retry} from 'core/utils';

const BecomeAPartner = lazy(() => retry(() => import('./become-a-partner')));
const PartnersList = lazy(() => retry(() => import('./partners-list')));
const PartnerDetails = lazy(() => retry(() => import('./partner-details')));

export {BecomeAPartner, PartnersList, PartnerDetails};
