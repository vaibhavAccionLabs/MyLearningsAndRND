import BusinessPartnerRoutes from './BusinessPartnerRoutes';

const BusinessPartners = props => (
  <BusinessPartnerRoutes modules={props.submodules} />
);

export default BusinessPartners;
