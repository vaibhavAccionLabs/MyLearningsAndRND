import React from 'react';
import {Row, Col, Button, Tooltip} from 'antd';
import {CheckCircleFilled, CheckCircleOutlined} from '@ant-design/icons';
import {getBanner, getLogo} from 'core/utils';
import {blueStar, noCollageLogo, defaultbannerjob} from 'assets/images';
import './style.less';
const Banner = ({
  jobBoardDetails,
  onSignUpProgram,
  signedUpPrograms,
  onSaveProgramClick,
  savedPrograms,
}) => {
  const {
    data: {
      name,
      banner_image,
      banner_cloudinary,
      business_partner_program_uuid,
      institute_details: {
        institute_banner_cloudinary,
        institute_logo_cloudinary,
      } = {},
      business_partner_details: {
        business_partner_banner_cloudinary,
        business_partner_logo_cloudinary,
      } = {},
    } = {},
  } = jobBoardDetails || {};
  const {requestApply, request: signedUpProgramsReq} = signedUpPrograms || {};
  const {request: savedProgramReq, requestSave} = savedPrograms || {};
  const getBannerImageStyle = () => ({
    background: `url(${
      (institute_banner_cloudinary && getBanner(institute_banner_cloudinary)) ||
      banner_image ||
      defaultbannerjob
    }) no-repeat top left`,
  });

  const programSigned = () => {
    if (signedUpPrograms && signedUpPrograms.data) {
      const exists = signedUpPrograms.data.filter(
        i =>
          i.program_details &&
          i.program_details.business_partner_program_uuid ===
            business_partner_program_uuid,
      );
      if (exists[0]) return true;
    }
    return false;
  };
  const programSaved = () => {
    if (savedPrograms && savedPrograms.data) {
      const exists = savedPrograms.data.filter(
        i =>
          i.program_details &&
          i.program_details.business_partner_program_uuid ===
            business_partner_program_uuid,
      );
      if (exists[0]) return true;
    }
    return false;
  };
  return (
    <div>
      <div className='occupationBanner' style={getBannerImageStyle()}>
        {/* <div className='banner-inner '>
        <Row justify='space-between' className='btns'>
          <Col xs={24} sm={24} md={24} lg={24} className='text-right pr-5'>
            {!programSigned() && !signedUpProgramsReq && (
              <>
                {programSaved() ? (
                  <Button
                    type='primary'
                    shape='circle'
                    className='starRating saved'>
                    <CheckCircleFilled className='checked-circle' />
                    <span className='inf-text'>Saved</span>
                  </Button>
                ) : (
                  <Tooltip title='Save program'>
                    <Button
                      type='primary'
                      shape='circle'
                      loading={savedProgramReq || requestSave}
                      onClick={onSaveProgramClick}
                      className='starRating d-inline-block mr-3'>
                      {!savedProgramReq && !requestSave && (
                        <img src={blueStar} alt='star' />
                      )}
                    </Button>
                  </Tooltip>
                )}
              </>
            )}

            {programSigned() ? (
              <Button
                type='primary'
                className='px-4 d-inline-block green-btn'
                icon={<CheckCircleOutlined />}>
                Applied
              </Button>
            ) : (
              <Button
                className='ant-btn btnApply ant-btn-primary px-4 d-inline-block'
                onClick={onSignUpProgram}
                disabled={requestApply || signedUpProgramsReq}
                loading={requestApply || signedUpProgramsReq}>
                Apply
              </Button>
            )}
          </Col>
        </Row>
        <div className='p-title py-4'>{name}</div>
        <div className='text-center pb-4'>
          <Button className='ant-btn ant-btn-primary py-2 btn-purple'>
            Company Profile
          </Button>
        </div>
      </div> */}
      </div>
      <div className='opportunity_logo'>
        <img src={getLogo(institute_logo_cloudinary)} alt='logo' />
      </div>
    </div>
  );
};

export default Banner;
