import React from 'react';
import {successTick} from 'assets/images';

const ApplyModal = ({programDetail}) => {
  const {data: {name} = {}} = programDetail || {};
  return (
    <div className='program-apply-modal'>
      <img src={successTick} className='icn' alt='succes-icon' />
      <div className='ttl'>Applied Successfully!</div>
      <div className='sub'>
        Your have signed up for <span>‘{name}’</span>
        successfullty. Now you will get notifications about the program
      </div>
      <div className='sub'>
        <span>Note:</span> Make sure <span className='bl'>Your Profile</span> is
        up-to-date.
      </div>
    </div>
  );
};

export default ApplyModal;
