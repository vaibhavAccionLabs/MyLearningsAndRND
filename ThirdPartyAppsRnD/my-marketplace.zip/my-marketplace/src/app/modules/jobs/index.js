import React, {useEffect} from 'react';
import {message} from 'antd';
import {useParams, useHistory} from 'react-router-dom';
import {connect} from 'react-redux';

import {
  fetchJobBoardsDetails,
  getJobBoardsDetails,
  getJobApplied,
  fetchAppliedJobs,
  getJobSaved,
  fetchSavedJobs,
  saveJob,
  applyJob,
  resetAppliedJobs,
  resetSavedJobs,
} from 'redux/modules/jobs';

import {
  updateOpportunityInterest,
  fetchSavedOpportunities,
  getSavedOpportunities,
  resetSavedOpportunities,
  fetchAppliedOpportunities,
  resetAppliedOpportunities,
  getAppliedOpportunities,
  unSaveOpportunity,
} from 'redux/modules/occupation';

import {openLoginScreen} from 'redux/modules/auth';

import {AppBreadcrumb, RequestErrorLoader} from 'core/components';
import {useAuth} from 'core/hooks';
import {queryStringParse} from 'core/utils';

//local components.
import {Banner as LocalJobBanner} from './sharedComponents';
import Banner from './components/Banner';
import JobInfo from './components/JobInfo';

import './styles.less';

let isAction = null;
const Jobs = props => {
  const params = useParams();
  const {
    jobBoardDetails,
    fetchJobBoardsDetails,
    openLoginScreen,
    updateOpportunityInterest,
    fetchSavedOpportunities,
    resetSavedOpportunities,
    fetchAppliedOpportunities,
    resetAppliedOpportunities,
    unSaveOpportunity,
    SavedOpportunity,
  } = props;
  const {jobId, jobType, institutionName = null} = params;
  const [token, user] = useAuth();
  const history = useHistory();
  const {
    location: {search},
  } = history;

  const {related_occupation} = queryStringParse(search);

  const {
    data: {
      occupation_name,
      opportunity_type,
      opportunity_id,
      title,
      job_post_thumbnail_cloudinary,
      institute_details: {institution_uuid, institution_name} = {},
    } = {},
  } = jobBoardDetails || {};

  const initLoginData = () => {
    if (isAction != 'apply') {
      fetchAppliedOpportunities();
    }
    if (isAction != 'save') {
      fetchSavedOpportunities();
    }
  };

  useEffect(() => {
    fetchJobBoardsDetails(jobId, jobType, institutionName);
    return () => {
      resetAppliedOpportunities();
      resetSavedOpportunities();
    };
  }, [jobId, jobType, institutionName]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (token) {
      initLoginData();
    }
  }, [token]); // eslint-disable-line react-hooks/exhaustive-deps

  const onApplyJob = async () => {
    const data = {
      job_post_thumbnail_cloudinary: job_post_thumbnail_cloudinary,
      bp_opportunity_id: opportunity_id,
      opportunity_name: title,
      opportunity_type: opportunity_type,
      institute_uuid: institution_uuid,
      institute_name: institution_name,
      action_type: 'apply',
    };
    await updateOpportunityInterest(data, err => {
      if (err) {
        message.error(err);
      } else {
        // Check if the opportunity is saved, if yes then unSave after applying.
        const opportunitySavedData = opportunitySaved();
        if (opportunitySavedData.status) {
          // unsave opportunity
          unSaveOpportunity(opportunitySavedData.app_id);
        }
        message.success(
          'Applied Successfully and can be viewed in Your Profile',
        );
      }
    });
    fetchAppliedOpportunities();
    isAction = null;
  };

  const opportunitySaved = () => {
    if (SavedOpportunity && SavedOpportunity.data) {
      const exists = SavedOpportunity.data.filter(
        i => i.bp_opportunity_id === opportunity_id,
      );
      if (exists[0]) {
        return {
          app_id: exists[0].opp_application_uuid,
          status: true,
        };
      }
    }
    return {
      status: false,
    };
  };

  const onApplyJobClick = () => {
    const {data: {URL} = {}} = jobBoardDetails || {};
    if (jobType === 'local') {
      if (token) {
        onApplyJob();
      } else {
        isAction = 'apply';
        openLoginScreen({
          callback: () => {
            fetchAppliedOpportunities((jobs = []) => {
              const exists = jobs.filter(
                i => i.bp_opportunity_id === opportunity_id,
              );
              if (exists[0]) {
                message.warning('This Opportunity is already applied.');
              } else {
                onApplyJob();
              }
            });
          },
        });
      }
    } else {
      if (URL) {
        window.open(URL, '_blank');
      }
    }
  };
  const onSaveJob = async () => {
    const data = {
      job_post_thumbnail_cloudinary: job_post_thumbnail_cloudinary,
      bp_opportunity_id: opportunity_id,
      opportunity_name: title,
      opportunity_type: opportunity_type,
      institute_uuid: institution_uuid,
      institute_name: institution_name,
      action_type: 'save',
    };

    await updateOpportunityInterest(data, err => {
      if (err) {
        message.error(err);
      } else {
        message.success('Opportunity saved to your profile');
      }
    });
    fetchSavedOpportunities();
    isAction = null;
  };

  const onSaveJobClick = () => {
    if (token) {
      onSaveJob();
    } else {
      isAction = 'save';
      openLoginScreen({
        callback: () => {
          fetchSavedOpportunities((jobs = []) => {
            const exists = jobs.filter(
              i => i.bp_opportunity_id === opportunity_id,
            );
            if (exists[0]) {
              message.warning('This Opportunity is already saved.');
            } else {
              onSaveJob();
            }
          });
        },
      });
    }
  };

  const occName = occupation_name || related_occupation;
  const decodedOccName = decodeURIComponent(occName);

  return (
    <RequestErrorLoader body={{request: jobBoardDetails?.request}}>
      <div className='job-homepage '>
        {jobType === 'local' ? (
          <>
            <div className='breadcrumb_container'>
              <AppBreadcrumb
                dataList={
                  related_occupation
                    ? [
                        {
                          name: 'Career Detail',
                          path: `/occupation?query=${related_occupation}`,
                        },
                        {
                          name: 'Job Description',
                        },
                      ]
                    : [
                        {
                          name: 'Find Opportunities',
                          path: '/business-partners',
                        },
                        {
                          name: institution_name,
                          path: `/business-partners/${institution_name}`,
                        },
                        {
                          name: title,
                        },
                      ]
                }
              />
            </div>
            <LocalJobBanner {...props} />
          </>
        ) : (
          <>
            <div className='breadcrumb_container'>
              <AppBreadcrumb
                dataList={[
                  {
                    name: 'Job',
                  },
                ]}
              />
            </div>
            <Banner
              {...props}
              jobType={jobType}
              onApplyJob={onApplyJobClick}
              onSaveJobClick={onSaveJobClick}
            />
          </>
        )}
        <div className='contentContainer'>
          <JobInfo
            {...props}
            jobType={jobType}
            onOpportunityApply={onApplyJobClick}
            onOpportunitySave={onSaveJobClick}
          />
        </div>
      </div>
    </RequestErrorLoader>
  );
};

const mapStateToProps = state => ({
  jobBoardDetails: getJobBoardsDetails(state),
  appliedJobs: getJobApplied(state),
  savedJobs: getJobSaved(state),
  SavedOpportunity: getSavedOpportunities(state),
  AppliedOpportunity: getAppliedOpportunities(state),
});

export default connect(mapStateToProps, {
  fetchJobBoardsDetails,
  fetchAppliedJobs,
  fetchSavedJobs,
  openLoginScreen,
  saveJob,
  applyJob,
  resetAppliedJobs,
  resetSavedJobs,
  updateOpportunityInterest,
  fetchSavedOpportunities,
  resetSavedOpportunities,
  fetchAppliedOpportunities,
  resetAppliedOpportunities,
  unSaveOpportunity,
})(Jobs);
