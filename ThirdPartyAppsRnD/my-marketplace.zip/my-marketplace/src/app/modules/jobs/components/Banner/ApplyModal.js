import React from 'react';
import {successTick} from 'assets/images';

const ApplyModal = ({jobBoardDetails}) => {
  const {data: {job_title, business_partner: {company_name} = {}} = {}} =
    jobBoardDetails || {};
  return (
    <div className='job-apply-modal'>
      <img src={successTick} className='icn' alt='success-icon' />
      <div className='ttl'>Application Submitted !</div>
      <div className='sub'>
        You have successfully applied to the <span>{job_title}</span> job at{' '}
        <span>{company_name}</span>
        <br />
        You can view a list of the jobs that you have applied to in your
        profile.
      </div>
      <div className='sub'>
        <span>Note:</span> Make sure <span className='bl'>Your Profile</span> is
        up-to-date.
      </div>
    </div>
  );
};

export default ApplyModal;
