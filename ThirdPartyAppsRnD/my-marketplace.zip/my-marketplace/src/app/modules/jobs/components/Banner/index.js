import React from 'react';
import {Button, Tooltip} from 'antd';
import {
  CheckCircleFilled,
  CheckCircleOutlined,
  LoadingOutlined,
} from '@ant-design/icons';
import {blueStar, maplocation} from 'assets/images';

const Banner = ({
  jobBoardDetails,
  onApplyJob,
  jobType,
  onSaveJobClick,
  savedJobs,
  appliedJobs,
}) => {
  const {
    data: {
      Location,
      JobTitle,
      job_title,
      title,
      city,
      state,
      zip,
      business_partner_job_id,
    } = {},
  } = jobBoardDetails || {};
  const location = Location || (city && state ? `${city}, ${state}` : '-');
  const jobtitle = title || job_title || JobTitle;
  const jobApplied = () => {
    if (appliedJobs && appliedJobs.data) {
      const exists = appliedJobs.data.filter(
        i =>
          i.jobs_details &&
          i.jobs_details.jobs_uuid === business_partner_job_id,
      );
      if (exists[0]) return true;
    }
    return false;
  };
  const jobSaved = () => {
    // return true;
    if (savedJobs && savedJobs.data) {
      const exists = savedJobs.data.filter(
        i =>
          i.jobs_details &&
          i.jobs_details.jobs_uuid === business_partner_job_id,
      );
      if (exists[0]) return true;
    }
    return false;
  };
  return (
    <header className='banner px-5 py-4'>
      <div className='d-flex justify-content-center text-center'>
        <div>
          {/* <h5>Job detail for</h5> */}
          <h2>{jobtitle}</h2>
          <h5 className='mb-0'>
            <img src={maplocation} alt='location' className='pr-2 pb-1' />
            {location}
          </h5>
          <div>
            {!jobApplied() && !appliedJobs.applyRequest && jobType === 'local' && (
              <>
                {jobSaved() ? (
                  <Button
                    type='primary'
                    shape='circle'
                    className='starRating saved'>
                    <CheckCircleFilled
                      className='checked-circle'
                      color='green'
                    />
                    <span className='inf-text'>Saved</span>
                  </Button>
                ) : (
                  <button
                    type='button'
                    title='Save job'
                    disabled={savedJobs.request || savedJobs.saveRequest}
                    onClick={onSaveJobClick}
                    className='ant-btn ant-btn-circle starRating d-inline-block mr-3'>
                    {!savedJobs.request && !savedJobs.saveRequest && (
                      <img src={blueStar} alt='star' />
                    )}
                    {(savedJobs.request || savedJobs.saveRequest) && (
                      <LoadingOutlined />
                    )}
                  </button>
                )}
              </>
            )}
            {/* {jobType === 'local' && (
            <button
              type='button'
              onClick={onSaveJobClick}
              className='ant-btn ant-btn-circle starRating d-inline-block mr-3'>
              <img src={blueStar} alt='star' />
            </button>
          )} */}
            {jobApplied() ? (
              <Button
                type='primary'
                className='px-4 d-inline-block green-btn'
                icon={<CheckCircleOutlined />}>
                Applied
              </Button>
            ) : (
              <button
                type='button'
                onClick={onApplyJob}
                disabled={appliedJobs.request || appliedJobs.applyRequest}
                className='ant-btn btnApply ant-btn-primary px-4 d-inline-block'>
                <span>Apply</span>
              </button>
            )}
            {jobType === 'local' && (
              <div className='btnCompany'>
                <button
                  type='button'
                  className='ant-btn btn-purple px-4 my-3 d-block'>
                  <span>Company Profile</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Banner;
