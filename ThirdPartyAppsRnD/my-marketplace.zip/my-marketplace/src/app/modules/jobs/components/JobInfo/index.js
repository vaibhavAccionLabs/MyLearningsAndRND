import {OpportunityDetails} from 'core/components';
import {carrerOneStop} from 'assets/images';

const JobInfo = ({
  jobBoardDetails,
  jobType,
  onOpportunityApply,
  onOpportunitySave,
  SavedOpportunity,
  AppliedOpportunity,
}) => {
  const {data = {}, data: {Description} = {}} = jobBoardDetails || {};
  return jobType === 'local' ? (
    <OpportunityDetails
      details={data}
      OpportunityApply={onOpportunityApply}
      OpportunitySave={onOpportunitySave}
      savedOpportunities={SavedOpportunity}
      AppliedOpportunities={AppliedOpportunity}
    />
  ) : (
    <div className='job-details-content contentContainer'>
      <div className=' p-5 px-0 py-3'>
        <h1>The Position</h1>
        <p dangerouslySetInnerHTML={{__html: Description}} />
      </div>
      <div className='py-5 pt-1'>
        <img src={carrerOneStop} width={119} />
      </div>
    </div>
  );
};

export default JobInfo;
