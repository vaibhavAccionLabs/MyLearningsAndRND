import {AppBreadcrumb} from 'core/components';
import policyData from 'data/policy.json';

import style from './style.module.less';

const Description = ({desc}) => {
  if (desc && Array.isArray(desc)) {
    return desc.map((el, idx) => {
      if (el && Array.isArray(el)) {
        return (
          <ol className={style.alpha_list_w} key={`ol-${idx}`}>
            {el.map((e, i) => (
              <li key={`list-${i}`}>{e}</li>
            ))}
          </ol>
        );
      }
      return <p key={`pa-${idx}`}>{el}</p>;
    });
  }
  return <p>{desc}</p>;
};

const PrivacyPolicy = () => (
  <div className={style.privacy_secion}>
    <div className={`${style.banner}`}>
      <h1>{policyData.bannerHeading}</h1>
    </div>
    <AppBreadcrumb
      dataList={[
        {
          name: policyData.bannerHeading,
        },
      ]}
    />

    <div className={`contentContainer mt-4 mb-5 ${style.mobContainer}`}>
      {policyData?.content?.map(({header, description}, idx) => (
        <div key={`con-${idx}`}>
          <h3>{header}</h3>
          <Description desc={description} />
        </div>
      ))}
    </div>
  </div>
);

export default PrivacyPolicy;
