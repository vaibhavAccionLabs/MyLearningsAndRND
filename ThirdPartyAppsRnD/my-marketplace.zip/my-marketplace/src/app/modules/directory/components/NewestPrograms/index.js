import {Link} from 'react-router-dom';

import {Carousel, RequestErrorLoader, PathCard} from 'core/components';

import './style.less';

const NewestPrograms = ({paths, appConfig: {isMobileView}}) => {
  return (
    <div className='contentContainer program-career' data-cy='newest-programs'>
      <div className='d-flex justify-content-between mt-4 pb-3'>
        <h2>Newest Programs</h2>
        <Link className='btn-blue-outer' to='/search?newest_path=true'>
          EXPLORE MORE
        </Link>
      </div>
      <RequestErrorLoader
        body={{...paths, data: paths.newestData?.path_details}}>
        {paths.newestData?.path_details?.length > 0 && (
          <Carousel
            className={`newestProgram-slider ${
              !isMobileView && paths.newestData?.path_details?.length < 4
                ? 'new-program-less-cards'
                : ''
            }`}
            config={{
              slidesToShow: 4,
              slidesToScroll: 4,
              responsive: [
                {
                  breakpoint: 1024,
                  settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                  },
                },
                {
                  breakpoint: 600,
                  settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                  },
                },
                {
                  breakpoint: 480,
                  settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                  },
                },
              ],
            }}
            data={paths.newestData.path_details.map((path, idx) => {
              return (
                <ul
                  className='search-card p-0'
                  key={path.uuid}
                  data-cy='newest-programs-element'>
                  <PathCard data={path} enableNavigation />
                </ul>
              );
            })}
          />
        )}
      </RequestErrorLoader>
    </div>
  );
};

export default NewestPrograms;
