import {lazy} from 'react';
import {retry} from 'core/utils';

const NewestPrograms = lazy(() => retry(() => import('./NewestPrograms')));
const ProgramsByCareer = lazy(() => retry(() => import('./ProgramsByCareer')));

export {NewestPrograms, ProgramsByCareer};
