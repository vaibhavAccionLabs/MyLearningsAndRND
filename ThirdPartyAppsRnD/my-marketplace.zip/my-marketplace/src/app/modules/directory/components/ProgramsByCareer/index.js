import {useHistory} from 'react-router-dom';
import {Carousel, RequestErrorLoader, LazyImage} from 'core/components';
import {getCardImgSet} from 'core/utils';
import style from './style.module.less';

const ProgramsByCareer = ({ProgramsByCareer}) => {
  const history = useHistory();

  const navigateTo = param => {
    history.push(`/search?cluster_name=${encodeURIComponent(param)}`);
  };

  let finalData = [];
  if (ProgramsByCareer.data?.length) {
    finalData = ProgramsByCareer.data;
    // Remove cluster data whose active_path_count is 0
    // finalData = ProgramsByCareer.data.filter(
    //   cluster => cluster.active_path_count,
    // );
  }

  return (
    <div
      className={`contentContainer ${style.programs_screens}`}
      data-cy='programs-by-career'>
      <h2 className='mt-4 mb-3'>Programs by Career</h2>
      <RequestErrorLoader body={ProgramsByCareer}>
        {finalData?.length > 0 && (
          <Carousel
            className={`careerSlider ${style.careerSlider}`}
            config={{
              centerPadding: '60px',
              slidesToShow: 4,
              slidesToScroll: 4,
              rows: finalData.length > 4 ? 2 : 1,
              slidesPerRow: 1,
              responsive: [
                {
                  breakpoint: 1024,
                  settings: {
                    slidesToShow: 2,
                    rows: 2,
                    slidesPerRow: 1,
                    slidesToScroll: 2,
                  },
                },
                {
                  breakpoint: 600,
                  settings: {
                    slidesToShow: 2,
                    rows: 2,
                    slidesPerRow: 1,
                    slidesToScroll: 2,
                  },
                },
                {
                  breakpoint: 480,
                  settings: {
                    slidesToShow: 1,
                    rows: 2,
                    slidesPerRow: 1,
                    slidesToScroll: 1,
                  },
                },
              ],
            }}
            data={finalData.map(cluster => {
              const config = {
                // c_prop: 'crop',
                // height: 200,
                // width: 300,
                //ar_prop: '8:3',
                noConfigNeeded: true,
              };
              const IMG = getCardImgSet(cluster.cluster_card_url, '', config);
              // if (cluster?.active_path_count) {
              return (
                <div
                  className={style.programsByCareer}
                  key={cluster.cluster_uuid}
                  onClick={() => navigateTo(cluster.cluster_name)}
                  data-cy='program-by-career-element'>
                  <>
                    <LazyImage
                      src={IMG?.defaultImage}
                      dataSrc={IMG?.normalImage}
                      alt='cluster_image'
                      dataSrcSet={IMG?.srcSet}
                    />
                    <div className={style.sub_careerProgram}>
                      <span>{cluster.cluster_name}</span>
                      <span>({cluster.active_path_count} Programs)</span>
                    </div>
                  </>
                </div>
              );
              // }
            })}
          />
        )}
      </RequestErrorLoader>
    </div>
  );
};

export default ProgramsByCareer;
