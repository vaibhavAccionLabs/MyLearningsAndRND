import {AppBreadcrumb} from 'core/components';

import DirectoryRoutes from './DirectoryRoutes';

import './style.less';

const Directory = props => {
  const {submodules} = props;

  return (
    <>
      <AppBreadcrumb
        dataList={[
          {
            name: 'Explore Programs',
          },
        ]}
      />
      <DirectoryRoutes modules={submodules} />
    </>
  );
};

export default Directory;
