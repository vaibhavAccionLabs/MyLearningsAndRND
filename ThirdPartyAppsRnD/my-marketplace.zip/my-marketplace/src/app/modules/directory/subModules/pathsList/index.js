import {useEffect, createRef} from 'react';
import {connect} from 'react-redux';
import {useLocation} from 'react-router-dom';

import {getAppConfig} from 'redux/modules/general';
import {
  fetchProgramsByCareer,
  getProgramsByCareer,
} from 'redux/modules/programs';

import {
  fetchNewestPrograms,
  getPaths,
  clearPathSearch,
  resetInitalLoad,
} from 'redux/modules/search';

import {fetchPosList, getPosList, clearPosList} from 'redux/modules/directory';

import {ErrorBoundary} from 'core/components';
import {NewestPrograms, ProgramsByCareer} from '../../components';

const PathsList = props => {
  const programByCareer = createRef();
  const loc = useLocation();

  const {
    fetchProgramsByCareer,
    fetchNewestPrograms,
    clearPathSearch,
    resetInitalLoad,
    ProgramsByCareer: careerProgram,
    paths,
  } = props;

  useEffect(() => {
    if (loc?.hash) {
      let referer = programByCareer;
      // check for specific hash and override referer value..
      referer.current.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
      });
    }
  }, [loc, programByCareer]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!careerProgram?.data) {
      fetchProgramsByCareer();
    }

    if (!paths?.newestData) {
      fetchNewestPrograms(8, 1, 'date_desc');
    }

    return () => {
      clearPathSearch();
      resetInitalLoad();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <ErrorBoundary
      nameOfComponent='module-directory-path-list'
      typeOfUi='subPage'>
      <div ref={programByCareer}>
        <ProgramsByCareer {...props} />
      </div>
      <div id='newest_programs'>
        <NewestPrograms {...props} />
      </div>
    </ErrorBoundary>
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  posList: getPosList(state),
  ProgramsByCareer: getProgramsByCareer(state),
  paths: getPaths(state),
});

export default connect(mapStateToProps, {
  fetchPosList,
  clearPosList,
  fetchProgramsByCareer,
  fetchNewestPrograms,
  clearPathSearch,
  resetInitalLoad,
})(PathsList);
