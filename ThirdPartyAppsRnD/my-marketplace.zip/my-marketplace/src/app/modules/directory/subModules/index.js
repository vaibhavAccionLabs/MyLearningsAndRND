import {lazy} from 'react';
import {retry} from 'core/utils';

const PathsList = lazy(() => retry(() => import('./pathsList')));

export {PathsList};
