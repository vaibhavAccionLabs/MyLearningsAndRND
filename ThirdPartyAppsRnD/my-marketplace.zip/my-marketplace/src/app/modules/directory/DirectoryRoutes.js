import {SubRouter} from 'core/components';

const DirectoryRoutes = ({modules}) => (
  <SubRouter modules={modules} defaultRedirection='/directory/paths-list' />
);

export default DirectoryRoutes;
