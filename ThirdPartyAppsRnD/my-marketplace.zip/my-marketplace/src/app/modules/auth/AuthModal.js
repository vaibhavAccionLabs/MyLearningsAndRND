import React, {useState} from 'react';
import {Row, Col, Modal} from 'antd';

import {API} from 'config';
import {signingInTexts} from 'data/auth';
import {Services} from 'core/Services';
import {CustomTabSwitch} from 'core/components';

//local componets:
import {
  SignIn,
  SignUp,
  SignUpSuccess,
  ChangePassword,
  ForgotPassword,
} from './components';

import {goEducateLogoWhite} from 'assets/images';

import './style.less';

const services = new Services();

const Tabs = [
  {key: 'signin', value: signingInTexts.signInText || ''},
  {key: 'signup', value: signingInTexts.signUpText || ''},
];

const AuthModal = ({
  auth,
  login,
  loginScreen,
  forgotPassword,
  closeLoginScreen,
  forgotPasswordData,
}) => {
  const {
    savedCredentials,
    config: {screen = 'signin'},
  } = loginScreen || {};
  const [currentTab, setTab] = useState(screen);
  const [mainView, setMainView] = useState('default');
  const [signUpStatus, setSignUpStatus] = useState({
    request: false,
    error: false,
    data: {},
  });
  const [changePasswordData, setChangePasswordData] = useState({});
  const onSubmitSignUp = data => {
    setSignUpStatus({...signUpStatus, request: true, error: false});
    try {
      services
        .createUpdateRecord({}, API.gps.signup, data, 'POST')
        .then(async res => {
          if (res && res.status === 'Success') {
            const loginData = {
              username: data.email.toLowerCase(),
              password: data.password,
            };
            await login(loginData, false);
            setSignUpStatus({
              request: false,
              error: false,
              success: true,
              data,
            });
            setMainView('signinsucess');
          } else {
            setSignUpStatus({
              request: false,
              error: res.Error ? res.Error : true,
            });
          }
        });
    } catch (err) {
      setSignUpStatus({request: false, error: true});
    }
  };
  const openChangePassword = data => {
    setChangePasswordData(data);
    setMainView('changepassword');
  };

  const returnToLogin = () => {
    setMainView('default');
  };

  const goToForgotPassword = () => {
    setMainView('forgotpassword');
  };

  const renderView = () => (
    <>
      <h2>
        {currentTab === 'signin'
          ? signingInTexts.signInText
          : signingInTexts.signUpText}
      </h2>
      <p>
        {currentTab === 'signin'
          ? signingInTexts.signUpDescription
          : signingInTexts.signInDescription}
        ,{' '}
        <span
          className='linkItem'
          onClick={() =>
            onTabChange(currentTab === 'signin' ? 'signup' : 'signin')
          }>
          {currentTab === 'signin'
            ? signingInTexts.signUpText
            : signingInTexts.signInText}
        </span>
      </p>
      {currentTab === 'signin' ? (
        <SignIn
          onLogin={login}
          auth={auth}
          goToForgotPassword={goToForgotPassword}
          savedCredentials={savedCredentials}
          openChangePassword={openChangePassword}
        />
      ) : (
        <SignUp onSubmitSignUp={onSubmitSignUp} signUpStatus={signUpStatus} />
      )}
    </>
  );

  const onTabChange = val => setTab(val);

  const renderContainer = () => {
    return (
      <Row className='auth-modal-layout' data-cy='sign-in-modal'>
        {/* <Col sm={10} xs={24} className='banner-section'>
          <div className='banner-img' data-cy='sign-in-banner-img' />
          <div className='signbanner-left' data-cy='sign-in-banner-content'>
            <div className='square_anim'>
              <span className='square'></span>
              <span className='square'></span>
              <span className='square'></span>
            </div>
            <img src={goEducateLogoWhite} alt='logo' className='img-fluid' />
            <h3 className='pt-2'>{signingInTexts.discoverPathwayText || ''}</h3>
            <h5>
              {signingInTexts.poweredByText || ''}
              <img src={goEducateLogoWhite} alt='logo' className='img-fluid' />
            </h5>
          </div>
        </Col> */}
        <Col sm={24} xs={24} className='auth-content'>
          {/* <div>
            <CustomTabSwitch
              dataTabs={Tabs}
              onChange={onTabChange}
              currentTab={currentTab}
            />
          </div> */}
          {renderView()}
        </Col>
      </Row>
    );
  };
  return (
    <Modal
      visible={true}
      maskClosable={false}
      footer={null}
      title={null}
      className={`auth-modal ${mainView === 'forgotpassword' ? 'forgot' : ''} ${
        mainView === 'signinsucess' ? 'signup-sucess-modal' : ''
      }`}
      maskStyle={{backgroundColor: '#ffffff', opacity: 0.8}}
      onCancel={closeLoginScreen}>
      {mainView === 'default' && renderContainer()}
      {mainView === 'signinsucess' && (
        <SignUpSuccess data={signUpStatus.data} onDone={closeLoginScreen} />
      )}
      {mainView === 'forgotpassword' && (
        <ForgotPassword
          returnToLogin={returnToLogin}
          data={forgotPasswordData}
          forgotPassword={forgotPassword}
          closeLoginScreen={closeLoginScreen}
        />
      )}
      {mainView === 'changepassword' && (
        <ChangePassword
          data={changePasswordData}
          onLogin={login}
          auth={auth}
          closeLoginScreen={closeLoginScreen}
        />
      )}
    </Modal>
  );
};
export default AuthModal;
