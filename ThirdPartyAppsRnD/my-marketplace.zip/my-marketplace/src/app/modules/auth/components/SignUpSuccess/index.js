import React, {useEffect} from 'react';
import {Button} from 'antd';
import {iconmail} from 'assets/images';
import {CheckOutlined} from '@ant-design/icons';

import {authSuccess} from 'data/auth';

const SignUpSuccess = ({data, onDone}) => {
  useEffect(() => {
    setTimeout(onDone, 6000);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className='sign-up-success'>
      <div className='ttl'>
        <CheckOutlined />
        <span>{authSuccess.successMsg}</span>{' '}
      </div>
      {/* <div className='hdr-sign'>
      <div className='ttl'>{authSuccess.welcomeMsg}</div>
      <div className='sub-ttl'>{authSuccess.tagLine}</div>
    </div>
    <div className='success-content'>
      <img src={iconmail} alt='mail icon' className='mb-4' />
      <h1>{authSuccess.instructMsg}</h1>
      <h3>
        {authSuccess.heading} <span>{data.email}</span>
      </h3>
      <p>{authSuccess.des}</p>
      <Button
        type='primary'
        htmlType='submit'
        size='large'
        className='my-2 px-5'
        onClick={onDone}>
        {authSuccess.btnTxt}
      </Button>
    </div> */}
    </div>
  );
};

export default SignUpSuccess;
