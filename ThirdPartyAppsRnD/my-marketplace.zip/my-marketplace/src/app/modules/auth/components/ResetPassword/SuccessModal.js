import React from 'react';
import {successTick} from 'assets/images';
import {signingInTexts} from 'data/auth';

const ApplyModal = ({returnToLogin}) => {
  return (
    <div className='reset-pass-apply-modal'>
      <img src={successTick} className='icn' alt='success-icon' />
      <div className='ttl'>{signingInTexts.resetSuccessTitle || ''}</div>
      <div className='sub'>{signingInTexts.resetSuccessLabel || ''}</div>
      <div className='sub'>
        {signingInTexts.resetConfirmation?.pleaseText || ''}
        <span onClick={returnToLogin} className='bl'>
          {signingInTexts.resetConfirmation?.loginText || ''}
        </span>{' '}
        {signingInTexts.resetConfirmation?.postLoginText || ''}
      </div>
    </div>
  );
};

export default ApplyModal;
