import {Fragment} from 'react';
import {Button, Col, Form, Input, Row, Checkbox, Alert, Divider} from 'antd';
import {useInstance} from 'core/hooks';

import {GoogleButton} from 'core/components';

import {FooterMenu, SUPPORT_MAIL} from 'config';
import {footerMenuTexts} from 'data/footer';
import {signingInTexts, errorMessages} from 'data/auth';

const SignUp = ({onSubmitSignUp, signUpStatus}) => {
  const {request, error, data: instanceData} = useInstance();
  const onSubmit = values => {
    let nameArray = values?.full_name?.split(' ') || [];
    const firstName = nameArray[0];
    const lastName = nameArray.slice(1).join(' ') || '';
    const data = {
      first_name: firstName,
      last_name: lastName,
      email: values?.email?.toLowerCase(),
      agree: values?.agree,
      password: values?.password,
      instance: (instanceData?.institution_id && instanceData.subdomain) || '',
      institute_logo: '',
    };
    onSubmitSignUp(data);
  };

  const onKeyUp = e => {
    return e.target.value.toLowerCase();
  };

  return (
    <>
      <Form onFinish={onSubmit} data-cy='sign-up-form' layout='vertical'>
        {signUpStatus &&
          signUpStatus.error &&
          typeof signUpStatus.error === 'string' && (
            <div>
              <Alert message={signUpStatus.error} type='error' showIcon />
              <br />
            </div>
          )}
        {/* <Row gutter={30}>
          <Col sm={12} xs={24}>
            <Form.Item
              name='first_name'
              rules={[
                {required: true, message: errorMessages.invalidFirstName || ''},
              ]}
              data-cy='sign-up-form-item'>
              <Input
                className='a-input'
                size='large'
                placeholder={signingInTexts.firstNamePlaceholder || ''}
              />
            </Form.Item>
          </Col>
          <Col sm={12} xs={24}>
            <Form.Item
              name='last_name'
              rules={[
                {required: true, message: errorMessages.invalidLastName || ''},
              ]}
              data-cy='sign-up-form-item'>
              <Input
                className='a-input'
                size='large'
                placeholder={signingInTexts.lastNamePlaceholder || ''}
              />
            </Form.Item>
          </Col>
        </Row> */}
        <Form.Item
          name='full_name'
          label='Full Name'
          rules={[{required: true, message: errorMessages.invalidName || ''}]}
          data-cy='sign-up-form-item'>
          <Input
            size='large'
            maxLength={64}
            className='a-input'
            data-cy='sign-up-name'
            placeholder={signingInTexts.fullNamePlaceholder || ''}
          />
        </Form.Item>
        <Form.Item
          name='email'
          label='Email'
          rules={[
            {required: true, message: errorMessages.noEmailSignUp || ''},
            {
              type: 'email',
              message: errorMessages.invalidEmail || '',
            },
          ]}
          data-cy='sign-up-form-item'>
          <Input
            size={'large'}
            className='a-input'
            data-cy='sign-up-email'
            style={{textTransform: 'lowercase'}}
            placeholder={signingInTexts.emailPlaceholder || ''}
            rules={[{required: true, message: 'Please !'}]}
          />
        </Form.Item>
        <Form.Item
          name='password'
          label='Password'
          rules={[{required: true, message: errorMessages.noPassword || ''}]}>
          <Input.Password
            size='large'
            className='a-input'
            data-cy='sign-up-password'
            placeholder={signingInTexts.createPasswordPlaceholder || ''}
          />
        </Form.Item>
        <Row justify={'space-between'}>
          <Col md={2} lg={1} xs={1} className='checkboxItem'>
            <Form.Item
              name='agree'
              valuePropName='checked'
              rules={[
                {
                  validator: (_, value) =>
                    value
                      ? Promise.resolve()
                      : Promise.reject(
                          new Error(errorMessages.termsNotAccepted || ''),
                        ),
                },
              ]}
              data-cy='agree-terms-conditions'>
              <Checkbox className='a-checkbox a-links' />
            </Form.Item>
          </Col>
          <Col md={22} lg={23} xs={23} className='checkboxDescription'>
            <p>
              {`${signingInTexts.acknowledgementText} `}
              {FooterMenu.map(({key, path, target}) => {
                const {[key]: {secondaryName = ''} = {}} =
                  footerMenuTexts || {};
                if (key === 'TERMS' || key === 'PRIVACY') {
                  return (
                    <Fragment key={key}>
                      <Button
                        target={target}
                        className='term-option'
                        href={path}>
                        {secondaryName}
                      </Button>
                      {key === 'TERMS' && (
                        <span className='separator'> and </span>
                      )}
                    </Fragment>
                  );
                }
              })}
            </p>
          </Col>
        </Row>
        <Button
          type='primary'
          htmlType='submit'
          block
          size='large'
          loading={signUpStatus && signUpStatus.request}
          data-cy='form-sign-up'>
          {signingInTexts.signUpText || ''}
        </Button>
        <div className='dividerLine'>
          <Divider />
          <span className='continueWith'>
            {signingInTexts.continueWith || ''}
          </span>
        </div>
        <div className='googleBtnContainer'>
          <GoogleButton />
        </div>
        <p className='havingTrouble'>
          {signingInTexts.havingTroubleText}{' '}
          <a href={`mailto:${SUPPORT_MAIL}`}>Contact Support</a>
        </p>
        <br />
      </Form>
      {/* <div className='terms-n-privacy' data-cy='sign-up-terms-privacy'>
        {FooterMenu.map(({key, path, target}) => {
          const {[key]: {secondaryName = ''} = {}} = footerMenuTexts || {};
          if (key === 'TERMS' || key === 'PRIVACY') {
            return (
              <Fragment key={key}>
                <Button target={target} className='term-option' href={path}>
                  {secondaryName}
                </Button>
                {key === 'TERMS' && <span className='separator'>|</span>}
              </Fragment>
            );
          }
        })}
      </div> */}
    </>
  );
};

export default SignUp;
