import {createRef, useEffect} from 'react';
import {Col, Form, Input, Row, Button} from 'antd';
import {signingInTexts, errorMessages} from 'data/auth';

const ChangePassword = props => {
  const {data, closeLoginScreen, onLogin, history, auth} = props || {};
  const formRef = createRef();
  useEffect(() => {
    if (data && data.ChallengeParameters) {
      const EmailValue = JSON.parse(data.ChallengeParameters.userAttributes)
        .email;
      if (EmailValue) {
        formRef &&
          formRef.current &&
          formRef.current.setFieldsValue({
            ['email']: EmailValue || '',
          });
      }
    }
    return () => {};
  }, [data]);

  if (
    !(
      data &&
      data.ChallengeName &&
      data.ChallengeName === 'NEW_PASSWORD_REQUIRED'
    )
  ) {
    closeLoginScreen();
  }
  const onSubmit = values => {
    const formData = {
      email: values.email,
      new_password: values.password,
      session: data && data.Session,
    };
    onLogin(formData, false, history);
  };
  const layout = {
    labelCol: {span: 7},
    wrapperCol: {span: 18},
  };

  return (
    <div className='change-password'>
      <div className='ttl'>{signingInTexts.changePasswordLabel || ''}</div>
      <div className='sub-ttl'>
        {signingInTexts.changePasswordRequestText || ''}
      </div>
      <div className='form-l'>
        <Form onFinish={onSubmit} {...layout} ref={formRef}>
          <Form.Item
            name='email'
            label={signingInTexts.emailLabel || ''}
            rules={[
              {required: true, message: errorMessages.noEmail || ''},
              {type: 'email', message: errorMessages.invalidEmail || ''},
            ]}
            className='f-itm'>
            <Input
              disabled={true}
              className='a-input'
              size='large'
              placeholder={signingInTexts.resetPasswordEmailPlaceholder || ''}
            />
          </Form.Item>
          <Form.Item
            name='password'
            label={signingInTexts.newPasswordLabel || ''}
            rules={[
              {
                required: true,
                message: errorMessages.changePasswordError || '',
              },
            ]}
            className='f-itm'>
            <Input
              className='a-input'
              type='password'
              size='large'
              placeholder={signingInTexts.newPasswordPlaceholder || ''}
            />
          </Form.Item>
          <Form.Item
            name='repassword'
            label={signingInTexts.reEnterPasswordLabel || ''}
            rules={[
              {
                validator: (_, value) =>
                  formRef &&
                  formRef.current &&
                  formRef.current.getFieldValue('password') === value
                    ? Promise.resolve()
                    : Promise.reject(
                        new Error(errorMessages.passwordMismatch || ''),
                      ),
              },
            ]}
            className='f-itm'>
            <Input
              className='a-input'
              type='password'
              size='large'
              placeholder={signingInTexts.reEnterNewPasswordPlaceholder || ''}
            />
          </Form.Item>
          <Row justify='end'>
            <Col>
              <Button
                htmlType='submit'
                size='large'
                type='primary'
                loading={auth.request}>
                {signingInTexts.changePasswordBtnText || ''}
              </Button>
            </Col>
          </Row>
        </Form>
      </div>
    </div>
  );
};

export default ChangePassword;
