import React, {useState} from 'react';
import {Button, Form, Alert, Modal} from 'antd';
import {connect} from 'react-redux';
import {useHistory, useLocation} from 'react-router-dom';
import {queryStringParse} from 'core/utils';
import {
  confirmForgotPassword,
  forgotPasswordSelector,
} from 'redux/modules/auth';
import SuccessModal from './SuccessModal';
import {signingInTexts, errorMessages} from 'data/auth';
import './style.less';

const layout = {
  labelCol: {span: 4},
  wrapperCol: {span: 20},
};

const ResetPassword = ({confirmForgotPassword, data}) => {
  const formRef = React.createRef();
  const router = useHistory();
  const [submit, setSubmit] = useState(false);
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);

  const {search} = useLocation();
  const {email, username} = queryStringParse(search);

  const returnToLogin = () => {
    setShowSuccessPopup(false);
    router.push('/?sign_in=True');
  };

  const onSuccessPopupClose = () => {
    setShowSuccessPopup(false);
    router.push('/');
  };

  const onSubmit = values => {
    setSubmit(true);
    confirmForgotPassword(values, res => {
      res && (res.Success || res.success) && setShowSuccessPopup(true);
    });
  };
  return (
    <>
      <Form
        onFinish={onSubmit}
        {...layout}
        ref={formRef}
        initialValues={{username: username}}>
        <div className='resetPassword'>
          <h1>{signingInTexts.resetPasswordLabel || ''}</h1>
          <p>{signingInTexts.resetPasswordDescription || ''}</p>
          {submit && data && data.error && data.error.Failed && (
            <div>
              <Alert message={data.error.Failed} type='error' showIcon />
              <br />
            </div>
          )}

          <div className='d-flex py-2 mt-4'>
            <div className='reset-l'>
              {signingInTexts.verificationCodeLabel || ''}
              <span>*</span>
            </div>
            <div className='reset-r'>
              <Form.Item
                name='verification_code'
                rules={[
                  {
                    required: true,
                    message: errorMessages.noVerificationCode || '',
                  },
                ]}>
                <input
                  placeholder={signingInTexts.verificationCodePlaceholder || ''}
                />
              </Form.Item>
            </div>
          </div>
          <div className='d-flex py-2'>
            <div className='reset-l'>
              {signingInTexts.emailLabel || ''}
              <span>*</span>
            </div>
            <div className='reset-r'>
              <Form.Item
                name='username'
                rules={[
                  {required: true, message: errorMessages.noEmail || ''},
                  {type: 'email', message: errorMessages.invalidEmail || ''},
                ]}>
                <input
                  disabled={true}
                  placeholder={
                    signingInTexts.resetPasswordEmailPlaceholder || ''
                  }
                />
              </Form.Item>
            </div>
          </div>
          <div className='d-flex py-2'>
            <div className='reset-l'>
              {signingInTexts.newPasswordLabel || ''}
              <span>*</span>
            </div>
            <div className='reset-r'>
              <Form.Item
                name='new_password'
                rules={[
                  {required: true, message: errorMessages.noPassword || ''},
                ]}>
                <input
                  type='password'
                  placeholder={signingInTexts.newPasswordPlaceholder || ''}
                />
              </Form.Item>
            </div>
          </div>
          <div className='d-flex py-2'>
            <div className='reset-l'>
              {signingInTexts.reEnterPasswordLabel || ''}
              <span>*</span>
            </div>
            <div className='reset-r'>
              <Form.Item
                name='re_password'
                rules={[
                  {
                    validator: (_, value) =>
                      formRef &&
                      formRef.current &&
                      formRef.current.getFieldValue('new_password') === value
                        ? Promise.resolve()
                        : Promise.reject(
                            new Error(errorMessages.passwordMismatch || ''),
                          ),
                  },
                ]}>
                <input
                  type='password'
                  placeholder={
                    signingInTexts.reEnterNewPasswordPlaceholder || ''
                  }></input>
              </Form.Item>
            </div>
          </div>
          <div className='text-right mt-4'>
            <Button
              disabled={data.requestConfirm}
              loading={data.requestConfirm}
              htmlType={'submit'}
              className='btn ant-btn-primary'>
              {signingInTexts.resetBtnText || ''}
            </Button>
          </div>
        </div>
      </Form>
      <Modal
        maskStyle={{backgroundColor: '#ffffff', opacity: 0.8}}
        visible={showSuccessPopup}
        className='modal-msg'
        maskClosable={false}
        closable={false}
        centered={true}
        title={null}
        width={700}
        mask={true}
        footer={[
          <Button key='submit' type='primary' onClick={onSuccessPopupClose}>
            {signingInTexts.doneBtnText || ''}
          </Button>,
        ]}>
        <SuccessModal returnToLogin={returnToLogin} />
      </Modal>
    </>
  );
};

const mapStateToProps = state => ({
  data: forgotPasswordSelector(state),
});

export default connect(mapStateToProps, {
  confirmForgotPassword,
})(ResetPassword);
