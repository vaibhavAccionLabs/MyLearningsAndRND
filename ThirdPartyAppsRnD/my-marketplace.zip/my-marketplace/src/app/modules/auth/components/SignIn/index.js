import React, {useState} from 'react';
import {Button, Col, Form, Input, Row, Checkbox, Alert, Divider} from 'antd';
import {signingInTexts, errorMessages} from 'data/auth';
import {GoogleOutlined} from '@ant-design/icons';

const SignIn = ({
  onLogin,
  auth,
  savedCredentials,
  history,
  openChangePassword,
  goToForgotPassword,
}) => {
  const [isSubmit, setSubmit] = useState(false);
  const onSubmit = values => {
    setSubmit(true);
    const data = {
      username: values.email,
      password: values.password,
    };

    //For Analytics
    // window.dataLayer.push({
    //   event: 'formSubmission',
    //   formType: 'Login form',
    //   formPosition: 'Popup',
    //   data: data,
    // });

    onLogin(data, values.remember, history, data => {
      if (
        data &&
        data.ChallengeName &&
        data.ChallengeName === 'NEW_PASSWORD_REQUIRED'
      ) {
        openChangePassword(data);
      }
    });
  };
  return (
    <div>
      <Form onFinish={onSubmit} data-cy='sign-in-form' layout='vertical'>
        <Form.Item
          name='email'
          label='Email'
          initialValue={savedCredentials && savedCredentials.username}
          rules={[
            {
              required: true,
              message: errorMessages.noEmail || '',
            },
            {
              type: 'email',
              message: errorMessages.invalidEmail || '',
            },
          ]}>
          <Input
            size='large'
            className='a-input'
            data-cy='sign-in-email'
            style={{textTransform: 'lowercase'}}
            placeholder={signingInTexts.emailPlaceholder || ''}
          />
        </Form.Item>
        <Form.Item
          name='password'
          label='Password'
          initialValue={savedCredentials && savedCredentials.password}
          rules={[{required: true, message: errorMessages.noPassword || ''}]}>
          <Input.Password
            size='large'
            className='a-input'
            data-cy='sign-in-password'
            placeholder={signingInTexts.passwordPlaceholder || ''}
          />
        </Form.Item>

        {isSubmit && auth && auth.error && auth.error.reason && (
          <div>
            <Alert message={auth.error.reason} type='error' showIcon />
            <br />
          </div>
        )}

        <Row justify={'space-between'}>
          <Col>
            <Form.Item
              name='remember'
              valuePropName='checked'
              data-cy='remember-me'>
              <Checkbox className='a-checkbox a-links'>
                {signingInTexts.rememberMeText || ''}
              </Checkbox>
            </Form.Item>
          </Col>
          <Col>
            <Button
              type='link'
              className='a-links'
              onClick={goToForgotPassword}
              data-cy='forgot-password'>
              {signingInTexts.forgotPasswordText || ''}
            </Button>
          </Col>
        </Row>
        <Button
          type='primary'
          htmlType='submit'
          block
          size={'large'}
          loading={auth.request}
          data-cy='form-sign-in'>
          {signingInTexts.signInText || ''}
        </Button>
        <div className='dividerLine'>
          <Divider />
          <span className='continueWith'>
            {signingInTexts.continueWith || ''}
          </span>
        </div>
        <div className='googleBtnContainer'>
          <Button
            className='googleBtn'
            block
            icon={<GoogleOutlined />}
            data-cy='form-google-sign-in'>
            {signingInTexts.googleBtnTxt || ''}
          </Button>
        </div>
        <br />
        <br />
        <br />
      </Form>
    </div>
  );
};

export default SignIn;
