import React, {useState} from 'react';
import {Col, Form, Input, Row, Button, message} from 'antd';
import SuccessModal from './SuccessModal';
import {signingInTexts, errorMessages} from 'data/auth';
const {error} = message;

const ChangePassword = props => {
  const {returnToLogin, data, closeLoginScreen, history, forgotPassword} =
    props || {};
  const formRef = React.createRef();
  const [successModal, setSuccessModal] = useState(false);
  const [email, setEmail] = useState('');
  const onSubmit = values => {
    const formData = {
      username: values.email,
    };
    setEmail(values.email);
    forgotPassword(formData, res => {
      res && (res.success || res.Success) && setSuccessModal(true);
      res && res.Error && error(res.Error);
    });
  };
  const layout = {
    labelCol: {span: 4},
    wrapperCol: {span: 20},
  };
  const onCloseSuccessModal = () => {
    setSuccessModal(false);
  };
  const onResend = () => {
    setSuccessModal(false);
    onSubmit({email});
  };
  return (
    <div className='change-password' data-cy='forgot-password-popup'>
      <div className='ttl' data-cy='forgot-pass-heading'>
        {signingInTexts.forgotYourPasswordLabel || ''}
      </div>
      <div className='sub-ttl' data-cy='forgot-pass-description'>
        {signingInTexts.forgotPasswordDescription || ''}
      </div>
      <div className='form-l'>
        <Form onFinish={onSubmit} {...layout} ref={formRef}>
          <Form.Item
            name='email'
            label={signingInTexts.emailLabel || ''}
            rules={[
              {required: true, message: errorMessages.noEmail || ''},
              {type: 'email', message: errorMessages.invalidEmail || ''},
            ]}
            className='f-itm'
            data-cy='forgot-pass-email'>
            <Input
              className='a-input'
              size='large'
              placeholder={signingInTexts.forgotPasswordEmailPlaceholder || ''}
            />
          </Form.Item>
          <br />
          <Row justify='end' align='middle' gutter={32}>
            <Col data-cy='return-to-login-page'>
              <span onClick={returnToLogin} className='lnk-btn'>
                {signingInTexts.returnToLoginText || ''}
              </span>
            </Col>
            <Col data-cy='forgot-pass-submit-btn'>
              <Button
                htmlType='submit'
                size='large'
                type='primary'
                loading={data.request}>
                {signingInTexts.submitBtnText || ''}
              </Button>
            </Col>
          </Row>
        </Form>
      </div>
      <SuccessModal
        email={email}
        onResend={onResend}
        onClose={onCloseSuccessModal}
        visible={successModal}
      />
    </div>
  );
};

export default ChangePassword;
