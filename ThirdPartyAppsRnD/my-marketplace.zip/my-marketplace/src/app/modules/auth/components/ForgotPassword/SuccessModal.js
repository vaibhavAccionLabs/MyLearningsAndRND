import React from 'react';
import {Divider, Modal} from 'antd';
import {signingInTexts} from 'data/auth';

const SuccessModal = ({email, onClose, visible, onResend}) => {
  return (
    <Modal
      className='forgot-pass-success'
      visible={visible}
      footer={false}
      title={null}
      onCancel={onClose}>
      <div className='ttl' data-cy='reset-pass-heading'>
        {signingInTexts.resetPasswordLabel || ''}
      </div>
      <div className='desc' data-cy='reset-pass-desc'>
        {signingInTexts.forgotPasswordSuccessDesc?.preSuccessDesc || ''}
        <span>{` ${email}`}</span>
        {`${signingInTexts.forgotPasswordSuccessDesc?.fullStop || ''} `}
        {signingInTexts.forgotPasswordSuccessDesc?.postSuccessDesc || ''}
      </div>
      <Divider />
      <div className='ftr' data-cy='reset-pass-footer'>
        <div data-cy='reset-footer-pre'>
          {signingInTexts.emailNotReceivedText || ''}
        </div>
        <div data-cy='reset-footer-post'>
          {signingInTexts.checkSpamText?.preCheckSpamText || ''}
          <span onClick={onResend} data-cy='resend-email-btn'>
            {` ${signingInTexts.checkSpamText?.resendText || ''} `}
          </span>
          {signingInTexts.checkSpamText?.postCheckSpamText || ''}
        </div>
      </div>
    </Modal>
  );
};
export default SuccessModal;
