import React from 'react';
import {connect} from 'react-redux';

import {
  loginScreenSelector,
  openLoginScreen,
  closeLoginScreen,
  login,
  authSelector,
  forgotPasswordSelector,
  forgotPassword,
} from 'redux/modules/auth';

import AuthModal from './AuthModal';

const AuthScreen = props => {
  const {loginScreen} = props;
  return loginScreen?.visible ? <AuthModal {...props} /> : <></>;
};

const mapStateToProps = state => ({
  loginScreen: loginScreenSelector(state),
  auth: authSelector(state),
  forgotPasswordData: forgotPasswordSelector(state),
});

export default connect(mapStateToProps, {
  openLoginScreen,
  closeLoginScreen,
  login,
  forgotPassword,
})(AuthScreen);
