import {useEffect} from 'react';
import {useHistory} from 'react-router-dom';
import {connect} from 'react-redux';

import {queryStringParse} from 'core/utils';

import {EventList, EventDetails} from './submodules';

import {getAppConfig} from 'redux/modules/general';
import {
  fetchUpcomingEvents,
  getUpcomingEvents,
  resetEventList,
  clearEventDetails,
} from 'redux/modules/events';

import './style.less';

const SearchEvents = props => {
  const {clearEventDetails} = props;
  const history = useHistory();
  const {
    location: {search},
  } = history;

  const {event_id, activetab} = queryStringParse(search);

  useEffect(() => {
    if (!event_id) {
      clearEventDetails();
    }
  }, [event_id, search]); // eslint-disable-line react-hooks/exhaustive-deps

  return event_id ? (
    <EventDetails event_id={event_id} />
  ) : (
    <EventList {...props} activetab={activetab} />
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  upcomingEvents: getUpcomingEvents(state),
});

export default connect(mapStateToProps, {
  fetchUpcomingEvents,
  resetEventList,
  clearEventDetails,
})(SearchEvents);
