// import {Divider} from 'antd';

import QRCode from '../QRCode';

import {ErrorBoundary} from 'core/components';

// import {mobileIcon} from 'assets/images';

import './style.less';

const MobileInfo = ({event_id}) => (
  <ErrorBoundary nameOfComponent='mod-comp-mobile-info'>
    <div className='access-info'>
      {/* <div id='mobile'>
        <span className='mobile'>
          <img src={mobileIcon} />
          <h3 className='fw-b'>Mobile</h3>
        </span>
        <p className='label'>Text</p>
        <div className='info'>
          <span className='info-label'>Text Code </span>
          <span>: {event_id}</span>
        </div>
        <div className='info'>
          <span className='info-label'>To </span>
          <span>: {process.env.REACT_APP_EVENT_SIGN_UP_TEXT_NUMBER}</span>
        </div>
      </div>
      <Divider /> */}
      <QRCode event_id={event_id} />
    </div>
  </ErrorBoundary>
);

export default MobileInfo;
