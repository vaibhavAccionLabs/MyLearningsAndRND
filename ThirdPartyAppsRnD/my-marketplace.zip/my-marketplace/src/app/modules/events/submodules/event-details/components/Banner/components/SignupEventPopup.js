import {useState} from 'react';
import {
  Modal,
  Form,
  Button,
  Radio,
  Input,
  InputNumber,
  Select,
  DatePicker,
  Checkbox,
} from 'antd';

import {PATTERN} from 'core/regex';

import '../../../style.less';

const {Option} = Select;
const {TextArea} = Input;

const SignupEventPopup = ({
  visible,
  onClose,
  onConfirm,
  userDetails = {},
  eventDetails = {},
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const {
    uuid,
    institute_id,
    business_partner_name: {company_name} = {},
    institute_details: {name: institute_name = ''} = {},
    survey_questions = [],
    respondent_info_fields = [],
  } = eventDetails;
  const hosted_by = institute_id ? institute_name : company_name;
  const onInfoSubmit = async formOutput => {
    setIsLoading(true);
    let respondentData = {};
    respondent_info_fields.forEach(field => {
      let _field = field;
      if (field === 'phone' || field === 'mobile') _field = 'phone_number';
      if (userDetails[_field]) {
        respondentData[field] = userDetails[_field];
      }
    });
    let surveyQuestions = [];
    if (survey_questions?.length > 0) {
      for (let i = 0; i < survey_questions.length; i++) {
        let question = survey_questions[i];
        surveyQuestions.push({
          uuid: question.uuid,
          question: question.question,
          answer: formOutput[question.question]
            ? String(formOutput[question.question])
            : String(Boolean(formOutput[question.question])),
        });
      }
    }
    const payload = {
      event_uuid: uuid,
      respondent_info_fields_values: respondentData,
      event_ques_ans: surveyQuestions,
    };
    onConfirm(payload);
  };

  return (
    <Modal
      title='Signup for Event'
      visible={visible}
      footer={null}
      wrapClassName='SignupEventModal'
      confirmLoading={isLoading}
      onCancel={onClose}>
      <p className='purple-bg'>
        <span className='pink-text'>{hosted_by || '-'} </span>
        needs the following information.
      </p>
      <Form onFinish={onInfoSubmit} className='signup-form'>
        {survey_questions &&
          survey_questions.length > 0 &&
          survey_questions.map((field, index) => {
            if (field?.response_type === 'RADIO') {
              return (
                <div key={index}>
                  <p className='question'>{`${field?.question}?`}</p>
                  <Form.Item
                    rules={[
                      {
                        required: true,
                        message: `Please choose an option`,
                      },
                    ]}
                    name={field?.question}
                    key={field?.question}>
                    <Radio.Group value={1}>
                      {field?.response_options &&
                        field?.response_options.map((option, idx) => {
                          return (
                            <Radio key={idx} value={option}>
                              {option}
                            </Radio>
                          );
                        })}
                    </Radio.Group>
                  </Form.Item>
                </div>
              );
            } else if (field?.response_type === 'PICKLIST') {
              return (
                <div key={index}>
                  <p className='question'>{`${field?.question}?`}</p>
                  <Form.Item
                    rules={[
                      {
                        required: true,
                        message: `Please select an option`,
                      },
                    ]}
                    name={field?.question}
                    key={field?.question}>
                    <Select placeholder='Select an option'>
                      {field?.response_options &&
                        field?.response_options.map((option, idx) => {
                          return (
                            <Option key={idx} value={option}>
                              {option}
                            </Option>
                          );
                        })}
                    </Select>
                  </Form.Item>
                </div>
              );
            } else if (field?.response_type === 'DATE') {
              return (
                <div key={index}>
                  <p className='question'>{`${field?.question}?`}</p>
                  <Form.Item
                    key={field?.question}
                    name={field?.question}
                    rules={[
                      {
                        required: true,
                        message: `Please select a date`,
                      },
                    ]}>
                    <DatePicker format={'MM/DD/YYYY'} />
                  </Form.Item>
                </div>
              );
            } else if (field?.response_type === 'CHECKBOX') {
              return (
                <div key={index}>
                  <p className='question'>{`${field?.question}?`}</p>
                  <Form.Item key={field?.question} name={field?.question}>
                    <Checkbox />
                  </Form.Item>
                </div>
              );
            } else if (field?.response_type === 'NUMBER') {
              return (
                <div key={index}>
                  <p className='question'>{`${field?.question}?`}</p>
                  <Form.Item
                    key={field?.question}
                    name={field?.question}
                    rules={[
                      {
                        required: true,
                        message: `Please enter a number`,
                      },
                      // {
                      //   pattern: PATTERN.number,
                      //   message: `Please enter a valid answer in number format`,
                      // },
                    ]}>
                    <InputNumber />
                  </Form.Item>
                </div>
              );
            } else if (field?.response_type === 'TEXTAREA') {
              return (
                <div key={index}>
                  <p className='question'>{`${field?.question}?`}</p>
                  <Form.Item
                    name={field?.question}
                    className='f-itm'
                    key={field?.question}>
                    <TextArea rows={4} />
                  </Form.Item>
                </div>
              );
            } else {
              return (
                <div key={index}>
                  <p className='question'>{`${field?.question}?`}</p>
                  <Form.Item
                    className='f-itm'
                    name={field?.question}
                    rules={[
                      {
                        required: true,
                        message: 'Please enter a value',
                      },
                    ]}
                    className='f-itm'>
                    <Input className='a-input' size='large' />
                  </Form.Item>
                </div>
              );
            }
          })}
        <div className='event-signup-footer'>
          <Button
            onClick={onClose}
            type={'default'}
            className={'btn-orange-outline'}>
            CANCEL
          </Button>
          <Button
            loading={isLoading}
            type={'primary'}
            className='banner-cancel-btn'
            htmlType='submit'>
            SIGNUP
          </Button>
        </div>
      </Form>
    </Modal>
  );
};

export default SignupEventPopup;
