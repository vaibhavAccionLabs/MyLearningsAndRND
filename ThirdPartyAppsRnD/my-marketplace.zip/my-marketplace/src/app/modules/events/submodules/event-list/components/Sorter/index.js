import React from 'react';
import {Select} from 'antd';

const {Option} = Select;

const SortData = [
  {
    title: 'All',
    value: 'all',
  },
  {
    title: 'In-Person',
    value: 'in-person',
  },
  {
    title: 'Virtual',
    value: 'virtual',
  },
];

const Sorter = ({event_type, onChange}) => (
  <div className='events-search-sorter'>
    <h3>Upcoming Events</h3>
    <div>
      <span className='text-right'>
        <span className='sortby'>Event Type</span>
        <Select
          dropdownClassName='sort-grid'
          className='pl-3'
          defaultValue={event_type}
          value={event_type}
          onChange={value => onChange('event_type', value)}>
          {SortData.map(({value, title}, idx) => (
            <Option value={value} key={idx}>
              {title}
            </Option>
          ))}
        </Select>
      </span>
    </div>
  </div>
);

export default React.memo(Sorter);
