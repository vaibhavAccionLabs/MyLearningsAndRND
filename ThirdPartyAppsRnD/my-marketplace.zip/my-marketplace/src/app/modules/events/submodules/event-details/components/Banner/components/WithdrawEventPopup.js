import {useState} from 'react';
import {Modal} from 'antd';

import '../../../style.less';

const WithdrawEventPopup = ({title, visible, onClose, onConfirm}) => {
  const [isLoading, setIsLoading] = useState(false);
  const onWithdraw = () => {
    setIsLoading(true);
    onConfirm();
  };

  return (
    <Modal
      wrapClassName='WithdrawEventModal'
      title='Withdraw Event Signup'
      visible={visible}
      width='70%'
      okText='Yes'
      mask={true}
      closable={true}
      onOk={onWithdraw}
      confirmLoading={isLoading}
      onCancel={onClose}>
      <p>
        Are your sure that you no longer wish to attend the event{' '}
        <span className='pink-text'>{title}</span> ?
      </p>
      <p>This will remove the event from the dashboard.</p>
    </Modal>
  );
};

export default WithdrawEventPopup;
