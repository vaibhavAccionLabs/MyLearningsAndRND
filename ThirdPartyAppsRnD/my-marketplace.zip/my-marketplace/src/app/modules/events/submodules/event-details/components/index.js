import Banner from './Banner';
import MobileInfo from './MobileInfo';

export {Banner, MobileInfo};
