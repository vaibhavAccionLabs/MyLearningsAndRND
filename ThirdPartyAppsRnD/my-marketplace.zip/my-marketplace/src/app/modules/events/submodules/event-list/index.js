import {useCallback, useEffect, useState} from 'react';
import {Row, Col, Form, Button, Badge} from 'antd';
import {FilterOutlined} from '@ant-design/icons';
import isEmpty from 'lodash/isEmpty';

import {useEnableDisableScroll} from 'core/hooks';
import {
  AppBreadcrumb,
  EventCard,
  RequestErrorLoader,
  NoEvents,
  ErrorBoundary,
} from 'core/components';

import {FiltersForm, Sorter} from './components';

const EventList = props => {
  const {
    fetchUpcomingEvents,
    upcomingEvents,
    resetEventList,
    clearEventDetails,
    activetab,
    category,
    name,
    appConfig: {isMobileView},
  } = props;
  const {data} = upcomingEvents;
  const {
    isFilterVisible,
    onFilterClick,
    setIsFilterVisible,
  } = useEnableDisableScroll();
  const [reqParams, setReqParams] = useState({
    event_type: 'all',
    page: 1,
  });

  const [filters, setFilters] = useState({});

  useEffect(() => {
    const Obj = Object.assign({}, reqParams, {
      event_type: 'all',
      page: 1,
    });
    setReqParams(Obj);
    setFilters({});
    form.resetFields();
    let filter = filters;
    if (category && name) {
      filter = Object.assign({}, filters, {[category]: name});
    }
    fetchUpcomingEvents(Obj, filter);

    return () => {
      resetEventList();
      clearEventDetails();
    };
  }, [fetchUpcomingEvents, name]); // eslint-disable-line react-hooks/exhaustive-deps

  const [form] = Form.useForm();

  const loadMoreEvents = () => {
    const newPage = reqParams.page + 1;
    const Obj = Object.assign({}, reqParams, {
      event_type: reqParams.event_type,
      page: newPage,
    });
    refetchData(Obj, filters, true);
  };

  const onSorterChange = useCallback((key, value) => {
    const Obj = Object.assign({}, reqParams, {[key]: value, page: 1});
    refetchData(Obj, filters);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const onFinish = values => {
    let filterApply = false;
    if (values) {
      const filterKeys = Object.keys(values);
      filterKeys.map(key => {
        if (values[key] || values[key] === '') {
          filterApply = true;
        }
      });
      if (filterApply) {
        const Obj = Object.assign({}, reqParams, {page: 1});
        setFilters(values);
        refetchData(Obj, values);
        isMobileView && setIsFilterVisible(false);
      }
    }
  };

  // to handle error conditions
  const onFinishFailed = errorInfo => {
    console.log('Failed:', errorInfo);
  };

  const onFilterReset = () => {
    const Obj = Object.assign({}, reqParams, {event_type: 'all', page: 1});
    setFilters({});
    form.resetFields();
    refetchData(Obj, null);
    isMobileView && setIsFilterVisible(false);
  };

  const refetchData = useCallback((Obj, filters, loadMore = false) => {
    setReqParams(Obj);
    let filter = filters;
    if (category && name) {
      filter = Object.assign({}, filters, {[category]: name});
    }
    fetchUpcomingEvents(Obj, filter, loadMore);
  });

  const hideLoadMore =
    data?.page_details &&
    reqParams?.page >= data?.page_details?.no_of_pages &&
    !upcomingEvents.request &&
    !upcomingEvents.error;

  return (
    <div id='SearchEvents'>
      {!activetab && (
        <>
          <header className='findStudent_banner'>
            <div className='header_bannerText'>
              <div>
                <h1 className='title'>Search Events</h1>
                <h5 className='desc'>
                  Discover local and virtual events like job fairs, employer
                  presentations and workshops.
                </h5>
              </div>
            </div>
          </header>
          {/* <AppBreadcrumb
            dataList={[
              {
                name: 'Search Events',
              },
            ]}
          /> */}
        </>
      )}

      <div className='findStudent_search mx-3 my-4 py-4'>
        {isMobileView && (
          <span className='filterUpcoming'>
            <span className='w_text'>Filter Results</span>
            <Badge dot={!isEmpty(filters)}>
              <FilterOutlined onClick={onFilterClick} />
            </Badge>
          </span>
        )}
        <Row>
          {isFilterVisible && (
            <Col xs={24} sm={24} md={5} lg={5} className='pr-3'>
              <FiltersForm
                form={form}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                filters={filters}
                onReset={onFilterReset}
                isMobileView={isMobileView}
                onHideFilter={onFilterClick}
              />
            </Col>
          )}
          <Col xs={24} sm={24} md={19} lg={19}>
            <div className='search-events-data'>
              <Sorter {...reqParams} onChange={onSorterChange} />
              <ErrorBoundary
                nameOfComponent='module-event-list'
                typeOfUi='subPage'>
                <RequestErrorLoader
                  body={{
                    ...upcomingEvents,
                    data: upcomingEvents.data?.event_details || [],
                  }}
                  overideNoDataContainer={<NoEvents navPath={false} />}>
                  {data?.event_details?.length > 0 && (
                    <div className='upComing_eventCard'>
                      <ul>
                        {data.event_details.map(event => (
                          <EventCard
                            enableNavigation
                            data={event}
                            key={event?.event_id}
                          />
                        ))}
                      </ul>
                      {!hideLoadMore && (
                        <div className='text-center'>
                          <Button
                            type='primary'
                            className='events-load-more'
                            onClick={loadMoreEvents}>
                            {upcomingEvents?.request
                              ? 'LOADING...'
                              : 'LOAD MORE'}
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </RequestErrorLoader>
              </ErrorBoundary>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default EventList;
