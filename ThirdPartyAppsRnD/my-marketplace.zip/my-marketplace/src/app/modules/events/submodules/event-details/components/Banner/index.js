import {useState, useEffect} from 'react';
import {Button, message} from 'antd';
//Avatar
import {CheckCircleFilled} from '@ant-design/icons';
import moment from 'moment';

import {getBanner} from 'core/utils';
//getLogo
import {useAuth, useUser} from 'core/hooks';
import {ErrorBoundary} from 'core/components';

import {SignupEventPopup, WithdrawEventPopup, QRCode} from './components';
import '../../style.less';

const Banner = ({
  fetchUserData,
  eventDetails,
  withdrawEvent,
  signUpForEvent,
  openLoginScreen,
  fetchStudentEventSignUpStatus,
  event_id,
  appConfig: {isMobileView},
}) => {
  const {
    uuid,
    title,
    end_date,
    // institute_id,
    survey_questions,
    banner_cloudinary,
    respondent_info_fields,
    // institute_details: {logo_cloudinary: institute_logo} = {},
    // business_partner_name: {logo_cloudinary: bp_logo} = {},
  } = eventDetails;
  const [token] = useAuth();
  const userData = useUser();

  const {data: userDetails = {}} = userData;

  //const event_logo = institute_id ? institute_logo : bp_logo;

  const [signUpLoading, setSignUpLoading] = useState(false);
  const [isEventSignUp, setEventSignUp] = useState(false);
  const [SignupPopupVisible, setSignupPopupVisible] = useState(false);
  const [WithdrawPopupVisible, setWithdrawPopupVisible] = useState(false);

  const closePopups = () => {
    setSignupPopupVisible(false);
    setWithdrawPopupVisible(false);
  };

  const getRespondentInfo = userInfo => {
    let respondentData = {};
    respondent_info_fields.forEach(field => {
      let _field = field;
      if (field === 'phone' || field === 'mobile') _field = 'phone_number';
      if (userInfo?.[_field]) {
        respondentData[field] = userInfo[_field];
      }
    });
    return respondentData;
  };

  const onSignUp = async data => {
    try {
      const response = await signUpForEvent(data);
      if (response?.Success) {
        message.success(response.Success);
        setEventSignUp(true);
        setSignUpLoading(false);
        closePopups();
        return;
      } else if (response?.error) {
        setEventSignUp(true);
        closePopups();
        throw new Error(response?.error);
      }
      throw new Error('Something went wrong, Please try again...');
    } catch (error) {
      message.error(
        error.message || 'Something went wrong, Please try again...',
      );
      setSignUpLoading(false);
      closePopups();
    }
  };

  const onWithdraw = async () => {
    try {
      const response = await withdrawEvent(uuid);
      if (response?.Success) {
        message.success(response.Success);
        setEventSignUp(false);
        closePopups();
        return;
      }
      throw new Error('Something went wrong, Please try again...');
    } catch (error) {
      message.error(
        error?.message || 'Something went wrong, Please try again...',
      );
    }
  };

  const getBannerImageStyle = () => ({
    backgroundImage: `url(${getBanner(banner_cloudinary, {
      width: isMobileView ? window.screen.width : 1250,
      height: 250,
    })})`,
  });

  const signupEventCheck = async () => {
    setSignUpLoading(true);
    const statusResponse =
      event_id && (await fetchStudentEventSignUpStatus(event_id));
    if (statusResponse?.event_details?.length) {
      setEventSignUp(true);
      setSignUpLoading(false);
      return true;
    }

    setEventSignUp(false);
    setSignUpLoading(false);
    return false;
  };

  const signUpEvent = async user_data => {
    if (survey_questions?.length) {
      setSignupPopupVisible(true);
    } else {
      setSignUpLoading(true);
      const userProfile = user_data || (await fetchUserData());
      const payload = {
        event_uuid: uuid,
        event_ques_ans: [],
        respondent_info_fields_values: getRespondentInfo(userProfile),
      };
      onSignUp(payload);
    }
  };

  const onEventSignUpClick = async () => {
    if (token) {
      await signUpEvent(userDetails);
    } else {
      openLoginScreen({
        callback: async () => {
          if (await signupEventCheck()) {
            message.warning('You already signed up for the event.');
          } else {
            await signUpEvent();
          }
        },
      });
    }
  };

  useEffect(() => {
    signupEventCheck();
  }, [token]); // eslint-disable-line react-hooks/exhaustive-deps

  const hideEllipse = moment().isAfter(end_date, 'second');

  return (
    <ErrorBoundary nameOfComponent='mod-comp-event-details-banner'>
      <div className='event-banner'>
        <div className='event-banner-container' style={getBannerImageStyle()}>
          <div className='overlay'></div>
          <div className='contentContainer d-flex justify-content-between align-items-center'>
            <div></div>
            <div className='title pt-2'>
              <span className='mb-2'>{title}</span>
              <div className='banner-row-1'>
                {/* <div className='avatar'>
              <Avatar
                size={60}
                className='event-logo'
                src={getLogo(event_logo)}
              />
            </div> */}
                {!hideEllipse && (
                  <div className='actions'>
                    {isEventSignUp && (
                      <Button
                        className='btn-transparent mr-3'
                        onClick={() => setWithdrawPopupVisible(true)}>
                        Withdraw
                      </Button>
                    )}
                    <Button
                      loading={signUpLoading}
                      disabled={isEventSignUp}
                      className={`btn btn-blue ${
                        isEventSignUp ? 'btn-green' : ''
                      }`}
                      onClick={onEventSignUpClick}>
                      {isEventSignUp ? (
                        <CheckCircleFilled
                          className='checked-circle'
                          color='green'
                        />
                      ) : null}
                      {isEventSignUp ? 'Signed Up' : 'Signup for event'}
                    </Button>
                  </div>
                )}
              </div>
            </div>
            <div className='qrCode'>
              <QRCode event_id={event_id} />
            </div>
          </div>
        </div>

        {SignupPopupVisible && (
          <SignupEventPopup
            onConfirm={onSignUp}
            onClose={closePopups}
            userDetails={userDetails}
            eventDetails={eventDetails}
            visible={SignupPopupVisible}
          />
        )}

        {WithdrawPopupVisible && (
          <WithdrawEventPopup
            title={title}
            onClose={closePopups}
            onConfirm={onWithdraw}
            visible={WithdrawPopupVisible}
          />
        )}
      </div>
    </ErrorBoundary>
  );
};

export default Banner;
