import QRCode from 'qrcode.react';

import {ErrorBoundary} from 'core/components';

const Code = ({event_id}) => (
  <ErrorBoundary nameOfComponent='mod-comp-qrCode'>
    <div id='QR Code'>
      {/* <h3 className='fw-b'>QR Code</h3> */}
      <QRCode
        value={`${window?.location?.origin}/events?event_id=${event_id}`}
        size={100}
        bgColor='#ffffff'
        fgColor='#000000'
        level='L'
      />
    </div>
  </ErrorBoundary>
);

export default Code;
