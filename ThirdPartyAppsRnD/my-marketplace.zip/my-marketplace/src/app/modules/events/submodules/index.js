import EventDetails from './event-details';
import EventList from './event-list';

export {EventList, EventDetails};
