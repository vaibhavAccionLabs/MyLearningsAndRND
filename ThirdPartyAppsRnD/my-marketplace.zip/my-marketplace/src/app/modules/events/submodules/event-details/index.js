import {useEffect} from 'react';
import {connect} from 'react-redux';
import {Row, Col, List, Empty} from 'antd';
import moment from 'moment';

import {Banner, MobileInfo} from './components';

import {fileTypeIcon} from 'core/utils';
import {
  AppBreadcrumb,
  RequestErrorLoader,
  NoContentNavigator,
  ErrorBoundary,
} from 'core/components';

import {getAppConfig} from 'redux/modules/general';

import {
  clearEventDetails,
  fetchEventDetails,
  getStudentEventSignUpStatus,
  getEventDetails,
  withdrawEvent,
  signUpForEvent,
  fetchStudentEventSignUpStatus,
} from 'redux/modules/events';

import {openLoginScreen} from 'redux/modules/auth';
import {fetchUserData} from 'redux/modules/profile';

import './style.less';

const EventsDetail = props => {
  const {
    eventDetails,
    fetchEventDetails,
    eventDetailsError,
    eventDetailsRequest,
    SignedUpEventsError,
    SignedUpEventsRequest,
    clearEventDetails,
  } = props;

  const {
    description,
    event_id = '-',
    event_type = '-',
    start_date = '-',
    attachments = [],
    sponsored_by = '-',
    institute_id,
    institute_details: {name: institute_name = ''} = {},
    business_partner_name: {company_name} = {},
  } = eventDetails || {};

  const hosted_by = institute_id ? institute_name : company_name;

  const eventDescription = () => {
    let content = description || '-';
    return (
      <div
        className='EventDescription'
        dangerouslySetInnerHTML={{__html: content}}
      />
    );
  };

  useEffect(() => {
    props?.event_id && fetchEventDetails(props?.event_id);
    return () => {
      clearEventDetails();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className='EventsDetail'>
      <ErrorBoundary nameOfComponent='module-event-details' typeOfUi='subPage'>
        <RequestErrorLoader
          overideNoDataContainer={
            <NoContentNavigator
              message='Events Detail not found'
              pathTo='/events'
              label='
            Search Events'
            />
          }
          body={{
            request: eventDetailsRequest || SignedUpEventsRequest,
            error: eventDetailsError || SignedUpEventsError,
            data: eventDetails,
          }}>
          {!eventDetailsRequest && !eventDetailsError && (
            <>
              <AppBreadcrumb
                dataList={[
                  {
                    name: 'Search Events',
                    path: '/events',
                  },
                  {
                    name: 'Events Detail',
                  },
                ]}
              />
              <Banner {...props} />
              <div className='contentContainer'>
                <Row className='data-container'>
                  <Col lg={16} md={16} sm={24} xs={24} className='content'>
                    <div id='sponsoredBy'>
                      <h3>Sponsored by</h3>
                      <p>{sponsored_by || '-'}</p>
                    </div>
                    <div id='Description'>
                      <h3>Description</h3>
                      {eventDescription() || '-'}
                    </div>
                    <div id='Attachments'>
                      <h3>Attachments</h3>
                      <List
                        className='document_list'
                        locale={{
                          emptyText: (
                            <Empty
                              description={'No attachments'}
                              imageStyle={{display: 'none'}}
                            />
                          ),
                        }}
                        dataSource={attachments}
                        loading={false}
                        renderItem={({name, attachment}) => {
                          const Icon = fileTypeIcon(attachment);
                          return (
                            <List.Item>
                              <Icon />
                              <a
                                href={attachment}
                                target='_blank'
                                className='px-2'
                                download='file'>
                                {name}
                              </a>
                            </List.Item>
                          );
                        }}
                      />
                    </div>
                  </Col>
                  <Col lg={8} md={8} sm={24} xs={24}>
                    <Row className='data-row'>
                      <Col
                        lg={24}
                        md={24}
                        sm={24}
                        xs={24}
                        className='data-column'>
                        <div>
                          <p>Date & Time</p>
                          <h3>
                            {start_date
                              ? moment(start_date).format('MM/DD/YYYY; hh:mm A')
                              : '-'}
                          </h3>
                        </div>
                      </Col>
                      <Col
                        lg={24}
                        md={24}
                        sm={24}
                        xs={24}
                        className='data-column'>
                        <div>
                          <p>Hosted By</p>
                          <h3>{hosted_by || '-'}</h3>
                        </div>
                      </Col>
                      <Col
                        lg={24}
                        md={24}
                        sm={24}
                        xs={24}
                        className='data-column event_type'>
                        <div>
                          <p>Event Type</p>
                          <h3>{event_type || '-'}</h3>
                        </div>
                      </Col>
                    </Row>

                    {/* <MobileInfo event_id={event_id} /> */}
                  </Col>
                </Row>
              </div>
            </>
          )}
        </RequestErrorLoader>
      </ErrorBoundary>
    </div>
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  eventDetails: getEventDetails(state).data,
  eventDetailsRequest: getEventDetails(state).request,
  eventDetailsError: getEventDetails(state).error,
  StudentEventSignUpStatusError: getStudentEventSignUpStatus(state).error,
  StudentEventSignUpStatusRequest: getStudentEventSignUpStatus(state).request,
});

export default connect(mapStateToProps, {
  fetchEventDetails,
  clearEventDetails,
  withdrawEvent,
  signUpForEvent,
  fetchStudentEventSignUpStatus,
  openLoginScreen,
  fetchUserData,
})(EventsDetail);
