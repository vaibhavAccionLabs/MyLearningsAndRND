import {Form, Input, Button} from 'antd';
import {CloseOutlined} from '@ant-design/icons';
import style from './style.module.less';

const FiltersForm = ({
  form,
  onFinish,
  onFinishFailed,
  filters,
  onReset,
  isMobileView,
  onHideFilter,
}) => {
  let showReset = false;
  const filterKeys = Object.keys(filters);

  if (filterKeys?.length) {
    filterKeys?.map(key => {
      if (filters[key]) {
        showReset = true;
      }
    });
  }
  return (
    <>
      <div className={style.events_filters}>
        <h2>Search By</h2>
        {isMobileView && <CloseOutlined onClick={onHideFilter} />}
        <Form
          form={form}
          layout='vertical'
          name='events_filters'
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}>
          <Form.Item label='Title' name='title'>
            <Input placeholder='Search By Title' />
          </Form.Item>

          <Form.Item label='Location' name='location'>
            <Input placeholder='Search By City, State Or Zip' />
          </Form.Item>

          <Form.Item>
            <Button
              type='primary'
              className='btn-purple w-100'
              htmlType='submit'>
              Search
            </Button>
          </Form.Item>

          {showReset && (
            <div className={style.reset_filters}>
              <span onClick={onReset}>Reset Filter</span>
            </div>
          )}
        </Form>
      </div>
    </>
  );
};

export default FiltersForm;
