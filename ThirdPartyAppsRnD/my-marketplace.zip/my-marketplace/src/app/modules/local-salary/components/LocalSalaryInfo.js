import React, {useState} from 'react';
import {Col, Row} from 'antd';

import {
  CustomTabSwitch,
  BarChart,
  NoResults,
  MultiBarChart,
} from 'core/components';

import {carrerOneStop} from 'assets/images';

const formatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});
const tabs = [
  {
    value: 'Annual',
    key: 'Annual',
  },
  {
    value: 'Hourly',
    key: 'Hourly',
  },
];

const chartFormatter = {
  formatChartYAxisLabel: label => {
    if (label > 1000) {
      return '$' + label / 1000 + 'k';
    } else {
      return '$' + label;
    }
  },
  toolTipFormatter: (tooltipItem, data) => {
    const d = formatter.format(tooltipItem.yLabel);
    if (tooltipItem.datasetIndex === 0) {
      return `Workers on average earn ${d} or less.`;
    } else if (tooltipItem.datasetIndex === 1) {
      return `10% of workers earn ${d}.`;
    } else {
      return `10% of workers earn ${d} or more.`;
    }
  },
  datalabelFormatter: label => {
    return formatter.format(label);
  },
};

const getBarThickness = () => {
  return window.innerWidth > 450 ? 62 : 22;
};
const LocalSalaryInfo = props => {
  const {invalidSearch, salary: {data: {local_salary_info} = {}} = {}} = props;
  const [barThickness, setBarThickness] = useState(getBarThickness());
  const [currentTab, setCurrentTab] = useState('Annual');
  const data = [];
  const graphData = {
    labels: [],
    datasets: [],
  };
  if (local_salary_info) {
    const tabData = local_salary_info[currentTab];
    const median = [];
    const percentile_10 = [];
    const percentile_90 = [];
    Object.keys(tabData).forEach(key => {
      if (Object.keys(tabData[key]).length !== 0) {
        data.push(tabData[key]);
        graphData.labels.push(tabData[key].area_name);
        median.push(parseFloat(tabData[key].salary_median));
        percentile_10.push(parseFloat(tabData[key].salary_10th_percentile));
        percentile_90.push(parseFloat(tabData[key].salary_90th_percentile));
      }
    });
    graphData.datasets = [
      {
        data: percentile_10,
        borderColor: '#fff',
        borderWidth: 4,
        backgroundColor: '#F7A06D',
      },
      {
        data: median,
        borderColor: '#fff',
        borderWidth: 4,
        backgroundColor: '#73A6E2',
      },
      {
        data: percentile_90,
        borderColor: '#fff',
        borderWidth: 4,
        backgroundColor: '#70AEB6',
      },
    ];
  }

  const onTabChange = v => setCurrentTab(v);

  return (
    <>
      {invalidSearch ? (
        <NoResults />
      ) : (
        <>
          <br />
          <div className='px-0 py-1 mob_yr_tabs'>
            <CustomTabSwitch
              onChange={onTabChange}
              currentTab={currentTab}
              dataTabs={tabs}
            />
          </div>
          {graphData.labels && graphData.labels.length > 0 && (
            <MultiBarChart
              datasets={graphData.datasets}
              barThickness={barThickness}
              toolTipFormatter={chartFormatter.toolTipFormatter}
              datalabelFormatter={chartFormatter.datalabelFormatter}
              yAxisLabelFormatter={chartFormatter.formatChartYAxisLabel}
              labels={graphData.labels}
            />
          )}
          {graphData.labels && graphData.labels.length > 0 && (
            <div className='px-0 py-4'>
              {/* <h2>Average Wage Trend</h2> */}
              <br />
              {/* <BarChart
                datasets={graphData.datasets}
                labels={graphData.labels}
                toolTipFormatter={chartFormatter.toolTipFormatter}
                // yAxisLabelFormatter={chartFormatter.formatChartYAxisLabel}
              /> */}
            </div>
          )}

          {data.length === 0 && (
            <Row justify='center'>
              <Col>
                <NoResults />
              </Col>
            </Row>
          )}
          <Row className='px-0 py-4'>
            {data &&
              data.length > 0 &&
              data.map(dt => (
                <Col xs={24} sm={12} md={12} lg={12} key={dt.area_name}>
                  <h4>In {dt.area_name}:</h4>
                  <ul className='list'>
                    <li>
                      Workers on average earn
                      <span className='priceColor'>
                        {' '}
                        {formatter.format(dt.salary_median)}.
                      </span>
                    </li>
                    <li>
                      10% of workers earn
                      <span className='priceColor'>
                        {' '}
                        {formatter.format(dt.salary_10th_percentile)} or less.
                      </span>
                    </li>
                    <li>
                      10% of workers earn
                      <span className='priceColor'>
                        {' '}
                        {formatter.format(dt.salary_90th_percentile)} or more.
                      </span>
                    </li>
                  </ul>
                </Col>
              ))}
          </Row>
        </>
      )}
      <div className='py-0 pb-3 mob_spc-logo'>
        <img src={carrerOneStop} width={119} />
      </div>
    </>
  );
};

export default LocalSalaryInfo;
