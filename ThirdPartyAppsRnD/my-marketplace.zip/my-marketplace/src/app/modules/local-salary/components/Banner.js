import React from 'react';

const Banner = ({occupationName, queryParams}) => {
  const {zip, state} = queryParams;
  return (
    <div className='banner px-5 py-3'>
      <div className='d-block text-center'>
        <h2>{decodeURIComponent(occupationName)}</h2>
        <h5>
          Local Salary Info for{' '}
          <b>{zip || (state ? decodeURIComponent(state) : state)}</b>
        </h5>
        {/* <button className='btn-blue-outer'>Back to Career Overview</button> */}
      </div>
    </div>
  );
};

export default Banner;
