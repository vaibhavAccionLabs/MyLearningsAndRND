import React, {useEffect} from 'react';
import {useHistory} from 'react-router-dom';
import {connect} from 'react-redux';

import {fetchLocalSalary, getLocalSalary} from 'redux/modules/salary';

import {queryStringParse} from 'core/utils';
import {
  AppBreadcrumb,
  LocalSalarySearch,
  Loader,
  RequestErrorLoader,
} from 'core/components';

// local components
import Banner from './components/Banner';
import LocalSalaryInfo from './components/LocalSalaryInfo';

import './style.less';

const LocalSalary = props => {
  const history = useHistory();
  const {fetchLocalSalary, salary} = props;
  const {
    location: {search},
  } = history;

  const params = queryStringParse(search);
  const query = params.state || params.zip;
  const invalidSearch = !query || !params.occupation;
  const occupationName = params.occupation;

  useEffect(() => {
    const {state, zip, occupation} = params;
    const query = state || zip;
    if (!invalidSearch) fetchLocalSalary(query, occupation);
  }, [params.state, params.zip]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <RequestErrorLoader body={{request: salary?.request}}>
      <div className='breadcrumbCurve'>
        <AppBreadcrumb
          dataList={[
            {
              name: 'Occupation Detail',
              path: `/occupation?query=${occupationName}`,
            },
            {
              name: 'Job Outlook Map',
            },
          ]}
        />
      </div>
      <div className='local-salary'>
        {!invalidSearch && (
          <Banner
            {...props}
            occupationName={occupationName}
            queryParams={params}
          />
        )}
        <div className='contentContainer'>
          <div className='px-5 py-4 search-c'>
            <LocalSalarySearch
              {...props}
              islocalSalaryPage={true}
              occupationName={occupationName}
            />
          </div>
          <div className='jobsSalary'>
            <LocalSalaryInfo {...props} invalidSearch={invalidSearch} />
          </div>
        </div>
      </div>
    </RequestErrorLoader>
  );
};

const mapStateToProps = state => ({
  salary: getLocalSalary(state),
});

export default connect(mapStateToProps, {
  fetchLocalSalary,
})(LocalSalary);
