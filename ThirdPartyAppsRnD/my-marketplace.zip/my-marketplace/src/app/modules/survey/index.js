import {useHistory} from 'react-router-dom';
import {connect} from 'react-redux';

import {useAuth} from 'core/hooks';
import {AppBreadcrumb} from 'core/components';

import {openLoginScreen} from 'redux/modules/auth';

import {Banner} from './sharedComponents';
import SurveyRoutes from './SurveyRoutes';

import {breadcrumbData} from 'data/survey.json';

import './style.less';

const Survey = props => {
  const history = useHistory();
  const {
    location: {pathname},
  } = history;
  const [token] = useAuth();
  const navigateToSurvey = () => {
    let url = `/survey/my-survey`;
    history.push(url);
  };
  const openSurvey = () => {
    if (token) {
      navigateToSurvey();
    } else {
      props.openLoginScreen({
        callback: async () => {
          navigateToSurvey();
        },
      });
    }
  };
  return (
    <div className='career-interest-survey'>
      <AppBreadcrumb dataList={breadcrumbData} />
      {pathname === '/survey' && <Banner {...props} openSurvey={openSurvey} />}
      <SurveyRoutes modules={props.submodules} />
    </div>
  );
};

export default connect(null, {openLoginScreen})(Survey);
