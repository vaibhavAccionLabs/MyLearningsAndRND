import {useEffect, useState, useCallback} from 'react';
import {connect} from 'react-redux';
import {useHistory, useLocation} from 'react-router-dom';
import {Button, Checkbox, Col, Collapse, Row} from 'antd';

import {queryStringParse} from 'core/utils';
import {
  Loader,
  CareerInterestSurveyResult,
  RequestErrorLoader,
  ErrorBoundary,
} from 'core/components';

import {getAppConfig} from 'redux/modules/general';
import {
  getCareerInterestSurveyQuestions,
  fetchCareerInterestQuestions,
  saveCareerInterestSurvey,
  getCareerInterestSurveyResults,
} from 'redux/modules/survey';
import {fetchClusters, getClusters} from 'redux/modules/search';

import {successTick} from 'assets/images';

import {mySurveyStaticData} from 'data/survey.json';

const {Panel} = Collapse;

const formatData = data => {
  const obj = {};
  if (Array.isArray(data)) {
    data.forEach(i => {
      if (obj[i.assessment_type]) {
        obj[i.assessment_type].push(i);
      } else {
        obj[i.assessment_type] = [i];
      }
    });
    return obj;
  } else {
    return {};
  }
};

const MySurvey = props => {
  const router = useHistory();
  const {search} = useLocation();
  const {reset} = queryStringParse(search);
  const [questions, setQuestions] = useState({});
  const [currentPanel, setCurrentPanel] = useState('0');
  const [answers, setAnswers] = useState({});
  const [completed, setCompleted] = useState(-1);
  const [loading, setLoading] = useState(false);
  const [showResultsPage, setShowResultsPage] = useState(false);

  useEffect(() => {
    props.fetchCareerInterestQuestions();
    props.getCareerInterestSurveyResults();
    props.fetchClusters();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (
      props.careerInterest &&
      props.careerInterest.data &&
      Array.isArray(props.careerInterest.data)
    )
      setQuestions(formatData(props.careerInterest.data));
  }, [props.careerInterest, props.careerInterest.data]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (props.careerInterest.answers) {
      if (reset) {
        onReset();
      } else {
        const {student_responses} = props.careerInterest.answers;
        if (student_responses && student_responses.length > 0) {
          setCompleted(3);
          const ob = {};
          student_responses.forEach(s => {
            ob[s.assessment_uuid] = true;
          });
          setAnswers(ob);
        }
        setShowResultsPage(true);
      }
    }
  }, [props.careerInterest.answers, reset]); // eslint-disable-line react-hooks/exhaustive-deps

  const onCheckAnswer = (e, question) => {
    if (e.target.checked) {
      setAnswers({...answers, [question.assessment_uuid]: true});
    } else {
      setAnswers({...answers, [question.assessment_uuid]: false});
    }
  };
  const submit = async () => {
    router.replace('/survey/my-survey');
    const formatAnswers = Object.entries(answers)
      .filter(i => i[1] === true)
      .map(i => i[0]);
    setLoading(true);
    try {
      await props.saveCareerInterestSurvey({student_responses: formatAnswers});
      props.getCareerInterestSurveyResults();
      setLoading(false);
      setShowResultsPage(true);
    } catch (err) {
      setLoading(false);
    }
  };
  const onNext = idx => {
    const {
      appConfig: {isMobileView},
    } = props;
    const scrollToPos = isMobileView ? 20 : 50;
    if (completed <= idx) setCompleted(idx);
    setCurrentPanel(idx);
    window.scrollTo({
      top: scrollToPos + parseInt(idx) * 70,
      behavior: 'smooth',
    });
  };
  const onChangePanel = k => {
    try {
      if (parseInt(k) < completed) setCurrentPanel(k);
    } catch (err) {}
  };
  const onReset = useCallback(() => {
    const {
      appConfig: {isMobileView},
    } = props;
    const scrollToPos = 75;
    currentPanel !== '0' && setCurrentPanel('0');
    completed !== -1 && setCompleted(-1);
    setAnswers({});
    showResultsPage && setShowResultsPage(false);
    window.scrollTo({
      top: scrollToPos,
      behavior: 'smooth',
    });
  });

  const isRequesting =
    props.careerInterest.request ||
    loading ||
    props.careerInterest.requestAnswers ||
    props.clusters.request;
  return (
    <ErrorBoundary nameOfComponent='module-my-survey' typeOfUi='subPage'>
      <div className='careerInterests survey_container'>
        <RequestErrorLoader
          body={{
            request: isRequesting,
          }}>
          <div className='cnt_survey pb-1'>
            <h2>{mySurveyStaticData.heading}</h2>
            {showResultsPage ? (
              <CareerInterestSurveyResult
                surveyAnswers={props.careerInterest?.answers}
                clusters={props.clusters?.data}
              />
            ) : (
              <div className='collpase-container'>
                <Collapse
                  accordion
                  defaultActiveKey={['0']}
                  activeKey={currentPanel}
                  onChange={onChangePanel}
                  expandIconPosition='right'>
                  {Object.keys(questions).map((panelKey, idx) => (
                    <Panel
                      key={idx + ''}
                      className={completed > idx ? 'completed' : ''}
                      header={
                        <>
                          {completed > idx ? (
                            <img src={successTick} />
                          ) : (
                            <span className='dot-i' />
                          )}
                          <div className='pan-header'>{panelKey}</div>
                        </>
                      }>
                      <div>
                        <div className='p-c-title'>
                          {mySurveyStaticData.panelDesc[panelKey]}
                        </div>
                        <div className='p-c-questions'>
                          {questions[panelKey].map(question => (
                            <div
                              className='pc-checkbox'
                              key={question.assessment_uuid}>
                              <Checkbox
                                onChange={e => onCheckAnswer(e, question)}
                                checked={
                                  answers[question.assessment_uuid] === true
                                }>
                                {question.question}
                              </Checkbox>
                            </div>
                          ))}
                        </div>
                        <Row justify='end'>
                          <Col>
                            {Object.keys(questions).length === idx + 1 ? (
                              <Button type={'primary'} onClick={submit}>
                                {mySurveyStaticData.btnText.showResults}
                              </Button>
                            ) : (
                              <Button
                                type={'primary'}
                                onClick={() => onNext(idx + 1 + '')}>
                                {mySurveyStaticData.btnText.next}
                              </Button>
                            )}
                          </Col>
                        </Row>
                      </div>
                    </Panel>
                  ))}
                </Collapse>
              </div>
            )}
            {!isRequesting && (
              <button
                className='ant-btn btn-purple-transparent'
                type='button'
                onClick={onReset}>
                {mySurveyStaticData.btnText.reset}
              </button>
            )}
          </div>
          <p className='px-5 py-2 disclaimer'>
            <span>{mySurveyStaticData.disclaimer.title}</span>{' '}
            {mySurveyStaticData.disclaimer.description}
          </p>
        </RequestErrorLoader>
      </div>
    </ErrorBoundary>
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  clusters: getClusters(state),
  careerInterest: getCareerInterestSurveyQuestions(state),
});

export default connect(mapStateToProps, {
  fetchCareerInterestQuestions,
  saveCareerInterestSurvey,
  getCareerInterestSurveyResults,
  fetchClusters,
})(MySurvey);
