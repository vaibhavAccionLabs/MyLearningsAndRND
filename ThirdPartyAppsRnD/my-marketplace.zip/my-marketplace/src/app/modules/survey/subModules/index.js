import {lazy} from 'react';
import {retry} from 'core/utils';

const MySurvey = lazy(() => retry(() => import('./mySurvey')));
const SurveyHome = lazy(() => retry(() => import('./home')));

export {MySurvey, SurveyHome};
