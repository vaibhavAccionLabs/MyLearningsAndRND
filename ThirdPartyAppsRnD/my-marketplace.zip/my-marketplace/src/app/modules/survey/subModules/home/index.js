import {Row, Col} from 'antd';
import {connect} from 'react-redux';
import {useHistory} from 'react-router-dom';

import {openLoginScreen} from 'redux/modules/auth';

import {useAuth} from 'core/hooks';

import {
  survey1,
  survey2,
  survey3,
  surveyCircle,
  surveyBig,
} from 'assets/images';

import {homeData} from 'data/survey.json';

function MySurvey(props) {
  const history = useHistory();
  const [token] = useAuth();
  const navigateToSurvey = () => {
    let url = `/survey/my-survey`;
    history.push(url);
  };
  const openSurvey = () => {
    if (token) {
      navigateToSurvey();
    } else {
      props.openLoginScreen({
        callback: async () => {
          navigateToSurvey();
        },
      });
    }
  };
  return (
    <div className='careerInterests survey_container'>
      <Row data-cy='career-heading-content'>
        <Col xs={12} sm={12} md={12} lg={12} className='py-5'>
          <h4>
            {homeData.heading}
            <span>{homeData.subHeading}</span>
          </h4>
          <p>{homeData.description}</p>
        </Col>
        <Col xs={12} sm={12} md={12} lg={12} className='pt-4'>
          <img src={surveyBig} alt='thumb' />
        </Col>
      </Row>
      <h1 className='my-5' data-cy='survey-question'>
        {homeData.surveyQuestion}
      </h1>
      <div className='curve_effect' data-cy='curve-effect-cont'>
        <div className='curve_right'>
          <img src={survey1} alt='thumb' />
          <img src={surveyCircle} alt='thumb' className='lft-circle' />
        </div>
        <div className='employers_cnt right'>
          <div className='radiant_list' data-cy='survey-list'>
            {homeData.surveyAnswers_1}
          </div>
        </div>
      </div>
      <div className='curve_effect' data-cy='curve-effect-cont'>
        <div className='employers_cnt'>
          <div className='radiant_list right-text' data-cy='survey-list'>
            {homeData.surveyAnswers_2}
          </div>
        </div>
        <div className='curve_left'>
          <img src={survey2} alt='thumb' />
        </div>
      </div>
      <div className='curve_effect' data-cy='curve-effect-cont'>
        <div className='curve_right lastChild'>
          <img src={survey3} alt='thumb' />
          <img src={surveyCircle} alt='thumb' className='lft-circle last' />
        </div>
        <div className='employers_cnt right'>
          <div className='radiant_list' data-cy='survey-list'>
            {homeData.surveyAnswers_3}
          </div>
        </div>
      </div>
      <div className='cnt_survey mt-5' data-cy='take-survey-cont'>
        <h2>{homeData.aboutSurvey.heading}</h2>
        <p>
          {homeData.aboutSurvey.timeRequiredText.title}{' '}
          <span>{homeData.aboutSurvey.timeRequiredText.value}</span>
        </p>
        <button
          className='ant-btn btn-purple  mb-5 '
          type='button'
          onClick={openSurvey}>
          {homeData.btnText}
        </button>
      </div>
      <p className='px-5 py-4 disclaimer' data-cy='survey-disclaimer'>
        <span>{homeData.disclaimer.title}</span>{' '}
        {homeData.disclaimer.description}
      </p>
    </div>
  );
}
export default connect(null, {openLoginScreen})(MySurvey);
