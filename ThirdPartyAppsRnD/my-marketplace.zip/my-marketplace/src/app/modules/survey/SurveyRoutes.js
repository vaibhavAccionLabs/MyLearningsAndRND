import {SubRouter} from 'core/components';

const SurveyRoutes = ({modules}) => (
  <SubRouter modules={modules} defaultRedirection='/survey' />
);

export default SurveyRoutes;
