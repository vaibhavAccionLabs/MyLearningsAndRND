import {useLocation} from 'react-router-dom';

import {bannerData} from 'data/survey.json';

const Banner = ({openSurvey}) => {
  const location = useLocation();
  return (
    <header
      className='career-interest-survey-banner'
      data-cy='discover-interest-banner'>
      <h1>{bannerData.title}</h1>
      {location?.pathname !== '/survey/my-survey' && (
        <>
          <h4>{bannerData.subTitle}</h4>
          <button className='btn-purple-outer' onClick={openSurvey}>
            {bannerData.btnText}
          </button>
        </>
      )}
    </header>
  );
};

export default Banner;
