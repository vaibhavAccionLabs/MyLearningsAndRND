import React, {useEffect, useState} from 'react';
import {useHistory} from 'react-router-dom';
import {connect} from 'react-redux';
import isEmpty from 'lodash/isEmpty';

import {getAppConfig} from 'redux/modules/general';
import {getInstance} from 'redux/modules/instance';
import {
  fetchPathsSearch,
  fetchSchools,
  fetchAwardTypes,
  fetchDuration,
  getAwardTypes,
  getSchools,
  getDuration,
  getPaths,
  clearPathSearch,
  clearAwardTypes,
  clearSchools,
  clearDuration,
  resetInitalLoad,
  fetchCareerSearch,
  getCareerSearch,
  clearCareerSearch,
} from 'redux/modules/search';
import {
  fetchLocalJobs,
  fetchJobBoards,
  getLocalJobs,
  getJobBoards,
  clearLocalJobs,
  clearJobBoards,
} from 'redux/modules/jobs';
import {
  fetchPrograms,
  getPrograms,
  clearPrograms,
} from 'redux/modules/programs';
import {
  fetchPathDetails,
  getPathsToCompare,
  getComparePathDetails,
} from 'redux/modules/pathways';
import {
  AppBreadcrumb,
  RequestErrorLoader,
  NoResults,
  LazyImage,
} from 'core/components';
import {queryStringParse, getBanner} from 'core/utils';

import {ProgramSearch, OpportunitySearch, CareerSearch} from './containers';
import {SearchType} from './components';

import SearchModule from 'data/search';

import './search.less';

const tabs = [
  {label: 'Programs', value: 'programs'},
  {label: 'Opportunities', value: 'opportunities'},
  {label: 'Careers', value: 'careers'},
];

const Search = props => {
  const {paths, relatedPathways, isCareerPathways, hideFilterTabs} = props;
  const history = useHistory();
  const [pageNo, setPageNo] = useState(1);
  const [searchType, setSearchType] = useState(tabs[0].value);

  const {
    location: {search},
  } = history;

  const params = queryStringParse(search);

  useEffect(() => {
    setSearchType(params?.activetab || tabs[0].value);
  }, [params?.activetab, search]); // eslint-disable-line react-hooks/exhaustive-deps

  const clusterImgSrc =
    params.cluster_name &&
    getBanner(paths.data?.cluster_associated?.cluster_banner_url);

  const overRideNoresultText =
    !params ||
    (!params.query &&
      !params.pos &&
      !params.newest_path &&
      !params.cluster_name);

  let showContent = false;
  if (!paths.request || (paths.request && pageNo > 1)) {
    showContent = true;
  }

  const hideButton =
    pageNo >= paths.data?.page_details?.no_of_pages && !paths?.request;

  let defaultBreadcrumbList = [
    {
      name: SearchModule.breadcrumbSearchTxt,
    },
  ];

  if (params?.cluster_name) {
    defaultBreadcrumbList = [
      {
        path: '/directory/paths-list#programs_by_career',
        name: SearchModule.breadcrumbExploreCareerPathwaysTxt,
      },
      {
        name: decodeURIComponent(params?.cluster_name),
      },
    ];
  }

  const renderTabs = () => {
    switch (searchType) {
      case tabs[0].value:
        return (
          <ProgramSearch
            {...props}
            isCareerPathways={isCareerPathways}
            overRideNoresultText={overRideNoresultText}
            showContent={showContent}
            relatedPathways={relatedPathways}
            hideButton={hideButton}
            pageNo={pageNo}
            setPageNo={setPageNo}
            history={history}
          />
        );
      case tabs[1].value:
        return <OpportunitySearch {...props} params={params} />;
      case tabs[2].value:
        return <CareerSearch {...props} params={params} />;
      default:
        return <div />;
    }
  };

  return (
    <>
      <>
        {!relatedPathways && !isCareerPathways && (
          <AppBreadcrumb dataList={defaultBreadcrumbList} />
        )}

        {(isEmpty(params) ||
          (!params.query &&
            !params.newest_path &&
            !params.cluster_name &&
            !isCareerPathways)) && (
          <NoResults
            heading={SearchModule.getStartedTxt}
            subHeading={SearchModule.typePathNames}
          />
        )}

        {params?.newest_path && (
          <div className='newest_program_header'>
            {/* <h1>{SearchModule.newestProgramsTitle}</h1> */}
          </div>
        )}

        {params?.cluster_name && (
          <RequestErrorLoader
            body={{
              ...paths,
              request: !paths.data?.cluster_associated && paths.request,
              error: false,
            }}>
            {(showContent || paths.data?.cluster_associated) && (
              <div className=' pb-0'>
                <div
                  className='cluster_header'
                  style={{
                    background: `url(${clusterImgSrc}) center left no-repeat`,
                  }}>
                  {/* <LazyImage
                    renderSrcSet
                    src={clusterImgSrc}
                    alt='cluster_image'
                  /> */}
                  <div className=''>
                    <h1>{paths.data?.cluster_associated?.cluster_name}</h1>
                  </div>
                </div>
              </div>
            )}
          </RequestErrorLoader>
        )}
        {!params?.cluster_name &&
          !params?.newest_path &&
          params?.query &&
          !hideFilterTabs && (
            <SearchType
              tabs={tabs}
              currentTab={searchType}
              onChangeTab={value => {
                let path =
                  history.location.pathname +
                  '?query=' +
                  params?.query +
                  '&activetab=' +
                  value;
                if (value === 'opportunities') {
                  history.push(path + '&type=local_jobs');
                } else {
                  history.push(path);
                }
                setSearchType(value);
              }}
            />
          )}
      </>
      {(params?.cluster_name ||
        params?.newest_path ||
        params?.query ||
        isCareerPathways) &&
        renderTabs()}
    </>
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  instance: getInstance(state),
  comparePathsList: getPathsToCompare(state),
  comparePath: getComparePathDetails(state),
  awardTypes: getAwardTypes(state),
  schools: getSchools(state),
  duration: getDuration(state),
  paths: getPaths(state),
  programs: getPrograms(state),
  localJobs: getLocalJobs(state),
  jobBoards: getJobBoards(state),
  careerSearch: getCareerSearch(state),
});

export default connect(mapStateToProps, {
  fetchLocalJobs,
  fetchJobBoards,
  fetchPrograms,
  fetchPathDetails,
  fetchPathsSearch,
  fetchSchools,
  fetchAwardTypes,
  fetchDuration,
  clearLocalJobs,
  clearJobBoards,
  clearPrograms,
  clearPathSearch,
  clearAwardTypes,
  clearSchools,
  clearDuration,
  resetInitalLoad,
  fetchCareerSearch,
  clearCareerSearch,
})(Search);
