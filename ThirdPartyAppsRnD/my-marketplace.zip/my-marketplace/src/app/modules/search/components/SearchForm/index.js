import {Form, Input, Button} from 'antd';
import isEmpty from 'lodash/isEmpty';

const SearchForm = ({
  form,
  onSearchSubmit,
  onSearchFailed,
  onResetClick,
  searchData,
}) => {
  let showReset = false;

  if (searchData && Object.keys(searchData)) {
    Object.keys(searchData).map(key => {
      if (!isEmpty(searchData[key])) {
        showReset = true;
      }
    });
  }
  return (
    <Form
      form={form}
      name='basic'
      layout='vertical'
      onFinish={onSearchSubmit}
      onFinishFailed={onSearchFailed}
      name='program_search'
      className='filter_edu_location'
      autoComplete='off'>
      <Form.Item label='Educator' name='educator'>
        <Input placeholder='Search By Educator Name' />
      </Form.Item>

      <Form.Item label='Location' name='location'>
        <Input placeholder='Search By City, State Or Zip' />
      </Form.Item>

      <Form.Item>
        <Button type='primary' htmlType='submit'>
          Search
        </Button>
      </Form.Item>
      {showReset && (
        <div className='reset-filters'>
          <span onClick={onResetClick}>Reset Search</span>
        </div>
      )}
    </Form>
  );
};

export default SearchForm;
