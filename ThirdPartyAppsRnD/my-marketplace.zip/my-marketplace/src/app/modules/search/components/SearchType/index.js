import React, {useCallback} from 'react';
import {Col, Row} from 'antd';
import style from './style.module.less';

const SearchType = ({currentTab, onChangeTab, tabs}) => {
  const tabClasses = useCallback(
    itm => {
      if (itm.value === currentTab) return `${style.tb_itm} ${style.active}`;
      //'tb-itm active';

      return style.tb_itm;
    },
    [currentTab],
  ); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Row justify='center' className={style.search_type_tabs}>
      <Col>
        <Row gutter={24} className={style.search_type_layout} align='center'>
          <Col className={style.lbl}>
            <h3>View Results by</h3>
          </Col>
          <Col className={style.tbs}>
            <Row gutter={24}>
              {tabs?.map(tab => (
                <Col key={tab.value}>
                  <div
                    className={tabClasses(tab)}
                    onClick={() => onChangeTab(tab.value)}>
                    <span>{tab.label}</span>
                  </div>
                </Col>
              ))}
            </Row>
          </Col>
        </Row>
      </Col>
    </Row>
  );
};

export default SearchType;
