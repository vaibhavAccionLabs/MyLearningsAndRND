import {Button, Tag, Select} from 'antd';

import {CustomMultiSelect} from 'core/components';

import SearchForm from '../SearchForm';
import SearchModule from 'data/search';
import './style.less';

const {Option} = Select;

const sortData = [
  {
    value: 'relevant',
    text: SearchModule.sortTxtData.relevantLabel,
  },
  {
    value: 'date_desc',
    text: SearchModule.sortTxtData.newToOldLabel,
  },
  {
    value: 'date_asc',
    text: SearchModule.sortTxtData.oldToNewLabel,
  },
];

const SearchFilters = props => {
  const {
    clearAllFilters,
    closeFilter,
    selectedItems,
    setSelectedItems,
    onSortChange,
    params,
    sortValue,
    onHideFilter,
    onlySortBy,
    appConfig: {isMobileView},
    isRelevant,
    instance,
  } = props;

  const isDisplaySearch =
    !instance?.data?.super_type_name ||
    instance?.data?.super_type_name === 'Consortium';
  const AwardData =
    props.awardTypes &&
    props.awardTypes.data &&
    props.awardTypes.data.map(item => ({
      type: 'award_type',
      uuid: item.uuid,
      title: item.options,
      count: item.path_count,
    }));

  const DurationData =
    props.duration &&
    props.duration.data &&
    props.duration.data.map((item, idx) => ({
      type: 'duration',
      uuid: item.uuid,
      count: item.path_count,
      title: item.name,
      customTitle: `${item.name}`,
    }));

  const clearAllButton = () => (
    <Button
      className='clear-all'
      disabled={selectedItems?.length ? false : true}
      onClick={() => clearAllFilters()}>
      {SearchModule.clearAllBtnTxt}
    </Button>
  );
  return (
    <div className='filter-section'>
      <div className='search-filters'>
        {!onlySortBy ? (
          <>
            <div className='filter-label'>
              {SearchModule.filterLabel} : {isMobileView && clearAllButton()}
            </div>
            <div className='filter_field'>
              <label>Award Type</label>
              <CustomMultiSelect
                name={SearchModule.awardTypeDropdownPlaceholder}
                data={AwardData}
                selectedItems={selectedItems}
                setSelectedItems={setSelectedItems}
                fetchData={props.fetchAwardTypes}
                request={props.awardTypes?.request}
                params={params}
                disableOptions={props.paths?.request}
              />
              {selectedItems?.length > 0 && (
                <div className='selected-filters'>
                  {selectedItems
                    .filter(item => item.type === 'award_type')
                    .map(item => (
                      <Tag
                        key={item.uuid}
                        closable
                        onClose={e => closeFilter(e, item)}>
                        {item.customTitle || item.title}
                      </Tag>
                    ))}
                </div>
              )}
            </div>
            <div className='filter_field'>
              <label>Duration</label>
              <CustomMultiSelect
                name={SearchModule.durationDropdownPlaceholder}
                data={DurationData}
                selectedItems={selectedItems}
                setSelectedItems={setSelectedItems}
                fetchData={props.fetchDuration}
                request={props.duration?.request}
                params={params}
                disableOptions={props.paths?.request}
              />
              {selectedItems?.length > 0 && (
                <div className='selected-filters'>
                  {selectedItems
                    .filter(item => item.type === 'duration')
                    .map(item => (
                      <Tag
                        key={item.uuid}
                        closable
                        onClose={e => closeFilter(e, item)}>
                        {item.customTitle || item.title}
                      </Tag>
                    ))}
                </div>
              )}
            </div>
          </>
        ) : (
          <div className='sort_field'>
            <label>Sort By:</label>
            <Select
              defaultValue={sortValue}
              value={sortValue}
              onChange={onSortChange}>
              {sortData.map((item, i) => {
                if (!isRelevant && i === 0) {
                  return '';
                }
                return (
                  <Option key={item.value} value={item.value}>
                    {item.text}
                  </Option>
                );
              })}
            </Select>
          </div>
        )}
      </div>

      {!onlySortBy && isDisplaySearch && <SearchForm {...props} />}

      {isMobileView && !onlySortBy && (
        <>
          <Button className='clear-all apply-mob' onClick={onHideFilter}>
            <span>{SearchModule.applyBtnTxt}</span>
          </Button>
          <Button className='btn_close apply-mob' onClick={onHideFilter}>
            <span>{SearchModule.closeBtnTxt}</span>
          </Button>
        </>
      )}
    </div>
  );
};

export default SearchFilters;
