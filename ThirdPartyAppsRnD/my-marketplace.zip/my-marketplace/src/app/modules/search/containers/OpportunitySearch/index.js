//Sharable components from Module - Occupation
import {EmploymentOpportunites} from 'app/modules/occupation/components';

function OpportunitySearch(props) {
  const {params, history} = props;

  const onEmploymentTypeChange = value => {
    let path =
      history.location.pathname +
      '?query=' +
      params?.query +
      '&activetab=opportunities' +
      '&type=' +
      value;
    history.push(path);
  };
  return (
    <div className='global_opportunity_list contentContainer'>
      <EmploymentOpportunites
        {...props}
        params={params}
        onChange={onEmploymentTypeChange}
        onlyLocal={true}
        formLabel='Filters :'
        stopFilterScrollOnMobile={true}
      />
    </div>
  );
}

export default OpportunitySearch;
