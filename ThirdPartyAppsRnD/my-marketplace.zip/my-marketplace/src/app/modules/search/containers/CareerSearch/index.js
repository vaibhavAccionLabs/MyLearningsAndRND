import {useEffect, useState} from 'react';
import {Button} from 'antd';

import {CAREER_ONE_STOP_IMAGE_BASE_PATH} from 'config';
import {
  RequestErrorLoader,
  NoResults,
  ErrorBoundary,
  LazyImage,
  SearchResultsCounter,
} from 'core/components';
import {getModuleBasePath, currencyFormatter} from 'core/utils';

import SearchModule from 'data/search';
import style from './style.module.less';

const CareerSearch = ({
  fetchCareerSearch,
  params,
  history,
  careerSearch,
  clearCareerSearch,
}) => {
  const [pageNo, setPageNo] = useState(1);
  const {
    location: {search},
  } = history;

  useEffect(() => {
    const query = params?.query;
    clearCareerSearch();
    if (params?.activetab === 'careers') {
      fetchCareerSearch(query, pageNo, [{type: 'sort_by', title: 'relevant'}]);
    }
  }, [search]); // eslint-disable-line react-hooks/exhaustive-deps

  let showContent = false;
  if (!careerSearch?.request || (careerSearch?.request && pageNo > 1)) {
    showContent = true;
  }
  const hideButton =
    pageNo >= careerSearch?.page_details?.no_of_pages && !careerSearch?.request;

  const loadMoreData = () => {
    const query = params?.query;
    const newPageNo = pageNo + 1;
    setPageNo(newPageNo);
    fetchCareerSearch(query, newPageNo);
  };

  const navigateToOccupationDetail = value => {
    const BasePath = getModuleBasePath('occupation');
    history.push(`${BasePath}?query=${encodeURIComponent(value)}`);
  };
  return (
    <div className='contentContainer'>
      <ErrorBoundary nameOfComponent='module-search' typeOfUi='subPage'>
        <RequestErrorLoader
          txt={SearchModule.loadingTxt}
          body={{
            ...careerSearch,
            request: careerSearch?.request,
            data: careerSearch?.data || [],
          }}
          overideNoDataContainer={
            <NoResults
              heading={SearchModule.getStartedTxt}
              subHeading={SearchModule.typePathNames}
            />
          }>
          {showContent && (
            <div className='global-career-search contentContainer py-3 pathwaySuccess'>
              <SearchResultsCounter
                className={'rp-search-result-text py-3 pl-4'}
                currentLength={careerSearch.data?.length}
                totalResults={careerSearch?.page_details?.total_count}
                request={careerSearch?.request}
              />
              {/* || params?.pos || params?.cluster_name */}
              <ul className={`contentContainer ${style.careerSearch_card}`}>
                {careerSearch?.data?.map(dt => (
                  <li
                    key={dt.id}
                    onClick={() =>
                      navigateToOccupationDetail(dt.occupation_name)
                    }>
                    <div>
                      <LazyImage
                        src={`${CAREER_ONE_STOP_IMAGE_BASE_PATH}${
                          dt?.occupation_details?.video_details?.[0]
                            ?.VideoCode || ''
                        }.jpg`}
                        className='img-fluid'
                      />
                      <span className={style.avg_value}>
                        {currencyFormatter.format(
                          dt?.occupation_details?.salary_annual_median,
                        )}{' '}
                        avg.
                      </span>
                    </div>
                    <h4 title={dt.occupation_name}>{dt.occupation_name}</h4>
                  </li>
                ))}
              </ul>
              {!hideButton && (
                <div className='text-center py-4'>
                  <Button
                    type='primary'
                    className={style.btn_load_more}
                    onClick={loadMoreData}>
                    {careerSearch.request
                      ? SearchModule.loadingTxt
                      : SearchModule.loadMoreBtnTxt}
                  </Button>
                </div>
              )}
            </div>
          )}
        </RequestErrorLoader>
      </ErrorBoundary>
    </div>
  );
};
export default CareerSearch;
