import React, {useEffect, useState, useCallback} from 'react';
import {Badge, Button, Row, Col, Form} from 'antd';
import {FilterOutlined} from '@ant-design/icons';

import {useEnableDisableScroll} from 'core/hooks';
import {queryStringParse} from 'core/utils';
import {
  PathCard,
  ComparePaths,
  RequestErrorLoader,
  NoResults,
  ErrorBoundary,
  SearchResultsCounter,
} from 'core/components';

import {SearchFilters} from '../../components';

import SearchModule from 'data/search';
import './style.less';
const ProgramSearch = props => {
  const {
    clearAwardTypes,
    clearSchools,
    clearDuration,
    clearPathSearch,
    resetInitalLoad,
    fetchPathsSearch,
    paths,
    isCareerPathways,
    comparePath,
    pageNo,
    overRideNoresultText,
    showContent,
    relatedPathways,
    //fetchPathDetails,
    comparePathsList,
    hideButton,
    appConfig: {isMobileView},
    setPageNo,
    businessPartnerName,
    history,
  } = props;

  const {
    location: {search, pathname},
  } = history;

  const params = queryStringParse(search);
  const isRelevant = pathname === '/search' && params?.query;
  const defaultSortByValue = isRelevant ? 'relevant' : 'date_desc';

  const [form] = Form.useForm();

  const {isFilterVisible, onFilterClick} = useEnableDisableScroll();

  const [selectedItems, setSelectedItems] = useState([]);
  const [sortBy, setSortBy] = useState(defaultSortByValue);
  const [searchData, setSearchData] = useState(null);

  const getRequiredFilters = useCallback(filters =>
    Array.isArray(filters)
      ? [...filters, {type: 'sort_by', title: sortBy}]
      : [{type: 'sort_by', title: sortBy}],
  );

  const getParamObj = useCallback(() => {
    const paramsObj = {};
    if (params?.query) {
      paramsObj.type = relatedPathways ? 'occupation_name' : 'gsearch';
      paramsObj.value = unescape(params.query);
    }
    if (params?.pos) {
      paramsObj.type = 'pos';
      paramsObj.value = unescape(params.pos);
    }
    if (params?.cluster_name) {
      paramsObj.type = 'cluster_name';
      paramsObj.value = unescape(params.cluster_name);
    }
    if (params?.newest_path) {
      paramsObj.type = 'newest_path';
      paramsObj.value = unescape(params.newest_path);
    }
    if (isCareerPathways && businessPartnerName) {
      paramsObj.type = 'company_name';
      paramsObj.value = unescape(businessPartnerName);
    }

    return paramsObj;
  }, [
    params.query,
    params.pos,
    params.cluster_name,
    params.newest_path,
    isCareerPathways,
    businessPartnerName,
    relatedPathways,
  ]);

  const getSearchData = useCallback(() => {
    if (searchData) {
      return Object.keys(searchData)
        .map(key => ({
          type: key,
          title: searchData[key],
        }))
        .filter(obj => obj.title);
    } else {
      return [];
    }
  });

  useEffect(() => {
    clearAwardTypes();
    clearSchools();
    clearDuration();
    fetchPathsSearch(getParamObj(), [
      {type: 'sort_by', title: defaultSortByValue},
    ]);
    setSelectedItems([]);
    setPageNo(1);
    setSortBy(defaultSortByValue);
    onResetClick(false);

    return () => {
      clearPathSearch();
      resetInitalLoad();
    };
  }, [search]); // eslint-disable-line react-hooks/exhaustive-deps

  const loadMoreData = useCallback(() => {
    const newPageNo = pageNo + 1;
    setPageNo(newPageNo);
    const filters = [...getRequiredFilters(selectedItems), ...getSearchData()];
    fetchPathsSearch(getParamObj(), filters, newPageNo);
  }, [
    fetchPathsSearch,
    getParamObj,
    getRequiredFilters,
    getSearchData,
    pageNo,
    selectedItems,
    setPageNo,
  ]);

  const onSortChange = useCallback(async value => {
    const filters = [
      ...selectedItems,
      ...getSearchData(),
      {type: 'sort_by', title: value},
    ];
    await fetchPathsSearch(getParamObj(), filters);
    setPageNo(1);
    setSortBy(value);
  });

  const closeFilter = useCallback(
    async (event, item) => {
      event.preventDefault();
      event.stopPropagation();
      const filterSelectedItem = selectedItems.filter(
        sItem => sItem.uuid !== item.uuid,
      );
      setSelectedItems(filterSelectedItem);
      const filters = [
        ...getRequiredFilters(filterSelectedItem),
        ...getSearchData(),
      ];
      await fetchPathsSearch(getParamObj(), filters);
      setPageNo(1);
    },
    [
      fetchPathsSearch,
      getParamObj,
      getRequiredFilters,
      getSearchData,
      selectedItems,
      setPageNo,
    ],
  );

  const clearAllFilters = useCallback(async () => {
    setSelectedItems([]);
    const filters = [...getRequiredFilters([]), ...getSearchData()];
    await fetchPathsSearch(getParamObj(), filters);
    setPageNo(1);
  }, [
    fetchPathsSearch,
    getParamObj,
    getRequiredFilters,
    getSearchData,
    setPageNo,
  ]);

  const setFilter = useCallback(
    async data => {
      setSelectedItems(data);
      const filters = [...getRequiredFilters(data), ...getSearchData()];
      await fetchPathsSearch(getParamObj(), filters);
      setPageNo(1);
    },
    [
      fetchPathsSearch,
      getParamObj,
      getRequiredFilters,
      getSearchData,
      setPageNo,
    ],
  );

  const onSearchSubmit = async values => {
    if (values) {
      const moreFilters = Object.keys(values)
        .map(key => ({
          type: key,
          title: values[key],
        }))
        .filter(obj => obj.title);
      const filters = [...moreFilters, ...getRequiredFilters(selectedItems)];
      await fetchPathsSearch(getParamObj(), filters);
      setPageNo(1);
      setSearchData(values);
    }
  };
  const onSearchFailed = () => {};

  const onResetClick = async (isRequest = true) => {
    const filters = getRequiredFilters(selectedItems);
    if (isRequest) {
      await fetchPathsSearch(getParamObj(), filters);
    }
    setPageNo(1);
    setSearchData(null);
    form.resetFields();
  };

  const renderFilters = (onlySortBy = false) => (
    <SearchFilters
      {...props}
      closeFilter={closeFilter}
      clearAllFilters={clearAllFilters}
      selectedItems={selectedItems}
      setSelectedItems={setFilter}
      onSortChange={onSortChange}
      params={getParamObj()}
      sortValue={sortBy}
      onHideFilter={onFilterClick}
      onlySortBy={onlySortBy}
      form={form}
      onSearchSubmit={onSearchSubmit}
      onSearchFailed={onSearchFailed}
      onResetClick={onResetClick}
      searchData={searchData}
      isRelevant={isRelevant}
    />
  );

  return (
    <>
      <div>
        {!paths.initialLoad && (
          <>
            {isMobileView && (
              <span className='filterPathway'>
                <span className='w_text'>
                  {SearchModule.filterResultsMobileTitle}
                </span>
                <Badge dot={selectedItems.length ? true : false}>
                  <FilterOutlined onClick={onFilterClick} />
                </Badge>
              </span>
            )}
          </>
        )}
        <ErrorBoundary nameOfComponent='module-search' typeOfUi='subPage'>
          <RequestErrorLoader
            txt={
              comparePath?.request
                ? SearchModule.addingPathToCompareTxt
                : SearchModule.loadingTxt
            }
            body={{
              ...paths,
              request: (paths.request && pageNo === 1) || comparePath?.request,
              data: true,
            }}>
            {!paths.initialLoad && (
              <div className='mx-3 pathwaySuccess'>
                <Row>
                  <Col xs={24} sm={24} md={5} lg={5}>
                    <div
                      className={`progam_list_n_filters ${
                        isMobileView && isFilterVisible
                          ? 'enable-mobile-filter'
                          : ''
                      }`}>
                      {isFilterVisible && renderFilters()}
                    </div>
                  </Col>
                  <Col xs={24} sm={24} md={19} lg={19}>
                    <div className='program_counter_n_sort'>
                      <SearchResultsCounter
                        className={
                          relatedPathways && 'rp-search-result-text py-3 pl-4'
                        }
                        currentLength={paths.data?.path_details?.length || 0}
                        totalResults={
                          paths.data?.page_details?.total_count || 0
                        }
                        request={paths?.request}
                      />
                      <div className='occupation_related_pathways'>
                        {renderFilters(true)}
                      </div>
                    </div>
                    <RequestErrorLoader
                      txt={
                        comparePath?.request
                          ? SearchModule.addingPathToCompareTxt
                          : SearchModule.loadingTxt
                      }
                      body={{
                        ...paths,
                        request: false,
                        data: paths.data?.path_details || [],
                      }}
                      waitUntil={paths?.request || comparePath?.request}
                      overideNoDataContainer={
                        isCareerPathways ? (
                          <NoResults subHeading=' ' />
                        ) : overRideNoresultText ? (
                          <NoResults
                            heading={SearchModule.getStartedTxt}
                            subHeading={SearchModule.typePathNames}
                          />
                        ) : (
                          <NoResults />
                        )
                      }>
                      {showContent && (
                        <ul className='search-card p-0 py-3 prog_Search_card'>
                          {paths.data?.path_details?.map(path => (
                            <PathCard
                              data={path}
                              key={path.uuid}
                              enableNavigation
                              // addToCompare={fetchPathDetails}
                              comparePathsList={comparePathsList}
                            />
                          ))}
                        </ul>
                      )}
                      {!hideButton && showContent && (
                        <div className='text-center py-4'>
                          <Button
                            type='primary'
                            className='btn-load-more'
                            onClick={loadMoreData}>
                            {paths.request
                              ? SearchModule.loadingTxt
                              : SearchModule.loadMoreBtnTxt}
                          </Button>
                        </div>
                      )}
                    </RequestErrorLoader>
                  </Col>
                </Row>
              </div>
            )}
          </RequestErrorLoader>
        </ErrorBoundary>
      </div>
      {comparePathsList?.length > 0 && <ComparePaths />}
    </>
  );
};

export default ProgramSearch;
