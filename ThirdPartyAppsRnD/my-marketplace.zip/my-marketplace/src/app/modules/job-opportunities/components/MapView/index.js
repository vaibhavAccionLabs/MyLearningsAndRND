import React from 'react';
import maplistcolor from '../../style.module.less';
export const LegendsList = [
  {
    key: 'above_average',
    color: 'map_orange',
    label: 'Above average opportunities',
  },
  {
    key: 'average',
    color: 'map_lgBlue',
    label: 'Average opportunities',
  },
  {
    key: 'below_average',
    color: 'map_blue',
    label: 'Below average opportunities',
  },
  {
    key: 'no_data',
    color: 'map_white',
    label: 'No data available',
  },
];

function Legends() {
  return (
    <ul className={`${maplistcolor.maplist} px-5 py-4 text-center`}>
      {LegendsList.map(({key, color, label}, idx) => (
        <li key={`legend-${idx}-${key}`}>
          <span className={maplistcolor[color]}>&nbsp;</span>
          {label}
        </li>
      ))}
    </ul>
  );
}

function MapView({src}) {
  return (
    <div className='map-view px-5 py-4 text-center'>
      {src && <img src={`data:image/gif;base64,${src}`} alt='map' />}
      <Legends />
      <p>
        Looking to move? Some states have more opportunities for this type of
        work than others.
      </p>
      <p>
        <span className='orange'>Orange </span> states have an
        <span className='orange'> above average </span> share of this career in
        their workforce.
      </p>
      <p>
        <span className='blue'>Blue </span> states have an
        <span className='blue'> below average </span> share of this career in
        their workforce.
      </p>
    </div>
  );
}

export default MapView;
