import React from 'react';

function Banner({displayName}) {
  return (
    <div className='banner px-5 py-4'>
      <div className='d-flex justify-content-between '>
        <h5>Job outlook for</h5>
        {/* <button className='btn-blue-outer'>Back to Career Overview</button> */}
      </div>
      <h2>{displayName}</h2>
    </div>
  );
}

export default Banner;
