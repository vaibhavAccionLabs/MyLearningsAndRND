import React from 'react';
import {Table} from 'antd';

import {LegendsList} from '../MapView';

const columns = [
  {
    title: 'State',
    dataIndex: 'state',
    key: 'state',
  },
  {
    title: 'Job outlook',
    dataIndex: 'job_outlook',
    key: 'job_outlook',
  },
];

const concatData = (Obj = {}, data = []) => {
  const {key, state} = Obj;
  let length = data.length;
  if (key && state && Array.isArray(state)) {
    return state.map(({name}, idx) => ({
      key: length + idx + 1,
      state: name,
      job_outlook: key,
    }));
  }
  return data;
};
const getKeyName = key => LegendsList.filter(item => item.key === key)[0].label;

const prepareData = Obj => {
  const {above_average, below_average, average} = Obj || {};
  let data = [];

  if (above_average && above_average.state) {
    data = [
      ...data,
      ...concatData(
        {key: getKeyName('above_average'), state: above_average.state},
        data,
      ),
    ];
  }
  if (average && average.state) {
    data = [
      ...data,
      ...concatData({key: getKeyName('average'), state: average.state}, data),
    ];
  }
  if (below_average && below_average.state) {
    data = [
      ...data,
      ...concatData(
        {key: getKeyName('below_average'), state: below_average.state},
        data,
      ),
    ];
  }

  return data;
};

function DataGrid({opportunities}) {
  const {occupation_details: {check_out_my_state} = {}} =
    opportunities.data || {};

  const dataSource = prepareData(check_out_my_state);

  return (
    <div className='listView-grid px-5 py-4'>
      <Table dataSource={dataSource} columns={columns} pagination={false} />
    </div>
  );
}

export default DataGrid;
