import React, {useState, useEffect} from 'react';
import {useHistory} from 'react-router-dom';
import {connect} from 'react-redux';

import {
  fetchJobOpportunities,
  getJobOpportunities,
  clearJobOpportunities,
} from 'redux/modules/occupation';

import {queryStringParse} from 'core/utils';
import {AppBreadcrumb, Loader, JobOutlook} from 'core/components';
// Local Components
import {Banner, DataGrid, MapView} from './components';

import './style.less';

const JobOpportunites = props => {
  const [view, setView] = useState(false);
  const history = useHistory();
  const {
    opportunities,
    opportunities: {data},
    fetchJobOpportunities,
    clearJobOpportunities,
  } = props;
  const {occupation_name, map_image_data} = data || {};

  const {
    location: {search},
  } = history;

  const params = queryStringParse(search);
  const displayName =
    decodeURIComponent(params && params.query) || occupation_name;
  useEffect(() => {
    fetchJobOpportunities(params.query);
    return () => {
      clearJobOpportunities();
    };
  }, [params.query]); // eslint-disable-line react-hooks/exhaustive-deps

  const onViewChange = key => setView(key);

  return (
    <>
      <div className='breadcrumbCurve'>
        <AppBreadcrumb
          dataList={[
            {
              name: 'Occupation Detail',
              path: `/occupation?query=${displayName}`,
            },
            {
              name: 'Job Outlook Map',
            },
          ]}
        />
      </div>
      <div className='jobOpportunities'>
        <Banner displayName={displayName} />
        {!opportunities.request && !opportunities.error && (
          <div className='job-opportunity-content'>
            <JobOutlook
              moduleName='job-opportunities'
              view={view}
              data={data}
              history={history}
              onViewChange={onViewChange}
            />
            {!view ? <MapView src={map_image_data} /> : <DataGrid {...props} />}
          </div>
        )}
      </div>
      {opportunities.request && (
        <Loader text='Loading Job Opportunites, Please Wait... ' />
      )}
    </>
  );
};

const mapStateToProps = state => ({
  opportunities: getJobOpportunities(state),
});

export default connect(mapStateToProps, {
  fetchJobOpportunities,
  clearJobOpportunities,
})(JobOpportunites);
