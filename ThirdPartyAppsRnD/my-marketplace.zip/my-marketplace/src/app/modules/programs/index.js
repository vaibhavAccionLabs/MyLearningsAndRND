import React, {useEffect} from 'react';
import {useParams, useLocation} from 'react-router-dom';
import {connect} from 'react-redux';
import {message} from 'antd';

import {openLoginScreen} from 'redux/modules/auth';
import {
  fetchProgramDetail,
  getProgramDetail,
  fetchSignedUpPrograms,
  signUpProgram,
  getSignedUpPrograms,
  clearProgramDetail,
  saveProgram,
  fetchSavedPrograms,
  getSavedPrograms,
  resetSignedPrograms,
  resetSavedPrograms,
} from 'redux/modules/programs';

import {queryStringParse} from 'core/utils';
import {useAuth} from 'core/hooks';
import {
  AppBreadcrumb,
  //CustomTabs,
  RequestErrorLoader,
  ErrorBoundary,
} from 'core/components';

import {getAppConfig} from 'redux/modules/general';

import {
  updateOpportunityInterest,
  fetchSavedOpportunities,
  getSavedOpportunities,
  resetSavedOpportunities,
  fetchAppliedOpportunities,
  resetAppliedOpportunities,
  getAppliedOpportunities,
  unSaveOpportunity,
} from 'redux/modules/occupation';

import {Banner} from './sharedComponents';
import {Overview} from './components';

import programsData from 'data/programs.json';

import './style.less';

let isAction = null; // used in the initLoggedInData to ignore the api calls on login if action took from SAVE or SIGNUP Button

const Programs = props => {
  const {
    openLoginScreen,
    fetchProgramDetail,
    programDetail,
    clearProgramDetail,
    updateOpportunityInterest,
    fetchSavedOpportunities,
    resetSavedOpportunities,
    fetchAppliedOpportunities,
    resetAppliedOpportunities,
    SavedOpportunity,
    unSaveOpportunity,
  } = props;
  const {programId, institutionName = null} = useParams();
  const [token, user] = useAuth();

  const {search} = useLocation();
  const {type, related_occupation} = queryStringParse(search);

  const {
    data: {
      business_partner_program_uuid: progId,
      opportunity_id,
      opportunity_type,
      title,
      job_post_thumbnail_cloudinary,
      institute_details: {institution_uuid, institution_name} = {},
    } = {},
  } = programDetail || {};

  const initLoggedInData = () => {
    if (token) {
      if (isAction != 'signup') {
        fetchAppliedOpportunities();
      }
      if (isAction != 'save') {
        fetchSavedOpportunities();
      }
    }
  };

  useEffect(() => {
    if (programId && institutionName) {
      fetchProgramDetail(programId, type, institutionName);
      initLoggedInData();
    }
    return () => {
      clearProgramDetail();
      resetAppliedOpportunities();
      resetSavedOpportunities();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    initLoggedInData();
  }, [token]); // eslint-disable-line react-hooks/exhaustive-deps

  // const tabs = [
  //   {
  //     title: 'OVERVIEW',
  //     key: 'career_overview',
  //     children: <Overview {...props} />,
  //   },
  // ];

  const onSignUpProgram = async () => {
    const data = {
      job_post_thumbnail_cloudinary: job_post_thumbnail_cloudinary,
      bp_opportunity_id: opportunity_id,
      opportunity_name: title,
      opportunity_type: opportunity_type,
      institute_uuid: institution_uuid,
      institute_name: institution_name,
      action_type: 'apply',
    };
    await updateOpportunityInterest(data, err => {
      if (err) {
        message.error(err);
      } else {
        // Check if the opportunity is saved, if yes then unsave after applying
        const opportunitySavedData = opportunitySaved();
        if (opportunitySavedData.status) {
          // unsave opportunity
          unSaveOpportunity(opportunitySavedData.app_id);
        }
        message.success(programsData.appliedSuccessfullyMsg);
      }
    });

    fetchAppliedOpportunities();
    isAction = null;
  };

  const opportunitySaved = () => {
    if (SavedOpportunity && SavedOpportunity.data) {
      const exists = SavedOpportunity.data.filter(
        i => i.bp_opportunity_id === opportunity_id,
      );
      if (exists[0]) {
        return {
          app_id: exists[0].opp_application_uuid,
          status: true,
        };
      }
    }
    return {
      status: false,
    };
  };

  const onSignUpProgramClick = async () => {
    if (token) {
      onSignUpProgram();
    } else {
      isAction = 'signup';
      openLoginScreen({
        callback: async () => {
          fetchAppliedOpportunities((signedUpPrograms = []) => {
            const exists = signedUpPrograms.filter(
              i => i.bp_opportunity_id === opportunity_id,
            );
            if (exists[0]) {
              message.warning(programsData.opportunityAlreadyAppliedMsg);
            } else {
              onSignUpProgram();
            }
          });
        },
      });
    }
  };

  const onSaveProgram = async () => {
    const data = {
      job_post_thumbnail_cloudinary: job_post_thumbnail_cloudinary,
      bp_opportunity_id: opportunity_id,
      opportunity_name: title,
      opportunity_type: opportunity_type,
      institute_uuid: institution_uuid,
      institute_name: institution_name,
      action_type: 'save',
    };
    await updateOpportunityInterest(data, err => {
      if (err) {
        message.warning(err);
      } else {
        message.success(programsData.opportunitySavedMsg);
      }
    });
    fetchSavedOpportunities();

    isAction = null;
  };

  const onSaveProgramClick = async () => {
    if (token) {
      onSaveProgram();
    } else {
      isAction = 'save';
      openLoginScreen({
        callback: () => {
          fetchSavedOpportunities((savedPrograms = []) => {
            const exists = savedPrograms.filter(
              i => i.bp_opportunity_id === opportunity_id,
            );
            if (exists[0]) {
              message.warning(programsData.opportunityAlreadySavedMsg);
            } else {
              onSaveProgram();
            }
          });
        },
      });
    }
  };

  return (
    <>
      <ErrorBoundary nameOfComponent='module-programs' typeOfUi='subPage'>
        <RequestErrorLoader body={{request: programDetail?.request}}>
          <AppBreadcrumb
            dataList={
              related_occupation
                ? [
                    {
                      name: 'Career Detail',
                      path: `/occupation?query=${related_occupation}`,
                    },
                    {
                      name: 'Job Description',
                    },
                  ]
                : [
                    {
                      name: 'Find Opportunities',
                      path: '/business-partners',
                    },
                    {
                      name: institution_name,
                      path: `/business-partners/${institution_name}`,
                    },
                    {
                      name: title,
                    },
                  ]
            }
          />
          <Banner
            {...props}
            onSignUpProgram={onSignUpProgramClick}
            onSaveProgramClick={onSaveProgramClick}
          />

          <div className='programs-tabs contentContainer'>
            <Overview
              {...props}
              onOpportunityApply={onSignUpProgramClick}
              onOpportunitySave={onSaveProgramClick}
            />
          </div>
        </RequestErrorLoader>
      </ErrorBoundary>
    </>
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  signedUpPrograms: getSignedUpPrograms(state),
  savedPrograms: getSavedPrograms(state),
  programDetail: getProgramDetail(state),
  SavedOpportunity: getSavedOpportunities(state),
  AppliedOpportunity: getAppliedOpportunities(state),
});

export default connect(mapStateToProps, {
  fetchProgramDetail,
  fetchSignedUpPrograms,
  signUpProgram,
  openLoginScreen,
  clearProgramDetail,
  saveProgram,
  fetchSavedPrograms,
  resetSignedPrograms,
  resetSavedPrograms,
  updateOpportunityInterest,
  fetchSavedOpportunities,
  resetSavedOpportunities,
  fetchAppliedOpportunities,
  resetAppliedOpportunities,
  unSaveOpportunity,
})(Programs);
