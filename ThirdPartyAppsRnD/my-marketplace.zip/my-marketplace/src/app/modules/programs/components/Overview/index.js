import {OpportunityDetails} from 'core/components';
import './style.less';

const Overview = ({
  appConfig: {isMobileView},
  programDetail,
  onOpportunityApply,
  onOpportunitySave,
  SavedOpportunity,
  AppliedOpportunity,
}) => {
  const {data} = programDetail || {};
  return (
    <OpportunityDetails
      details={data}
      isMobileView={isMobileView}
      OpportunityApply={onOpportunityApply}
      OpportunitySave={onOpportunitySave}
      savedOpportunities={SavedOpportunity}
      AppliedOpportunities={AppliedOpportunity}
    />
  );
};
export default Overview;
