import {getBanner, getLogo} from 'core/utils';
import {defaultbannerjob} from 'assets/images';

import './style.less';

const Banner = ({programDetail, appConfig: {isMobileView}}) => {
  const {
    data: {
      banner_image,
      business_partner_details: {
        business_partner_banner_cloudinary,
        business_partner_logo_cloudinary,
      } = {},
      institute_details: {
        institute_banner_cloudinary,
        institute_logo_cloudinary,
      } = {},
    } = {},
  } = programDetail || {};

  const getBannerImageStyle = () => ({
    background: `url(${
      (institute_banner_cloudinary &&
        getBanner(institute_banner_cloudinary, {
          width: isMobileView ? window.screen.width : 1250,
          height: isMobileView ? 200 : 250,
        })) ||
      banner_image ||
      defaultbannerjob
    }) no-repeat top left`,
  });

  return (
    <div>
      <div className='occupationBanner' style={getBannerImageStyle()}></div>
      <div className='opportunity_logo'>
        <img src={getLogo(institute_logo_cloudinary)} alt='logo' />
      </div>
    </div>
  );
};

export default Banner;
