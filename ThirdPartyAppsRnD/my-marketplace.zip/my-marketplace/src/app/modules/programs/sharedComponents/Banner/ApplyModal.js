import {successTick} from 'assets/images';
import {applyModalData} from 'data/programs.json';

const ApplyModal = ({programDetail}) => {
  const {data: {name} = {}} = programDetail || {};
  return (
    <div className='program-apply-modal'>
      <img src={successTick} className='icn' alt='succes-icon' />
      <div className='ttl'>{applyModalData.appliedSuccessfullyMsg}</div>
      <div className='sub'>
        {applyModalData.desciptionPre} <span>‘{name}’</span>
        {applyModalData.desciptionPost}
      </div>
      <div
        className='sub'
        dangerouslySetInnerHTML={{__html: applyModalData?.note}}
      />
    </div>
  );
};

export default ApplyModal;
