import {OccupationSearch} from 'core/components';

const Banner = props => {
  return (
    <header className='careenDestination-header contentContainer'>
      <h1>
        <span className='header-title-color-bg'>Check</span> Out Careers
      </h1>
      <div className='search-ca-destination'>
        <OccupationSearch {...props} />
      </div>

      {/* <input
          className='searchCareer'
          placeholder='Search by occupation or job title'></input> */}
    </header>
  );
};

export default Banner;
