import React, {useCallback} from 'react';
import {Col, Row} from 'antd';
import style from './filter.module.less';

const Filter = ({currentTab, onChangeTab, tabs}) => {
  const tabClasses = useCallback(
    itm => {
      if (itm.value === currentTab) return `${style.tb_itm} ${style.active}`;
      return style.tb_itm;
    },
    [currentTab],
  ); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Row justify='center' className={style.career_dest_filter}>
      <Col>
        <Row gutter={24} className={style.career_dest_layout} align='center'>
          <Col className={style.lbl}>
            <h3>Filter Careers by</h3>
          </Col>
          <Col className={style.tbs}>
            <Row gutter={24}>
              {tabs?.map(tab => (
                <Col key={tab.value}>
                  <div
                    className={tabClasses(tab)}
                    onClick={() => onChangeTab(tab.value, tab)}>
                    <span>{tab.label}</span>
                  </div>
                </Col>
              ))}
            </Row>
          </Col>
        </Row>
      </Col>
    </Row>
  );
};

export default Filter;
