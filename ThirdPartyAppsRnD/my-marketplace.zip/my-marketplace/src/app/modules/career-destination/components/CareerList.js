import {Button, Col, Row} from 'antd';
import {LazyImage} from 'core/components';
import style from './career.module.less';

const formatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
});

const CareerList = props =>
  props?.data?.length > 0 && (
    <>
      <ul className={`contentContainer ${style.careerSearch_card}`}>
        {props?.data.map(dt => (
          <li
            key={dt.id}
            onClick={() => props.navigateToSearch(dt.occupation_title)}>
            <div>
              <LazyImage
                src={`https://cdn.careeronestop.org/OccVids/OccupationVideos/${
                  dt?.video_details?.[0]?.VideoCode || ''
                }.jpg`}
                className='img-fluid'
              />
              <span className={style.avg_value}>
                {formatter.format(dt.salary_annual_median)} avg.
              </span>
            </div>
            <h4 title={dt.occupation_title}>{dt.occupation_title}</h4>
          </li>
        ))}
      </ul>
      {!props.pageEnd && (
        <Row justify='center'>
          <Col>
            <Button
              type={'primary'}
              className={style.btn_load_more}
              onClick={props.onLoadMoreClick}>
              Load More
            </Button>
          </Col>
        </Row>

        //className='btn-load-more mt-4 mb-3'
      )}
      <br />
    </>
  );

export default CareerList;
