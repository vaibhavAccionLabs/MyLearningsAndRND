import React, {useEffect, useMemo, useState} from 'react';
import {connect} from 'react-redux';

import {
  AppBreadcrumb,
  RequestErrorLoader,
  ErrorBoundary,
  RibbonNavigator,
} from 'core/components';
import {getModuleBasePath} from 'core/utils';

import {CareerList, Filter} from './components';

import {
  fetchOccupationRank,
  getCareerRank,
} from 'redux/modules/career-destination';

import './style.less';

const itemsPerPage = 8;

const tabs = [
  {
    label: 'Highest Paying',
    value: 'highest_paying_rank',
    apiKey: 'highest_paying',
  },
  {
    label: 'Most Openings',
    value: 'most_openings_rank',
    apiKey: 'most_openings',
  },
  {
    label: 'Fastest Growing',
    value: 'fastest_growing_rank',
    apiKey: 'fastest_growing',
  },
];

const CareerDestination = props => {
  const [page, setPage] = useState(0);
  const [tab, setTab] = useState(tabs[1].value);
  const [pageEnd, setPageEnd] = useState(false);

  useEffect(() => {
    props.fetchOccupationRank(tabs[1].apiKey);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const pages = useMemo(() => {
    const {data} = props.careerRank;
    if (data && data) {
      if (parseInt(data.length / itemsPerPage) === page) setPageEnd(true);
      return data.slice(0, page * itemsPerPage + itemsPerPage);
    } else return null;
  }, [props.careerRank, page, tab]); // eslint-disable-line react-hooks/exhaustive-deps

  const onLoadMoreClick = () => {
    setPage(page + 1);
  };
  const onTabChange = (key, tab) => {
    setTab(key);
    setPage(0);
    setPageEnd(false);
    props.fetchOccupationRank(tab.apiKey);
  };
  const navigateToSearch = value => {
    const BasePath = getModuleBasePath('occupation');
    props.history.push(`${BasePath}?query=${encodeURIComponent(value)}`);
  };
  return (
    <>
      <header className='findStudent_banner'>
        <div className='header_bannerText'>
          <div>
            <h1 className='title'>Discover Careers</h1>
            <h5 className='desc'>
              Search and learn more about careers by what interests you the
              most.
            </h5>
          </div>
        </div>
      </header>
      <RibbonNavigator
        heading='Discover Career Interest'
        btnTxt='TAKE THE SURVEY'
        btnPath='/survey'>
        <span>
          Take a <strong>Career Interest Survey</strong> to help you decide what
          kinds of <strong>careers</strong> you might want to explore
        </span>
      </RibbonNavigator>
      <div className='careenDestination'>
        {/* <AppBreadcrumb
          dataList={[
            {
              name: 'Check Out Careers',
            },
          ]}
        /> */}
        <ErrorBoundary
          nameOfComponent='module-career-destination'
          typeOfUi='subPage'>
          <RequestErrorLoader body={props.careerRank}>
            {props.careerRank?.data?.length > 0 && (
              <>
                <Filter
                  tabs={tabs}
                  currentTab={tab}
                  onChangeTab={onTabChange}
                />
                <ul className='contentContainer p-0'>
                  <h3 className='results-text'>
                    Top{' '}
                    <span>
                      {props?.careerRank?.data
                        ? props?.careerRank?.data?.length
                        : 0}
                    </span>{' '}
                    Results
                  </h3>
                </ul>

                <CareerList
                  data={pages}
                  navigateToSearch={navigateToSearch}
                  onLoadMoreClick={onLoadMoreClick}
                  pageEnd={pageEnd}
                />
              </>
            )}
          </RequestErrorLoader>
        </ErrorBoundary>
      </div>
    </>
  );
};

const mapStateToProps = state => ({
  careerRank: getCareerRank(state),
});

export default connect(mapStateToProps, {fetchOccupationRank})(
  CareerDestination,
);
