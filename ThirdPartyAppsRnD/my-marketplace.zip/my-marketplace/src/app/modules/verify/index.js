import {useState, useEffect} from 'react';
import {useLocation} from 'react-router-dom';
import {queryStringParse} from 'core/utils';
import {useAuth} from 'core/hooks';
import {API} from 'config';
import {Services} from 'core/Services';
import {emailSuccess} from 'assets/images';
import style from './style.module.less';

const services = new Services();

const Verify = () => {
  const [isEmailVerifed, setIsEmailVerified] = useState(false);
  const [token, user] = useAuth();
  const [error, setError] = useState(null);
  const {search} = useLocation();
  const {confirmation_token} = queryStringParse(search);

  console.log('SEARCH::', search);

  const redirect = (timeLapse = 0) =>
    setTimeout(() => {
      window.location.href = window?.location?.origin;
    }, timeLapse);

  useEffect(() => {
    // trigger verification API
    let endpoint = `${API.gps.confirm_user_account}fed-89-stud-conf-tkn`;
    if (confirmation_token && token) {
      services.updateStatus(token, endpoint, {confirmation_token}).then(res => {
        console.log('RESponse::');
        if (res.Success) {
          setIsEmailVerified(true);
          redirect();
          return;
        }
        if (res?.Error) {
          setError(res.error);
        }
      });
      return;
    }
    redirect();
  }, [token, confirmation_token]);

  if (error) {
    return (
      <div className={style.emailComp_bg}>
        <div className={`contentContainer ${style.emailComp_verify}`}>
          <h4>Error Occured</h4>
          <p>{error || 'Something went wrong. Try again later!'}</p>
        </div>
      </div>
    );
  }
  return (
    <div className={style.emailComp_bg}>
      {isEmailVerifed ? (
        <div className={style.emailComp_verifySuccess}>
          <img src={emailSuccess} alt='award' className='pr-2' />
          <h4>Email Verified!</h4>
          <p>
            You have successfully verified your email address. Redirecting you
            to <span>GoEducate...</span>
          </p>
        </div>
      ) : (
        <div className={`contentContainer ${style.emailComp_verify}`}>
          <h4>Please Wait!</h4>
          <p>Your email is being verified...</p>
        </div>
      )}
    </div>
  );
};

export default Verify;
