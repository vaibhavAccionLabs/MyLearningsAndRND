import {useState} from 'react';
import {numberInUSFormat} from 'core/utils';
import './style.less';

const CostCard = ({pathData}) => {
  const {cost_description, estimated_cost} = pathData || {};
  const [moreText, setMoreText] = useState(false);
  return cost_description || estimated_cost ? (
    <>
      <div className='cost-card'>
        <div>
          {estimated_cost && (
            <>
              <h1 className='ttl'>Cost</h1>
              <h2 className='cst'>
                Estimated Cost <span>${numberInUSFormat(estimated_cost)}</span>
              </h2>
            </>
          )}

          {cost_description && (
            <>
              <h2 className='cst'>Description</h2>
              <div className='desc-text'>
                {moreText
                  ? cost_description
                  : cost_description.substring(0, 500)}
                {cost_description.length > 500 && (
                  <span className='mr' onClick={() => setMoreText(!moreText)}>
                    {moreText ? 'See Less' : 'See More'}
                  </span>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </>
  ) : (
    <></>
  );
};

export default CostCard;
