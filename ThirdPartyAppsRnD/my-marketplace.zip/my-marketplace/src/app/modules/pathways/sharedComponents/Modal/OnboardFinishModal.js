import React from 'react';
import {successTick} from 'assets/images';
import {Modal, Button} from 'antd';

const OnboardFinishModal = ({onCancel, visible = false, navigateTo}) => {
  return (
    <Modal
      visible={visible}
      closable={null}
      onCancel={onCancel}
      maskStyle={{backgroundColor: '#ffffffe0'}}
      className='finish-path-modal onboard-finish-path-modal'
      footer={null}
      width={600}>
      <div>
        <img src={successTick} className='icn' alt='success-icon' />
        <div className='ttl'>Congratulations!</div>
        <div className='sub'>
          Your have successfully completed onboarding into this program.
          <br />
          You can now begin viewing program requirements, job matches and other
          opportunities that match this progam.
        </div>
      </div>
      <br />
      <br />
      <div className='ant-modal-confirm-btns'>
        <Button
          onClick={() => navigateTo('/settings/dashboard')}
          className='ant-btn-primary'>
          Go To My Dashboard
        </Button>
      </div>
      <br />
    </Modal>
  );
};

export default OnboardFinishModal;
