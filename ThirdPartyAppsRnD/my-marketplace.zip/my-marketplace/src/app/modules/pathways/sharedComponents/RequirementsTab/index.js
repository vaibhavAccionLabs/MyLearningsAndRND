import React, {useState} from 'react';
import {CourseModal} from 'core/components';
import SegmentTable from './SegmentTable';
import GenEd from './GenEd';
import './style.less';

const RequirementsTab = props => {
  const {pathData, myPlanData} = props;
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [displayCourse, setDisplayCourse] = useState(false);

  const onClose = () => {
    setSelectedCourse(null);
    setDisplayCourse(false);
  };

  const onCourseClick = course => {
    setSelectedCourse(course);
    setDisplayCourse(true);
  };

  const CoursesTableColumns = [
    {
      title: 'COURSE ID',
      dataIndex: 'course_id',
      key: 'course_id',
      render: (text, record) => (
        <div onClick={() => onCourseClick(record)}>{text}</div>
      ),
    },
    {
      title: 'COURSE TITLE',
      dataIndex: 'course_name',
      key: 'course_name',
    },
    {
      title: 'UNITS',
      dataIndex: 'units',
      key: 'units',
    },
  ];

  return (
    <>
      <p>
        In order to complete this pathway, each of the requirements listed on
        this page must be satisfied.
      </p>

      <div className='py-2'>
        {/* default value is units */}
        <h2 className='capitalize'>{`Required ${
          pathData?.score_system || 'units'
        }:`}</h2>
        <h3 className='capitalize'>{`${pathData?.total_units_required || '-'} ${
          pathData?.score_system || 'units'
        }`}</h3>
      </div>
      <div className='py-2'>
        <h2>General Education Requirements: </h2>
        <div className='generalReq'>
          {myPlanData && pathData && pathData.general_education_option ? (
            <GenEd {...props} columns={CoursesTableColumns} />
          ) : (
            <p>
              {pathData && pathData.general_education_option
                ? 'This path requires the completion of a general education option.'
                : 'There is no general education requirement for this path.'}
            </p>
          )}
        </div>
      </div>

      {pathData?.segment &&
        Array.isArray(pathData.segment) &&
        pathData.segment.length > 0 && (
          <div className='py-2'>
            <h2>{`${pathData?.segment_box_name || 'Core Courses'}:`}</h2>
            <SegmentTable
              defaultOpen
              data={pathData.segment}
              columns={CoursesTableColumns}
            />
          </div>
        )}

      {pathData?.segment_groups &&
        Array.isArray(pathData.segment_groups) &&
        pathData.segment_groups.length > 0 && (
          <div className='py-4'>
            <h2>{`${
              pathData?.segment_group_box_name || 'Additional Core Courses'
            }:`}</h2>
            <SegmentTable
              defaultOpen
              data={pathData.segment_groups}
              columns={CoursesTableColumns}
              isOnlySegmentGrp
            />
          </div>
        )}

      <CourseModal
        visible={displayCourse}
        onModalClose={onClose}
        data={selectedCourse}
      />
    </>
  );
};

export default RequirementsTab;
