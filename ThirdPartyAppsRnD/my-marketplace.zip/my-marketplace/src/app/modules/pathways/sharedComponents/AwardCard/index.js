import {awardtype} from 'assets/images';
import {durationString} from 'core/utils';
import './style.less';

const AwardCard = ({pathData}) => {
  const {
    min_gpa,
    score_system,
    award_type_name,
    institute_details,
    total_units_required,
  } = pathData || {};
  const durationData = durationString(pathData);
  return (
    <div className='award-card'>
      <div>
        <h1 className='ttl'>
          School{' '}
          <span title={institute_details?.name || ''}>
            {institute_details?.name || '-'}
          </span>
        </h1>
        <h2>
          <img src={awardtype} alt='award' className='pr-2' />
          <span title={award_type_name || ''}>{award_type_name || '-'}</span>
        </h2>
        <ul className='m-0 p-0 mb-0'>
          <li>
            <h1>{total_units_required || '-'}</h1>
            <h5>{score_system || 'units'}</h5> {/* default value is units */}
          </li>
          <li>
            <h1
              className={`text-center ${min_gpa ? '' : 'text-grey'}`}
              title={!min_gpa ? 'No minimum GPA required' : ''}>
              {min_gpa || 'None'}
            </h1>
            <h5>Minimum GPA</h5>
          </li>
          <li>
            <h1 title={durationData}>{durationData}</h1>
            <h5>Duration</h5>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default AwardCard;
