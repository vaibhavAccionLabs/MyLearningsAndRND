import {Button, Popconfirm, Spin} from 'antd';
import {LazyImage} from 'core/components';
import {durationString, getBanner} from 'core/utils';
import {
  whitetick,
  heartWhite,
  awardTypeWhite,
  heartPurpleBorder,
  // defaultbannerprofile,
} from 'assets/images';
import './style.less';

const Banner = ({
  showActions,
  pathData,
  onStartPathwayClick,
  onCompareClick,
  studentOnboard,
  isCurentPathisActive,
  displayWorkforce,
  workforceData,
  onSavePathClick,
  savedPath,
  removeSavedPath,
  isNextStep,
  goToNextStep,
  finishPathway,
  isFinishButton,
  isPathLoading,
}) => {
  // const {data: workforce_data = {}} = workforceData || {};
  const {data: saved_path, request: savedPathRequest} = savedPath || {};
  const {
    min_gpa,
    location,
    title = '-',
    score_system,
    award_type_name,
    uuid: path_uuid,
    institute_details,
    banner_cloudinary,
    total_units_required,
    program_details,
    program_details: {cluster_card_url = '', cluster_banner_url = ''} = {},
  } = pathData || {};
  const durationData = durationString(pathData);
  let BannerSrc = banner_cloudinary;
  let DisplayTitle = title;
  const clusterImg = getBanner(cluster_banner_url);

  // if (displayWorkforce && workforceData?.data) {
  //   BannerSrc = workforce_data?.cluster_image || defaultbannerprofile;
  //   DisplayTitle = workforce_data?.name;
  // }
  const {data: studentOnboardData = {}, request: studentOnboardRequest} =
    studentOnboard || {};

  const isPathSaved =
    pathData &&
    saved_path &&
    Array.isArray(saved_path) &&
    saved_path.map(i => i.path_uuid).indexOf(path_uuid) !== -1;
  const onSavePath = () => {
    if (!savedPathRequest && !isPathSaved && onSavePathClick) {
      onSavePathClick();
    }
  };

  return (
    <div
      className='program-banner px-5 py-4'
      style={{
        background: `url(${clusterImg}) no-repeat center top`,
      }}>
      <div className='contentContainer'>
        <div className='program-banner-container b_container_web'>
          <div className='video'>
            <Spin
              spinning={workforceData?.request || isPathLoading}
              wrapperClassName='image_rerender'>
              {!workforceData?.request && !isPathLoading && (
                <LazyImage renderSrcSet src={BannerSrc} alt='cluster_image' />
              )}
            </Spin>
          </div>
          <div className='r-container b_container_web'>
            <div className='title py-2' title={DisplayTitle}>
              {DisplayTitle}
            </div>
            <div className='award-card-container'>
              <div className='award-row'>
                <h1 className='ttl pr-5'>
                  <img src={awardTypeWhite} alt='award' className='pr-2' />
                  <span title={award_type_name || ''}>
                    {award_type_name || '-'}
                  </span>
                </h1>
                <h2 className='ttl'>
                  Offered By:{' '}
                  <span title={institute_details?.name || ''}>
                    {institute_details?.name || '-'}
                  </span>
                </h2>
              </div>
              <div className='award-row'>
                <h2 className='ttl'>
                  Location:{' '}
                  <span title={location}>{location || 'Not Available'}</span>
                </h2>
              </div>
              <ul className='m-0 p-0 mb-0'>
                <li>
                  <h1>{total_units_required || '-'}</h1>
                  <h5>{score_system || 'units'}</h5>{' '}
                  {/* default value is units */}
                </li>
                <li>
                  <h1
                    className={`text-center ${min_gpa ? '' : 'text-grey'}`}
                    title={!min_gpa ? 'No minimum GPA required' : ''}>
                    {min_gpa || 'None'}
                  </h1>
                  <h5>Minimum GPA</h5>
                </li>
                <li>
                  <h1 title={durationData}>{durationData}</h1>
                  <h5>Duration</h5>
                </li>
              </ul>
            </div>
          </div>
          <div className='actions-container'>
            {isNextStep && (
              <Button type='primary' onClick={goToNextStep}>
                Go to Next Step
              </Button>
            )}
            {isFinishButton &&
              studentOnboardData?.completed_stage !== 'career' && (
                <Button
                  type='primary'
                  className='btn-transparent'
                  onClick={finishPathway}>
                  FINISH PROGRAM
                </Button>
              )}
            {displayWorkforce &&
              studentOnboardData?.completed_stage === 'career' && (
                <Button type='primary' className='btn-green'>
                  <img src={whitetick} alt='successTick' className='px-2' />
                  FINISHED PROGRAM
                </Button>
              )}
            {showActions && (
              <>
                <Button
                  type='primary'
                  onClick={onStartPathwayClick}
                  loading={studentOnboardRequest}>
                  {isCurentPathisActive()
                    ? 'CONTINUE PROGRAM'
                    : 'START PROGRAM'}
                </Button>
                {/* Compare Button is not required */}
                {/* <Button
                  type='primary'
                  className='btn-transparent'
                  onClick={() => onCompareClick(pathData)}>
                  COMPARE
                </Button> */}
                {savedPathRequest ? (
                  <Button loading shape='circle' />
                ) : isPathSaved ? (
                  <Popconfirm
                    title='Are you sure to remove the saved path?'
                    onConfirm={removeSavedPath}
                    overlayClassName='saveConfirm'
                    okText='Yes'
                    cancelText='No'>
                    <Button
                      type='primary'
                      shape='circle'
                      loading={savedPathRequest}
                      disabled={savedPathRequest}
                      className='btn-green heartRating saved'
                      icon={<img src={heartWhite} alt='heart' />}
                    />
                  </Popconfirm>
                ) : (
                  <div className='btnheartcircle'>
                    <Button
                      type='primary'
                      shape='circle'
                      className='heartRating'
                      onClick={onSavePath}
                      loading={savedPathRequest}
                      disabled={savedPathRequest}
                      icon={<img src={heartPurpleBorder} alt='heart' />}
                    />
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
      <div className='program-banner-container b_container_mob'>
        <div className='d-flex justify-content-center mob'>
          <div className='video'>
            <Spin
              spinning={workforceData?.request || isPathLoading}
              wrapperClassName='image_rerender'>
              {!workforceData?.request && !isPathLoading && (
                <LazyImage renderSrcSet src={BannerSrc} alt='cluster_image' />
              )}
            </Spin>
          </div>
          <div className='r-container'>
            <div className='title py-2'>{DisplayTitle}</div>
          </div>
        </div>
        <div className='actions-container'>
          {isNextStep && (
            <Button type='primary' onClick={goToNextStep}>
              Go to Next Step
            </Button>
          )}
          {isFinishButton && studentOnboardData?.completed_stage !== 'career' && (
            <Button
              type='primary'
              className='btn-transparent'
              onClick={finishPathway}>
              FINISH PROGRAM
            </Button>
          )}
          {displayWorkforce &&
            studentOnboardData?.completed_stage === 'career' && (
              <Button type='primary' className='btn-green'>
                <img src={whitetick} alt='successTick' className='px-2' />
                FINISHED PROGRAM
              </Button>
            )}
          {showActions && (
            <>
              <Button
                type='primary'
                onClick={onStartPathwayClick}
                loading={studentOnboardRequest}>
                {isCurentPathisActive() ? 'CONTINUE PROGRAM' : 'START PROGRAM'}
              </Button>
              {/* <Button
                type='primary'
                className='btn-transparent'
                onClick={() => onCompareClick(pathData)}>
                COMPARE
              </Button> */}
              {savedPathRequest ? (
                <Button loading shape='circle' />
              ) : isPathSaved ? (
                <Popconfirm
                  title='Are you sure to remove the saved path?'
                  onConfirm={removeSavedPath}
                  overlayClassName='saveConfirm'
                  okText='Yes'
                  cancelText='No'>
                  <Button
                    type='primary'
                    shape='circle'
                    loading={savedPathRequest}
                    disabled={savedPathRequest}
                    className='btn-green heartRating saved'
                    icon={<img src={heartWhite} alt='heart' />}
                  />
                </Popconfirm>
              ) : (
                <div className='btnheartcircle'>
                  <Button
                    type='primary'
                    shape='circle'
                    className='heartRating'
                    onClick={onSavePath}
                    loading={savedPathRequest}
                    disabled={savedPathRequest}
                    icon={<img src={heartPurpleBorder} alt='heart' />}
                  />
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Banner;
