import React, {useEffect, useState} from 'react';
import {Button, Popover} from 'antd';
import {InfoCircleFilled} from '@ant-design/icons';

import {RequestErrorLoader} from 'core/components';
import {getModuleBasePath} from 'core/utils';

import {brightIcon} from 'assets/images';
import './style.less';

export const BrightOutlookContent = () => (
  <>
    <p>
      Bright Outlook occupations are expected to grow rapidly in the next
      several years, or will have large numbers of job openings.
    </p>
    <p>
      Every Bright Outlook occupation matches at least one of the following
      criteria:
    </p>
    <p>
      Projected to grow faster than average (employment increase of 5% or more)
      over the period 2019-2029 for the US nationwide.
    </p>
    <p>
      Projected to have 100,000 or more job openings over the period 2019-2029
      for the US nationwide.
    </p>
  </>
);

function Occupations({
  fetchOccupations,
  clearOccupations,
  occupations,
  subHeading,
  children,
  history,
  appConfig: {isMobileView},
}) {
  const [totalOccupations, setTotalOccupations] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [pageSize, setPageSize] = useState(9);
  const [pageNo, setPageNo] = useState(1);
  useEffect(() => {
    fetchOccupations();
    return () => {
      clearOccupations();
    };
  }, [clearOccupations, fetchOccupations]);
  useEffect(() => {
    if (occupations.data && occupations.data.occupation_total_count) {
      const totalPages = Math.ceil(
        occupations.data.occupation_total_count / pageSize,
      );
      setTotalPages(totalPages);
      setTotalOccupations(occupations.data.occupation_total_count);
    }
    return () => {};
  }, [occupations.data, pageSize]);
  const loadMoreOccupations = () => {
    if (pageNo < totalPages) {
      setPageNo(pageNo + 1);
      fetchOccupations(pageSize, pageNo + 1);
    }
  };
  const navigateTo = value => {
    // history.push(`/occupation?query=${value}`);
    const BasePath = getModuleBasePath('occupation');
    window.open(`${BasePath}?query=${value}`, '_blank').focus();
  };

  return (
    <div className='py-3'>
      <div className='headerelated_occupatonsr'>
        <div className='d-flex'>
          <h2 className='heading'>Related Occupations</h2>
          <p className='additional-info'>
            <img src={brightIcon} alt='bright-icon' /> Bright Outlook
            Occupations
            <Popover
              placement='bottomLeft'
              className='pl-2'
              content={BrightOutlookContent()}
              overlayClassName='relatedOccupations-popover'
              trigger={isMobileView ? 'click' : 'hover'}>
              <InfoCircleFilled />
            </Popover>
          </p>
        </div>
        {subHeading && <div className='sub-heading'>{subHeading}</div>}
      </div>
      {children}
      <RequestErrorLoader
        body={{...occupations, request: occupations?.request && pageNo <= 1}}>
        {occupations.data && (
          <div className='occupations-list'>
            <ul>
              {occupations.data.occupation &&
                Array.isArray(occupations.data.occupation) &&
                occupations.data.occupation.map((occ, idx) => (
                  <li key={idx}>
                    <span className='tag' onClick={() => navigateTo(occ.name)}>
                      {occ.name}
                    </span>
                    {occ.bright && <img src={brightIcon} alt='bright-icon' />}
                  </li>
                ))}
            </ul>
            {pageNo < totalPages && (
              <div className='py-3 text-center'>
                <Button className='btn btn-pink' onClick={loadMoreOccupations}>
                  {`${occupations?.request ? 'Loading...' : 'Load More'}`}
                </Button>
              </div>
            )}
          </div>
        )}
      </RequestErrorLoader>
    </div>
  );
}

export default Occupations;
