import React from 'react';
import {successTick} from 'assets/images';
import {Modal, Button} from 'antd';

const FinishPathWayModal = ({onCancel, visible = false, navigateTo}) => {
  return (
    <Modal
      visible={visible}
      onCancel={onCancel}
      className='finish-path-modal'
      footer={null}
      width={600}>
      <div>
        <img src={successTick} className='icn' alt='success-icon' />
        <div className='ttl'>Congratulations!</div>
        <div className='sub'>
          Your have successfully finished your pathway!
          <br />
          <br />
          What would you like to do next?
        </div>
      </div>
      <br />
      <br />
      <div className='ant-modal-confirm-btns'>
        <Button onClick={() => navigateTo('/settings/profile')}>
          Go To My Profile
        </Button>
        <Button className='ant-btn-primary' onClick={() => navigateTo('/')}>
          Go to home page
        </Button>
      </div>
      <br />
    </Modal>
  );
};

export default FinishPathWayModal;
