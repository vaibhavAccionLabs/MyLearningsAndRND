import {useState, useEffect, useMemo} from 'react';
import {Row, Col, Button} from 'antd';
import {PDFDownloadLink} from '@react-pdf/renderer';
//PDFViewer :: Can be used for development
import {MyDocument, CourseModal, CourseMap} from 'core/components';
import {useAuth} from 'core/hooks';

import './myplan.less';

const ProgramMap = ({pathData, isDownlodable}) => {
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [isPlan, setIsPlan] = useState(false);
  const [token, user] = useAuth();

  useEffect(() => {
    if (pathData && Array.isArray(pathData.terms) && pathData.terms.length) {
      setIsPlan(true);
    } else {
      setIsPlan(false);
    }
    return () => {};
  }, [pathData]);

  const onClose = () => setSelectedCourse(null);

  const onCourseClick = course => setSelectedCourse(course);

  const renderDownload = useMemo(() => {
    return (
      pathData &&
      user &&
      isDownlodable && (
        <>
          <PDFDownloadLink
            document={
              <MyDocument data={pathData} path={pathData} user={user} />
            }
            fileName='my_course_map.pdf'>
            {({loading}) => (
              <Button className='btn btn-purple-outer mr-4'>
                {loading ? 'Loading Document...' : 'Download'}
              </Button>
            )}
          </PDFDownloadLink>

          {/* // For development use only */}
          {/* <PDFViewer width='100%' height='700vh'>
            <MyDocument data={pathData} path={pathData} user={user} />
          </PDFViewer> */}
        </>
      )
    );
  }, [isDownlodable, pathData, user]);

  return (
    <>
      <div className='myCourseMap'>
        <Row>
          <Col xs={24} sm={24} md={12} lg={12}>
            <h2>Course Sequence by Term</h2>
          </Col>
          {isPlan && (
            <Col xs={24} sm={24} md={12} lg={12} className='text-right'>
              {renderDownload}
            </Col>
          )}

          <Col xs={24} sm={24} md={24} lg={24} className='my-2'>
            <div>
              <p className='mb-1'>
                The following map displays courses that are required for the
                completion of this program.
              </p>
            </div>
            <hr />
          </Col>
        </Row>
      </div>

      {isPlan && (
        <>
          <CourseMap
            showFilters
            myPlanData={{data: pathData}}
            onClick={onCourseClick}
          />
          <CourseModal
            visible={selectedCourse ? true : false}
            onModalClose={onClose}
            data={selectedCourse}
          />
        </>
      )}
    </>
  );
};

export default ProgramMap;
