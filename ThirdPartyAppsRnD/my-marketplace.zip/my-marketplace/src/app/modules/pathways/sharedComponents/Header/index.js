import {Row, Col, Typography} from 'antd';
import {awardtype} from 'assets/images';
const {Title} = Typography;

const Header = ({pathData}) => {
  const {
    min_gpa,
    total_courses,
    award_type_name,
    institute_details,
    program_duration,
  } = pathData || {};

  return (
    <Row className='awardSection px-5'>
      <Col xs={24} sm={24} md={8} lg={8}>
        <Row className={'pb-2 pt-4'} wrap={false}>
          <Title level={5}>School&nbsp; &nbsp;</Title>
          <Title level={4} className='mt-0' ellipsis>
            {institute_details?.name || '-'}
          </Title>
        </Row>
        <Row className={'pb-3'}>
          <Title level={3} ellipsis>
            <img src={awardtype} alt='award' className='pr-2' />
            {award_type_name || '-'}
          </Title>
        </Row>
      </Col>
      <Col xs={24} sm={24} md={16} lg={16}>
        <Row>
          <Col xs={8} sm={8} md={8} lg={8} className='text-center py-4'>
            <Title level={1} className='text-center' ellipsis>
              {total_courses || '-'}
            </Title>
            <p>Courses</p>
          </Col>
          <Col
            xs={8}
            sm={8}
            md={8}
            lg={8}
            className='text-center gpa-section py-4'>
            <Title
              ellipsis
              className={`text-center ${min_gpa ? '' : 'text-grey'}`}
              title={!min_gpa ? 'No minimum GPA required' : ''}
              level={1}>
              {min_gpa || 'None'}
            </Title>
            <p>Minimum GPA</p>
          </Col>
          <Col xs={8} sm={8} md={8} lg={8} className='text-center py-4'>
            <Title level={1} className='text-center' ellipsis>
              {`${program_duration || '-'} Yr`}
            </Title>
            <p>Duration</p>
          </Col>
        </Row>
      </Col>
    </Row>
  );
};

// import React from 'react';
// import GaugeChart from 'react-gauge-chart';
// import {Button, Row, Col, Progress, Tooltip} from 'antd';
// import {InfoCircleFilled} from '@ant-design/icons';

// import {awardtype} from 'assets/images';
// import PathwayModule from 'data/pathway';

// const ROITooltipContent = () => (
//   <>
//     <h5>{PathwayModule.ROIQuestion}</h5>
//     <p>{PathwayModule.ROIDescription}</p>
//   </>
// );

// const CredentialDemandTooltipContent = () => (
//   <>
//     <h5>{PathwayModule.CredDemandQuestion}</h5>
//     <p>{PathwayModule.CredDemandDescription}</p>
//   </>
// );

// const Header = ({pathData}) => {
//   return (
//     <Row className='awardSection p-3 px-5'>
//       <Col xs={24} sm={24} md={7} lg={7}>
//         <Row>
//           <Col xs={4} sm={4} md={4} lg={4}>
//             <h5>School</h5>
//           </Col>
//           <Col xs={20} sm={20} md={20} lg={20}>
//             <h4>
//               {(pathData &&
//                 pathData.institute_details &&
//                 pathData.institute_details.name) ||
//                 '-'}
//             </h4>
//           </Col>
//         </Row>
//         <h3 className='py-1'>
//           <img src={awardtype} alt='award' className='pr-2' />
//           {(pathData && pathData.award_type_name) || '-'}
//         </h3>
//         <Row className='py-1'>
//           <Col xs={8} sm={8} md={8} lg={8} className='text-left'>
//             <h1>{(pathData && pathData.total_courses) || '-'}</h1>
//             <p>Courses</p>
//           </Col>
//           <Col xs={8} sm={8} md={8} lg={8} className='text-left'>
//             <h1>{(pathData && pathData.min_gpa) || '-'}</h1>
//             <p>Minimum GPA</p>
//           </Col>
//           <Col xs={8} sm={8} md={8} lg={8} className='text-left'>
//             <h1>{`${(pathData && pathData.program_duration) || '-'} Yr`}</h1>
//             <p>Duration</p>
//           </Col>
//         </Row>
//       </Col>
//       <Col xs={24} sm={24} md={10} lg={10}>
//         <div className='text-center pb-4'>
//           <h5 className='d-inline-block'>{PathwayModule.ROI}</h5>
//           <span>
//             <Tooltip placement='bottomRight' title={ROITooltipContent}>
//               <Button>
//                 <InfoCircleFilled />
//               </Button>
//             </Tooltip>
//           </span>
//         </div>
//         <Row className='returnInvest'>
//           <Col xs={24} sm={24} md={12} lg={12} className='pb-2'>
//             <Row style={{textAlign: 'center'}}>
//               <Col xs={8} sm={8} md={12} lg={12} className='text-right'>
//                 <Progress
//                   type='circle'
//                   percent={0}
//                   width={80}
//                   strokeColor='#fed878'
//                   strokeWidth={8}
//                 />
//               </Col>
//               <Col xs={14} sm={14} md={12} lg={12}>
//                 <p>Students Graduated</p>
//               </Col>
//             </Row>
//           </Col>
//           <Col xs={24} sm={24} md={12} lg={12} className='pb-2'>
//             <Row style={{textAlign: 'center'}}>
//               <Col xs={8} sm={8} md={12} lg={12} className='text-right'>
//                 <Progress
//                   type='circle'
//                   percent={0}
//                   width={80}
//                   strokeColor='#6dad5f'
//                   strokeWidth={8}
//                 />
//               </Col>
//               <Col xs={14} sm={14} md={12} lg={12}>
//                 <p>Students Get Job/Training</p>
//               </Col>
//             </Row>
//           </Col>
//         </Row>
//       </Col>
//       <Col xs={24} sm={24} md={7} lg={7}>
//         <div style={{textAlign: 'center', paddingBottom: '8px'}}>
//           <h5 className='d-inline-block'>{PathwayModule.CredDemand}</h5>
//           <span>
//             <Tooltip
//               placement='bottomRight'
//               title={CredentialDemandTooltipContent}>
//               <Button>
//                 <InfoCircleFilled />
//               </Button>
//             </Tooltip>
//           </span>
//         </div>
//         <Row>
//           <Col xs={24} sm={24} md={15} lg={15}>
//             <GaugeChart
//               id='gauge-chart1'
//               percent={0.5}
//               arcPadding={0}
//               cornerRadius={0}
//               arcsLength={[0.25, 0.25, 0.25, 0.25]}
//               colors={['#dc2828', '#feca57', '#62d9b7', '#11bc0e']}
//             />
//             <div className='text-center font-family-bold'>Good!</div>
//           </Col>
//           <Col xs={24} sm={24} md={9} lg={9}>
//             <Row className='credentialDemand'>
//               <Col xs={12} sm={12} md={12} lg={12} className='pb-2'>
//                 <h5 className='poor'>Poor</h5>
//               </Col>
//               <Col xs={12} sm={12} md={12} lg={12} className='pb-2'>
//                 <h5 className='fair'>Fair</h5>
//               </Col>
//               <Col xs={12} sm={12} md={12} lg={12}>
//                 <h5 className='good'>Good</h5>
//               </Col>
//               <Col xs={12} sm={12} md={12} lg={12}>
//                 <h5 className='excellent'>Excellent</h5>
//               </Col>
//             </Row>
//           </Col>
//         </Row>
//       </Col>
//     </Row>
//   );
// };

export default Header;
