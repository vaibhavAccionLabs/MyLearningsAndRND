import React from 'react';
import {Col, Modal, Row} from 'antd';
import ProfileIcon from './profileIcon';
import './style.less';

const OnBoardType = ({
  data,
  visible,
  toggleOnboardType,
  onSelectOnboardType,
}) => {
  const {data: onboardData} = data || {};
  return (
    <Modal
      visible={visible}
      footer={null}
      title={null}
      onCancel={() => toggleOnboardType(false)}
      className={'onboard-type-modal'}>
      <div className='onboard-type-c'>
        <div className='o-t-ttl'>
          Please select the student type that best describes you:
        </div>
        <br />
        <Row className='o-t-cards' gutter={41}>
          {Array.isArray(onboardData) &&
            onboardData.map(itm => (
              <Col key={itm} xs={24} sm={8} key={itm.uuid}>
                <div
                  className='o-t-itm-wrap'
                  onClick={() => onSelectOnboardType(itm)}>
                  <div className='o-t-itm'>
                    <div className='o-t-itm-title-wrap'>
                      <div className='o-t-itm-title'>
                        {/* <div
                          className='o-t-itm-dot'
                          style={{backgroundColor: itm.color}}
                        /> */}
                        <ProfileIcon fill={itm.color} />
                        <div
                          className='o-t-itm-text'
                          style={{color: itm.color}}>
                          {itm?.OnboardingType?.name}
                        </div>
                      </div>
                    </div>
                    <div className='o-t-itm-desc'>
                      {itm?.OnboardingType?.description}
                    </div>
                  </div>
                </div>
              </Col>
            ))}
        </Row>
      </div>
    </Modal>
  );
};

export default OnBoardType;
