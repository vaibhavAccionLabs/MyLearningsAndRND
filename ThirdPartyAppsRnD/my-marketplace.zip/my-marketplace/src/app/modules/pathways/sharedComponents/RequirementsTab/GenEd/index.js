import {RequestErrorLoader} from 'core/components';

import SegmentTable from '../SegmentTable';

const GenEd = props => {
  const {myPlanData, genEdOptions, columns, pathData} = props;

  return (
    <RequestErrorLoader
      body={{request: myPlanData.request || genEdOptions.request}}>
      {myPlanData.data && pathData.ge_path_details && (
        <SegmentTable
          data={pathData.ge_path_details}
          columns={columns}
          defaultOpen={true}
        />
      )}
    </RequestErrorLoader>
  );
};

export default GenEd;
