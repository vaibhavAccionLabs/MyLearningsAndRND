import React, {Fragment} from 'react';
import {Table, Space} from 'antd';

import {CustomCollapse} from 'core/components';
import {diplayRules, prepareCourseTableData} from 'core/utils';

function SegmentTable({data, columns, isOnlySegmentGrp, defaultOpen = false}) {
  const displayPanel = (mapData, isOnlySegment) => {
    return (
      <Space direction='vertical' className='accAdditionalCourse'>
        {mapData &&
          Array.isArray(mapData) &&
          mapData.length &&
          mapData.map((item, index) => {
            const {segment_name, segment_group_name, title, segments} = item;
            const data = prepareCourseTableData(item, 'courses');
            return (
              <CustomCollapse
                defaultOpen={defaultOpen}
                key={`segment-${index}`}
                header={segment_name || title || segment_group_name}>
                <div className='py-1'>
                  {diplayRules(isOnlySegment, item)}
                  {(segments &&
                    Array.isArray(segments) &&
                    segments.length &&
                    segments.map((segment, sIdx) => {
                      const {title, segment_name: name} = segment;
                      const data = prepareCourseTableData(segment, 'courses');
                      return (
                        <Fragment key={`segment-group-${sIdx}`}>
                          <h3 className='seg-group-title pl-3 py-3 mb-0'>
                            {title || name}
                          </h3>
                          <Table
                            className='segment-course-table'
                            columns={columns}
                            dataSource={data}
                            pagination={false}
                          />
                        </Fragment>
                      );
                    })) || (
                    <Table
                      className='segment-course-table'
                      columns={columns}
                      dataSource={data}
                      pagination={false}
                    />
                  )}
                </div>
              </CustomCollapse>
            );
          })}
      </Space>
    );
  };

  const renderPanels = () => {
    if (Array.isArray(data) && data.length > 0 && !isOnlySegmentGrp) {
      return displayPanel(data, true);
    } else if (Array.isArray(data) && data.length > 0 && isOnlySegmentGrp) {
      return displayPanel(data, false);
    } else if (data && data.segments && data.segment_groups) {
      // make one Array of segments and segment groups
      const newData = [...data.segments, ...data.segment_groups];
      return displayPanel(newData, false);
    }
  };

  return <>{data && renderPanels()}</>;
}

export default SegmentTable;
