import {useState, useEffect, useMemo} from 'react';
import {connect} from 'react-redux';
import {useParams, useHistory} from 'react-router-dom';
import {Steps, message, Modal} from 'antd';

import {
  fetchPathDetails,
  fetchActivePaths,
  fetchStudentOnboard,
  fetchMyPlan,
  fetchRecommendedPlan,
  fetchGenEdOptions,
  fetchOnboardTypes,
  fetchOccupations,
  fetchAllOccupations,
  clearOccupations,
  clearAllOccupations,
  getPathDetails,
  getStudentOnboard,
  getOnboardSteps,
  onboardTypeSelector,
  getOccupations,
  isPathLoading,
  clearPathDetails,
  clearOnboardTypes,
  clearStudentOnboard,
  clearMyPlan,
  clearGenEdOptions,
  clearRecommendedPlan,
  savePath,
  savedPathSelector,
  fetchSavedPaths,
  removeSavedPath,
  getPathwayOpportunities,
  fetchPathwayOpportunities,
  resetPathwayOpportunities,
  deleteActivePath,
  getActivePath,
} from 'redux/modules/pathways';
import {
  fetchAwardTypes,
  awardTypesSelector,
  skillsSelector,
  fetchSkills,
} from 'redux/modules/profile';
import {
  fetchLocalJobs,
  fetchJobBoards,
  fetchPublicInsightJobs,
  getLocalJobs,
  getJobBoards,
  getPublicInsightJobs,
  clearLocalJobs,
  clearJobBoards,
  clearPublicInsightJobs,
} from 'redux/modules/jobs';
import {
  getJobZoneDetails,
  getOccupationRoles,
  saveOccupationRates,
  fetchOccupationRoles,
  fetchJobZoneDetails,
  getOccupationDetails,
  fetchOccupationDetails,
  clearOccupationDetails,
  subscribeForOccupation,
  getSubscribedOccupation,
  unSubscribeForOccupation,
  fetchSubscribedOccupation,
  resetSubscribedOccupation,
} from 'redux/modules/occupation';
import {
  fetchPrograms,
  getPrograms,
  clearPrograms,
  getComparedPrograms,
  clearComparePrograms,
  fetchComparePrograms,
} from 'redux/modules/programs';
import {getAppConfig} from 'redux/modules/general';
import {openLoginScreen} from 'redux/modules/auth';

import {API} from 'config';
import {Services} from 'core/Services';
import {useAuth, useComparePaths} from 'core/hooks';
import {
  Header,
  AppBreadcrumb,
  ComparePaths,
  RequestErrorLoader,
} from 'core/components';

//Local Containers
import {ExplorePath, PlanYourPath, OnBoard, Workforce} from './containers';
// Local Components
import {OnBoardType, FinishPathWayModal} from './sharedComponents';

import './explore.less';

const {Step} = Steps;
const services = new Services();
const {error, success} = message;

const PathWayNavigator = props => {
  const {
    pathData,
    isPathLoading,
    fetchPathDetails,
    clearPathDetails,
    openLoginScreen,
    fetchOnboardTypes,
    onboardTypes,
    fetchStudentOnboard,
    clearStudentOnboard,
    studentOnboard,
    fetchAwardTypes,
    // awardTypes,
    fetchSkills,
    skills,
    fetchSavedPaths,
    savePath,
    savedPath,
    removeSavedPath,
    deleteActivePath,
    activePaths,
    fetchComparePrograms,
    clearComparePrograms,
    appConfig: {isMobileView},
  } = props;

  const [currentStep, setCurrentStep] = useState(0);
  const {collegeName, pathName, awardType, programUuid} = useParams();
  const [onboardType, setOnboardType] = useState(false);
  const [loading, setLoading] = useState(false);
  const [finishPathwayModal, setFinishPathwayModal] = useState(false);
  const history = useHistory();
  const [token, user] = useAuth();
  const {onCompareClick, comparePathsList} = useComparePaths(pathData);

  const saveStep = (step, uuid) => {
    const {data: studentOnboardData} = studentOnboard || {};
    const {student_onboard_uuid} = studentOnboardData || {};
    const completed = getCompletedStepIndex();
    if (step <= completed) return;
    const body = {
      completed_stage: navigatorSteps[step - 1].key,
    };
    return services
      .createUpdateRecord(
        token,
        `${API.gps.student_onboard}/${student_onboard_uuid || uuid}`,
        body,
        'PATCH',
      )
      .then(res => {
        fetchStudentOnboard(pathData);
        if (res && res.completed_stage === 'career')
          setFinishPathwayModal(true);
      });
  };
  const onStepChange = step => {
    if (step > 0) {
      if (!token || !studentOnboard.data) {
        return;
      }
      if (!isCurentPathisActive()) {
        return;
      }
    }
    setCurrentStep(step);
    saveStep(step);
  };

  const onboardSteps = getOnboardSteps({studentOnboard, onboardTypes});

  const isCurentPathisActive = useMemo(
    () => () => {
      const {data} = studentOnboard || {};
      const {uuid} = pathData || {};
      if (data && uuid) {
        if (data.path_uuid === uuid) {
          return true;
        }
      }
      return false;
    },
    [pathData, studentOnboard],
  );

  const handleExistStudentOnboard = studentOnboardData => {
    if (
      pathData &&
      pathData.uuid &&
      studentOnboardData.path_uuid === pathData.uuid
    ) {
      initStepIndex();
    } else {
      openActiveProgramStatus(studentOnboardData);
    }
  };

  const onStartPathwayClick = () => {
    if (studentOnboard.data) {
      handleExistStudentOnboard(studentOnboard.data);
      return;
    }
    if (token) {
      toggleOnboardType(true);
    } else {
      openLoginScreen({
        callback: async () => {
          const data = await fetchStudentOnboard(pathData);
          if (data[0]) {
            handleExistStudentOnboard(data[0]);
            return;
          }
          toggleOnboardType(true);
        },
      });
    }
  };
  const openActiveProgramStatus = studentOnboardData => {
    const {path_details} = studentOnboardData || {};
    let url = `/pathway/${
      path_details.institute_details &&
      encodeURIComponent(path_details.institute_details.name)
    }/${encodeURIComponent(path_details.title)}/${encodeURIComponent(
      path_details.award_type_name,
    )}/${path_details.program_id || path_details.program}`;
    Modal.warning({
      title: 'Active Program Found',
      centered: true,
      width: 800,
      className: 'modal-msg',
      content: (
        <div>
          You are already started a pathway{' '}
          <a
            style={{
              textDecoration: 'underline',
              color: '#3bc4ff',
              fontWeight: 'bold',
            }}
            href={url}
            target='_blank'>
            {path_details && path_details.title}.
          </a>{' '}
          At this time you can start only one path.
        </div>
      ),
    });
  };

  const onSelectOnboardType = onboardType => {
    const {institute_details: {institution_id} = {}} = pathData || {};
    const data = {
      path_uuid: pathData?.uuid,
      onboarding_type: onboardType?.OnboardingType?.uuid,
      completed_step_uuid: [],
      completed_task_uuid: [],
      institute_uuid: institution_id,
    };
    setOnboardType(false);
    setLoading(true);
    services
      .createUpdateRecord(token, API.gps.student_onboard, data, 'POST')
      .then(res => {
        setLoading(false);
        setCurrentStep(1);
        saveStep(1, res.student_onboard_uuid);
        fetchStudentOnboard(pathData);
      })
      .catch(err => {
        setLoading(false);
        error('Error in starting the pathway');
      });
  };

  const goToPlan = () => onStepChange(2);

  const toggleOnboardType = status => setOnboardType(status);

  const initializeDataForLoginUser = async () => {
    // this function calls the  aps'is that are required only if user logged in (onboard, plan, workforce)
    const {institute_details} = pathData || {};
    if (skills && !skills.data) fetchSkills();
    fetchAwardTypes();
    fetchSavedPaths();
    await fetchOnboardTypes(institute_details);
    await fetchStudentOnboard(pathData); //pathdata is required since if the current path and active onboard path is same then only getStudentOnboard selector gives the data
  };

  useEffect(() => {
    (async function () {
      await fetchPathDetails(
        decodeURIComponent(collegeName),
        decodeURIComponent(pathName),
        decodeURIComponent(awardType),
        programUuid,
      );
    })();
    return () => {
      clearPathDetails();
      clearOnboardTypes();
      clearStudentOnboard();
      clearComparePrograms();
    };
  }, [collegeName, pathName, awardType, programUuid]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    // initializeDataForLoginUser();
    if (pathData) {
      if (token) {
        initializeDataForLoginUser();
      }
      pathData?.uuid && fetchComparePrograms(pathData.uuid);
    }
    if (!token) {
      setCurrentStep(0);
    }
  }, [pathData, token]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSavePath = async savedPathData => {
    const {uuid, institute_details: {institution_id} = {}} = pathData || {};
    const {data} = savedPathData || savedPath || {};
    const exists =
      data && Array.isArray(data) && data.filter(i => i.path_uuid === uuid);
    if (exists && exists.length > 0) {
      Modal.warning({
        title: 'Already Saved',
        centered: true,
        width: 800,
        icon: null,
        className: 'modal-msg',
        content: 'You already saved this path',
      });
      return;
    }
    if (uuid) {
      await savePath(uuid, institution_id, res => {
        if (res && res.save_path_uuid) {
          success('Path successfully saved to profile');
        }
      });
      fetchSavedPaths();
    }
  };
  const onSavePathClick = () => {
    if (token) {
      handleSavePath();
    } else {
      openLoginScreen({
        callback: async () => {
          const {data} = savePath || {};
          if (!data)
            fetchSavedPaths(data => {
              handleSavePath({data});
            });
          else handleSavePath();
        },
      });
    }
  };

  const onRemoveSavedPath = async () => {
    const {uuid} = pathData || {};
    if (uuid) {
      await removeSavedPath(uuid);
      fetchSavedPaths();
    }
  };

  const navigateTo = link => history.push(link);

  const goToNextStep = () => onStepChange(currentStep + 1);

  const finishPathway = () => saveStep(currentStep + 1);

  const onCancelOnboard = () => {
    clearStudentOnboard();
    onStepChange(0);
  };

  const goBackToOnboardTypeSelect = () => {
    clearStudentOnboard();
    onStepChange(0);
    toggleOnboardType(true);
  };

  const navigatorSteps = [
    {
      title: 'Explore Paths',
      key: 'explore_paths',
      children: (
        <ExplorePath
          {...props}
          pathData={pathData}
          savedPath={savedPath}
          onSavePathClick={onSavePathClick}
          studentOnboard={studentOnboard}
          isCurentPathisActive={isCurentPathisActive}
          removeSavedPath={onRemoveSavedPath}
          onCompareClick={onCompareClick}
          onStartPathwayClick={onStartPathwayClick}
        />
      ),
    },
    {
      title: 'Onboard',
      key: 'onboard',
      children: (
        <OnBoard
          onboardSteps={onboardSteps}
          goBackToOnboardTypeSelect={goBackToOnboardTypeSelect}
          studentOnboard={studentOnboard}
          fetchStudentOnboard={fetchStudentOnboard}
          token={token}
          deleteActivePath={deleteActivePath}
          pathData={pathData}
          onStepChange={onStepChange}
          goToPlan={goToPlan}
          onCancelOnboard={onCancelOnboard}
        />
      ),
    },
    {
      title: pathData?.program_map ? 'Program Map' : 'Plan Your Path',
      key: 'plan_your_path',
      children: <PlanYourPath {...props} goToNextStep={goToNextStep} />,
    },
    {
      title: 'Career Discovery',
      key: 'career',
      children: <Workforce {...props} finishPathway={finishPathway} />,
    },
  ];

  const breadcrumbList = [
    {
      name: 'Search',
      path: '/search',
    },
    {name: 'Pathway Navigator'},
    isMobileView && {name: navigatorSteps[currentStep]?.title},
  ];

  const getCompletedStepIndex = () => {
    if (
      studentOnboard &&
      studentOnboard.data &&
      studentOnboard.data.completed_stage &&
      pathData &&
      pathData.uuid &&
      studentOnboard.data.path_uuid === pathData.uuid
    ) {
      const idx =
        navigatorSteps
          .map(i => i.key)
          .indexOf(studentOnboard.data.completed_stage) + 1;
      // return idx >= navigatorSteps.length ? navigatorSteps.length : idx; // desabled for hiding the rest steps
      return idx > 0 ? 1 : 0;
    } else {
      return 0;
    }
  };
  const initStepIndex = () => {
    if (
      studentOnboard &&
      studentOnboard.data &&
      studentOnboard.data.completed_stage === null
    )
      return;
    const index = getCompletedStepIndex();
    setCurrentStep(index === navigatorSteps.length ? index - 1 : index);
  };
  const completedStep = getCompletedStepIndex();
  useEffect(() => {
    if (currentStep === 0) initStepIndex();
  }, [studentOnboard]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <RequestErrorLoader
      body={{
        request:
          isPathLoading ||
          loading ||
          onboardTypes.request ||
          activePaths.request ||
          studentOnboard.request,
      }}>
      {/* <Header>
        <h1>Pathway Navigator</h1>
        <Steps
          current={currentStep}
          className='navigator-steps'
          onChange={onStepChange}
          labelPlacement='vertical'>
          {navigatorSteps.map(({title}, idx) => (
            <Step
              key={idx}
              title={title}
              status={completedStep > idx ? 'finish' : 'wait'}
            />
          ))}
        </Steps>
      </Header> */}

      <AppBreadcrumb dataList={breadcrumbList} />

      {navigatorSteps?.[currentStep]?.children}

      {comparePathsList?.length > 0 && <ComparePaths />}

      <OnBoardType
        data={onboardTypes}
        visible={onboardType}
        onSelectOnboardType={onSelectOnboardType}
        toggleOnboardType={toggleOnboardType}
      />
      <FinishPathWayModal
        onCancel={() => setFinishPathwayModal(false)}
        navigateTo={navigateTo}
        visible={finishPathwayModal}
      />
    </RequestErrorLoader>
  );
};

// REDUX CONNECTION
const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  pathData: getPathDetails(state),
  isPathLoading: isPathLoading(state),
  onboardTypes: onboardTypeSelector(state),
  studentOnboard: getStudentOnboard(state),
  occupations: getOccupations(state),
  awardTypes: awardTypesSelector(state),
  skills: skillsSelector(state),
  savedPath: savedPathSelector(state),
  pathwayOpportunities: getPathwayOpportunities(state),
  activePaths: getActivePath(state),
  programs: getPrograms(state),
  localJobs: getLocalJobs(state),
  jobBoards: getJobBoards(state),
  publicInsightJobs: getPublicInsightJobs(state),
  jobZoneDetails: getJobZoneDetails(state),
  occupationRoles: getOccupationRoles(state),
  comparedPrograms: getComparedPrograms(state),
  occupationDetails: getOccupationDetails(state),
  subscribedOccupation: getSubscribedOccupation(state),
});

export default connect(mapStateToProps, {
  fetchPathDetails,
  fetchActivePaths,
  fetchOnboardTypes,
  fetchStudentOnboard,
  fetchMyPlan,
  fetchRecommendedPlan,
  fetchGenEdOptions,
  fetchOccupations,
  fetchAllOccupations,
  openLoginScreen,
  clearOccupations,
  clearAllOccupations,
  clearPathDetails,
  clearOnboardTypes,
  clearStudentOnboard,
  fetchAwardTypes,
  fetchSkills,
  fetchSavedPaths,
  savePath,
  removeSavedPath,
  clearMyPlan,
  clearGenEdOptions,
  clearRecommendedPlan,
  fetchPathwayOpportunities,
  resetPathwayOpportunities,
  deleteActivePath,
  fetchPrograms,
  fetchLocalJobs,
  fetchJobBoards,
  fetchPublicInsightJobs,
  clearPrograms,
  clearLocalJobs,
  clearJobBoards,
  clearPublicInsightJobs,
  saveOccupationRates,
  fetchOccupationRoles,
  fetchJobZoneDetails,
  fetchOccupationDetails,
  clearOccupationDetails,
  subscribeForOccupation,
  unSubscribeForOccupation,
  fetchSubscribedOccupation,
  resetSubscribedOccupation,
  clearComparePrograms,
  fetchComparePrograms,
})(PathWayNavigator);
