import React, {Component} from 'react';
import {Row, Col, Button} from 'antd';
import {PlusCircleOutlined} from '@ant-design/icons';

import update from 'immutability-helper';

import {newSortArrayOfObjPropertyBased, checkCourseAdded} from 'core/utils';
import {AllCourseList, CustomTabSwitch, CourseModal} from 'core/components';

import CoreCourses from './CoreCourses';
import AdditionalCoreCourses from './AdditionalCoreCourses';
import GenEdReQuirements from './GenEdReQuirements';
import TermsContainer from './TermsContainer';
import RecommendedPlan from './RecommendedPlan';
import AddTerm from './AddTerm';
import Demographics from './Demographics';

import './style.less';

const dataTabs = [
  {
    key: 'my_plan',
    value: 'MY PLAN',
  },
  {
    key: 'recommended_plan',
    value: 'RECOMMENDED PLAN',
  },
];

class CreateMyPlan extends Component {
  state = {
    terms: [],
    addTermVisible: false,
    editTermIndex: -1,
    isAnyChange: false,
    activeTab: 'my_plan',
    courseVisible: false,
    selectedCourse: null,
  };

  componentDidMount() {
    const {initialData} = this.props;
    this.initEditData(initialData);
  }

  componentDidUpdate(prevProps, prevState) {
    const {initialData} = this.props;
    if (prevProps.initialData !== initialData) {
      this.initEditData(initialData);
    }
  }

  initEditData = data => {
    let terms = [];
    data &&
      data.length > 0 &&
      data.forEach(d => {
        const term = {
          term_name: d.term_name,
          data: [...d.courses],
        };
        terms.push(term);
      });
    this.setState({terms});
  };

  onDrop = (term, index, data) => {
    const {termIndex, itemIndex} = data;
    if (termIndex === index) return;

    let updatedData = [{...data.data}];
    if (data.itemType !== 'terms-item-course-type') {
      updatedData = [{...updatedData[0], itemType: data.itemType}];
    }

    this.setState(
      update(this.state, {
        terms: {
          [index]: {
            data: {
              $push: updatedData,
            },
          },
        },
        isAnyChange: {$set: true},
      }),
      () => {
        if (
          data.type === 'TERMS_ITEM' &&
          termIndex !== undefined &&
          itemIndex !== undefined
        ) {
          this.setState(
            update(this.state, {
              terms: {
                [termIndex]: {
                  data: {
                    $splice: [[itemIndex, 1]],
                  },
                },
              },
              isAnyChange: {$set: true},
            }),
          );
        }
      },
    );
  };

  addTerm = values => {
    const {editTermIndex} = this.state;
    if (editTermIndex > -1) {
      this.setState(
        update(this.state, {
          terms: {
            [editTermIndex]: {
              term_name: {
                $set: values.term_name,
              },
            },
          },
          editTermIndex: {
            $set: -1,
          },
          addTermVisible: {
            $set: false,
          },
          isAnyChange: {
            $set: true,
          },
        }),
      );
      return;
    }

    const term = {
      term_name: values.term_name,
      data: [],
    };
    const updatedTerms = [...this.state.terms, term];
    this.setState({
      terms: updatedTerms,
      addTermVisible: false,
      isAnyChange: true,
    });
  };

  onTermEdit = index => {
    this.setState({
      editTermIndex: index,
      addTermVisible: true,
    });
  };

  onTermDelete = index => {
    this.setState(
      update(this.state, {
        terms: {
          $splice: [[index, 1]],
        },
        isAnyChange: {$set: true},
      }),
    );
  };

  checkCourseAdded = course => {
    const {terms} = this.state;
    return checkCourseAdded(course, terms);
  };

  checkSegmentsAdded = segment => {
    const {terms} = this.state;
    for (let i = 0; i < terms.length; i++) {
      const t = terms[i];
      const {data} = t;
      const exists = data.filter(d => {
        return d.segment_alter_name
          ? d.segment_alter_name === segment.segment_alter_name
          : d.segment_name === segment.segment_name;
      })[0];
      if (exists) return true;
    }
    return false;
  };

  onDeleteCourse = (termIndex, itemIndex) => {
    if (termIndex !== undefined && itemIndex !== undefined) {
      this.setState(
        update(this.state, {
          terms: {
            [termIndex]: {
              data: {
                $splice: [[itemIndex, 1]],
              },
            },
          },
          isAnyChange: {$set: true},
        }),
      );
    }
  };

  formatSegmentsData = segments => {
    const data = [];
    segments &&
      segments.forEach(s => {
        if (
          s.rule_type === 'Choose number of course(s)' &&
          s.number_of_required_course > 0
        ) {
          for (let i = 0; i < s.number_of_required_course; i++) {
            const obj = Object.assign({}, s);
            obj['segment_name'] =
              s.number_of_required_course == 1
                ? s.segment_name
                : `${s.segment_name}  (${i + 1})`;
            data.push(obj);
          }
        } else if (
          s.rule_type === 'Complete number of unit(s)' &&
          s.number_of_required_course > 0
        ) {
          let total_units = 0;
          let course_require = 0;
          if (s.courses && s.courses.length) {
            const sortedCourses = newSortArrayOfObjPropertyBased(
              s.courses,
              'units',
              'descending',
            );
            sortedCourses.forEach(course => {
              if (total_units < s.number_of_required_course) {
                total_units += parseFloat(course.units);
                course_require += 1;
              }
            });
          }
          for (let i = 0; i < course_require; i++) {
            const obj = Object.assign({}, s);
            obj['segment_name'] =
              course_require === 1
                ? s.segment_name
                : `${s.segment_name}  (${i + 1})`;
            data.push(obj);
          }
        } else {
          data.push(s);
        }
      });
    return data;
  };

  onSubmitMyPlan = () => {
    const {onSubmit} = this.props;
    const {terms} = this.state;
    const data = [];
    terms.forEach((term, termIndex) => {
      let Obj = {
        term_name: term.term_name || `Term ${termIndex + 1}`,
        courses: {},
      };
      term.data.forEach(course => {
        Obj.courses[course.uuid] = course.itemType || course.course_type;
      });
      data.push(Obj);
    });
    onSubmit(data);
  };

  onTabChange = tab =>
    this.setState({
      activeTab: tab,
    });

  onSelectDeselectCourse = course => {
    this.setState({
      selectedCourse: course || null,
      courseVisible: course ? true : false,
    });
  };

  toggleAddTermModal = () => {
    this.setState({
      addTermVisible: !this.state.addTermVisible,
      editTermIndex: -1,
    });
  };

  render() {
    const {
      terms,
      isAnyChange,
      addTermVisible,
      activeTab,
      courseVisible,
      selectedCourse,
      editTermIndex,
    } = this.state;
    const {
      requirementsData: {Data, pathwayPlanner} = {},
      isSaving,
    } = this.props;

    const {segment: segments = [], segment_groups = []} = Data || {};
    let disable = true;
    if (isAnyChange && terms.length) {
      disable = false;
    }

    return (
      <>
        <Demographics terms={terms} path={Data} genEdData={pathwayPlanner} />
        <div className='recommended-plan'>
          <Row type='flex' className='recommended-plan-layout'>
            <Col xs={24} sm={16} md={24} lg={16} className='require-block'>
              <div className='panel-header'>Requirements</div>
              <div className='panel-content'>
                <Row gutter={36}>
                  <Col xs={24} sm={12}>
                    <div className='card-layout-col'>
                      {segments && segments.length > 0 && (
                        <CoreCourses
                          data={Data}
                          terms={terms}
                          checkCourseAdded={this.checkCourseAdded}
                          onSelect={this.onSelectDeselectCourse}
                        />
                      )}
                      {segment_groups && segment_groups.length > 0 && (
                        <AdditionalCoreCourses
                          data={Data}
                          terms={terms}
                          checkCourseAdded={this.checkCourseAdded}
                          onSelect={this.onSelectDeselectCourse}
                        />
                      )}
                      <AllCourseList
                        displayListItem
                        config={{
                          terms,
                          itemType: 'elective',
                          checkIfAddedToTerm: this.checkCourseAdded,
                        }}
                        itemHeight={35}
                        title='Electives'
                        onSelect={this.onSelectDeselectCourse}
                      />
                    </div>
                  </Col>
                  {Data?.general_education_option && pathwayPlanner && (
                    <Col xs={24} sm={12}>
                      <GenEdReQuirements
                        terms={terms}
                        checkCourseAdded={this.checkCourseAdded}
                        data={{gen_ed: pathwayPlanner}}
                        onSelect={this.onSelectDeselectCourse}
                      />
                    </Col>
                  )}
                </Row>
              </div>
            </Col>
            <Col xs={24} sm={8} md={24} lg={8} className='plan-block'>
              <div className='panel-header'>
                <CustomTabSwitch
                  dataTabs={dataTabs}
                  currentTab={activeTab}
                  onChange={this.onTabChange}
                />
              </div>

              {activeTab === 'my_plan' ? (
                <>
                  <div className='panel-content'>
                    <div className='card-layout'>
                      <div className='card-header'>
                        <span>Terms ({(terms && terms.length) || 0})</span>
                        <PlusCircleOutlined onClick={this.toggleAddTermModal} />
                      </div>
                      <div className='card-content'>
                        <TermsContainer
                          onTermDelete={this.onTermDelete}
                          onTermEdit={this.onTermEdit}
                          addTerm={this.toggleAddTermModal}
                          onDrop={this.onDrop}
                          terms={terms}
                          onDeleteCourse={this.onDeleteCourse}
                          onSelect={this.onSelectDeselectCourse}
                          cautionDisplay
                        />
                      </div>
                    </div>
                  </div>
                  <div className='action'>
                    <Button
                      className='btn btn-pink'
                      onClick={this.onSubmitMyPlan}
                      disabled={disable}
                      loading={isSaving}>
                      Save
                    </Button>
                  </div>
                </>
              ) : (
                <RecommendedPlan
                  {...this.props}
                  isReadonly
                  onSelect={this.onSelectDeselectCourse}
                />
              )}
            </Col>
          </Row>
        </div>

        <AddTerm
          visible={addTermVisible}
          onClose={this.toggleAddTermModal}
          onAddTerm={this.addTerm}
          availableTerms={terms}
          initialValue={editTermIndex > -1 ? terms[editTermIndex] : null}
          editMode={editTermIndex > -1}
        />

        <CourseModal
          data={selectedCourse}
          visible={courseVisible}
          onModalClose={this.onSelectDeselectCourse}
        />
      </>
    );
  }
}

export default CreateMyPlan;
