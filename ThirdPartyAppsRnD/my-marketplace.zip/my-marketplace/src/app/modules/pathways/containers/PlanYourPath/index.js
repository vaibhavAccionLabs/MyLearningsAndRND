import {useState, useEffect} from 'react';
import {Row, Col} from 'antd';
import {useMyPlan, useGenEdOptions} from 'core/hooks';

import {CustomTabs} from 'core/components';
import {PathwayPlanner, MyCourseMap} from './components';
import {
  Banner,
  RequirementsTab,
  //AwardCard,
  ProgramMap,
} from '../../sharedComponents';

const PlanYourPath = props => {
  const {
    pathData,
    fetchMyPlan,
    fetchGenEdOptions,
    clearMyPlan,
    clearGenEdOptions,
    clearRecommendedPlan,
  } = props;
  const [activeTab, setActiveTab] = useState('requirements');
  const myPlan = useMyPlan();
  const genEdOptions = useGenEdOptions();

  useEffect(() => {
    (async function () {
      if (!pathData?.program_map) {
        await fetchGenEdOptions();
        await fetchMyPlan();
      }
    })();
    return () => {
      clearMyPlan();
      clearGenEdOptions();
      clearRecommendedPlan();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const onTabChange = key => setActiveTab(key);

  const tabs = pathData?.program_map
    ? [
        {
          title: 'PROGRAM MAP',
          key: 'requirements',
          children: <ProgramMap {...props} isDownlodable />,
        },
      ]
    : [
        {
          title: 'REQUIREMENTS',
          key: 'requirements',
          children: (
            <RequirementsTab
              {...props}
              myPlanData={myPlan}
              genEdOptions={genEdOptions}
            />
          ),
        },
        {
          title: 'PATHWAY PLANNER',
          key: 'pathway_planner',
          children: <PathwayPlanner {...props} onTabChange={onTabChange} />,
        },
        {
          title: 'MY COURSE MAP',
          key: 'my_course_map',
          children: (
            <MyCourseMap
              {...props}
              myPlanData={myPlan}
              onTabChange={onTabChange}
            />
          ),
        },
      ];

  return (
    <>
      <Banner {...props} isNextStep />
      <div className='pathways-tabs contentContainer pt-3 pb-4'>
        <Row className='d-flex'>
          <Col xs={24} sm={24} md={24} lg={24} className='px-3'>
            <CustomTabs
              onChange={onTabChange}
              activeKey={activeTab}
              tabsList={tabs}
            />
          </Col>
          {/* <Col xs={24} sm={24} md={24} lg={6} className='pathcard-info'>
            <AwardCard {...props} />
          </Col> */}
        </Row>
      </div>
    </>
  );
};

export default PlanYourPath;
