import React, {useState, useEffect} from 'react';
import {Collapse, Button} from 'antd';
import {DeleteOutlined, EditOutlined} from '@ant-design/icons';
import TermDrop from './TermDrop';

const {Panel} = Collapse;

const TermsContainer = ({
  isReadonly,
  terms,
  addTerm,
  onDrop,
  onTermDelete,
  onTermEdit,
  onDeleteCourse,
  onSelect,
  cautionDisplay,
}) => {
  const [activeKey, setActiveKey] = useState([]);
  useEffect(() => {
    // default open on edit mode...
    let ACTIVE_KEYS = [];
    if (terms && terms.length > 0) {
      for (let i = 0; i < terms.length; i++) {
        ACTIVE_KEYS.push(i.toString());
      }
      switchPanel([...ACTIVE_KEYS, (terms.length - 1).toString()]);
    }
  }, [terms && terms.length]); // eslint-disable-line react-hooks/exhaustive-deps

  const switchPanel = key => setActiveKey(key);

  const renderHeader = (term, index) => {
    let totalUnits = 0;
    if (term && term.data && term.data.length > 0) {
      term.data.forEach(course => {
        if (course && course.units && course.units !== 'None') {
          totalUnits += parseFloat(course.units);
        }
      });
    }
    return (
      <div className='term-list-panel-header'>
        <span className='term-header' style={{paddingLeft: '10px'}}>
          {`Term ${index + 1} - ${
            term.term_name
              ? `${term.term_name + ' (' + totalUnits + ' Units)'}`
              : `${totalUnits} Units`
          }`}
        </span>
        {!isReadonly && (
          <div className='actions'>
            <EditOutlined
              onClick={e => {
                e.preventDefault();
                e.stopPropagation();
                onTermEdit(index);
              }}
            />
            {term && (!term.data || term.data.length === 0) && (
              <DeleteOutlined
                onClick={e => {
                  e.preventDefault();
                  e.stopPropagation();
                  onTermDelete(index);
                }}
              />
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className='terms-container'>
      {terms && terms.length > 0 ? (
        <Collapse
          // accordion
          activeKey={activeKey}
          onChange={switchPanel}
          className='term-list-panel'>
          {terms &&
            terms.map((term, index) => (
              <Panel
                showArrow={false}
                forceRender={true}
                header={renderHeader(term, index)}
                key={index.toString()}>
                <TermDrop
                  isReadonly={isReadonly}
                  onDrop={data => {
                    onDrop(term, index, data);
                  }}
                  termIndex={index}
                  onDeleteCourse={onDeleteCourse}
                  term={term}
                  onSelect={onSelect}
                  allterms={terms}
                  cautionDisplay={cautionDisplay}
                />
              </Panel>
            ))}
        </Collapse>
      ) : (
        <div className='note'>
          <p className='mb-0'>There are currently no courses in this term.</p>
          <p className='mb-0'> Drag and drop courses here.</p>
          <div className='py-3'>
            <Button onClick={addTerm} type='primary'>
              Add Term
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default TermsContainer;
