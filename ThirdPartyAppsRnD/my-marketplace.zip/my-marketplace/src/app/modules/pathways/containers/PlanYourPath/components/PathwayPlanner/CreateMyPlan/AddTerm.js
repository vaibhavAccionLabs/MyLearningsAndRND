import React, {useEffect} from 'react';
import {Modal, Form, Input} from 'antd';

const layout = {
  labelCol: {
    span: 8,
  },
  wrapperCol: {
    span: 16,
  },
};

const AddTerm = props => {
  const {
    visible,
    onClose,
    onAddTerm,
    availableTerms,
    initialValue,
    editMode,
  } = props;
  const [form] = Form.useForm();

  const onOk = () => {
    form.submit();
  };

  const onFinish = values => {
    onAddTerm(values);
    form.resetFields();
  };

  useEffect(() => {
    if (editMode && initialValue && initialValue.term_name) {
      form.setFieldsValue({
        term_name: initialValue.term_name,
      });
    } else {
      form.setFieldsValue({
        term_name: '',
      });
    }
    return () => {};
  }, [editMode, initialValue]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    visible && (
      <Modal
        maskClosable={false}
        visible={visible}
        title={editMode ? 'Edit Term' : 'Add Term'}
        okText={editMode ? 'Save Term' : 'Add Term'}
        onOk={onOk}
        onCancel={onClose}
        width='700px'
        className='modal-move-top add-new-term'>
        <Form
          {...layout}
          name='addTerm'
          form={form}
          onFinish={onFinish}
          onFinishFailed={err => console.log(err)}>
          <Form.Item
            label='Term Name'
            name='term_name'
            rules={[
              {
                required: true,
                message: 'Term name can not be empty.',
              },
              {
                validator(rule, value, callback) {
                  if (editMode) {
                    if (
                      initialValue.term_name.toLowerCase() ===
                      value.toLowerCase()
                    ) {
                      callback();
                    }
                  }
                  if (value) {
                    availableTerms.forEach(term => {
                      if (
                        term.term_name.toLowerCase() === value.toLowerCase()
                      ) {
                        callback(`${value} already exists.`);
                      }
                    });
                  }
                  callback();
                },
              },
            ]}>
            <Input placeholder='Enter term name' />
          </Form.Item>
        </Form>
      </Modal>
    )
  );
};

export default AddTerm;
