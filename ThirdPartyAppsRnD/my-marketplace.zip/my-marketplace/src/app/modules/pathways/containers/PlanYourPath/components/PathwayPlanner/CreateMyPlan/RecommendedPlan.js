import React, {useState, useEffect} from 'react';
import {useRecommendedPlan} from 'core/hooks';

import {RequestErrorLoader} from 'core/components';

import TermsContainer from './TermsContainer';

function RecommendedPlan(props) {
  const {fetchRecommendedPlan, onSelect} = props;
  const recommendedPlan = useRecommendedPlan();

  useEffect(() => {
    (async function () {
      if (!recommendedPlan.data) {
        await fetchRecommendedPlan();
      }
    })();
    return () => {};
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const prepareTermsData = data => {
    let terms = [];
    if (data && Array.isArray(data)) {
      data.forEach(d => {
        const term = {
          uuid: d.uuid,
          data: [...d.courses],
        };
        terms.push(term);
      });
    }
    return terms;
  };

  return (
    <>
      <RequestErrorLoader body={recommendedPlan} />
      {!recommendedPlan.request &&
        !recommendedPlan.error &&
        recommendedPlan.data &&
        recommendedPlan.data.terms &&
        recommendedPlan.data.terms.length > 0 && (
          <div className='panel-content'>
            <div className='card-layout'>
              <div className='card-header'>
                <span>Terms ({recommendedPlan.data.terms.length || 0})</span>
              </div>
              <div className='card-content'>
                <TermsContainer
                  {...props}
                  terms={prepareTermsData(recommendedPlan.data.terms)}
                />
              </div>
            </div>
          </div>
        )}

      {!recommendedPlan.request &&
        !recommendedPlan.error &&
        recommendedPlan.data &&
        recommendedPlan.data.terms &&
        recommendedPlan.data.terms.length === 0 && (
          <div className='no-recommended-plan'>No Recommended Plan</div>
        )}
    </>
  );
}

export default RecommendedPlan;
