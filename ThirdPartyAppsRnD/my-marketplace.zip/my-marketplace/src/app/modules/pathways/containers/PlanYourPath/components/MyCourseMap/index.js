import {useState, useEffect, useMemo} from 'react';
import {Row, Col, Button} from 'antd';
import {PDFDownloadLink} from '@react-pdf/renderer';
//PDFViewer :: Can be used for development
import {MyDocument, CourseModal, CourseMap} from 'core/components';
import {useAuth} from 'core/hooks';

import './myplan.less';

const MyCourseMap = ({pathData, myPlanData, onTabChange}) => {
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [isPlan, setIsPlan] = useState(false);
  const [token, user] = useAuth();

  useEffect(() => {
    if (
      myPlanData.data &&
      Array.isArray(myPlanData.data.terms) &&
      myPlanData.data.terms.length
    ) {
      setIsPlan(true);
    } else {
      setIsPlan(false);
    }
    return () => {};
  }, [myPlanData.data]);

  const onClose = () => setSelectedCourse(null);

  const onCourseClick = course => setSelectedCourse(course);

  const renderDownload = useMemo(() => {
    return (
      myPlanData.data &&
      pathData &&
      user && (
        <>
          <PDFDownloadLink
            document={
              <MyDocument data={myPlanData.data} path={pathData} user={user} />
            }
            fileName='my_course_map.pdf'>
            {({loading}) => (
              <Button className='btn btn-purple-outer mr-4'>
                {loading ? 'Loading Document...' : 'Download'}
              </Button>
            )}
          </PDFDownloadLink>

          {/* // For developmment use only */}
          {/* <PDFViewer width='100%' height='700vh'>
            <MyDocument data={myPlanData.data} path={pathData} user={user} />
          </PDFViewer> */}
        </>
      )
    );
  }, [myPlanData, pathData, user]);

  return !token ? (
    <>
      <div className='pathplanner'>
        <div className='outerborder'>
          <div className='content-pathplanner text-center'>
            <p>You are not logged In</p>
          </div>
        </div>
      </div>
    </>
  ) : (
    <>
      <div className='myCourseMap'>
        <Row>
          <Col xs={12} sm={24} md={12} lg={12}>
            <h2>Course Sequence by Term</h2>
          </Col>
          {isPlan && (
            <Col xs={12} sm={24} md={12} lg={12} className='text-right'>
              {renderDownload}
            </Col>
          )}

          {!isPlan ? (
            <Col xs={24} sm={24} md={24} lg={24} className='my-2 createmyPlan'>
              <div className='outerborder'>
                <p className='mb-1'>
                  Please create a plan for your pathway in the "Pathway Planner"
                  tab above.
                </p>
                <p className='mb-1'>
                  Once your plan is created, you will be able to view it in a
                  map view here!
                </p>
                <button
                  className='btn btn-purple-outer my-3'
                  onClick={() => onTabChange('pathway_planner')}>
                  Create My Plan
                </button>
              </div>
            </Col>
          ) : (
            <Col xs={24} sm={24} md={24} lg={24} className='my-2'>
              <div>
                <p className='mb-1'>
                  The following map displays the courses that you have chosen
                  for your pathway plan.
                </p>
                <p className='mb-1'>
                  Click on any of the courses below to view course details!
                </p>
              </div>
              <hr />
            </Col>
          )}
        </Row>
      </div>
      {isPlan && (
        <>
          <CourseMap
            showFilters
            myPlanData={myPlanData}
            onClick={onCourseClick}
          />
          <CourseModal
            visible={selectedCourse ? true : false}
            onModalClose={onClose}
            data={selectedCourse}
          />
        </>
      )}
    </>
  );
};

export default MyCourseMap;
