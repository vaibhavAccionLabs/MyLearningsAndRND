import {useEffect, useState} from 'react';
import {Collapse, Row, Col, Steps, Button, message} from 'antd';
import {MinusOutlined, PlusOutlined} from '@ant-design/icons';

import {Services} from 'core/Services';
import {RequestErrorLoader} from 'core/components';

import {API} from 'config';

import './style.less';
import OnboardFinishModal from '../../sharedComponents/Modal/OnboardFinishModal';
import {useHistory} from 'react-router-dom';

const {Panel} = Collapse;
const {Step} = Steps;

const services = new Services();

const OnBoard = ({
  onboardSteps,
  studentOnboard,
  token,
  fetchStudentOnboard,
  goToPlan,
  onStepChange,
  pathData,
  deleteActivePath,
  onCancelOnboard,
  goBackToOnboardTypeSelect,
}) => {
  const history = useHistory();
  const {steps} = onboardSteps || {};
  const {institute_details: {name} = {}} = pathData || {};
  const {data: studentOnboardData} = studentOnboard || {};
  const [init, setInit] = useState(false);
  const [onboardCompletdModal, setOnboadCompleteModal] = useState(false);
  const [completed, setCompleted] = useState({
    completed_step_uuid: [],
    completed_task_uuid: [],
  });
  const [onboardStatus, setOnboardStatus] = useState({
    currentStep: -1,
    currentTask: -1,
  });
  const [loading, setLoading] = useState(false);
  const setStepStatus = () => {
    const {completed_step_uuid, completed_task_uuid} = studentOnboardData;
    let currentStep = -1;
    let currentTask = -1;
    setCompleted({
      completed_step_uuid,
      completed_task_uuid,
    });
    if (completed_step_uuid && completed_step_uuid.length > 0)
      currentStep = completed_step_uuid.length;
    if (completed_task_uuid && completed_task_uuid.length > 0) {
      if (currentStep === -1) currentStep = 0;
      currentTask = steps[completed_step_uuid.length]
        ? steps[completed_step_uuid.length].tasks
            .map(i => i.uuid)
            .indexOf(completed_task_uuid[completed_task_uuid.length - 1])
        : -1;
    }
    setOnboardStatus({
      ...onboardStatus,
      currentTask: currentTask + 1,
      currentStep,
    });
  };
  useEffect(() => {
    if (studentOnboardData && steps) {
      if (!init) {
        setInit(true);
        setStepStatus();
      }
    }
  }, [studentOnboardData, steps]); // eslint-disable-line react-hooks/exhaustive-deps
  const nextStep = index => {
    setOnboardStatus({...onboardStatus, currentStep: index, currentTask: 0});
  };
  const isOnboardCompleted = completed_tasks => {
    const {completed_task_uuid: completed_tasks_uuids} = completed;
    const completed_task_uuid = completed_tasks
      ? completed_tasks
      : completed_tasks_uuids;
    if (steps && steps.length === 0) return true;
    let lastTask = null;
    steps &&
      steps.length > 0 &&
      steps.forEach(step => {
        const tasks = step.tasks;
        tasks &&
          tasks.length > 0 &&
          tasks.forEach(task => {
            lastTask = task;
          });
      });
    if (lastTask && completed_task_uuid.indexOf(lastTask.uuid) !== -1)
      return true;
    return false;
  };
  const startOnboard = () => {
    if (Array.isArray(steps) && steps.length > 0) {
      nextStep(0);
    }
  };
  const saveSteps = (completed_steps, completed_tasks) => {
    const {student_onboard_uuid} = studentOnboardData;
    const body = {
      completed_step_uuid: completed_steps,
      completed_task_uuid: completed_tasks,
    };
    return services
      .createUpdateRecord(
        token,
        `${API.gps.student_onboard}/${student_onboard_uuid}`,
        body,
        'PATCH',
      )
      .then(res => {
        fetchStudentOnboard(pathData);

        setCompleted({
          completed_step_uuid: res.completed_step_uuid,
          completed_task_uuid: res.completed_task_uuid,
        });
        if (isOnboardCompleted(res.completed_task_uuid)) {
          setOnboadCompleteModal(true);
        }
      });
  };

  const navigateTo = link => history.push(link);

  const nextTask = async () => {
    setLoading(true);
    const {completed_step_uuid, completed_task_uuid} = completed;
    const noOfTaskInCurrentStep = steps[onboardStatus.currentStep].tasks.length;
    const taskAlreadyAdded =
      completed_task_uuid.indexOf(
        steps[onboardStatus.currentStep].tasks[onboardStatus.currentTask].uuid,
      ) !== -1;
    if (taskAlreadyAdded) {
      setOnboardStatus({
        ...onboardStatus,
        currentTask: onboardStatus.currentTask + 1,
      });
      setLoading(false);
      return;
    }
    if (noOfTaskInCurrentStep === onboardStatus.currentTask + 1) {
      const completed_steps = [
        ...completed_step_uuid,
        steps[onboardStatus.currentStep].step_uuid,
      ];
      const completed_tasks = [
        ...completed_task_uuid,
        steps[onboardStatus.currentStep].tasks[onboardStatus.currentTask].uuid,
      ];
      await saveSteps(completed_steps, completed_tasks).then(res => {
        setOnboardStatus({
          currentStep: parseInt(onboardStatus.currentStep) + 1,
          currentTask: 0,
        });
      });
    } else {
      const completed_steps = [...completed_step_uuid];
      const completed_tasks = [
        ...completed_task_uuid,
        steps[onboardStatus.currentStep].tasks[onboardStatus.currentTask].uuid,
      ];
      await saveSteps(completed_steps, completed_tasks).then(res => {
        setOnboardStatus({
          ...onboardStatus,
          currentTask: onboardStatus.currentTask + 1,
        });
      });
    }
    setLoading(false);
  };

  const onChangePanel = i => {
    if (!i[1]) return;
    if (
      !isAllTaskCompleted(steps[i[1]]) ||
      (!isAllTaskCompleted(steps[i[1] - 1]) && steps[i[1]]) ||
      completed.completed_step_uuid.length === i[1]
    ) {
      let currentTask = 0;
      if (completed.completed_step_uuid.length === i[1]) {
        const index = steps[i[1]].tasks
          .map(i => i.uuid)
          .indexOf(
            completed.completed_task_uuid[
              completed.completed_task_uuid.length - 1
            ],
          );
        currentTask = index + 1;
      }
      setOnboardStatus({...onboardStatus, currentStep: i[1], currentTask});
    }
  };

  const onChangeTask = i => {
    setOnboardStatus({...onboardStatus, currentTask: i});
  };

  const getTaskStatus = task => {
    if (completed.completed_task_uuid.indexOf(task.uuid) !== -1)
      return 'finish';
  };
  const isAllTaskCompleted = step => {
    let count = 0;
    if (step && step.tasks) {
      step.tasks.forEach(s => {
        if (completed.completed_task_uuid.indexOf(s.uuid) !== -1) count++;
      });
      return count !== step.tasks.length;
    }
    return false;
  };
  const onDeleteActivePath = async () => {
    const {student_onboard_uuid} =
      studentOnboard && studentOnboard.data ? studentOnboard.data : {};
    if (student_onboard_uuid) {
      await deleteActivePath(student_onboard_uuid, err => {
        if (err) {
          message.error(err);
        } else {
          onCancelOnboard();
        }
      });
    }
  };
  const goBackToOnboardType = async () => {
    const {student_onboard_uuid} =
      studentOnboard && studentOnboard.data ? studentOnboard.data : {};
    if (student_onboard_uuid) {
      await deleteActivePath(student_onboard_uuid, err => {
        if (err) {
          message.error(err);
        } else {
          goBackToOnboardTypeSelect();
        }
      });
    }
  };
  return (
    <RequestErrorLoader body={{request: loading}}>
      <div className='onboard-layout contentContainer px-5 py-4'>
        <div className='head'>
          Welcome to {name || ''} and your pathway to success!
        </div>
        <div className='sub-head'>Getting Started</div>
        <div className='path-points'>
          <div className='p-itm'>
            A pathway describes and links a degree, certification, or training
            program to the steps needed to pursue it. A pathway also connects
            you to related occupations, job opportunities, employers, and events
            (coming soon!).
          </div>
          <div className='p-itm'>
            Completing a pathway on GoEducate gives you an education plan and a
            powerful way to explore career options.
          </div>
          <div className='p-itm'>
            To apply or enroll in a pathway program, follow the links below to
            the school website and complete the steps there.
          </div>
          <div className='p-itm'>
            You can skip to any of the next steps and explore the courses in
            this program. When you’re ready to apply or enroll, navigate back
            here for further guidance.
          </div>
        </div>
        {completed.completed_task_uuid.length === 0 &&
          onboardStatus.currentStep === -1 && (
            <>
              <Button
                className='actn-btns'
                type={'primary'}
                onClick={startOnboard}>
                Let's Get Started
              </Button>
              <Button
                className='btn-pink actn-btns'
                onClick={onDeleteActivePath}>
                Cancel
              </Button>
              <Button
                className='go-back-btn actn-btns'
                type={'ghost'}
                onClick={goBackToOnboardType}>
                Go Back
              </Button>
            </>
          )}
        {onboardStatus.currentStep !== -1 && (
          <div className='steps'>
            {Array.isArray(steps) && (
              <Collapse
                bordered={false}
                expandIconPosition='right'
                className='steps-collpase'
                onChange={onChangePanel}
                activeKey={String(onboardStatus.currentStep).toString()}
                expandIcon={({isActive}) =>
                  isActive ? <MinusOutlined /> : <PlusOutlined />
                }>
                {steps.map((step, idx) => (
                  <Panel
                    key={String(idx).toString()}
                    header={
                      <div className='panel-ttl'>
                        <div className='panel-dot' />
                        <div className='panel-text'>{step.title}</div>
                      </div>
                    }
                    className={
                      completed.completed_step_uuid.indexOf(step.step_uuid) !==
                      -1
                        ? 'steps-collapse-panel finish '
                        : 'steps-collapse-panel'
                    }>
                    <Row className='onboard-step-layout'>
                      <Col sm={5} xs={24}>
                        <Steps
                          current={onboardStatus.currentTask}
                          size='small'
                          className='onboard-step'
                          onChange={onChangeTask}
                          direction='vertical'>
                          {Array.isArray(step.tasks) &&
                            step.tasks.map(task => (
                              <Step
                                title={task.title}
                                key={task.uuid}
                                status={getTaskStatus(task)}
                              />
                            ))}
                        </Steps>
                      </Col>
                      <Col sm={19} xs={24}>
                        {onboardStatus.currentStep !== -1 && (
                          <div
                            dangerouslySetInnerHTML={{
                              __html:
                                steps[onboardStatus.currentStep] &&
                                steps[onboardStatus.currentStep].tasks[
                                  onboardStatus.currentTask
                                ]
                                  ? steps[onboardStatus.currentStep].tasks[
                                      onboardStatus.currentTask
                                    ].description
                                  : '',
                            }}
                          />
                        )}
                        <Row justify='end'>
                          <Col>
                            {isAllTaskCompleted(step) && (
                              <Button type='primary' onClick={nextTask}>
                                Next
                              </Button>
                            )}
                          </Col>
                        </Row>
                      </Col>
                    </Row>
                  </Panel>
                ))}
              </Collapse>
            )}
          </div>
        )}

        {isOnboardCompleted() && studentOnboardData && (
          // studentOnboardData.completed_stage === 'explore_paths' &&
          <div className='completed-status'>
            {/* <div className='sub-ttl'>
                Continue to the next step of the Pathway Navigator!
              </div> */}
            {/* <Button type='primary' onClick={goToPlan}>
                Next Step */}
            {/* </Button> */}
            <Button
              type='primary'
              onClick={() => navigateTo('/settings/dashboard')}>
              Go To My Dashboard
            </Button>
            &nbsp; &nbsp;
            <Button type='primary' onClick={() => onStepChange(0)}>
              Go To Program Overview
            </Button>
          </div>
        )}
      </div>
      <OnboardFinishModal
        visible={onboardCompletdModal}
        navigateTo={p => {
          setOnboadCompleteModal(false);
          navigateTo(p);
        }}
      />
    </RequestErrorLoader>
  );
};

export default OnBoard;
