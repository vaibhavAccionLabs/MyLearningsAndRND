import React from 'react';
import {Progress} from 'antd';

import {
  formatCount,
  getGraphData,
  validateGenEduPlanned,
  getCoreUnitsGraphData,
} from 'core/utils';

const OverviewLabelFormat = ({value, denom}) => (
  <div style={{display: 'grid'}}>
    <span>{`${value}/${denom}`}</span>
  </div>
);

const Demographics = ({terms, path, genEdData}) => {
  const {
    total,
    totalUnits,
    totalUnitsPercent,
    totalCoreCourses,
    totalCoreCouresPercent,
  } = getGraphData({terms, path});

  const {
    completed: genEdCompleted,
    total: genEdTotal,
    perc: genEdCompletedPerc,
  } = validateGenEduPlanned(genEdData, terms);

  const {
    total: coreUnitsTotal,
    completed: coreUnitsCompleted,
    perc: coreUnitsPerc,
  } = getCoreUnitsGraphData(terms, path);

  return (
    <div className='my-plan-graphs'>
      <h1 className='header'>Plan Overview</h1>
      <div className='content'>
        {path && path.general_education_option && (
          <div className='gen-ed-units cnt_list text-center pb-4'>
            <h3 className='pb-3'>General Education Requirements Planned</h3>
            <Progress
              percent={30}
              width={80}
              format={percent => (
                <OverviewLabelFormat
                  value={genEdCompleted}
                  denom={genEdTotal}
                />
              )}
              type='circle'
              percent={genEdCompletedPerc}
              strokeWidth='8'
              strokeColor={genEdCompletedPerc >= 100 ? '#6eac5f' : '#FFB40A'}
            />
          </div>
        )}
        <div className='core-units cnt_list text-center pb-4'>
          <h3 className='pb-3'>Core Requirements Planned</h3>
          <Progress
            percent={30}
            width={80}
            format={percent => (
              <OverviewLabelFormat
                value={coreUnitsCompleted}
                denom={coreUnitsTotal}
              />
            )}
            type='circle'
            percent={coreUnitsPerc}
            strokeWidth='8'
            strokeColor={coreUnitsPerc >= 100 ? '#6eac5f' : '#FFB40A'}
          />
        </div>
        <div className='total-units cnt_list text-center pb-4'>
          <h3 className='pb-3 capitalize'>{`Total ${
            path?.score_system || 'units'
          } Planned`}</h3>
          <Progress
            percent={30}
            width={80}
            format={percent => (
              <OverviewLabelFormat
                value={totalUnits}
                denom={formatCount(path && path.total_units_required)}
              />
            )}
            type='circle'
            percent={totalUnitsPercent}
            strokeWidth='8'
            strokeColor={totalUnitsPercent >= 100 ? '#6eac5f' : '#FFB40A'}
          />
        </div>
      </div>
    </div>
  );
};

export default Demographics;
