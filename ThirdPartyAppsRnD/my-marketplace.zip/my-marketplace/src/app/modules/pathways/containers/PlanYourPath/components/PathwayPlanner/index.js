import React, {useState} from 'react';
import HTML5Backend from 'react-dnd-html5-backend';
import {DndProvider} from 'react-dnd';
import {message} from 'antd';
import {useMyPlan, useAuth, useActivePath} from 'core/hooks';

import CreateMyPlan from './CreateMyPlan';

import {API} from 'config';
import {Services} from 'core/Services';
import './pathplanner.less';

const services = new Services();
const {success, error} = message;
const PathwayPlanner = props => {
  const {pathData, onTabChange, fetchMyPlan} = props;
  const [isSaving, setIsSaving] = useState(false);
  const myPlan = useMyPlan();
  const [token, user] = useAuth();
  const activePath = useActivePath();

  const onSubmit = data => {
    if (activePath && activePath.data && activePath.data.length) {
      const {studentOnboard: {data: {student_onboard_uuid} = {}} = {}} = ({} =
        props || {});
      setIsSaving(true);
      const endPoint = `${API.srm.pathway_planner}`;
      const bodyData = {
        path_cluster_program: activePath.data[0].path_uuid,
        term: data,
      };
      services
        .createUpdateRecord(token, endPoint, bodyData, 'POST')
        .then(async res => {
          if (res && Array.isArray(res) && res.length) {
            let endPoint = `${API.gps.student_onboard}/${student_onboard_uuid}`;
            const bodyData = {
              my_plan:
                data && Array.isArray(data) && data.length >= 1 ? true : false,
            };
            await services.updateStatus(token, endPoint, bodyData);
            success('My Plan created successfully.');
            setIsSaving(false);
            fetchMyPlan();
            return;
          }
          error('Something went wrong. Try again later.');
        });
    }
  };

  return !token ? (
    <>
      <div className='pathplanner'>
        <div className='outerborder'>
          <div className='content-pathplanner text-center'>
            <p>You are not logged In</p>
          </div>
        </div>
      </div>
    </>
  ) : (
    <>
      <div className='pathplanner'>
        <h2>Map your journey to academic success!</h2>
        <div>
          <div className='content-pathplanner'>
            <p>
              The Pathway Planner tool is designed to help you succeed within
              your selected path. Using this tool, you will be able to create a
              customized academic plan that will ensure that you complete every
              requirement for your path.
            </p>
            <p>
              To use the Pathway Planner tool, simply drag and drop courses from
              the requirements section on the left to terms in your own
              customized plan in the middle. On the right, a recommended plan is
              provided to help you organize your courses.
            </p>
          </div>
        </div>
      </div>
      <div className='planner-view'>
        <DndProvider backend={HTML5Backend}>
          <CreateMyPlan
            {...props}
            requirementsData={{
              Data: pathData,
              pathwayPlanner: pathData?.ge_path_details,
            }}
            onSubmit={onSubmit}
            initialData={myPlan?.data?.terms || []}
            isSaving={isSaving}
          />
        </DndProvider>
      </div>
    </>
  );
};

export default PathwayPlanner;
