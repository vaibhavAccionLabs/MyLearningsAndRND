import {useEffect, useState} from 'react';
import {Popover, Select} from 'antd';
import {InfoCircleFilled} from '@ant-design/icons';

import {RequestErrorLoader} from 'core/components';

//Sharable components from Module - Occupation
import {Banner} from 'app/modules/occupation/sharedComponents';
import {CareerOverview} from 'app/modules/occupation/components';

//Local sharable component
import {BrightOutlookContent} from '../../../../sharedComponents/Occupations';

import {brightIcon} from 'assets/images';

import occupationData from 'data/occupation.json';
import './style.less';

const {Option} = Select;

const Career = props => {
  const {
    occupations,
    occupationDetails,
    fetchAllOccupations,
    clearAllOccupations,
    fetchOccupationDetails,
    clearOccupationDetails,
    resetSubscribedOccupation,
    appConfig: {isMobileView},
  } = props;
  const [occupationSelected, setOccupationSelected] = useState(null);

  useEffect(() => {
    if (occupations && !occupations.allOccupations) {
      fetchAllOccupations();
    }
    return () => {
      clearAllOccupations();
      clearOccupationDetails();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (
      occupations?.allOccupations?.occupation &&
      occupations.allOccupations.occupation?.[0]?.name
    ) {
      setOccupationSelected(occupations.allOccupations.occupation[0].name);
    }
  }, [occupations.allOccupations]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    fetchOccupationDetails(occupationSelected);
    return () => {
      resetSubscribedOccupation();
    };
  }, [occupationSelected]); // eslint-disable-line react-hooks/exhaustive-deps

  const onOccupationChange = value => setOccupationSelected(value);

  return (
    <div className='pt-3'>
      <div className='career-container'>
        <div className='d-flex'>
          <h2 className='heading'>Related Careers</h2>
          <p className='additional-info'>
            <img src={brightIcon} alt='bright-icon' /> Bright Outlook
            Occupations
            <Popover
              placement='bottomLeft'
              className='pl-2'
              content={BrightOutlookContent()}
              overlayClassName='relatedOccupations-popover'
              trigger={isMobileView ? 'click' : 'hover'}>
              <InfoCircleFilled />
            </Popover>
          </p>
        </div>
        <div className='sub-heading'>
          Discover a career profile below to view the detailed information of
          each occupation to help you prepare for your career path.
        </div>
      </div>
      <RequestErrorLoader
        txt={occupationData.loadingOccupTxt}
        body={{...occupations, request: occupations?.request}}>
        {occupations.allOccupations && (
          <div className='occupation-details'>
            <div className='occupation-dropdown-container'>
              <h2 className='heading'>Related Career</h2>
              <Select
                dropdownClassName='occupation-dd'
                className='occupation-dropdown pl-3'
                onChange={onOccupationChange}
                value={occupationSelected}>
                {occupations.allOccupations.occupation &&
                  Array.isArray(occupations.allOccupations.occupation) &&
                  occupations.allOccupations.occupation.map((occ, idx) => (
                    <Option value={occ.name} key={idx}>
                      <span>{occ.name}</span>
                      {occ.bright && <img src={brightIcon} alt='bright-icon' />}
                    </Option>
                  ))}
              </Select>
            </div>
            <RequestErrorLoader
              body={{
                ...occupationDetails,
                request: occupationDetails?.request,
              }}>
              {occupationDetails &&
                occupationDetails.data &&
                !occupationDetails.error && (
                  <>
                    <Banner {...props} />
                    <div className='pathways-tabs contentContainer occupation_tabs pt-3'>
                      <CareerOverview {...props} />
                    </div>
                  </>
                )}
            </RequestErrorLoader>
          </div>
        )}
      </RequestErrorLoader>
    </div>
  );
};

export default Career;
