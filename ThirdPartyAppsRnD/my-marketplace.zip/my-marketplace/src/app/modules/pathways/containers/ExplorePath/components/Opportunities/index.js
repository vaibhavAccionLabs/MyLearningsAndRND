import {useEffect, useState} from 'react';

//Sharable components from Module - Occupation
import {EmploymentOpportunites} from 'app/modules/occupation/components';

import {queryStringParse} from 'core/utils';
import {RequestErrorLoader, ErrorBoundary} from 'core/components';
import './style.less';

const Opportunities = props => {
  const {
    fetchAllOccupations,
    clearAllOccupations,
    history,
    occupations,
  } = props;
  const [selectedOccupation, setSelectedOccupation] = useState(null);
  const {
    location: {pathname, search},
  } = history;
  const params = queryStringParse(search);

  const onEmploymentTypeChange = value => {
    history.push(history.location.pathname + '?type=' + value);
  };

  const poplateSelectedOccupation = ({key, value, children}) =>
    setSelectedOccupation({
      data: {
        occupation_uuid: value,
        occupation_onnet: key,
        occupation_name: children,
      },
    });

  const onCareerChange = (_, obj) => poplateSelectedOccupation(obj);

  useEffect(() => {
    if (occupations?.allOccupations?.occupation?.length) {
      const {onnet, uuid, name} = occupations?.allOccupations?.occupation[0];
      poplateSelectedOccupation({
        key: onnet,
        value: uuid,
        children: name,
      });
    }
  }, [occupations]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!occupations?.allOccupations) {
      fetchAllOccupations();
    }
    return () => {
      clearAllOccupations();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <>
      <ErrorBoundary nameOfComponent='module-event-list' typeOfUi='subPage'>
        <RequestErrorLoader body={{request: occupations?.request}}>
          <EmploymentOpportunites
            {...props}
            params={params}
            onChange={onEmploymentTypeChange}
            occupationList={occupations}
            onCareerChange={onCareerChange}
            occupationDetails={selectedOccupation}
            dispCareerList={true}
          />
        </RequestErrorLoader>
      </ErrorBoundary>
    </>
  );
};

export default Opportunities;
