import {RequestErrorLoader} from 'core/components';
import {Banner, Occupations} from '../../sharedComponents';

const Workforce = props => {
  const {occupations} = props;
  return (
    <RequestErrorLoader body={{request: occupations.request}}>
      <Banner
        {...props}
        isFinishButton
        displayWorkforce
        workforceData={occupations || null}
      />
      <div className='pathways-tabs contentContainer px-5 py-4'>
        <div className='workforce-header'>
          <h2>Transfer your new skills to your career!</h2>
          <p>
            Connecting to the workforce has never been easier. Click any
            occupation below to explore your career options and apply to
            internships, apprenticeships, and jobs.
          </p>
        </div>
        <Occupations {...props} />
      </div>
    </RequestErrorLoader>
  );
};

export default Workforce;
