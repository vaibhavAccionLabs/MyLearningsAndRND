import {Row, Col} from 'antd';
import {CustomTabs} from 'core/components';

//Local Components
import {OverviewTab, Career, Opportunities} from './components';
import {Banner, RequirementsTab, ProgramMap} from '../../sharedComponents';

import './style.less';

const ExplorePath = props => {
  const {
    pathData,
    onCompareClick,
    onStartPathwayClick,
    studentOnboard,
    isCurentPathisActive,
    onSavePathClick,
    savedPath,
    removeSavedPath,
  } = props;

  const tabs = [
    {
      title: 'OVERVIEW',
      key: 'overview',
      children: <OverviewTab {...props} />,
    },
    {
      title: pathData?.program_map ? 'PROGRAM MAP' : 'REQUIREMENTS',
      key: 'requirements',
      children: pathData?.program_map ? (
        <ProgramMap {...props} />
      ) : (
        <RequirementsTab {...props} />
      ),
    },
    {
      title: 'CAREERS',
      key: 'careers',
      children: <Career {...props} />,
    },
    {
      title: 'OPPORTUNITIES',
      key: 'opportunities',
      children: <Opportunities {...props} />,
    },
  ];

  return (
    <>
      <Banner
        {...props}
        showActions
        pathData={pathData}
        onStartPathwayClick={onStartPathwayClick}
        removeSavedPath={removeSavedPath}
        isCurentPathisActive={isCurentPathisActive}
        studentOnboard={studentOnboard}
        savedPath={savedPath}
        onCompareClick={onCompareClick}
        onSavePathClick={onSavePathClick}
      />
      <div className='pathways-tabs contentContainer py-4'>
        <Row className='d-flex'>
          <Col xs={24} sm={24} md={24} lg={24}>
            <CustomTabs tabsList={tabs} />
          </Col>
        </Row>
      </div>
    </>
  );
};

export default ExplorePath;
