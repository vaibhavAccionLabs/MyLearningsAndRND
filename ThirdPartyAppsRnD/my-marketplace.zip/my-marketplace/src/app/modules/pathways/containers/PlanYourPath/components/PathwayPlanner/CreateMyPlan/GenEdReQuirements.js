import React from 'react';
import {Row, Col, Collapse} from 'antd';
import {CheckCircleOutlined} from '@ant-design/icons';
import {ListItem} from 'core/components';
import {isEmpty, validateGenEduPlanned} from 'core/utils';

const {Panel} = Collapse;
export default function GenEdReQuirements({
  data,
  terms,
  checkCourseAdded,
  onSelect,
}) {
  const {gen_ed, gen_ed: {segment_groups, segments} = {}} = data || {};

  const {segmentValidation, segmentGroupsValidation} = validateGenEduPlanned(
    gen_ed,
    terms,
  );

  const checkCombiValidations = () => {
    let validations = [];
    if (segmentValidation && segmentValidation.length) {
      segmentValidation.map(validation => {
        if (validation.valid) {
          validations.push(true);
        }
      });
    }
    if (segmentGroupsValidation && segmentGroupsValidation.length) {
      segmentGroupsValidation.map(validation => {
        if (validation.valid) {
          validations.push(true);
        }
      });
    }
    return validations;
  };

  const diplayRules = data => {
    const {rules} = data;
    return (
      rules &&
      !isEmpty(rules) &&
      Object.keys(rules).map((rule, idx) => {
        if (rules[rule] && rule === 'no_of_courses') {
          return (
            <span key={`rule-${idx}`}>
              Rule: Choose {rules[rule] || 0} course(s)
            </span>
          );
        } else if (rules[rule] && rule === 'no_of_units') {
          return (
            <span key={`rule-${idx}`}>
              Rule: Complete {rules[rule] || 0} unit(s)
            </span>
          );
        } else if (
          rules[rule] &&
          rule === 'no_of_courses_from_segment' &&
          rules[rule].length
        ) {
          return rules[rule].map((subRule, subIndex) => (
            <span key={`sub-rule-${subIndex}`}>
              Rule: Choose {subRule.no_of_courses || 0} course(s) from
              {subRule.title}
            </span>
          ));
        } else if (
          rules[rule] &&
          rule === 'no_of_units_from_segment' &&
          rules[rule].length
        ) {
          return rules[rule].map((subRule, subIndex) => (
            <span key={`sub-rule-${subIndex}`}>
              Rule: Complete {subRule.no_of_units || 0} unit(s) from{' '}
              {subRule.title}
            </span>
          ));
        } else if (
          rules[rule] &&
          !isEmpty(rules[rule]) &&
          rule === 'no_of_courses_from_no_of_segment'
        ) {
          return (
            <span key={`rule-${idx}`}>
              Rule: Choose {rules[rule].no_of_courses || 0} course(s) from
              atleast {rules[rule].no_of_segments || 0} segment(s)
            </span>
          );
        } else if (
          rules[rule] &&
          !isEmpty(rules[rule]) &&
          rule === 'no_of_units_from_no_of_segment'
        ) {
          return (
            <span key={`rule-${idx}`}>
              Rule: Choose {rules[rule].no_of_units || 0} units(s) from atleast{' '}
              {rules[rule].no_of_segments || 0} segment(s)
            </span>
          );
        }
      })
    );
  };

  let defaultKeys = [];
  let combineLength = 0;
  if (segments && segments.length) {
    combineLength += segments.length;
    segments.forEach((_, segmentIndex) => {
      defaultKeys.push(`segment-${segmentIndex}`);
    });
  }
  if (segment_groups && segment_groups.length) {
    combineLength += segment_groups.length;
    segment_groups.forEach((_, segmentGroupIndex) => {
      defaultKeys.push(`segment-group-${segmentGroupIndex}`);
    });
  }
  return (
    <div className='card-layout reqirement_gened'>
      <div className='card-header'>
        General Education Requirements
        {combineLength === checkCombiValidations().length && (
          <CheckCircleOutlined />
        )}
      </div>
      <div className='card-content gened'>
        <Collapse
          defaultActiveKey={[...defaultKeys]}
          className='gen-ed-requirements'>
          {segments &&
            segments.length > 0 &&
            segments.map((segment, segmentIndex) => (
              <Panel
                forceRender
                header={segment.title}
                key={`segment-${segmentIndex}`}
                className='gen-ed-segment'
                extra={
                  segmentValidation &&
                  segmentValidation[segmentIndex] &&
                  segmentValidation[segmentIndex].valid && (
                    <CheckCircleOutlined />
                  )
                }>
                <div className='rules-notification'>{diplayRules(segment)}</div>
                <Row className='coure-header'>
                  <Col xs={12} sm={18}>
                    Course ID
                  </Col>
                  <Col xs={12} sm={6}>
                    Units
                  </Col>
                </Row>
                {segment.courses &&
                  segment.courses.length > 0 &&
                  segment.courses.map((course, courseIndex) => (
                    <ListItem
                      terms={terms}
                      checkIfAddedToTerm={checkCourseAdded}
                      itemType='general'
                      key={`${course.uuid}-${segmentIndex}-${courseIndex}`}
                      data={course}
                      notCheckedForRequiredFields
                      itemLeftWidth={18}
                      itemRightWidth={6}
                      onClick={onSelect}
                    />
                  ))}
              </Panel>
            ))}

          {segment_groups &&
            segment_groups.length > 0 &&
            segment_groups.map((segmentGroup, segmentGroupIndex) => (
              <Panel
                forceRender
                header={segmentGroup.title}
                key={`segment-group-${segmentGroupIndex}`}
                className='gen-ed-segment-group'
                extra={
                  segmentGroupsValidation &&
                  segmentGroupsValidation[segmentGroupIndex] &&
                  segmentGroupsValidation[segmentGroupIndex].valid && (
                    <CheckCircleOutlined />
                  )
                }>
                <div className='rules-notification'>
                  {diplayRules(segmentGroup)}
                </div>
                {segmentGroup.segments.map((segment, segmentIndex) => (
                  <div key={`segment-${segmentGroupIndex}-${segmentIndex}`}>
                    <div className='segment-header'>{segment.title}</div>
                    <Row className='coure-header'>
                      <Col span={18}>Course ID</Col>
                      <Col span={6}>Units</Col>
                    </Row>
                    {segment.courses &&
                      segment.courses.length > 0 &&
                      segment.courses.map((course, courseIndex) => (
                        <ListItem
                          terms={terms}
                          checkIfAddedToTerm={checkCourseAdded}
                          itemType='general'
                          key={`${course.uuid}-${segmentIndex}-${courseIndex}`}
                          data={course}
                          notCheckedForRequiredFields
                          itemLeftWidth={18}
                          itemRightWidth={6}
                          onClick={onSelect}
                        />
                      ))}
                  </div>
                ))}
              </Panel>
            ))}
        </Collapse>
      </div>
    </div>
  );
}
