import isArray from 'lodash/isArray';
import isObject from 'lodash/isObject';
import isEmpty from 'lodash/isEmpty';
import {useHistory} from 'react-router-dom';

import {Button} from 'antd';
import jp from 'jsonpath';
import {durationString, numberInUSFormat} from 'core/utils';

import {RequestErrorLoader, ErrorBoundary, LazyImage} from 'core/components';
import compareStaticData from 'data/compare.json';

const rowsData = [
  {
    label: '',
    image: true,
  },
  {
    label: compareStaticData.rowsData.pathLabel,
    path: '$.title',
  },
  {
    label: compareStaticData.rowsData.awardTypeLabel,
    path: '$.award_type_name',
  },
  {
    label: compareStaticData.rowsData.schoolLabel,
    path: '$.institute_details.name',
  },
  {
    label: compareStaticData.rowsData.locationLabel,
    path: '$.location',
  },
  {
    label: compareStaticData.rowsData.timeToCompleteLabel,
    path: '$.program_duration',
  },
  {
    label: compareStaticData.rowsData.costLabel,
    path: '$.estimated_cost',
    render: value => (value ? `$${numberInUSFormat(value)}` : 'Not Available'),
  },
  {
    label: '',
    learnMore: true,
  },
];

const ComparePrograms = ({pathData, comparedPrograms}) => {
  const comparePrograms = comparedPrograms?.data;
  const history = useHistory();
  let comparedProgramsList = [];
  pathData && comparedProgramsList.push(pathData);
  comparePrograms &&
    isArray(comparePrograms) &&
    comparePrograms.length &&
    comparedProgramsList.push(...comparePrograms);

  const pathLength = (comparedProgramsList && comparedProgramsList.length) || 0;

  const navigateTo = path => {
    let {
      title = '',
      award_type_name = '',
      institute_details: {name = ''} = {},
      program,
      program_id,
    } = path;
    let url = `/pathway/${encodeURIComponent(name)}/${encodeURIComponent(
      title,
    )}/${encodeURIComponent(award_type_name)}/${program_id || program}`;
    history.push(url);
  };

  return (
    <div className='pt-3'>
      <RequestErrorLoader
        body={comparedPrograms}
        overideNoDataContainer={<div />}>
        {pathLength > 1 && (
          <div className='contentContainer'>
            <ErrorBoundary
              nameOfComponent='module-compare-paths'
              typeOfUi='subPage'>
              <h2 className='py-2'>Compare with similar programs</h2>
              <div className='compareProgramTable'>
                <table>
                  {pathLength > 0 &&
                    rowsData?.map((row, index) => (
                      <tr className='tableRow' key={index}>
                        <td className='tableData labelContainer'>
                          <div>{row.label}</div>
                        </td>
                        {comparedProgramsList &&
                          isArray(comparedProgramsList) &&
                          !isEmpty(comparedProgramsList) &&
                          comparedProgramsList.map((comparePath, index) => {
                            let data = ['Not Available'];
                            if (row.path === '$.program_duration') {
                              const durationData = durationString(comparePath);
                              data = [durationData];
                            } else {
                              data =
                                row.path &&
                                comparePath &&
                                isObject(comparePath) &&
                                jp.query(comparePath, row.path);
                              if (data && isArray(data) && !data.length) {
                                data = ['Not Available'];
                              }
                            }

                            return (
                              <td
                                className={`tableData valueContainer ${
                                  (row.image || row.learnMore) && 'alignCenter'
                                }`}>
                                {row.image ? (
                                  <LazyImage
                                    renderSrcSet
                                    alt='search banner'
                                    className='img-fluid'
                                    key={`comparePathCard-${index}`}
                                    src={comparePath?.banner_cloudinary}
                                  />
                                ) : (
                                  <></>
                                )}
                                {row.component ? (
                                  <row.component
                                    target='_blank'
                                    enableNavigation
                                    data={comparePath}
                                    key={`comparePathCard-${index}`}
                                  />
                                ) : (
                                  data &&
                                  data.map(value =>
                                    row.render ? (
                                      <p>{row.render(value)}</p>
                                    ) : row.path === '$.title' ? (
                                      <h3 title={value}>{value}</h3>
                                    ) : (
                                      <p title={value}>
                                        {value || 'Not Available'}
                                      </p>
                                    ),
                                  )
                                )}
                                {index !== 0 && row.learnMore ? (
                                  <Button
                                    type='primary'
                                    className='learnMoreBtn'
                                    onClick={() => navigateTo(comparePath)}>
                                    {compareStaticData.learnMoreBtnTxt || ''}
                                  </Button>
                                ) : (
                                  <></>
                                )}
                              </td>
                            );
                          })}
                      </tr>
                    ))}
                </table>
              </div>
            </ErrorBoundary>
          </div>
        )}
      </RequestErrorLoader>
    </div>
  );
};

export default ComparePrograms;
