import React from 'react';
import {Row, Col} from 'antd';
import {useDrop} from 'react-dnd';
import {ListItem} from 'core/components';

const TermDrop = ({
  isReadonly,
  term,
  onDrop,
  termIndex,
  onDeleteCourse,
  onSelect,
  allterms,
  cautionDisplay,
}) => {
  const [{canDrop, isOver}, drop] = useDrop({
    accept: 'TERMS_ITEM',
    drop: onDrop,
    collect: monitor => ({
      isOver: monitor.isOver(),
      canDrop: monitor.canDrop(),
    }),
  });

  const isActive = canDrop && isOver;
  let backgroundColor = '#fff';
  let noteColor = '#f9fdff';
  if (isActive) {
    backgroundColor = '#bde9fc';
    noteColor = '#def3d3';
  } else if (canDrop) {
    backgroundColor = '#bde9fc';
    noteColor = '#def3d3';
  }

  return (
    <div ref={drop} style={{backgroundColor}}>
      {term && term.data && term.data.length > 0 ? (
        <>
          <Row className='coure-header'>
            <Col span={20}>Course ID</Col>
            <Col span={4}>Units</Col>
          </Row>
          {term.data.map((data, index) => (
            <ListItem
              onDeleteCourse={isReadonly ? null : onDeleteCourse}
              key={'term-list' + index}
              data={data}
              itemType='terms-item-course-type'
              termIndex={termIndex}
              itemIndex={index}
              onClick={onSelect}
              currentIndex={`${termIndex}.${index}`}
              allSegments={allterms}
              cautionDisplay={cautionDisplay}
            />
          ))}
        </>
      ) : (
        <div className='note' style={{backgroundColor}}>
          There are currently no courses in this term.
          <br /> Drag and drop courses here.
        </div>
      )}
    </div>
  );
};

export default TermDrop;
