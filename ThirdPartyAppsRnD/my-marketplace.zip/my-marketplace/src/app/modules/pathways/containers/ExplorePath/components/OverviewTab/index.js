import React, {useState} from 'react';
import {Button, Row, Col} from 'antd';

import {skillsLearned} from 'core/utils';
import ComparePrograms from './ComparePrograms';
import {CostCard} from '../../../../sharedComponents';
import './style.less';

const OverviewTab = props => {
  const [isShowAll, setIsShowAll] = useState(false);
  const {
    pathData,
    studentOnboard,
    onStartPathwayClick,
    isCurentPathisActive,
  } = props;

  const {
    overviews = [],
    estimated_cost,
    cost_description,
    overview_description,
  } = pathData || {};

  const showCostCard = estimated_cost || cost_description;

  const OverviewDescription = () => {
    let content = overview_description || '-';
    return (
      <div className='reset' dangerouslySetInnerHTML={{__html: content}} />
    );
  };

  const onShowAllLess = () => setIsShowAll(!isShowAll);

  const OverviewContent = () => {
    if (overviews?.length) {
      return overviews.map((overview, idx) => {
        return (
          <div key={idx} className='py-2'>
            <h2>{overview.title}</h2>
            <ul>
              {overview.value.map((value, index) => {
                return (
                  <li
                    key={index}
                    className='reset'
                    dangerouslySetInnerHTML={{__html: value}}
                  />
                );
              })}
            </ul>
          </div>
        );
      });
    } else {
      return '';
    }
  };
  return (
    <>
      <Row>
        <Col
          xs={24}
          sm={24}
          md={showCostCard ? 18 : 24}
          lg={showCostCard ? 18 : 24}
          className='overviewTabs'>
          <div className='py-2'>
            <h2>About this Program</h2>
            {OverviewDescription()}
          </div>
          <div className='py-2'>
            <h2>Skills you will gain</h2>
            {skillsLearned(pathData, true, onShowAllLess, isShowAll)}
          </div>
          {OverviewContent()}
          {/* <div className='startProgramBtnContainer text-left'>
            <Button
              type='primary'
              onClick={onStartPathwayClick}
              loading={studentOnboard.request}>
              {isCurentPathisActive() ? 'CONTINUE PROGRAM' : 'START PROGRAM'}
            </Button>
          </div> */}
        </Col>
        {showCostCard && (
          <Col xs={24} sm={24} md={6} lg={6}>
            <CostCard {...props} />
          </Col>
        )}
      </Row>
      <ComparePrograms {...props} />
    </>
  );
};

export default OverviewTab;
