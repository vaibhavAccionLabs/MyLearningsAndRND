import {useState} from 'react';
import {connect} from 'react-redux';
import {useHistory} from 'react-router-dom';
import {Row, Col, Layout, Tabs} from 'antd';
import {getBanner} from 'core/utils';
import {openLoginScreen} from 'redux/modules/auth';
import {getAppConfig} from 'redux/modules/general';
import {useAuth, useInstance} from 'core/hooks';
import {ErrorBoundary, Header, ResourceCard} from 'core/components';

import {HomePageResources} from 'config';

import HOME_DATA from 'data/home';

import './style.less';
const {Content} = Layout;
const {TabPane} = Tabs;

const Home = props => {
  const [secondaryCardResource, setSecondaryCardResource] = useState({});

  const history = useHistory();
  const [token] = useAuth();
  const {data: instanceData} = useInstance();

  const {career, cardsData, bodyHeading} =
    HOME_DATA[props?.appConfig?.lang || 'en'] || HOME_DATA['en'];

  const getBannerImageStyle = () => {
    let headerStyle = {};
    if (instanceData?.institution_id && instanceData?.banner_cloudinary) {
      headerStyle = {
        backgroundImage: `url(${getBanner(instanceData?.banner_cloudinary, {
          width: props.appConfig.isMobileView ? window.screen.width : '1300',
          height: 380,
          quality: 80,
        })})`,
      };
    }
    return headerStyle;
  };

  const getBannerTitle = () => {
    let BannerTitle = career.heading;
    if (instanceData?.institution_id && instanceData?.tagline) {
      BannerTitle = instanceData?.tagline;
    }
    return BannerTitle;
  };

  const redirect = path => history.push(path);

  const pathNavigateTo = (path, checkAuth) => {
    if (checkAuth) {
      token
        ? redirect(path)
        : props.openLoginScreen({
            callback: auth => redirect(path),
          });
      return;
    }
    redirect(path);
  };

  const renderSecondaryCard = (resources, resData, d_class_name) => {
    return (
      resources?.length > 0 && (
        <Row
          className='resources_card sub_res_card m-0 p-0 text-center'
          data-cy='resource-subcards'>
          {resources?.map(({imgSrc, path, checkAuth, key}, idx) => {
            const {[key]: {heading = '', title = '', description = ''} = {}} =
              resData || {};
            return (
              <Col
                lg={6}
                md={6}
                sm={12}
                xs={15}
                key={`resource__${title}__card_${idx}`}>
                <ResourceCard
                  key={`resource__${title}__card`}
                  heading={heading}
                  title={title}
                  imgSrc={imgSrc}
                  classes={`card_design sub_${d_class_name}`}
                  description={description}
                  handleClick={() => pathNavigateTo(path, checkAuth)}
                />
              </Col>
            );
          })}
        </Row>
      )
    );
  };
  return (
    <>
      <Header
        className={instanceData?.banner_cloudinary ? 'college_banner' : ''}
        style={getBannerImageStyle()}>
        <div className='overlay'></div>
        <Row className='pt-2' justify='center' align='middle'>
          <Col xs={24} sm={24} md={24} lg={24}>
            <h1>{getBannerTitle()}</h1>
            <h5
              className='pb-3'
              dangerouslySetInnerHTML={{__html: career.desc || ''}}
            />
          </Col>
        </Row>
      </Header>
      <Content>
        <ErrorBoundary nameOfComponent='module-home' typeOfUi='subPage'>
          <section className='resources my-5'>
            <Row className='py-4  px-4' justify='center' align='middle'>
              <h2 className='text-center' data-cy='body-heading'>
                {bodyHeading || ''}
              </h2>
            </Row>
            <div className='contentContainer'>
              {/* Mobile-View Start */}
              {props.appConfig.isMobileView ? (
                <Tabs
                  className='home_path_tabs'
                  defaultActiveKey='1'
                  onChange={() => {}}>
                  {HomePageResources?.map(({subResources, key}, idx) => {
                    const {
                      [key]: {heading = '', title = '', subCardsData = {}} = {},
                    } = cardsData;
                    const Dynamic_Class_Name = `res_card_${idx + 1}`;
                    return (
                      <TabPane tab={heading || title} key={key}>
                        {renderSecondaryCard(
                          subResources,
                          subCardsData,
                          Dynamic_Class_Name,
                        )}
                      </TabPane>
                    );
                  })}
                </Tabs>
              ) : (
                <ul className='resources_card m-0 p-0 text-center'>
                  {HomePageResources?.map(
                    ({imgSrc, subResources, key}, idx) => {
                      const {
                        [key]: {
                          heading = '',
                          title = '',
                          description = '',
                          list = [],
                          subCardsData = {},
                          btn_txt,
                        } = {},
                      } = cardsData;
                      const isSameTitle =
                        secondaryCardResource?.heading === heading;
                      const Dynamic_Class_Name = `res_card_${idx + 1}`;
                      return (
                        <ResourceCard
                          key={`resource__${heading || title}__card`}
                          heading={heading}
                          title={title}
                          imgSrc={imgSrc}
                          description={description}
                          list={list}
                          btn_txt={btn_txt}
                          classes={`card_design ${Dynamic_Class_Name} ${
                            isSameTitle ? 'active' : ''
                          }`}
                          handleClick={() => {
                            const data = !isSameTitle
                              ? {
                                  subResources,
                                  subCardsData,
                                  title,
                                  heading,
                                  Dynamic_Class_Name,
                                }
                              : {};

                            setSecondaryCardResource(data);
                          }}
                        />
                      );
                    },
                  )}
                </ul>
              )}
              {secondaryCardResource?.subResources?.length > 0 &&
                renderSecondaryCard(
                  secondaryCardResource?.subResources,
                  secondaryCardResource?.subCardsData,
                  secondaryCardResource?.Dynamic_Class_Name,
                )}
            </div>
          </section>
        </ErrorBoundary>
      </Content>
    </>
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
});

export default connect(mapStateToProps, {openLoginScreen})(Home);
