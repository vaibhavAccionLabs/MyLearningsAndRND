import {useEffect, useState} from 'react';
import {Checkbox} from 'antd';
import {API} from 'config';
import {useSeeking} from 'core/hooks';

const ProfileStatus = ({data, onChange}) => {
  const [allUUIDs, setAllUUIDs] = useState([]);
  const seekingData = useSeeking();

  useEffect(() => {
    setAllUUIDs(data?.seeking?.map(item => item.seeking_uuid));
  }, [data]);

  const updateCheckBox = async (event, uuid) => {
    const updatedSeekings = event?.target?.checked
      ? [...allUUIDs, uuid]
      : allUUIDs?.filter(i => i !== uuid) || [];
    await onChange(
      'seeking',
      API.gps.student_profile,
      updatedSeekings,
      'PATCH',
    );
  };

  const maxUnchecked = !!(data?.seeking?.length === 1);

  return (
    <div className='d-flex justify-content-between mt-3 m-4'>
      {seekingData?.data?.map(({seeking_type, seeking_uuid}) => {
        const isChecked = !!allUUIDs?.includes(seeking_uuid);
        return (
          <Checkbox
            key={seeking_type}
            onChange={event => updateCheckBox(event, seeking_uuid)}
            checked={isChecked}
            disabled={isChecked && maxUnchecked}>
            {seeking_type}
          </Checkbox>
        );
      })}
    </div>
  );
};

export default ProfileStatus;
