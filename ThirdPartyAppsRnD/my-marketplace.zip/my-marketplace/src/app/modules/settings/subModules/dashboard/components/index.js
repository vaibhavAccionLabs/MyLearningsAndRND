import Resources from './Resources';

export {Resources};
