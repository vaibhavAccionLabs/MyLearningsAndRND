import {useEffect, useState} from 'react';
import {isEmpty, isArray} from 'lodash';
import {
  RequestErrorLoader,
  CourseMap,
  NoContentNavigator,
  ErrorBoundary,
} from 'core/components';
import {newSortArrayOfObjPropertyBased} from 'core/utils';

const MyCoursePlan = ({fetchMyPlan, clearMyPlan, myCoursePlan, activePath}) => {
  const {
    data: activePathData,
    request: activePathReq,
    error: activePathError,
  } = activePath;
  const {data, request, error} = myCoursePlan;
  const [programMapCoursePlan, setProgramMapCoursePlan] = useState(null);
  const [isProgramMap, setIsProgramMap] = useState(false);

  useEffect(() => {
    let PATH_DATA =
      activePathData &&
      Array.isArray(activePathData) &&
      activePathData[0]?.path_details?.terms
        ? activePathData[0].path_details
        : null;
    if (PATH_DATA?.program_map) {
      PATH_DATA = {
        ...PATH_DATA,
        terms: [
          ...PATH_DATA.terms.map(term => {
            const electiveCourses = newSortArrayOfObjPropertyBased(
              term.electives,
              'sequence',
            ).map(el => ({
              course_id: el.elective_id,
              course_type: el.course_type,
              course_name: el.elective_name,
              units: el.units,
            }));
            term.courses.push(...electiveCourses);
            return term;
          }),
        ],
      };
      setIsProgramMap(true);
      setProgramMapCoursePlan({data: PATH_DATA});
    }
  }, [activePath]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (
      activePathData &&
      Array.isArray(activePathData) &&
      !activePathData[0]?.path_details?.program_map
    ) {
      fetchMyPlan();
    }
    return () => {
      clearMyPlan();
    };
  }, [clearMyPlan, fetchMyPlan]); // eslint-disable-line react-hooks/exhaustive-deps

  let message = `No Course Map Found, Let's Find A Pathway!`;
  let dispButton = true;
  if (activePathData && isArray(activePathData) && !isEmpty(activePathData)) {
    message = 'No Course Map found, Create your academic plan';
    dispButton = false;
  }

  const VERIFY_DATA = isProgramMap ? programMapCoursePlan : myCoursePlan;

  const CourseMapData =
    !dispButton &&
    VERIFY_DATA?.data?.terms &&
    isArray(VERIFY_DATA.data.terms) &&
    !isEmpty(VERIFY_DATA.data.terms)
      ? VERIFY_DATA
      : {};

  return (
    <ErrorBoundary nameOfComponent='mod-comp-settings-myeducation-mycoursemap'>
      <RequestErrorLoader
        body={{
          data: CourseMapData,
          request: activePathReq || request,
          error: activePathError || error,
        }}
        overideNoDataContainer={
          <NoContentNavigator
            message={message}
            pathTo={dispButton ? '/search' : null}
            label={dispButton ? 'Explore Paths' : null}
          />
        }>
        <CourseMap myPlanData={CourseMapData} />
      </RequestErrorLoader>
    </ErrorBoundary>
  );
};

export default MyCoursePlan;
