import {useEffect} from 'react';
import {Modal} from 'antd';
import {isArray, isEmpty} from 'lodash';
import {
  PathCard,
  Carousel,
  RequestErrorLoader,
  NoContentNavigator,
  ErrorBoundary,
} from 'core/components';
import DeletePath from './removePathModal';

const SavedPaths = ({savedPaths, fetchSavedPaths, removeSavedPath}) => {
  useEffect(() => {
    fetchSavedPaths();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const unSavePath = ({title, uuid}) => {
    Modal.confirm({
      title: null,
      centered: true,
      width: 800,
      icon: null,
      closable: true,
      okText: 'YES',
      zIndex: 2000,
      className: 'modal-msg is-confirm',
      content: <DeletePath title={title} />,
      onOk: async () => {
        await removeSavedPath(uuid);
        await fetchSavedPaths();
      },
    });
  };

  const displayEllipses = [
    {
      title: 'Unsave',
      action: unSavePath,
      passingData: ['title', 'uuid'],
    },
  ];

  return (
    <ErrorBoundary nameOfComponent='mod-comp-settings-myeducation-savedpaths'>
      <RequestErrorLoader
        body={savedPaths}
        overideNoDataContainer={
          <NoContentNavigator
            message="No Saved Paths Found, Let's Find A Pathway!"
            pathTo='/directory/paths-list'
            label='Explore Paths'
          />
        }>
        {savedPaths.data &&
          isArray(savedPaths.data) &&
          !isEmpty(savedPaths.data) && (
            <Carousel
              config={{slidesToShow: 4}}
              data={savedPaths.data.map(path => (
                <PathCard
                  data={path?.path_details || {}}
                  displayEllipses={displayEllipses}
                  enableNavigation
                  customClass={
                    savedPaths.data.length < 4 ? 'customPathcard' : ''
                  }
                />
              ))}
            />
          )}
      </RequestErrorLoader>
    </ErrorBoundary>
  );
};

export default SavedPaths;
