import SavedPaths from './SavedPaths';
import MyActivePaths from './MyActivePaths';
import MyComparedPaths from './MyComparedPaths';
import MyCourseMap from './MyCourseMap';
import SurveyResults from './SurveyResults';
import Education from './Education';

export {
  MyActivePaths,
  SavedPaths,
  MyComparedPaths,
  MyCourseMap,
  SurveyResults,
  Education,
};
