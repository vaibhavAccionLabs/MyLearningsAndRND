import {CustomCollapse} from 'core/components';
import {getFilesAndTotalSize} from 'core/utils';
import {DocUploader} from '../../sharedComponents';
import profileData from 'data/settings-profile.json';

const ResumeAndCoverLetter = props => {
  const {
    profileData: {data, request, error},
  } = props;
  const {data: document_files, total_size_consumed} = getFilesAndTotalSize(
    data,
    'related_document',
  );
  return (
    <CustomCollapse header={profileData.resumeAndCoverData.collapseBarHeading}>
      <DocUploader
        {...props}
        profileData={{
          data: document_files,
          total_size_consumed,
          request,
          error,
        }}
      />
    </CustomCollapse>
  );
};

export default ResumeAndCoverLetter;
