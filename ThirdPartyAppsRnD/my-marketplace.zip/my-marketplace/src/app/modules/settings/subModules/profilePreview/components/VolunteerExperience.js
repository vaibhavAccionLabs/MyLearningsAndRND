import {Divider} from 'antd';
import {volunteerExperienceData} from 'data/settings-profilePreview.json';

const VolunteerExperience = ({data: voluntary_exp}) => (
  <div className='panel-section'>
    <div className='section-title'>
      {volunteerExperienceData.volunteerExperienceTitle}
    </div>
    {voluntary_exp &&
    Array.isArray(voluntary_exp) &&
    voluntary_exp.length > 0 ? (
      voluntary_exp.map((exp, idx) => {
        const Responsibilities =
          exp.roles_responsibilities.length > 0 &&
          exp.roles_responsibilities.filter(
            role => typeof role.roles_responsibilities === 'string',
          );
        return (
          <div className='_list' key={'experience-profile-' + idx}>
            {exp?.name && (
              <div className='_item'>
                <span className='_k'>
                  {volunteerExperienceData.volunteerExperienceTitle}:
                </span>
                <span className='_v'>{exp?.name}</span>
              </div>
            )}
            {exp?.hours && (
              <div className='_item'>
                <span className='_k'>
                  {volunteerExperienceData.hoursLabel}:
                </span>
                <span className='_v'>{exp?.hours}</span>
              </div>
            )}
            {Responsibilities && Responsibilities.length > 0 && (
              <div className='_item as-list'>
                <div className='_k'>
                  {volunteerExperienceData.rolesResponsibilitiesLabel}:
                </div>
                <ul className='list_blueDot'>
                  {Responsibilities.map((role, id) => (
                    <li key={`responsibility-${id}`} className='preWrapText'>
                      {role.roles_responsibilities}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {idx + 1 !== voluntary_exp.length && <Divider />}
          </div>
        );
      })
    ) : (
      <div>N/A</div>
    )}
  </div>
);

export default VolunteerExperience;
