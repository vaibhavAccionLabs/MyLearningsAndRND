import {isArray} from 'lodash';
import {RequestErrorLoader} from 'core/components';
import {useSaveProfileLoader} from 'core/hooks';
import {EditProfileWrapper} from '../../sharedComponents';
import ProfileAwards from './ProfileAwards';
import profileStaticData from 'data/settings-profile.json';

import './style.less';
import Awards from './style.module.less';

const AwardsProfile = ({onProfileDataSubmit, profileData, awardTypes}) => {
  const {error, request, data} = profileData;
  const {
    error: awardError,
    request: awardRequest,
    data: awardData,
  } = awardTypes;

  const [isLoading, onSubmit] = useSaveProfileLoader(
    request,
    onProfileDataSubmit,
  );

  const isAwardExists =
    data &&
    isArray(data.awards_leadership_projects_publications) &&
    data.awards_leadership_projects_publications.length;

  return (
    <RequestErrorLoader
      body={{request: isLoading || awardRequest, error: error || awardError}}>
      {!awardRequest && (
        <div
          className={
            isAwardExists ? Awards.awards_content : Awards.awards_no_content
          }>
          <ProfileAwards
            data={data}
            onChange={onSubmit}
            heading={profileStaticData.awardsData.collapseBarHeading}
          />
        </div>
      )}
    </RequestErrorLoader>
  );
};

export default EditProfileWrapper(AwardsProfile);
