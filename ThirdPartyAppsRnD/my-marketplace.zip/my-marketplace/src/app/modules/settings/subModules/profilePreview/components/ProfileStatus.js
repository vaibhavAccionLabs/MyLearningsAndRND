import {Checkbox} from 'antd';

import {useSeeking} from 'core/hooks';
import profilePreviewData from 'data/settings-profilePreview.json';

const ProfileStatus = ({data: student_profile}) => {
  const seekingData = useSeeking();
  const seekingInfoIDs = student_profile?.seeking?.map(
    item => item.seeking_uuid,
  );

  return (
    <div className='profile-edit-section color-rounded mb-4'>
      <div className='s-ttl'>{profilePreviewData.profileStatusHeading}</div>
      <div className='status-section'>
        <div className='d-flex justify-content-between m-4'>
          {seekingData?.data?.map(({seeking_type, seeking_uuid}) => {
            const isChecked = !!seekingInfoIDs?.includes(seeking_uuid);
            return (
              <Checkbox key={seeking_type} checked={isChecked}>
                {seeking_type}
              </Checkbox>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ProfileStatus;
