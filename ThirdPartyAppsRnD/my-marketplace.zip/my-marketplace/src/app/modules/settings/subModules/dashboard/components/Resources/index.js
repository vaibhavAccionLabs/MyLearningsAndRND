import {useHistory} from 'react-router-dom';
import {Row, Col} from 'antd';

import {ResourceCard} from 'core/components';
import {HomePageResources} from 'config';
import HOME_DATA from 'data/home';

export default props => {
  const history = useHistory();

  const {cardsData} =
    HOME_DATA[props?.appConfig?.lang || 'en'] || HOME_DATA['en'];

  const redirect = path => history.push(path);

  return (
    <div className='resources'>
      <div className='title py-4'>Resources</div>
      <Row
        className='resources_card sub_res_card px-4 text-center'
        data-cy='resourceSubcards'>
        {HomePageResources.map(res => {
          return res.subResources.map((subRes, idx) => {
            const {heading = '', title = '', description = ''} =
              cardsData[res?.key]?.subCardsData[subRes?.key] || {};
            return (
              subRes.alsoDispInDashboard && (
                <Col
                  lg={6}
                  md={6}
                  sm={12}
                  xs={15}
                  key={`resource__${title}__card_${idx}`}>
                  <ResourceCard
                    key={`resource__${title}__card`}
                    heading={heading}
                    title={title}
                    imgSrc={subRes?.imgSrc}
                    classes={`card_design mb-5`}
                    description={description}
                    handleClick={() => redirect(subRes?.path)}
                  />
                </Col>
              )
            );
          });
        })}
      </Row>
    </div>
  );
};
