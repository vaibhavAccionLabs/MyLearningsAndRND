import DocUploader from './docUploader';
import EditProfileWrapper from './EditProfileWrapper';

export {DocUploader, EditProfileWrapper};
