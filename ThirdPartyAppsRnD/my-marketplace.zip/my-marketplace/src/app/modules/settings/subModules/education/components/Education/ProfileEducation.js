import React, {useState} from 'react';
import {
  Button,
  Divider,
  Form,
  DatePicker,
  Checkbox,
  Row,
  Col,
  Select,
} from 'antd';
import {DeleteOutlined, EditOutlined} from '@ant-design/icons';
import moment from 'moment';

import {API} from 'config';

import {formatViewDate} from 'core/utils';
import {CountField} from 'core/components';

const awardTypes = [
  {label: 'Professional Certificate', value: 'professional_certificate'},
  {label: 'Associate Degree', value: 'associate_degre'},
  {label: 'Bachelor Degree', value: 'bachelor_degree'},
  {label: 'Graduate Degree', value: 'graduate_degree'},
  {label: 'Master Degree', value: 'master_degree'},
  {label: 'Doctoral Degree', value: 'doctoral_degree'},
  {label: 'Professional Degree', value: 'professional_degree'},
  {label: 'Specialist Degree', value: 'specialist_degree'},
  {label: 'Other', value: 'other'},
];

const layout = {
  labelCol: {span: 9},
  wrapperCol: {span: 15},
};

const AddEducation = ({edit, onCancel, onSubmit, data = {}}) => {
  const [form] = Form.useForm();
  const [fileds, setFields] = useState({
    is_present: data.is_present,
  });
  const onFinish = v => {
    if (onSubmit) onSubmit(v);
  };
  const onPresentChecked = () => {
    form.resetFields(['school_end_date']);
    form.setFieldsValue({school_end_date: ''});
  };

  const disabledStartDate = v => {
    const end_date = form.getFieldValue('school_end_date');
    const present = form.getFieldValue('is_present');
    let disable = false;
    disable = moment(v).isAfter(new Date());
    if (!disable && !present) disable = moment(v).isAfter(end_date);
    return disable;
  };
  const disabledEndDate = v => {
    const start_date = form.getFieldValue('school_start_date');
    let disable = false;
    disable = moment(v).isAfter(new Date());
    if (!disable) disable = moment(v).isBefore(start_date);
    return disable;
  };
  return (
    <div>
      <Form
        size={'large'}
        {...layout}
        form={form}
        name='basic'
        onFinish={onFinish}
        onValuesChange={(c, a) => setFields(a)}
        initialValues={{remember: true}}
        // onFinish={onFinish}
        // onFinishFailed={onFinishFailed}
      >
        <Form.Item
          label='School'
          name='school_name'
          className='field-input'
          initialValue={data.school_name}
          rules={[{required: true, message: 'School Name is required'}]}>
          <CountField
            placeholder='Enter School Name'
            showcount
            className='field-input'
            fieldtype='Input'
            maxLength={60}
          />
        </Form.Item>
        <Form.Item
          label='Date Started'
          name='school_start_date'
          initialValue={
            data.school_start_date
              ? moment(data.school_start_date, 'YYYY-MM-DD')
              : ''
          }
          className='input-date-picker'
          rules={[{required: true, message: 'Date is required'}]}>
          <DatePicker
            placeholder={'mm/dd/yyyy'}
            disabledDate={disabledStartDate}
            format={'MM-DD-YYYY'}
          />
        </Form.Item>
        <Form.Item
          label='Date Finished'
          className='edu_date_split'
          style={{marginBottom: 0}}>
          <Form.Item
            name='school_end_date'
            className='input-date-picker mob_split_item'
            initialValue={
              data.school_end_date
                ? moment(data.school_end_date, 'YYYY-MM-DD')
                : ''
            }
            style={{display: 'inline-block', width: 'calc(50% - 12px)'}}
            rules={[
              {
                required: fileds.is_present !== true,
                message: 'Date is required',
              },
            ]}>
            <DatePicker
              placeholder={'mm/dd/yyyy'}
              disabledDate={disabledEndDate}
              disabled={fileds.is_present === true}
              format={'MM-DD-YYYY'}
            />
          </Form.Item>
          <Form.Item
            name='is_present'
            className='mob_split_chk'
            initialValue={data.is_present}
            valuePropName={'checked'}
            style={{display: 'inline-block', width: 'calc(50% - 12px)'}}>
            <Checkbox onChange={onPresentChecked}>Present</Checkbox>
          </Form.Item>
        </Form.Item>
        {/* <Form.Item
          label='Degree/Award Recieved'
          name='degree_award'
          className='field-input'
          initialValue={data.degree_award}
          rules={[{required: true, message: 'Degree/Award is required'}]}>
          <CountField
            placeholder='Enter Degree/Award'
            className='field-textarea'
            fieldtype={'Input'}
            showcount
            maxLength={60}
          />
        </Form.Item> */}
        <Form.Item
          label='Degree/Award'
          name='degree_award'
          className='field-input'
          initialValue={data.degree_award}
          // rules={[{required: true, message: 'Degree/Award is required'}]}
        >
          <Select className='field-select' placeholder='Degree/Award Received'>
            {awardTypes.map(award => (
              <Select.Option value={award.label} key={award.value}>
                {award.label}
              </Select.Option>
            ))}
          </Select>
        </Form.Item>
        <div className='input-arrays'>
          <Form.Item
            label='Area of Focus/ Major'
            name='area_of_focus'
            className='field-input field-textarea'
            initialValue={data.area_of_focus}
            rules={
              [
                // {required: true, message: 'Area of Focus/ Major is required'},
              ]
            }>
            <CountField
              placeholder='Area of Focus/ Major'
              autoSize={{minRows: 1, maxRows: 6}}
              className='field-input'
              fieldtype='Input'
              showcount
              maxLength={60}
            />
          </Form.Item>
        </div>
        <Form.Item label='Comments' style={{marginBottom: 0}}>
          <Form.List
            name='education_comments'
            initialValue={data.comments ? data.comments : ['']}>
            {(fields, {add, remove}) => (
              <div>
                {fields.map(({key, name, fieldKey, ...restField}, idx) => (
                  <div className='input-arrays' key={idx}>
                    <Form.Item
                      {...restField}
                      name={[name, 'comments']}
                      fieldKey={[fieldKey, 'comments']}
                      className='field-input field-textarea'>
                      <CountField
                        placeholder={'Enter Comments'}
                        className='field-textarea'
                        fieldtype={'TextArea'}
                        autoSize={{minRows: 1, maxRows: 6}}
                        showcount
                        maxLength={100}
                      />
                    </Form.Item>
                    {idx != 0 && (
                      <DeleteOutlined
                        onClick={() => remove(name)}
                        className={'delete-input-icon'}
                      />
                    )}
                  </div>
                ))}
                <Row justify={'end'} className='actn-section-link'>
                  <Col>
                    <Button type='link' onClick={() => add()}>
                      + Add Comment
                    </Button>
                  </Col>
                </Row>
              </div>
            )}
          </Form.List>
        </Form.Item>

        <div className='s-actn is-right'>
          <Button
            className='btn btn-cancel'
            type={'primary'}
            onClick={onCancel}>
            Cancel
          </Button>
          <Button className='btn' type={'primary'} htmlType={'submit'}>
            {edit ? 'Save' : 'Add'}
          </Button>
        </div>
      </Form>
    </div>
  );
};

const getEarnedCredentials = data => {
  if (Array.isArray(data)) {
    const credentials = [];
    data.forEach(d => {
      if (credentials.indexOf(d.degree_award) === -1) {
        credentials.push(d.degree_award);
      }
    });
    return credentials;
  }
  return [];
};

const ProfileEducation = ({data, onChange, viewOnly}) => {
  const {education} = data || {};
  const [isAdd, setAdd] = useState(false);
  const [editIndex, setEditIndex] = useState(-1);
  const cancelAddEdit = () => {
    setAdd(false);
    setEditIndex(-1);
  };
  const formatData = (v, id) => {
    const data = {...v};
    data['school_start_date'] = v['school_start_date'].format('YYYY-MM-DD');
    if (v['school_end_date'])
      data['school_end_date'] = v['school_end_date'].format('YYYY-MM-DD');
    if (!v['school_end_date']) data['school_end_date'] = null;
    if (v?.education_comments?.length > 0) {
      data['education_comments'] = v.education_comments?.map(i => i.comments);
    }
    if (id) {
      data['education_uuid'] = id;
    }
    return data;
  };
  const onAddEducation = async v => {
    if (onChange) {
      await onChange(false, API.gps.education, formatData(v), 'POST', false);
      cancelAddEdit();
    }
  };
  const onEdit = async (v, id) => {
    if (onChange) {
      await onChange(false, API.gps.education, formatData(v), 'PATCH', id);
      cancelAddEdit();
    }
  };
  const editData = idx => {
    setAdd(false);
    setEditIndex(idx);
  };
  const deleteEducation = itm => {
    if (onChange)
      onChange(false, API.gps.education, {}, 'DELETE', itm.education_uuid);
  };

  const earnedCredentials = getEarnedCredentials(education);
  return (
    <div className='profile-edit-section education_profile_tabs'>
      <div className='s-ttl'></div>
      <div className='s-con'>
        {education &&
          Array.isArray(education) &&
          education?.map((edu, idx) =>
            editIndex === idx ? (
              <div className='s-section max-width' key={idx}>
                <AddEducation
                  data={edu}
                  edit={true}
                  onSubmit={v => onEdit(v, edu.education_uuid)}
                  onCancel={cancelAddEdit}
                />
                <Divider />
              </div>
            ) : (
              <div className='list-itm' key={idx}>
                {!viewOnly && (
                  <div className='list-actns'>
                    <EditOutlined onClick={() => editData(idx)} />
                    <DeleteOutlined onClick={() => deleteEducation(edu)} />
                  </div>
                )}

                <div className='list-itm-r'>
                  <span className='lbl'>School:</span>
                  <span className='val'>{edu.school_name}</span>
                </div>
                <div className='list-itm-r'>
                  <span className='lbl'>Attended:</span>
                  <span className='val'>
                    {formatViewDate(edu.school_start_date)} -{' '}
                    {edu.is_present
                      ? 'Present'
                      : formatViewDate(edu.school_end_date)}
                  </span>
                </div>
                <div className='list-itm-r'>
                  <span className='lbl'>Degree/Award:</span>
                  <span className='val'>{edu.degree_award || '-'}</span>
                </div>
                <div className='list-itm-r'>
                  <span className='lbl'>Area of Focus/ Major:</span>
                  <span className='val'>{edu.area_of_focus || '-'}</span>
                </div>
                {edu.comments &&
                edu.comments.length > 0 &&
                edu.comments[0].comments ? (
                  <div className='list-itm-r'>
                    <span className='lbl'>Comments:</span>
                    <div className='list-bullets'>
                      {edu.comments &&
                        edu.comments.map((cmt, idx) => (
                          <div className='itm wrap-content' key={idx}>
                            {cmt.comments}
                          </div>
                        ))}
                    </div>
                  </div>
                ) : null}
                {idx !== education.length - 1 && <Divider />}
              </div>
            ),
          )}
        {!education ||
          !Array.isArray(education) ||
          (education.length === 0 && (
            <div className='empty-ct'>No educations added.</div>
          ))}
      </div>
      {!viewOnly && (
        <>
          {isAdd && (
            <div className='s-con outerBorder' style={{maxWidth: 600}}>
              <AddEducation
                onCancel={cancelAddEdit}
                onSubmit={onAddEducation}
              />
            </div>
          )}
          {!isAdd && editIndex === -1 && (
            <div className='s-actn'>
              <Button
                className='btn btn-blue-outer'
                onClick={() => setAdd(true)}>
                Add Education
              </Button>
            </div>
          )}
        </>
      )}
      {education && earnedCredentials.length > 0 && (
        <div className='earn'>
          <h3>Earned Credentials</h3>
          <div className='earn-tag'>
            {earnedCredentials.map(c => (
              <span key={c}>{c}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
export default ProfileEducation;
