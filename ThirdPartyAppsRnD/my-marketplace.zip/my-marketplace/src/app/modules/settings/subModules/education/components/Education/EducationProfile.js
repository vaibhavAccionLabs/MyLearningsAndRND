import {RequestErrorLoader} from 'core/components';
import {useSaveProfileLoader} from 'core/hooks';

import {EditProfileWrapper} from '../../../profile/sharedComponents';
import ProfileEducation from './ProfileEducation';

import './style.less';
import '../../../profile/sharedComponents/style.less';
import Education from './style.module.less';

const EducationProfile = ({onProfileDataSubmit, profileData}) => {
  const {request, error, data} = profileData;
  const [isLoading, onSubmit] = useSaveProfileLoader(
    request,
    onProfileDataSubmit,
  );
  return (
    <RequestErrorLoader body={{request: isLoading || request, error}}>
      <div
        className={
          data && data.education.length > 0
            ? Education.edu_content
            : Education.edu_no_content
        }>
        <ProfileEducation data={data} onChange={onSubmit} />
      </div>
    </RequestErrorLoader>
  );
};

export default EditProfileWrapper(EducationProfile);
