import React, {useState} from 'react';
import {Form, Button, Tag, Input} from 'antd';

import {API} from 'config';
import profileData from 'data/settings-profile.json';

const ProfileInterests = ({data, onChange, viewOnly}) => {
  const {interest} = data || {};
  const [isAdd, setAdd] = useState(false);
  const [tags, setTag] = useState([]);

  const addInterests = () => {
    setTag(interest || []);
    setAdd(true);
  };
  const onDeleteInterest = async idx => {
    let newTags = [...(interest ? interest : [])];
    newTags.splice(idx, 1);
    if (onChange) {
      await onChange(
        'interest',
        API.gps.student_profile,
        [...newTags],
        'PATCH',
      );
      setAdd(false);
    }
  };

  const onTagSubmit = async ({tag}) => {
    if (tag) {
      await onChange(
        'interest',
        API.gps.student_profile,
        [...(tags ? [...tags, tag] : [])],
        'PATCH',
      );
      setAdd(false);
    }
  };

  return (
    <div className='profile-edit-section'>
      <div className='s-ttl'>{profileData.yourInterestData.interestTitle}</div>
      <div className='s-con'>
        {interest &&
          interest.map((i, idx) => (
            <Tag
              color='#E6E7FF'
              className='tag-list-item'
              onClose={() => onDeleteInterest(idx)}
              closable={!viewOnly}
              key={i}>
              {i}
            </Tag>
          ))}
        {!interest ||
          !Array.isArray(interest) ||
          (interest.length === 0 && (
            <div className='empty-ct'>
              {profileData.yourInterestData.noInterestAddedTxt}
            </div>
          ))}
        {isAdd && (
          <div>
            <br />
            <Form
              name='add-tag'
              onFinish={onTagSubmit}
              onFinishFailed={err => console.log(err)}>
              <Form.Item name='tag'>
                <Input placeholder='Add Interest' />
              </Form.Item>
              <Form.Item name='tag'>
                <Button className='btn' htmlType='submit' type='primary'>
                  {profileData.addBtnTxt}
                </Button>
                <Button
                  className='btn btn-cancel'
                  onClick={() => setAdd(false)}>
                  {profileData.cancelBtnTxt}
                </Button>
              </Form.Item>
            </Form>
          </div>
        )}
      </div>
      {!viewOnly && (
        <div className='s-actn'>
          {!isAdd && (
            <Button className='btn btn-purple-outer' onClick={addInterests}>
              {profileData.yourInterestData.addInterestBtn}
            </Button>
          )}
        </div>
      )}
    </div>
  );
};

export default ProfileInterests;
