import {useEffect} from 'react';
import {connect} from 'react-redux';
//Local Components
import {ContentHeader} from '../../components';
import {
  SavedPaths,
  MyActivePaths,
  MyComparedPaths,
  MyCourseMap,
  SurveyResults,
  Education as ProfileEducation,
} from './components';
import {
  //api calls
  fetchComparePathsList,
  fetchSavedPaths,
  fetchActivePathData,
  fetchMyPlan,
  //actions
  clearMyPlan,
  removeSavedPath,
  savedPathSelector,
  deleteActivePath,
  deleteComparedPath,
  //selectors
  getMyPlan,
  getActivePath,
  getComparePathDetails,
} from 'redux/modules/pathways';
import {
  getCareerInterestSurveyQuestions,
  fetchCareerInterestQuestions,
  saveCareerInterestSurvey,
  getCareerInterestSurveyResults,
} from 'redux/modules/survey';
import {fetchClusters, getClusters} from 'redux/modules/search';
import {fetchProfileData, profileDataSelector} from 'redux/modules/profile';
import {ErrorBoundary} from 'core/components';
import './style.less';

const Education = props => {
  const {profileData, fetchProfileData} = props;
  useEffect(() => {
    if (!profileData?.data && !profileData.request) {
      fetchProfileData();
    }
    return () => {};
  }, [profileData]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <ErrorBoundary
      nameOfComponent='module-settings-my-education'
      typeOfUi='subPage'>
      <div className='profile-education'>
        <ContentHeader title='My Education' />
        <div className='collapse-content'>
          <ProfileEducation {...props} />
          <MyActivePaths {...props} />
          <MyCourseMap {...props} />
          <SurveyResults {...props} />
          <SavedPaths {...props} />
          {/* MyComparedPaths is not required */}
          {/* <MyComparedPaths {...props} /> */}
        </div>
      </div>
    </ErrorBoundary>
  );
};

const mapStateToProps = state => ({
  profileData: profileDataSelector(state),
  comparePathData: getComparePathDetails(state),
  savedPaths: savedPathSelector(state),
  activePath: getActivePath(state),
  myCoursePlan: getMyPlan(state),
  clusters: getClusters(state),
  careerInterest: getCareerInterestSurveyQuestions(state),
});

export default connect(mapStateToProps, {
  fetchComparePathsList,
  fetchActivePathData,
  fetchSavedPaths,
  fetchMyPlan,
  clearMyPlan,
  removeSavedPath,
  deleteActivePath,
  deleteComparedPath,
  fetchCareerInterestQuestions,
  saveCareerInterestSurvey,
  getCareerInterestSurveyResults,
  fetchClusters,
  fetchProfileData,
})(Education);
