import {CustomCollapse} from 'core/components';
import DeclaredInterests from './DeclaredInterests';
import profileData from 'data/settings-profile.json';

const DeclaredInterestsWrapper = props => {
  return (
    <CustomCollapse header={profileData.yourInterestData.collapseBarHeading}>
      <DeclaredInterests {...props} />
    </CustomCollapse>
  );
};

export default DeclaredInterestsWrapper;
