import {Switch} from 'antd';
import {CustomCollapse} from 'core/components';
import {useSaveProfileLoader} from 'core/hooks';
import {API} from 'config';
import {EditProfileWrapper} from '../../sharedComponents';
import StatusData from './StatusData';
import profileStaticData from 'data/settings-profile.json';

const Status = props => {
  const {onProfileDataSubmit, profileData} = props;
  const {request, error, data} = profileData;
  const [isLoading, onSubmit] = useSaveProfileLoader(
    request,
    onProfileDataSubmit,
  );

  const onPublishChange = value => {
    onSubmit('display_profile', API.gps.student_profile, value, 'PATCH');
  };

  return (
    <CustomCollapse
      header={profileStaticData.profileStatusData.collapseBarHeading}
      defaultOpen
      hideExpandIcon
      extraNode={
        <span>
          {
            profileStaticData.profileStatusData
              .publishProfileExchangeToggleLabel
          }{' '}
          &nbsp;
          <Switch
            className='profile_status'
            onChange={onPublishChange}
            checked={data?.display_profile}
            loading={isLoading || (!data && request)}
          />
        </span>
      }>
      <StatusData {...props} />
    </CustomCollapse>
  );
};

export default EditProfileWrapper(Status);
