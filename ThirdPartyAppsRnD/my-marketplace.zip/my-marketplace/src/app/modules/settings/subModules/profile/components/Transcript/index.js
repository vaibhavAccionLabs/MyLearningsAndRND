import {CustomCollapse} from 'core/components';
import {getFilesAndTotalSize} from 'core/utils';
import {DocUploader} from '../../sharedComponents';
import profileData from 'data/settings-profile.json';

const Transcript = props => {
  const {
    profileData: {data, request, error},
  } = props;
  const {data: transcripts_files, total_size_consumed} = getFilesAndTotalSize(
    data,
    'transcript',
  );
  return (
    <CustomCollapse header={profileData.transcriptsData.collapseBarHeading}>
      <DocUploader
        {...props}
        profileData={{
          data: transcripts_files,
          total_size_consumed,
          request,
          error,
        }}
        type='transcript'
        label={profileData.transcriptsData.addTranscriptBtn}
      />
    </CustomCollapse>
  );
};

export default Transcript;
