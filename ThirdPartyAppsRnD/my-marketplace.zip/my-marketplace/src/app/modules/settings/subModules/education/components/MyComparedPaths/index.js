import {CustomCollapse} from 'core/components';
import MyComparedPaths from './myComparedPaths';

const MyEdComparedPaths = props => {
  return (
    <div className='myComparePaths-content'>
      <CustomCollapse header='My Compared Paths'>
        <MyComparedPaths {...props} />
      </CustomCollapse>
    </div>
  );
};

export default MyEdComparedPaths;
