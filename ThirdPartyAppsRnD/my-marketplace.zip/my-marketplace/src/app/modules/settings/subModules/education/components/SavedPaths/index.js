import {CustomCollapse} from 'core/components';
import SavedPaths from './savedPaths';
import './style.less';
const WorkforceSavedPaths = props => {
  return (
    <div className='savedPath-content'>
      <CustomCollapse header='My Saved Paths'>
        <SavedPaths {...props} />
      </CustomCollapse>
    </div>
  );
};

export default WorkforceSavedPaths;
