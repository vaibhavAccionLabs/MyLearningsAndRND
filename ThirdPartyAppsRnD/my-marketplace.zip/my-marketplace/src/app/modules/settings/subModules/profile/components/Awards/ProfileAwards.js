import React, {useEffect, useState} from 'react';
import {Button, Divider, Form, Select, Row, Col} from 'antd';
import {DeleteOutlined, EditOutlined} from '@ant-design/icons';
import {connect} from 'react-redux';

import {fetchAwardTypes, awardTypesSelector} from 'redux/modules/profile';
import {API} from 'config';
import {CountField} from 'core/components';
import profileData from 'data/settings-profile.json';

const layout = {
  labelCol: {span: 8},
  wrapperCol: {span: 16},
};
const AddProfileAwards = ({
  edit,
  awardTypes,
  onCancel,
  onSubmit,
  data = {},
}) => {
  const {data: awardTypeData} = awardTypes;
  const onFinish = v => {
    if (onSubmit) onSubmit(v);
  };

  return (
    <div className='s-section'>
      <Form size={'large'} {...layout} name='basic' onFinish={onFinish}>
        <Form.Item
          label={profileData.awardsData.itemType.label}
          name='item_type'
          className='field-select'
          initialValue={data.item_type}
          rules={[
            {
              required: true,
              message: profileData.awardsData.itemType.requiredMsg,
            },
          ]}>
          <Select placeholder={profileData.awardsData.itemType.placeholder}>
            {Array.isArray(awardTypeData) &&
              awardTypeData.map(type => (
                <Select.Option
                  key={type.item_type_uuid}
                  value={type.item_type_uuid}>
                  {type.item_type}
                </Select.Option>
              ))}
          </Select>
        </Form.Item>
        <Form.Item
          label={profileData.awardsData.itemName.label}
          name='item_title'
          className='field-input'
          initialValue={data.item_title}
          rules={[
            {
              required: true,
              message: profileData.awardsData.itemName.requiredMsg,
            },
          ]}>
          <CountField
            placeholder={profileData.awardsData.itemName.placeholder}
            fieldtype={'Input'}
            showcount
            maxLength={60}
          />
        </Form.Item>
        <Form.Item
          label={profileData.awardsData.additionalInformation.label}
          style={{marginBottom: 0}}>
          <Form.List
            name='additional_info'
            initialValue={data.comments || ['']}>
            {(fields, {add, remove}) => (
              <div>
                {fields.map(({key, name, fieldKey, ...restField}, idx) => (
                  <div className='input-arrays' key={idx}>
                    <Form.Item
                      name={[name, 'additional_info']}
                      fieldKey={[fieldKey, 'additional_info']}
                      className='field-input field-textarea'>
                      <CountField
                        placeholder={
                          profileData.awardsData.additionalInformation
                            .placeholder
                        }
                        className='field-textarea'
                        fieldtype={'TextArea'}
                        autoSize={{minRows: 1, maxRows: 6}}
                        showcount
                        maxLength={250}
                      />
                    </Form.Item>
                    {idx != 0 && (
                      <DeleteOutlined
                        onClick={() => remove(name)}
                        className={'delete-input-icon'}
                      />
                    )}
                  </div>
                ))}
                <Row justify={'end'} className='actn-section-link'>
                  <Col>
                    <Button type='link' onClick={() => add()}>
                      {profileData.addRoleBtnTxt}
                    </Button>
                  </Col>
                </Row>
              </div>
            )}
          </Form.List>
        </Form.Item>

        <div className='s-actn is-right'>
          <Button
            className='btn btn-cancel'
            type={'primary'}
            onClick={onCancel}>
            {profileData.cancelBtnTxt}
          </Button>
          <Button className='btn' type={'primary'} htmlType={'submit'}>
            {edit ? profileData.saveBtnTxt : profileData.addBtnTxt}
          </Button>
        </div>
      </Form>
    </div>
  );
};

const ProfileAwards = ({
  data,
  heading,
  onChange,
  viewOnly,
  awardTypes,
  fetchAwardTypes,
}) => {
  const {awards_leadership_projects_publications: awards} = data || {};
  const [isAdd, setAdd] = useState(false);
  const [editIndex, setEditIndex] = useState(-1);
  useEffect(() => {
    if (awardTypes && !awardTypes.data && fetchAwardTypes) fetchAwardTypes();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const cancelAddEdit = () => {
    setAdd(false);
    setEditIndex(-1);
  };
  const getAwardType = id => {
    const {data: awardTypesData = {}} = awardTypes || {};
    if (Array.isArray(awardTypesData)) {
      const idx = awardTypesData.map(i => i.item_type_uuid).indexOf(id);
      return awardTypesData[idx]?.item_type;
    } else {
      return id;
    }
  };
  const formatData = (v, id) => {
    const data = {...v};
    if (
      v?.additional_info &&
      Array.isArray(v?.additional_info) &&
      v.additional_info.length > 0
    ) {
      data['additional_info'] = v.additional_info.map(i => i.additional_info);
    }
    if (id) {
      data['award_info_uuid'] = id;
    }
    return data;
  };
  const onVolunteerExperience = async v => {
    if (onChange)
      await onChange(
        false,
        API.gps.awards_leadership,
        formatData(v),
        'POST',
        false,
      );
    cancelAddEdit();
  };
  const onEdit = async (v, id) => {
    if (onChange)
      await onChange(
        false,
        API.gps.awards_leadership,
        formatData(v, id),
        'PATCH',
        id,
      );
    cancelAddEdit();
  };
  const editData = idx => {
    setAdd(false);
    setEditIndex(idx);
  };
  const deleteAwards = async data => {
    if (onChange)
      await onChange(
        false,
        API.gps.awards_leadership,
        {},
        'DELETE',
        data.award_info_uuid,
      );
    cancelAddEdit();
  };
  return (
    <div className={'profile-edit-section' + (viewOnly ? ' rounded ' : '')}>
      <div className='s-ttl'>{heading}</div>
      <div className='s-con mb-4 mt-1'>
        {awards &&
          awards.map((item, idx) =>
            editIndex === idx ? (
              <div style={{maxWidth: 500}} key={idx}>
                <AddProfileAwards
                  data={item}
                  edit
                  awardTypes={awardTypes}
                  onSubmit={v => onEdit(v, item.award_info_uuid)}
                  onCancel={cancelAddEdit}
                />
                <Divider />
              </div>
            ) : (
              <div className='list-itm' key={idx}>
                {!viewOnly && (
                  <div className='list-actns'>
                    <EditOutlined onClick={() => editData(idx)} />
                    <DeleteOutlined onClick={() => deleteAwards(item)} />
                  </div>
                )}

                <div className='list-itm-r'>
                  <span className='lbl'>{getAwardType(item.item_type)}:</span>
                  <span className='val'>{item.item_title}</span>
                </div>
                <div className='list-itm-r'>
                  {/* <span className='lbl'>Roles and Responsibilities:</span> */}
                  <div className='list-bullets'>
                    {item.comments &&
                      item.comments.map((info, idx) => {
                        if (info.additional_info)
                          return (
                            <div className='itm wrap-content' key={idx}>
                              {info.additional_info}
                            </div>
                          );
                      })}
                  </div>
                </div>
                <Divider />
              </div>
            ),
          )}
        {!awards ||
          !Array.isArray(awards) ||
          (awards.length === 0 && (
            <div className='empty-ct'>
              {profileData.awardsData.noAwardsAddedTxt}
            </div>
          ))}
      </div>
      {!viewOnly && (
        <>
          {isAdd && (
            <div className='s-con' style={{maxWidth: 600}}>
              <AddProfileAwards
                onCancel={cancelAddEdit}
                awardTypes={awardTypes}
                onSubmit={onVolunteerExperience}
              />
            </div>
          )}
          {!isAdd && editIndex === -1 && (
            <div className='s-actn'>
              <Button
                className='btn btn-purple-outer'
                onClick={() => setAdd(true)}>
                {profileData.awardsData.addItemBtn}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

const mapStateToProps = state => ({
  awardTypes: awardTypesSelector(state),
});
export default connect(mapStateToProps, {
  fetchAwardTypes,
})(ProfileAwards);
