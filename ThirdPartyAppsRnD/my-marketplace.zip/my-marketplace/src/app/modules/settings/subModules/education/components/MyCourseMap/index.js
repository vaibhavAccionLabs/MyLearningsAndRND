import {CustomCollapse} from 'core/components';
import MyCoursePlan from './myCoursePlan';

const MyCourseMap = props => {
  return (
    <div className='myCourseMap-content'>
      <CustomCollapse header='My Course Map'>
        <MyCoursePlan {...props} />
      </CustomCollapse>
    </div>
  );
};

export default MyCourseMap;
