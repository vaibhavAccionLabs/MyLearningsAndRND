import React, {useState} from 'react';
import {Button, Divider, Form, DatePicker, Checkbox, Row, Col} from 'antd';
import {DeleteOutlined, EditOutlined} from '@ant-design/icons';
import moment from 'moment';

import {API} from 'config';
import {formatViewDate} from 'core/utils';
import {CountField} from 'core/components';
import profileData from 'data/settings-profile.json';

const layout = {
  labelCol: {span: 8},
  wrapperCol: {span: 16},
};
const AddWorkExperience = ({edit, onCancel, onSubmit, data = {}}) => {
  const [form] = Form.useForm();
  const [fileds, setFields] = useState({
    is_present: data.is_present,
  });
  const onFinish = v => {
    if (onSubmit) onSubmit(v);
  };
  const onPresentChecked = () => {
    form.resetFields(['end_date']);
    form.setFieldsValue({end_date: ''});
  };

  const disabledStartDate = v => {
    const end_date = form.getFieldValue('end_date');
    const present = form.getFieldValue('is_present');
    let disable = false;
    disable = moment(v).isAfter(new Date());
    if (!disable && !present) disable = moment(v).isAfter(end_date);
    return disable;
  };
  const disabledEndDate = v => {
    const start_date = form.getFieldValue('start_date');
    let disable = false;
    disable = moment(v).isAfter(new Date());
    if (!disable) disable = moment(v).isBefore(start_date);
    return disable;
  };

  return (
    <div className='s-section'>
      <Form
        size={'large'}
        form={form}
        {...layout}
        name='basic'
        onValuesChange={(c, a) => setFields(a)}
        onFinish={onFinish}>
        <Form.Item
          label={profileData.workExperienceData.company.label}
          name='company_name'
          className='field-input'
          initialValue={data.company_name}
          rules={[
            {
              required: true,
              message: profileData.workExperienceData.company.requiredMsg,
            },
          ]}>
          <CountField
            placeholder={profileData.workExperienceData.company.placeholder}
            fieldtype={'Input'}
            showcount
            maxLength={60}
          />
        </Form.Item>
        <Form.Item
          label={profileData.workExperienceData.location.label}
          name='job_location'
          className='field-input'
          initialValue={data.job_location}
          rules={[
            {
              required: true,
              message: profileData.workExperienceData.location.requiredMsg,
            },
          ]}>
          <CountField
            placeholder={profileData.workExperienceData.location.placeholder}
            fieldtype={'Input'}
            showcount
            maxLength={60}
          />
        </Form.Item>
        <Form.Item
          label={profileData.workExperienceData.dateStarted.label}
          name='start_date'
          initialValue={
            data.start_date ? moment(data.start_date, 'YYYY-MM-DD') : ''
          }
          className='input-date-picker mob_fullwidth'
          rules={[
            {
              required: true,
              message: profileData.workExperienceData.dateStarted.requiredMsg,
            },
          ]}>
          <DatePicker
            disabledDate={disabledStartDate}
            placeholder={'mm/dd/yyyy'}
            format={'MM-DD-YYYY'}
          />
        </Form.Item>
        <Form.Item
          label={profileData.workExperienceData.dateFinish.label}
          style={{marginBottom: 0}}>
          <Form.Item
            name='end_date'
            className='input-date-picker mob_date_start'
            initialValue={
              data.end_date ? moment(data.end_date, 'YYYY-MM-DD') : ''
            }
            style={{display: 'inline-block', width: 'calc(50% - 12px)'}}
            rules={[
              {
                required: fileds.is_present !== true,
                message: profileData.workExperienceData.dateFinish.requiredMsg,
              },
            ]}>
            <DatePicker
              disabledDate={disabledEndDate}
              disabled={fileds.is_present === true}
              placeholder={'mm/dd/yyyy'}
              format={'MM-DD-YYYY'}
            />
          </Form.Item>
          <Form.Item
            name='is_present'
            className='mob_date_chk'
            valuePropName={'checked'}
            initialValue={data && data.is_present}
            style={{display: 'inline-block', width: 'calc(50% - 12px)'}}>
            <Checkbox onChange={onPresentChecked}>
              {profileData.workExperienceData.presentTxt}
            </Checkbox>
          </Form.Item>
        </Form.Item>
        <Form.Item
          label={profileData.workExperienceData.position.label}
          name='job_title'
          className='field-input'
          initialValue={data.job_title}
          rules={[
            {
              required: true,
              message: profileData.workExperienceData.position.requiredMsg,
            },
          ]}>
          <CountField
            placeholder={profileData.workExperienceData.position.placeholder}
            fieldtype={'Input'}
            showcount
            maxLength={60}
          />
        </Form.Item>
        <Form.Item
          label={profileData.workExperienceData.roleResponsibilities.label}
          style={{marginBottom: 0}}>
          <Form.List
            name='job_responsibilities'
            initialValue={data.job_responsibilities || ['']}>
            {(fields, {add, remove}) => (
              <div>
                {fields.map(({key, name, fieldKey, ...restField}, idx) => (
                  <div className='input-arrays' key={idx}>
                    <Form.Item
                      name={[name, 'job_responsibilities']}
                      fieldKey={[fieldKey, 'job_responsibilities']}
                      className='field-input field-textarea'>
                      <CountField
                        placeholder={
                          profileData.workExperienceData.roleResponsibilities
                            .placeholder
                        }
                        className='field-textarea'
                        fieldtype={'TextArea'}
                        autoSize={{minRows: 1, maxRows: 6}}
                        showcount
                        maxLength={250}
                      />
                    </Form.Item>
                    {idx != 0 && (
                      <DeleteOutlined
                        onClick={() => remove(name)}
                        className={'delete-input-icon'}
                      />
                    )}
                  </div>
                ))}
                <Row justify={'end'} className='actn-section-link'>
                  <Col>
                    <Button type='link' onClick={() => add()}>
                      {profileData.addRoleBtnTxt}
                    </Button>
                  </Col>
                </Row>
              </div>
            )}
          </Form.List>
        </Form.Item>

        <div className='s-actn is-right'>
          <Button className='btn btn-cancel' type='primary' onClick={onCancel}>
            {profileData.cancelBtnTxt}
          </Button>
          <Button className='btn' type='primary' htmlType='submit'>
            {edit ? profileData.saveBtnTxt : profileData.addBtnTxt}
          </Button>
        </div>
      </Form>
    </div>
  );
};

const WorkExperience = ({
  data,
  onChange,
  viewOnly,
  hideTitle,
  title,
  hideEmpty,
}) => {
  const {work_exp: work_experience} = data || {};
  const [isAdd, setAdd] = useState(false);
  const [editIndex, setEditIndex] = useState(-1);
  const formatData = (v, id) => {
    const data = {...v};
    data['start_date'] = v['start_date'].format('YYYY-MM-DD');
    if (v['end_date']) data['end_date'] = v['end_date'].format('YYYY-MM-DD');
    if (!v['end_date']) data['end_date'] = null;
    if (v.job_responsibilities && v.job_responsibilities.length > 0) {
      data['job_responsibilities'] = v.job_responsibilities.map(
        i => i.job_responsibilities,
      );
    }
    if (id) {
      data['work_exp_uuid'] = id;
    }
    return data;
  };
  const cancelAddEdit = () => {
    setAdd(false);
    setEditIndex(-1);
  };
  const onAddExperience = async v => {
    if (onChange) {
      await onChange(
        false,
        API.gps.work_experience,
        formatData(v),
        'POST',
        false,
      );
      cancelAddEdit();
    }
  };
  const onEdit = async (v, id) => {
    if (onChange) {
      await onChange(
        false,
        API.gps.work_experience,
        formatData(v, id),
        'PATCH',
        id,
      );
    }

    cancelAddEdit();
  };
  const editData = idx => {
    setAdd(false);
    setEditIndex(idx);
  };
  const deleteWork = async exp => {
    if (onChange) {
      await onChange(
        false,
        API.gps.work_experience,
        {},
        'DELETE',
        exp.work_exp_uuid,
      );
    }
    cancelAddEdit();
  };
  return (
    <div className={'profile-edit-section' + (viewOnly ? ' rounded ' : '')}>
      {!hideTitle && <div className='s-ttl'>{title}</div>}

      <div className='s-con'>
        {work_experience &&
          work_experience.map((exp, idx) =>
            editIndex === idx ? (
              <div style={{maxWidth: 500}} key={idx}>
                <AddWorkExperience
                  data={exp}
                  edit={true}
                  onSubmit={v => onEdit(v, exp.work_exp_uuid)}
                  onCancel={cancelAddEdit}
                />
                <Divider />
              </div>
            ) : (
              <div className='list-itm' key={idx}>
                {!viewOnly && (
                  <div className='list-actns'>
                    <EditOutlined onClick={() => editData(idx)} />
                    <DeleteOutlined onClick={() => deleteWork(exp)} />
                  </div>
                )}

                <div className='list-itm-r'>
                  <span className='lbl'>
                    {exp.company_name} -{' '}
                    <span style={{fontWeight: 400}}>{exp.job_location}</span>
                  </span>
                </div>
                <div className='list-itm-r'>
                  {/* <span className='lbl'>Attended:</span> */}
                  <span className='val no-margin'>
                    {formatViewDate(exp.start_date)} -{' '}
                    {exp.is_present
                      ? profileData.workExperienceData.presentTxt
                      : formatViewDate(exp.end_date)}
                  </span>
                </div>
                <div className='list-itm-r'>
                  {/* <span className='lbl'>Degree/Award:</span> */}
                  <span className='lbl no-margin'>{exp.job_title}</span>
                </div>
                <div className='list-itm-r'>
                  {/* <span className='lbl'>Comments:</span> */}
                  <div className='list-bullets'>
                    {exp.job_responsibilities &&
                      exp.job_responsibilities.map((role, idx) => {
                        if (role.job_responsibilities)
                          return (
                            <div className='itm wrap-content' key={idx}>
                              {role.job_responsibilities}
                            </div>
                          );
                      })}
                  </div>
                </div>
                <Divider />
              </div>
            ),
          )}
        {!hideEmpty &&
          (!work_experience ||
            !Array.isArray(work_experience) ||
            (work_experience.length === 0 && (
              <div className='empty-ct'>
                {profileData.workExperienceData.noWorkExperienceAddedTxt}
              </div>
            )))}
      </div>
      {!viewOnly && (
        <>
          {isAdd && (
            <div className='s-con' style={{maxWidth: 600}}>
              <AddWorkExperience
                onCancel={cancelAddEdit}
                onSubmit={onAddExperience}
              />
            </div>
          )}
          {!isAdd && editIndex === -1 && (
            <div className='s-actn'>
              <Button
                className='btn btn-purple-outer'
                onClick={() => setAdd(true)}>
                {profileData.workExperienceData.addWorkExperienceBtn}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
};
export default WorkExperience;
