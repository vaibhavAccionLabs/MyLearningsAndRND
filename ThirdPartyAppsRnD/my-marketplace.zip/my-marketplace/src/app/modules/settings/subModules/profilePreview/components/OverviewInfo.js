import {formatPhoneNumber} from 'core/utils';
import {overviewData} from 'data/settings-profilePreview.json';

const OverviewInfo = ({student_Info}) => {
  const {address, phone_number, email} = student_Info || {};
  const phoneNumber = formatPhoneNumber(phone_number);
  let location = null;

  if (student_Info && address) {
    if (address?.city && address?.state)
      location = address.city + ', ' + address.state;
  }
  return (
    <>
      <div className='panel-title'>{overviewData.overviewTitle}</div>
      {location && (
        <div className='sub-panel'>
          <div className='sub-panel-title'>{overviewData.livesInLabel}</div>
          <div className='sub-panel-value'>{location}</div>
        </div>
      )}
      {email && (
        <div className='sub-panel'>
          <div className='sub-panel-title'>{overviewData.emailLabel}</div>
          <div className='sub-panel-value'>{email}</div>
        </div>
      )}
      {phoneNumber && phoneNumber !== '-' && (
        <div className='sub-panel'>
          <div className='sub-panel-title'>{overviewData.phoneNumberLabel}</div>
          <div className='sub-panel-value'>{phoneNumber}</div>
        </div>
      )}
    </>
  );
};

export default OverviewInfo;
