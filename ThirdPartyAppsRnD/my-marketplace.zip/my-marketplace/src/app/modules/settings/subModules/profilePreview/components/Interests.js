import {Tag} from 'antd';
import {interestsData} from 'data/settings-profilePreview.json';

const Interests = ({data: interest}) => (
  <div className='panel-section'>
    <div className='section-title'>{interestsData.interestsTitle}</div>
    <div className='plain-body'>
      {interest && Array.isArray(interest) && interest?.length > 0 ? (
        interest.map((int, idx) => (
          <Tag
            key={'pf-int-dt-' + idx}
            visible
            className='ant-tag-primary long-tag'>
            <span>
              <span key={idx}>{int}</span>
            </span>
          </Tag>
        ))
      ) : (
        <div>N/A</div>
      )}
    </div>
  </div>
);

export default Interests;
