import React, {useState, useEffect} from 'react';
import {Button, Message} from 'antd';
import {useUser} from 'core/hooks';

import AboutMeForm from './AboutMeForm';
import PersonalInfoView from './PersonalInfoView';
import SocialMedia from './socialMedia';

import profileData from 'data/settings-profile.json';

import './style.less';

const AboutMe = props => {
  const [readOnly, setReadOnly] = useState(true);
  const {error: UserError} = useUser();

  useEffect(() => {
    if (UserError) {
      Message.error(profileData.aboutMeData.somethingWentWrongMsg);
    }
  }, [UserError]);

  return (
    <div className='aboutMeContent'>
      {readOnly ? (
        <>
          <PersonalInfoView {...props} />
          <Button className='btn-blue-outer' onClick={() => setReadOnly(false)}>
            {profileData.aboutMeData.editPersonalInfoBtnTxt}
          </Button>
          <div className='social-banner mb-2'>
            <SocialMedia {...props} />
          </div>
        </>
      ) : (
        <AboutMeForm {...props} onComplete={() => setReadOnly(true)} />
      )}
    </div>
  );
};

export default AboutMe;
