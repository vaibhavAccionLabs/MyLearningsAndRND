import {RequestErrorLoader} from 'core/components';
import {useSaveProfileLoader} from 'core/hooks';
import {EditProfileWrapper} from '../../sharedComponents';
import ProfileInterests from './ProfileInterests';
import './style.less';

const DeclaredInterests = ({profileData, onProfileDataSubmit}) => {
  const {request, data} = profileData;
  const [isLoading, onSubmit] = useSaveProfileLoader(
    request,
    onProfileDataSubmit,
  );
  return (
    <RequestErrorLoader body={{...profileData, request: isLoading}}>
      <div
        className={
          data && data.interest && data.interest.length
            ? 'interests_content'
            : 'interests_no_content'
        }>
        <ProfileInterests data={profileData.data} onChange={onSubmit} />
      </div>
    </RequestErrorLoader>
  );
};

export default EditProfileWrapper(DeclaredInterests);
