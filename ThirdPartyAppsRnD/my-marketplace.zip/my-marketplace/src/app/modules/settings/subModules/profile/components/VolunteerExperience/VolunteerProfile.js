import {RequestErrorLoader} from 'core/components';
import {useSaveProfileLoader} from 'core/hooks';
import {EditProfileWrapper} from '../../sharedComponents';
import VolunteerExperience from './VolunteerExperience';
import './style.less';
import VolunteerExp from './style.module.less';

const EducationProfile = ({onProfileDataSubmit, profileData}) => {
  const {error, request, data} = profileData;
  const [isLoading, onSubmit] = useSaveProfileLoader(
    request,
    onProfileDataSubmit,
  );

  return (
    <RequestErrorLoader body={{...profileData, request: isLoading, error}}>
      <div
        className={
          data && data.voluntary_exp.length > 0
            ? VolunteerExp.volunteer_content
            : VolunteerExp.volunteer_nocontent
        }>
        <VolunteerExperience data={data} onChange={onSubmit} />
      </div>
    </RequestErrorLoader>
  );
};

export default EditProfileWrapper(EducationProfile);
