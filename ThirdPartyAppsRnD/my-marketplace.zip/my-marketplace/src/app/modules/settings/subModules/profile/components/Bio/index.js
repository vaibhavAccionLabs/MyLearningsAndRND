import {CustomCollapse} from 'core/components';
import BioData from './BioData';
import profileData from 'data/settings-profile.json';

const Bio = props => {
  return (
    <CustomCollapse header={profileData.bioData.collapseBarHeading}>
      <BioData {...props} />
    </CustomCollapse>
  );
};

export default Bio;
