import {useEffect} from 'react';
// import {Link} from 'react-router-dom';
import moment from 'moment';
import {
  RequestErrorLoader,
  TableLazyLoading,
  NoContentNavigator,
} from 'core/components';

const Opportunities = ({
  fetchNewOpportunities,
  resetNewOpportunities,
  NewOpportunity,
  profileData,
  fetchProfileData,
}) => {
  useEffect(() => {
    fetchNewOpportunities();
    fetchProfileData(); // Once the skill is updated, then fetch the latest skills data
    return () => {
      resetNewOpportunities();
    };
  }, [fetchNewOpportunities]); // eslint-disable-line react-hooks/exhaustive-deps

  const {data: opportunityData, request, error} = NewOpportunity || {};
  const items_per_page = 5;

  // Frame the table with required columns
  const columns = [
    {
      title: 'DATE POSTED',
      dataIndex: 'date',
      key: 'date',
    },
    {
      title: 'TITLE',
      dataIndex: 'title',
      key: 'title',
      render: ({text, type}, record) => (
        <a
          target='_target'
          href={`/programs/${encodeURIComponent(text)}/${encodeURIComponent(
            record?.company,
          )}?type=${type}`}>
          {text}
        </a>
      ),
    },
    {
      title: 'COMPANY',
      dataIndex: 'company',
      key: 'company',
    },
    {
      title: 'TYPE',
      dataIndex: 'type',
      key: 'type',
    },
    {
      title: 'SKILLS MATCH',
      dataIndex: 'skills-match',
      key: 'skills-match',
    },
  ];

  const scrollData = {
    y: 180,
  };

  // Sort the Data in descending order based on skills match %
  const actualData =
    (opportunityData?.data &&
      Array.isArray(opportunityData.data) &&
      opportunityData?.data?.length > 0 &&
      opportunityData.data.sort(function (a, b) {
        return b.skills_match - a.skills_match;
      })) ||
    [];

  // Frame the Data in required table format
  let skills_opportunity_data = [];
  actualData &&
    actualData.length > 0 &&
    actualData.map(skills_data =>
      skills_opportunity_data.push({
        key: skills_data?.opportunity_id,
        date: moment(skills_data?.created_on).format('LL'),
        title: {text: skills_data?.title, type: skills_data?.opportunity_type},
        company: skills_data?.institute_details?.institution_name,
        type:
          skills_data?.opportunity_type?.charAt(0).toUpperCase() +
          skills_data?.opportunity_type.slice(1),
        'skills-match': skills_data?.skills_match + '%',
      }),
    );

  const isSkillsAvailable = profileData?.data?.skills?.length > 0;

  return (
    <RequestErrorLoader
      overideNoDataContainer={
        <NoContentNavigator
          heading='No Matching Opportunities'
          message={
            isSkillsAvailable
              ? "There are no matching opportunities at this time that match your skills. Check out the program marketplace to earn skills needed for the opportunities you're after."
              : 'You have not added any skills to your profile. To get started add skills below'
          }
          pathTo={
            isSkillsAvailable ? '/directory/paths-list' : '/settings/skills'
          }
          label={isSkillsAvailable ? 'Explore Programs' : 'My Skills'}
          customClass='new-opportunities-no-skills'
        />
      }
      body={{...opportunityData, request: request}}>
      {actualData && !request && (
        <div className='new-opportunities-skills'>
          <TableLazyLoading
            columns={columns}
            data={skills_opportunity_data}
            pagination={false}
            scrollData={scrollData}
            items_per_page={items_per_page}
          />
        </div>
      )}
    </RequestErrorLoader>
  );
};
export default Opportunities;
