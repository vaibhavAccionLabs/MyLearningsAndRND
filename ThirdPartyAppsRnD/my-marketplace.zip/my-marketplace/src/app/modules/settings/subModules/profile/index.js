import {useEffect} from 'react';
import {connect} from 'react-redux';
import {Dropdown, Menu, Button, message} from 'antd';
import {CopyToClipboard} from 'react-copy-to-clipboard';
import {DownloadOutlined, CopyOutlined} from '@ant-design/icons';

import {
  fetchSkills,
  fetchSeekingData,
  fetchProfileData,
  updateProfile,
  updateUserProfile,
  uploadUserDocs,
  deleteUserDocs,
  profileDataSelector,
  awardTypesSelector,
  // About Me Section
  ethnicitySelector,
  citizenshipSelector,
  nativeLanguageSelector,
  fetchEthnicity,
  fetchCitizenship,
  fetchNativeLanguage,
} from 'redux/modules/profile';
import {fetchStates, getStates} from 'redux/modules/general';
import {ErrorBoundary} from 'core/components';
import {getLogo} from 'core/utils';
import {useUser} from 'core/hooks';
// local component
import {ContentHeader} from '../../components';
import {
  Bio,
  AboutMe,
  Awards,
  DeclaredInterests,
  Transcript,
  ResumeAndCoverLetter,
  WorkExperience,
  VolunteerExperience,
  Status,
  Portfolio,
} from './components';

import profileData from 'data/settings-profile.json';
import './style.less';

// Remove to enable status section
const SHOW_STATUS_AND_PREVIEW = true;

const Profile = props => {
  const {fetchProfileData, fetchSeekingData} = props;
  const {data: userData = {}} = useUser();
  const {qr_code, username = ''} = userData || {};

  useEffect(() => {
    fetchProfileData();
    fetchSeekingData();
    return () => {};
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const urlOrigin = `${window?.location?.origin}`;
  const profileUrl = `/profile/preview/${username || ''}`;
  const qrCodeImage = qr_code && getLogo(qr_code);
  const shareProfileMenu = (
    <Menu>
      <Menu.Item key='copyToClipBoard'>
        <CopyToClipboard
          text={`${urlOrigin}${profileUrl}`}
          onCopy={() =>
            message.success(`${profileData.shareProfileData.copySuccessMsg}`)
          }>
          <span>
            <CopyOutlined />
            {profileData.shareProfileData.copyProfileText}
          </span>
        </CopyToClipboard>
      </Menu.Item>
      <Menu.Item key='downloadQR' disabled={!qrCodeImage}>
        <a href={qrCodeImage} target='_blank' download='file'>
          <DownloadOutlined />
          {profileData.shareProfileData.downloadProfileText}
        </a>
      </Menu.Item>
    </Menu>
  );
  return (
    <ErrorBoundary
      nameOfComponent='module-settings-my-profile'
      typeOfUi='subPage'>
      <ContentHeader
        title={profileData.myProfileHeading}
        label={profileData.previewProfileBtnTxt}
        actionConfig={{
          href: profileUrl,
          target: '_blank',
          disabled: !username,
        }}>
        <Dropdown
          overlay={shareProfileMenu}
          trigger={['click']}
          overlayClassName='share-profile-dropdown-menu'
          disabled={!username}>
          <Button className='btn-purple-outer mx-2'>share profile</Button>
        </Dropdown>
      </ContentHeader>
      <div className='myprofile-content pt-2'>
        <div dangerouslySetInnerHTML={{__html: profileData.profileDesc}} />
        {SHOW_STATUS_AND_PREVIEW && (
          <div className='status-section mb-4'>
            <Status {...props} />
          </div>
        )}
        <div className='myprofile-aboutMe'>
          <AboutMe {...props} />
        </div>
        <div className='portfolio-section'>
          <Portfolio {...props} />
        </div>
        <div className='myprofile-bio mb-4'>
          <Bio {...props} />
        </div>
        <div className='myprofile-declared-interests mb-4'>
          <DeclaredInterests {...props} />
        </div>
        <div className='workExperience mb-4'>
          <WorkExperience {...props} />
        </div>
        <div className='myprofile-volunteerExp mb-4'>
          <VolunteerExperience {...props} />
        </div>
        <div className='myprofile-awards mb-4'>
          <Awards {...props} />
        </div>
        <div className='transcript-section'>
          <Transcript {...props} />
        </div>
        <div className='resumecover-section'>
          <ResumeAndCoverLetter {...props} />
        </div>
      </div>
    </ErrorBoundary>
  );
};

const mapStateToProps = state => ({
  profileData: profileDataSelector(state),
  awardTypes: awardTypesSelector(state),
  // About Me Section
  statesList: getStates(state).data,
  ethnicityData: ethnicitySelector(state),
  citizenshipData: citizenshipSelector(state),
  nativeLanguageData: nativeLanguageSelector(state),
});
export default connect(mapStateToProps, {
  fetchSkills,
  fetchProfileData,
  fetchSeekingData,
  updateUserProfile,
  uploadUserDocs,
  deleteUserDocs,
  updateProfile,
  // About Me Section
  fetchStates,
  fetchEthnicity,
  fetchCitizenship,
  fetchNativeLanguage,
})(Profile);
