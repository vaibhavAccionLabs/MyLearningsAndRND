import {lazy} from 'react';
import {retry} from 'core/utils';
import './styles.less';

const Dashboard = lazy(() => retry(() => import('./dashboard')));
const Profile = lazy(() => retry(() => import('./profile')));
const Education = lazy(() => retry(() => import('./education')));
const Skills = lazy(() => retry(() => import('./skills')));
const Workforce = lazy(() => retry(() => import('./workforce')));
const MyEvents = lazy(() => retry(() => import('./myEvents')));
const ProfilePreview = lazy(() => retry(() => import('./profilePreview')));

export {
  Dashboard,
  Profile,
  Education,
  Workforce,
  MyEvents,
  ProfilePreview,
  Skills,
};
