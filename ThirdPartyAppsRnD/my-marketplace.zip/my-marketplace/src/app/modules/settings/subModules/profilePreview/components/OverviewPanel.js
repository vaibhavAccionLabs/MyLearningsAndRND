import {Divider} from 'antd';

import Interests from './Interests';
import Education from './Education';
import OverviewInfo from './OverviewInfo';
import EducationalPathways from './EducationPathways';
import VolunteerExperience from './VolunteerExperience';
import profilePreviewData from 'data/settings-profilePreview.json';

const OverviewPanel = ({student_Info, student_profile, activePath}) => {
  const {education = [], voluntary_exp = [], interest = []} =
    student_profile || {};
  let renderView = <div>{profilePreviewData.noDataFoundTxt}</div>;

  if (student_Info && student_profile && activePath) {
    renderView = (
      <div className='side-panel'>
        <OverviewInfo student_Info={student_Info} />
        {education && Array.isArray(education) && education.length > 0 ? (
          <>
            <Divider className='panel-section-divider' />
            <Education data={education} />
          </>
        ) : null}
        {activePath?.title ? (
          <>
            <Divider className='panel-section-divider' />
            <EducationalPathways activePath={activePath} />
          </>
        ) : null}
        {voluntary_exp &&
        Array.isArray(voluntary_exp) &&
        voluntary_exp.length > 0 ? (
          <>
            <Divider className='panel-section-divider' />
            <VolunteerExperience data={voluntary_exp} />
          </>
        ) : null}
        {interest && Array.isArray(interest) && interest.length > 0 ? (
          <>
            <Divider className='panel-section-divider' />
            <Interests data={interest} />
          </>
        ) : null}
      </div>
    );
  }

  return renderView;
};

export default OverviewPanel;
