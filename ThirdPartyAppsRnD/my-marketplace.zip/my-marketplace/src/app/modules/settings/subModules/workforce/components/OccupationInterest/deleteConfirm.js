const DeleteConfirm = ({title = 'Occupation Title'}) => {
  return (
    <div className='delete-occ-modal'>
      <div className='ttl'>Remove Interest Rating</div>
      <div className='desc'>
        Are you sure want to remove the interest rating
        <br /> for the occupation: <span>{title}</span> ?.
      </div>
    </div>
  );
};

export default DeleteConfirm;
