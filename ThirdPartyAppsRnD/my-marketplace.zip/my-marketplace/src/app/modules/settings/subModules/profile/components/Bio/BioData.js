import {RequestErrorLoader} from 'core/components';
import {useSaveProfileLoader} from 'core/hooks';
import Bio from './style.module.less';
import {EditProfileWrapper} from '../../sharedComponents';

import ProfileBio from './ProfileBio';
import profileStaticData from 'data/settings-profile.json';

const BioData = ({onProfileDataSubmit, profileData}) => {
  const {request, data} = profileData;
  const [isLoading, onSubmit] = useSaveProfileLoader(
    request,
    onProfileDataSubmit,
  );
  return (
    <RequestErrorLoader body={{...profileData, request: isLoading}}>
      <div className={data && data.bio ? Bio.bio_content : Bio.bio_no_content}>
        <ProfileBio
          data={data}
          heading={profileStaticData.bioData.bioTitle}
          onChange={onSubmit}
        />
      </div>
    </RequestErrorLoader>
  );
};

export default EditProfileWrapper(BioData);
