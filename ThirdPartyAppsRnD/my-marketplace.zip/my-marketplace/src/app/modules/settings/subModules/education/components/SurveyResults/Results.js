import {useEffect} from 'react';

import {
  CareerInterestSurveyResult,
  RequestErrorLoader,
  NoContentNavigator,
  ErrorBoundary,
} from 'core/components';

import {NoCareerInterest} from 'data/pathway';

const SurveyResults = ({
  fetchCareerInterestQuestions,
  getCareerInterestSurveyResults,
  fetchClusters,
  careerInterest,
  clusters,
}) => {
  useEffect(() => {
    fetchCareerInterestQuestions();
    getCareerInterestSurveyResults();
    fetchClusters();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <ErrorBoundary nameOfComponent='mod-comp-settings-myeducation-surveyresults'>
      <RequestErrorLoader
        body={{
          ...careerInterest,
          request: careerInterest?.request || clusters?.request,
        }}
        checkForMultipleDataKeys={[
          {answers: '$.student_responses'},
          {data: '$'},
        ]}
        overideNoDataContainer={<div />}>
        {careerInterest &&
          !careerInterest.request &&
          !careerInterest.answers && (
            <NoContentNavigator
              message={NoCareerInterest}
              pathTo='/survey/my-survey?reset=true'
              label='Take Career Interest Survey'
            />
          )}

        {careerInterest?.answers &&
          Array.isArray(careerInterest?.answers?.student_responses) &&
          careerInterest.answers.student_responses?.length > 0 && (
            <CareerInterestSurveyResult
              surveyAnswers={careerInterest?.answers}
              clusters={clusters?.data}
              showButton
            />
          )}
      </RequestErrorLoader>
    </ErrorBoundary>
  );
};

export default SurveyResults;
