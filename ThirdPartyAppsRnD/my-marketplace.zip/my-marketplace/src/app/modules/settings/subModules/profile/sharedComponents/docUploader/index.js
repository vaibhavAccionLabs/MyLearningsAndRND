import {useState} from 'react';
import {List, Button, Upload, message, Empty} from 'antd';
import {DeleteOutlined} from '@ant-design/icons';
import {RequestErrorLoader, ErrorBoundary} from 'core/components';
import {fileTypeIcon, formatBytes, bytesToMegaBytes} from 'core/utils';
import {uploadDocData} from 'data/settings.json';

import './style.less';

const UploadFileFormats = [
  'text/csv',
  'image/bmp',
  'image/png',
  'image/jpg',
  'image/jpeg',
  'text/plain',
  'application/pdf',
  'application/xls',
  'application/msword', // doc
  'application/vnd.ms-excel', // xls
  'application/vnd.ms-excel.sheet.macroenabled.12', //xlsm
  'application/vnd.ms-excel.sheet.binary.macroenabled.12', //xlsb
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', //xlsx
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document', //docx
];

const DocUploader = ({
  viewOnly,
  profileData,
  uploadUserDocs,
  deleteUserDocs,
  maxFileSize = 10,
  noLoader,
  type = 'related_document',
  label = uploadDocData.addDocBtn,
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const {data, total_size_consumed, request, error} = profileData;
  const onSuccess = name => {
    message.success(`${name} ${uploadDocData.uploadSuccessfullyMsg}`);
    setIsLoading(false);
  };
  const onDeleteSuccess = () => {
    message.success(uploadDocData.deleteSuccessfullyMsg);
    setIsLoading(false);
  };

  const props = {
    showUploadList: false,
    beforeUpload: file => {
      const FileSize = bytesToMegaBytes(file.size);
      if (
        parseFloat(FileSize) > maxFileSize ||
        parseFloat(total_size_consumed) + parseFloat(FileSize) > maxFileSize
      ) {
        message.error(
          uploadDocData.sizeExceedErroMsg.replace('{maxFileSize}', maxFileSize),
        );
        return false;
      }
      if (!UploadFileFormats.includes(file.type)) {
        message.error(uploadDocData.AllowedFileFormatsMsg);
        return false;
      }
      return true;
    },
    customRequest: async ({file}) => {
      setIsLoading(true);
      await uploadUserDocs({file, key: type}, onSuccess);
    },
  };

  const deleteDoc = docId => {
    setIsLoading(true);
    deleteUserDocs(docId, onDeleteSuccess);
  };

  const Float_Size_Consumed = parseFloat(total_size_consumed);
  const isTotalSizeReachMax =
    Float_Size_Consumed > Number(((85 / 100) * maxFileSize).toFixed(2));

  let totalSizeConsmed = 0;
  if (Float_Size_Consumed > 0) {
    totalSizeConsmed = Float_Size_Consumed;
    if (totalSizeConsmed > maxFileSize) {
      totalSizeConsmed = maxFileSize;
    }
  }

  return (
    <ErrorBoundary nameOfComponent='mod-comp-settings-myprofile-docupload'>
      <RequestErrorLoader body={{request: noLoader ? false : isLoading, error}}>
        {!viewOnly && (
          <div className='storage_used'>
            {uploadDocData.totalStorageConsumedLabel}
            {': '}
            <span style={{color: isTotalSizeReachMax ? 'red' : '#000'}}>
              {totalSizeConsmed}MB
            </span>{' '}
            / {maxFileSize}MB
          </div>
        )}
        <List
          className='document_list'
          locale={{
            emptyText: (
              <Empty description={null} imageStyle={{display: 'none'}} />
            ),
          }}
          dataSource={data}
          loading={false}
          renderItem={({doc_name, doc_link, doc_uuid}) => {
            const Icon = fileTypeIcon(doc_link);
            return (
              <List.Item>
                <Icon />
                <a
                  href={doc_link}
                  target='_blank'
                  className='px-2'
                  download='file'>
                  {doc_name}
                </a>
                {!viewOnly && (
                  <DeleteOutlined onClick={() => deleteDoc(doc_uuid)} />
                )}
              </List.Item>
            );
          }}
        />
        {!viewOnly && (
          <div
            className={`doc_uploader ${data.length === 0 ? 'text-left' : ''}`}>
            <Upload {...props}>
              <Button className='btn-blue-outer' disabled={isLoading}>
                {label}
              </Button>
            </Upload>
          </div>
        )}
      </RequestErrorLoader>
    </ErrorBoundary>
  );
};

export default DocUploader;
