import React, {useState, useEffect} from 'react';
import {isEmpty, isArray, isObject} from 'lodash';
import {Button, Row, Col, Form, Input, Select, Checkbox} from 'antd';
import {LoadingOutlined} from '@ant-design/icons';
import debounce from 'debounce';
import {useUser} from 'core/hooks';
import {getCompleteDate} from 'core/utils';
import {PATTERN} from 'core/regex';
import {RequestErrorLoader} from 'core/components';
import {API} from 'config';
import SettingsModule from 'data/settings.json';

import profileData from 'data/settings-profile.json';

const {Option} = Select;
const {student_details = ''} = API.gps || {};
const AboutMeForm = ({
  onComplete,
  statesList,
  ethnicityData,
  citizenshipData,
  nativeLanguageData,
  fetchStates,
  fetchEthnicity,
  fetchCitizenship,
  fetchNativeLanguage,
  updateUserProfile,
}) => {
  const formRef = React.createRef();
  const {data: ethnicityList, request: ethnicityRequest} = ethnicityData;
  const {data: citizenshipList, request: citizenshipRequest} = citizenshipData;
  const {
    data: nativeLanguageList,
    request: nativeLanguageRequest,
  } = nativeLanguageData;
  const {data: userData, request} = useUser();
  const {
    dob,
    entry_semester: entry_semester_initVal,
    entry_semester_year: entry_semester_year_initVal,
    address: location_info,
    address_show: locationChkbx,
    phone_show: phoneNumberCkbx,
    alternate_email_show: secondaryEmailChkbx,
  } = userData || {};
  const [address_show, setLocation] = useState(locationChkbx);
  const [phone_show, setPhoneNumberCkbx] = useState(phoneNumberCkbx);
  const [alternate_email_show, setSecondaryEmail] = useState(
    secondaryEmailChkbx,
  );
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    !statesList && fetchStates();
    !ethnicityList && fetchEthnicity();
    !citizenshipList && fetchCitizenship();
    !nativeLanguageList && fetchNativeLanguage();
    return () => {
      setLocation(false);
      setSecondaryEmail(false);
      setPhoneNumberCkbx(false);
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const onSubmit = async values => {
    let {
      username,
      first_name,
      middle_name,
      last_name,
      gender,
      email,
      ethnicity,
      native_language,
      citizenship,
      // additonal params
      entry_semester,
      entry_semester_year,
      month,
      date,
      year,
      addressline,
      city,
      state,
      zip,
      phone_number,
      alternate_email_id,
      phone_show,
      address_show,
      alternate_email_show,
    } = values;
    const formData = {
      username,
      first_name,
      middle_name,
      last_name,
      gender,
      email,
      ethnicity,
      native_language,
      citizenship,
      phone_number,
      alternate_email_id,
      phone_show,
      address_show,
      alternate_email_show,
    };
    if (month && date && year) formData['dob'] = `${year}-${month}-${date}`;
    let ethnicity_id =
      ethnicity &&
      ethnicityList &&
      isArray(ethnicityList) &&
      ethnicityList.length > 0
        ? ethnicityList.find(item => item.name === ethnicity).ethnicity_uuid
        : null;
    let citizenship_id =
      citizenship &&
      citizenshipList &&
      isArray(citizenshipList) &&
      citizenshipList.length > 0
        ? citizenshipList.find(item => item.name === citizenship)
            .citizenship_uuid
        : null;
    let native_language_id =
      native_language &&
      nativeLanguageList &&
      isArray(nativeLanguageList) &&
      nativeLanguageList.length > 0
        ? nativeLanguageList.find(item => item.name === native_language)
            .native_lang_uuid
        : null;
    formData['ethnicity'] = ethnicity_id;
    formData['citizenship'] = citizenship_id;
    formData['native_language'] = native_language_id;
    formData['entry_semester'] = entry_semester || null;
    formData['entry_semester_year'] =
      (entry_semester_year && entry_semester_year.toString()) || null;
    let addressObj = {};
    let state_id =
      state && statesList && isArray(statesList) && statesList.length
        ? statesList.find(item => item.name === state).state_uuid
        : null;
    if (addressline && city && state_id && zip) {
      addressObj['city'] = `${city || ''}`;
      addressObj['state'] = `${state_id || ''}`;
      addressObj['address'] = `${addressline || ''}`;
      addressObj['zip'] = zip || null;
      formData['address'] = addressObj;
    } else {
      formData['address'] = {};
    }
    await updateUserProfile(formData);
    onComplete();
  };

  const onCheckBoxChange = e => {
    switch (e.target.id) {
      case 'address_show': {
        setLocation(e.target.checked);
        break;
      }
      case 'alternate_email_show': {
        setSecondaryEmail(e.target.checked);
        break;
      }
      case 'phone_show': {
        setPhoneNumberCkbx(e.target.checked);
        break;
      }
      default: {
      }
    }
  };

  const layout = {
    labelCol: {span: 24},
    wrapperCol: {span: 24},
  };

  const getOptions = (start, end, type) => {
    const options = [];
    if (type && type === 'month') {
      for (let i = start; i <= end; i++) {
        options.push(
          <Option value={i} key={i}>
            {SettingsModule.months[i - 1]}
          </Option>,
        );
      }
    } else {
      for (let i = start; i <= end; i++) {
        options.push(
          <Option value={i} key={i}>
            {i}
          </Option>,
        );
      }
    }
    return options;
  };

  const getFormFieldsValue = f => {
    if (formRef && formRef.current) {
      return formRef.current.getFieldValue(f);
    } else {
      return '';
    }
  };

  const onValuesChange = (c, all) => {
    if (!all[addressline] && !all[city] && !all[state] && !all[zip]) {
      if (formRef && formRef.current) {
        formRef.current.validateFields(['addressline', 'city', 'state', 'zip']);
      }
    }
    if (!all[date] && !all[month] && !all[year]) {
      if (formRef && formRef.current) {
        formRef.current.validateFields(['date', 'month', 'year']);
      }
    }
    if (!all[entry_semester] && !all[entry_semester_year]) {
      if (formRef && formRef.current) {
        formRef.current.validateFields([
          'entry_semester',
          'entry_semester_year',
        ]);
      }
    }
  };

  const currentYear = new Date().getFullYear();
  const {date, month, year} = getCompleteDate(dob);
  let addressline =
    isObject(location_info) &&
    !isEmpty(location_info) &&
    location_info['address']
      ? location_info['address']
      : null;
  let city =
    isObject(location_info) && !isEmpty(location_info) && location_info['city']
      ? location_info['city']
      : null;
  let state =
    isObject(location_info) && !isEmpty(location_info) && location_info['state']
      ? location_info['state']
      : null;
  let zip =
    isObject(location_info) && !isEmpty(location_info) && location_info['zip']
      ? location_info['zip'].toString()
      : null;
  let entry_semester = entry_semester_initVal || 'fall';
  let entry_semester_year = entry_semester_year_initVal || currentYear;

  const validateUserName = async (_, value, cb) => {
    if (
      !value ||
      !PATTERN.UserName.test(value) ||
      userData?.username === value
    ) {
      return cb();
    }
    setLoading(true);
    const data = await fetch(
      `${student_details}?check_username=${value}`,
    ).then(res => res.json());
    if (!data?.Success) {
      return cb(profileData.aboutMeData.userName?.alreadyExistsMsg);
    }
    setLoading(false);
    return cb();
  };

  const debouncedValidateUserName = debounce(validateUserName, 1000);

  return (
    <>
      <RequestErrorLoader
        body={{
          request:
            ethnicityRequest ||
            citizenshipRequest ||
            nativeLanguageRequest ||
            request,
        }}>
        {
          <Form
            onFinish={onSubmit}
            {...layout}
            onValuesChange={onValuesChange}
            initialValues={{
              ...userData,
              month,
              date,
              year,
              entry_semester,
              entry_semester_year,
              city,
              state,
              zip,
              addressline,
              phone_show,
              address_show,
              alternate_email_show,
            }}
            ref={formRef}>
            <div className='editPersonalInfo'>
              <h3 className='heading'>
                {profileData.aboutMeData.editPersonalInformationTitle}
              </h3>
              <p className='description'>
                {SettingsModule.editPersonalInfoDescription}
              </p>
              <Row className='field-container'>
                <Col xs={24} sm={24} md={24} lg={24}>
                  <Col xs={24} sm={24} md={8} lg={8}>
                    <Form.Item
                      name='username'
                      label={profileData.aboutMeData.userName?.label}
                      rules={[
                        {
                          required: true,
                          message:
                            profileData.aboutMeData?.userName?.requiredMsg,
                        },
                        {
                          pattern: PATTERN.UserName,
                          message:
                            profileData.aboutMeData?.userName?.patternMsg,
                        },
                        {
                          validator: debouncedValidateUserName,
                        },
                      ]}
                      className='f-itm'>
                      <Input
                        suffix={loading ? <LoadingOutlined /> : <></>}
                        className='f-input'
                        size='large'
                        placeholder={
                          profileData.aboutMeData.userName.placeholder
                        }
                      />
                    </Form.Item>
                  </Col>
                </Col>
              </Row>
              <Row className='field-container'>
                <Col xs={24} sm={24} md={8} lg={8}>
                  <Form.Item
                    name='first_name'
                    label={profileData.aboutMeData.firstName.label}
                    rules={[
                      {
                        required: true,
                        message: profileData.aboutMeData.firstName.requiredMsg,
                      },
                    ]}
                    className='f-itm'>
                    <Input
                      className='f-input'
                      size='large'
                      placeholder={
                        profileData.aboutMeData.firstName.placeholder
                      }
                    />
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={8} lg={8}>
                  <Form.Item
                    name='middle_name'
                    label={profileData.aboutMeData.middleName.label}
                    className='f-itm'>
                    <Input
                      className='f-input'
                      size='large'
                      placeholder={
                        profileData.aboutMeData.middleName.placeholder
                      }
                    />
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={8} lg={8}>
                  <Form.Item
                    name='last_name'
                    label={profileData.aboutMeData.lastName.label}
                    rules={[
                      {
                        required: true,
                        message: profileData.aboutMeData.lastName.requiredMsg,
                      },
                    ]}
                    className='f-itm'>
                    <Input
                      className='f-input'
                      size='large'
                      placeholder={profileData.aboutMeData.lastName.placeholder}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row className='field-container'>
                <Col xs={24} sm={24} md={8} lg={8}>
                  <Form.Item
                    name='gender'
                    label={profileData.aboutMeData.gender.label}
                    rules={[
                      {
                        required: true,
                        message: profileData.aboutMeData.gender.requiredMsg,
                      },
                    ]}
                    className='f-itm'>
                    <Select
                      className='f-select'
                      placeholder={profileData.aboutMeData.gender.placeholder}>
                      <Option key='male' value='male'>
                        {profileData.aboutMeData.gender.options.male}
                      </Option>
                      <Option key='female' value='female'>
                        {profileData.aboutMeData.gender.options.female}
                      </Option>
                      <Option key='other' value='other'>
                        {profileData.aboutMeData.gender.options.other}
                      </Option>
                      <Option key='decline to state' value='decline to state'>
                        {profileData.aboutMeData.gender.options.declineToState}
                      </Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={8} lg={8}>
                  <Form.Item
                    name='dob'
                    label={profileData.aboutMeData.dateOfBirth.label}
                    className='f-itm dob'>
                    <div className='dob-container'>
                      <Form.Item
                        name='month'
                        rules={[
                          {
                            validator: (_, value) => {
                              let _date = getFormFieldsValue('date');
                              let _year = getFormFieldsValue('year');
                              return (_date || _year) && !value
                                ? Promise.reject(
                                    new Error(
                                      profileData.aboutMeData.dateOfBirth.selectMonth.requiredMsg,
                                    ),
                                  )
                                : Promise.resolve();
                            },
                          },
                        ]}>
                        <Select
                          className='f-select'
                          dropdownClassName='wider-dropdown-list'
                          placeholder={
                            profileData.aboutMeData.dateOfBirth.selectMonth
                              .placeholder
                          }>
                          {getOptions(1, 12, 'month')}
                        </Select>
                      </Form.Item>
                      <Form.Item
                        name='date'
                        rules={[
                          {
                            validator: (_, value) => {
                              let _month = getFormFieldsValue('month');
                              let _year = getFormFieldsValue('year');
                              return (_month || _year) && !value
                                ? Promise.reject(
                                    new Error(
                                      profileData.aboutMeData.dateOfBirth.selectDate.requiredMsg,
                                    ),
                                  )
                                : Promise.resolve();
                            },
                          },
                        ]}>
                        <Select
                          className='f-select'
                          dropdownClassName='wider-dropdown-list'
                          placeholder={
                            profileData.aboutMeData.dateOfBirth.selectDate
                              .placeholder
                          }>
                          {getOptions(1, 31)}
                        </Select>
                      </Form.Item>
                      <Form.Item
                        name='year'
                        rules={[
                          {
                            validator: (_, value) => {
                              let _month = getFormFieldsValue('month');
                              let _date = getFormFieldsValue('date');
                              return (_month || _date) && !value
                                ? Promise.reject(
                                    new Error(
                                      profileData.aboutMeData.dateOfBirth.selectYear.requiredMsg,
                                    ),
                                  )
                                : Promise.resolve();
                            },
                          },
                        ]}>
                        <Select
                          className='f-select'
                          dropdownClassName='wider-dropdown-list'
                          placeholder={
                            profileData.aboutMeData.dateOfBirth.selectYear
                              .placeholder
                          }>
                          {getOptions(currentYear - 118, currentYear).reverse()}
                        </Select>
                      </Form.Item>
                    </div>
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={8} lg={8}>
                  <Form.Item
                    name='email'
                    label={profileData.aboutMeData.email.label}
                    rules={[
                      {
                        required: true,
                        message: profileData.aboutMeData.email.requiredMsg,
                      },
                    ]}
                    className='f-itm'>
                    <Input
                      className='f-input'
                      size='large'
                      disabled
                      placeholder={profileData.aboutMeData.email.placeholder}
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row className='field-container'>
                <Col xs={24} sm={24} md={8} lg={8}>
                  <Form.Item
                    name='ethnicity'
                    label={profileData.aboutMeData.raceEthnicity.label}
                    rules={[
                      {
                        required: true,
                        message:
                          profileData.aboutMeData.raceEthnicity.requiredMsg,
                      },
                    ]}
                    className='f-itm'>
                    <Select
                      className='f-select'
                      placeholder={
                        profileData.aboutMeData.raceEthnicity.placeholder
                      }>
                      {ethnicityList &&
                        isArray(ethnicityList) &&
                        ethnicityList.length > 0 &&
                        ethnicityList.map(
                          (item, index) =>
                            item && (
                              <Option value={item.name} key={index}>
                                {item.name}
                              </Option>
                            ),
                        )}
                    </Select>
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={8} lg={8}>
                  <Form.Item
                    name='native_language'
                    label={profileData.aboutMeData.nativeLanguage.label}
                    className='f-itm'>
                    <Select
                      className='f-select'
                      placeholder={
                        profileData.aboutMeData.nativeLanguage.placeholder
                      }>
                      {nativeLanguageList &&
                        isArray(nativeLanguageList) &&
                        nativeLanguageList.length > 0 &&
                        nativeLanguageList.map(
                          (item, index) =>
                            item && (
                              <Option value={item.name} key={index}>
                                {item.name}
                              </Option>
                            ),
                        )}
                    </Select>
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={8} lg={8}>
                  <Form.Item
                    name='citizenship'
                    label={profileData.aboutMeData.citizenship.label}
                    className='f-itm'>
                    <Select
                      className='f-select'
                      placeholder={
                        profileData.aboutMeData.citizenship.placeholder
                      }>
                      {citizenshipList &&
                        isArray(citizenshipList) &&
                        citizenshipList.length > 0 &&
                        citizenshipList.map(
                          (item, index) =>
                            item && (
                              <Option value={item.name} key={index}>
                                {item.name}
                              </Option>
                            ),
                        )}
                    </Select>
                  </Form.Item>
                </Col>
              </Row>
              <Row className='field-container'>
                <Col xs={24} sm={24} md={8} lg={8}>
                  <Form.Item
                    name='semester-label'
                    label={
                      profileData.aboutMeData.currentOrPlannedSemester.label
                    }
                    className='f-itm semester'>
                    <div className='semester-container'>
                      <Form.Item
                        name='entry_semester'
                        rules={[
                          {
                            validator: (_, value) => {
                              let _semester_year = getFormFieldsValue(
                                'entry_semester_year',
                              );
                              return _semester_year && !value
                                ? Promise.reject(
                                    new Error(
                                      profileData.aboutMeData.currentOrPlannedSemester.requiredMsg,
                                    ),
                                  )
                                : Promise.resolve();
                            },
                          },
                        ]}>
                        <Select
                          allowClear={true}
                          className='f-select'
                          dropdownClassName='wider-dropdown-list'
                          placeholder={
                            profileData.aboutMeData.currentOrPlannedSemester
                              .semDropdown.placeholder
                          }>
                          <Option key='fall' value='fall'>
                            {
                              profileData.aboutMeData.currentOrPlannedSemester
                                .options.fall
                            }
                          </Option>
                          <Option key='spring' value='spring'>
                            {
                              profileData.aboutMeData.currentOrPlannedSemester
                                .options.spring
                            }
                          </Option>
                        </Select>
                      </Form.Item>
                      <Form.Item
                        name='entry_semester_year'
                        rules={[
                          {
                            validator: (_, value) => {
                              let _semester = getFormFieldsValue(
                                'entry_semester',
                              );
                              return _semester && !value
                                ? Promise.reject(
                                    new Error(
                                      profileData.aboutMeData.currentOrPlannedSemester.requiredMsg.validationMsg,
                                    ),
                                  )
                                : Promise.resolve();
                            },
                          },
                        ]}>
                        <Select
                          allowClear={true}
                          dropdownClassName='wider-dropdown-list'
                          className='f-select'
                          placeholder={
                            profileData.aboutMeData.currentOrPlannedSemester
                              .yearDropdown.placeholder
                          }>
                          {getOptions(currentYear - 118, currentYear).reverse()}
                        </Select>
                      </Form.Item>
                    </div>
                  </Form.Item>
                </Col>
              </Row>
            </div>
            <div className='editContactInfo'>
              <h3 className='heading'>
                {profileData.aboutMeData.editContactInformationTitle}
              </h3>
              <p className='description'>
                {SettingsModule.editContactInfoDescription}
              </p>
              <Row className='field-container'>
                <Col xs={24} sm={24} md={6} lg={7}>
                  <Form.Item
                    name='address_show'
                    valuePropName='checked'
                    noStyle>
                    <Checkbox
                      className='f-input-checkbox'
                      onChange={onCheckBoxChange}>
                      <span className='txt'>
                        {profileData.aboutMeData.myLocationLabel} :
                      </span>
                    </Checkbox>
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={18} lg={17}>
                  <Row>
                    <Col xs={24} sm={24} md={24} lg={23}>
                      <Form.Item
                        name='addressline'
                        className='f-itm addressline-row'
                        rules={[
                          {
                            validator: (_, value) => {
                              let _city = getFormFieldsValue('city');
                              let _state = getFormFieldsValue('state');
                              let _zip = getFormFieldsValue('zip');
                              return (_city || _state || _zip) && !value
                                ? Promise.reject(
                                    new Error(
                                      profileData.aboutMeData.address.requiredMsg,
                                    ),
                                  )
                                : Promise.resolve();
                            },
                          },
                        ]}>
                        <Input
                          className='f-input'
                          size='large'
                          placeholder={
                            profileData.aboutMeData.address.placeholder
                          }
                        />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={24} md={8} lg={8}>
                      <Form.Item
                        name='city'
                        className='f-itm'
                        rules={[
                          {
                            validator: (_, value) => {
                              let _addressline = getFormFieldsValue(
                                'addressline',
                              );
                              let _state = getFormFieldsValue('state');
                              let _zip = getFormFieldsValue('zip');
                              return (_addressline || _state || _zip) && !value
                                ? Promise.reject(
                                    new Error(
                                      profileData.aboutMeData.city.requiredMsg,
                                    ),
                                  )
                                : Promise.resolve();
                            },
                          },
                        ]}>
                        <Input
                          className='f-input'
                          size='large'
                          placeholder={profileData.aboutMeData.city.placeholder}
                        />
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={24} md={8} lg={8}>
                      <Form.Item
                        name='state'
                        className='f-itm'
                        rules={[
                          {
                            validator: (_, value) => {
                              let _addressline = getFormFieldsValue(
                                'addressline',
                              );
                              let _city = getFormFieldsValue('city');
                              let _zip = getFormFieldsValue('zip');
                              return (_addressline || _city || _zip) && !value
                                ? Promise.reject(
                                    new Error(
                                      profileData.aboutMeData.state.requiredMsg,
                                    ),
                                  )
                                : Promise.resolve();
                            },
                          },
                        ]}>
                        <Select
                          className='f-select'
                          placeholder={
                            profileData.aboutMeData.state.placeholder
                          }
                          allowClear={true}>
                          {statesList &&
                            isArray(statesList) &&
                            statesList.length > 0 &&
                            statesList.map(
                              (item, index) =>
                                item && (
                                  <Option value={item.name} key={index}>
                                    {item.name}
                                  </Option>
                                ),
                            )}
                        </Select>
                      </Form.Item>
                    </Col>
                    <Col xs={24} sm={24} md={6} lg={6}>
                      <Form.Item
                        name='zip'
                        className='f-itm'
                        rules={[
                          {
                            pattern: PATTERN.Zip_Code,
                            message: profileData.aboutMeData.zip.validationMsg,
                          },
                          {
                            validator: (_, value) => {
                              let _addressline = getFormFieldsValue(
                                'addressline',
                              );
                              let _city = getFormFieldsValue('city');
                              let _state = getFormFieldsValue('state');
                              return (_addressline || _city || _state) && !value
                                ? Promise.reject(
                                    new Error(
                                      profileData.aboutMeData.zip.requiredMsg,
                                    ),
                                  )
                                : Promise.resolve();
                            },
                          },
                        ]}>
                        <Input
                          size='large'
                          className='f-input zipcode'
                          placeholder={profileData.aboutMeData.zip.placeholder}
                        />
                      </Form.Item>
                    </Col>
                  </Row>
                </Col>
              </Row>
              <Row className='field-container'>
                <Col xs={24} sm={24} md={6} lg={7}>
                  <Form.Item
                    name='alternate_email_show'
                    valuePropName='checked'
                    noStyle>
                    <Checkbox
                      className='f-input-checkbox'
                      onChange={onCheckBoxChange}>
                      <span className='txt'>
                        {profileData.aboutMeData.secondaryEmail.label} :
                      </span>
                    </Checkbox>
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={6} lg={6}>
                  <Form.Item
                    name='alternate_email_id'
                    className='f-itm'
                    rules={[
                      {
                        pattern: PATTERN.Email,
                        message:
                          profileData.aboutMeData.secondaryEmail.requiredMsg,
                      },
                    ]}>
                    <Input
                      className='f-input'
                      size='large'
                      placeholder={
                        profileData.aboutMeData.secondaryEmail.placeholder
                      }
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row className='field-container'>
                <Col xs={24} sm={24} md={6} lg={7}>
                  <Form.Item name='phone_show' valuePropName='checked' noStyle>
                    <Checkbox
                      className='f-input-checkbox'
                      onChange={onCheckBoxChange}>
                      <span className='txt'>
                        {profileData.aboutMeData.myPhoneNumber.label} :
                      </span>
                    </Checkbox>
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={6} lg={6}>
                  <Form.Item
                    name='phone_number'
                    className='f-itm'
                    rules={[
                      {
                        pattern: PATTERN.Phone,
                        message:
                          profileData.aboutMeData.myPhoneNumber.requiredMsg,
                      },
                    ]}>
                    <Input
                      className='f-input'
                      size='large'
                      type='number'
                      placeholder={
                        profileData.aboutMeData.myPhoneNumber.placeholder
                      }
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row justify='start'>
                <Col>
                  <Button
                    size='large'
                    className='btn-blue-outer'
                    onClick={() => onComplete()}
                    type='primary'>
                    {profileData.cancelBtnTxt}
                  </Button>
                </Col>
                <Col>
                  <Button
                    className='save-btn'
                    htmlType='submit'
                    type='primary'
                    size='large'
                    loading={request}>
                    {profileData.saveBtnTxt}
                  </Button>
                </Col>
              </Row>
            </div>
          </Form>
        }
      </RequestErrorLoader>
    </>
  );
};

export default AboutMeForm;
