import {connect} from 'react-redux';

import {ContentHeader} from '../../components';

import {
  OccupationsInterest,
  OccupationSubscriptions,
  AppliedWorkforces,
  SavedWorkforces,
  NewOpportunities,
} from './components';

import {getAppConfig} from 'redux/modules/general';

import {
  fetchOccupationInterests,
  getOccupationInterest,
  deleteOccupationInterest,
  profileDataSelector,
  fetchProfileData,
} from 'redux/modules/profile';

import {
  fetchSubscribedOccupation,
  getSubscribedOccupation,
  unSubscribeForOccupation,
  unSaveOpportunity,
  updateOpportunityInterest,
  fetchAppliedOpportunities,
  resetAppliedOpportunities,
  fetchSavedOpportunities,
  resetSavedOpportunities,
  getAppliedOpportunities,
  getSavedOpportunities,
  fetchNewOpportunities,
  resetNewOpportunities,
  getNewOpportunities,
} from 'redux/modules/occupation';

import {ErrorBoundary} from 'core/components';
import './style.less';

const Workforce = props => {
  return (
    <ErrorBoundary
      nameOfComponent='module-settings-my-workforce'
      typeOfUi='subPage'>
      <div className='workforce_layout'>
        <ContentHeader title='My Workforce' />
        <div className='newOpportunities_content mt-3'>
          <NewOpportunities {...props} />
        </div>
        <div className='appliedWorkforces_content mt-3'>
          <AppliedWorkforces {...props} />
        </div>
        <div className='savedWorkforces_content mt-3'>
          <SavedWorkforces {...props} />
        </div>
        <div className='occupationSubscription_content mt-3'>
          <OccupationSubscriptions {...props} />
        </div>
        <div className='occupationInterests mt-3'>
          <OccupationsInterest {...props} />
        </div>
      </div>
    </ErrorBoundary>
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  subscribedOccupation: getSubscribedOccupation(state),
  occupationInterest: getOccupationInterest(state),
  appliedOpportunities: getAppliedOpportunities(state),
  savedOpportunities: getSavedOpportunities(state),
  NewOpportunity: getNewOpportunities(state),
  profileData: profileDataSelector(state),
});

export default connect(mapStateToProps, {
  fetchSubscribedOccupation,
  unSubscribeForOccupation,
  fetchOccupationInterests,
  deleteOccupationInterest,
  unSaveOpportunity,
  updateOpportunityInterest,
  fetchAppliedOpportunities,
  resetAppliedOpportunities,
  fetchSavedOpportunities,
  resetSavedOpportunities,
  fetchNewOpportunities,
  resetNewOpportunities,
  fetchProfileData,
})(Workforce);
