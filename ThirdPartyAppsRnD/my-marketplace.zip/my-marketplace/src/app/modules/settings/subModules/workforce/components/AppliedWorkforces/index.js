import {CustomCollapse, ErrorBoundary} from 'core/components';
import Workforces from './Workforces';

const AppliedWorkforces = props => {
  return (
    <CustomCollapse header='Applications'>
      <ErrorBoundary nameOfComponent='mod-comp-settings-workforce-applied'>
        <Workforces {...props} />
      </ErrorBoundary>
    </CustomCollapse>
  );
};

export default AppliedWorkforces;
