import {connect} from 'react-redux';

import {
  fetchMyEvents,
  withdrawEvent,
  removeMyEvent,
  clearMyEvents,
  getMyEvents,
} from 'redux/modules/events';

import {ErrorBoundary} from 'core/components';
import {ContentHeader} from '../../components';
import EventsList from './components/EventsList';

const MyEvents = props => {
  return (
    <ErrorBoundary
      nameOfComponent='module-settings-my-events'
      typeOfUi='subPage'>
      <ContentHeader title='My Events' />
      <EventsList {...props} />
    </ErrorBoundary>
  );
};

const mapStateToProps = state => ({
  events: getMyEvents(state),
});

export default connect(mapStateToProps, {
  fetchMyEvents,
  clearMyEvents,
  withdrawEvent,
  removeMyEvent,
})(MyEvents);
