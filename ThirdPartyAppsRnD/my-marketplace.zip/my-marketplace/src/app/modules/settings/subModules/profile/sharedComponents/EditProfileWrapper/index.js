import {connect} from 'react-redux';

import {ErrorBoundary} from 'core/components';

import {
  updateProfile,
  profileDataSelector,
  skillsSelector,
} from 'redux/modules/profile';

const EditProfileWrapper = WrappedComponent => {
  const profileWrapper = props => {
    const {profileData: {data: studentProfileData} = {}, updateProfile} = props;
    const {student_profile_uuid} = studentProfileData || {};
    const onProfileDataSubmit = async (key, end_point, data, action, id) => {
      let endPoint = `${end_point}/${key ? student_profile_uuid : id || ''}`;
      let body = data;
      if (key) {
        body = {
          [key]: data,
        };
      }
      await updateProfile(endPoint, action, body);
      return;
    };

    return (
      <ErrorBoundary nameOfComponent='mod-comp-settings-myprofile-editprofilewrapper'>
        <WrappedComponent
          {...props}
          onProfileDataSubmit={onProfileDataSubmit}
        />
      </ErrorBoundary>
    );
  };

  const mapStateToProps = state => ({
    profileData: profileDataSelector(state),
    skills: skillsSelector(state),
  });
  return connect(mapStateToProps, {
    updateProfile,
  })(profileWrapper);
};

export default EditProfileWrapper;
