import {RequestErrorLoader} from 'core/components';
import {useSaveProfileLoader} from 'core/hooks';
import ProfileStatus from './ProfileStatus';

const StatusData = ({onProfileDataSubmit, profileData}) => {
  const {request, error, data} = profileData;
  const [isLoading, onSubmit] = useSaveProfileLoader(
    request,
    onProfileDataSubmit,
  );

  return (
    <RequestErrorLoader body={{request: isLoading || (!data && request)}}>
      {!error && data && <ProfileStatus data={data} onChange={onSubmit} />}
    </RequestErrorLoader>
  );
};

export default StatusData;
