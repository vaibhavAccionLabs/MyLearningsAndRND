import {getFilesAndTotalSize} from 'core/utils';

import {DocUploader} from '../../profile/sharedComponents';
import profilePreviewData from 'data/settings-profilePreview.json';

const ResumeCoverLetter = props => {
  const {
    profileData: {data: student_profile, request, error},
  } = props;
  const {data: document_files, total_size_consumed} = getFilesAndTotalSize(
    student_profile,
    'related_document',
  );

  return (
    <div className='profile-edit-section'>
      <div className='s-ttl'>
        {profilePreviewData.resumeCovarLetterDocumentsHeading}
      </div>
      <div className='s-con'>
        <DocUploader
          viewOnly
          profileData={{
            data: document_files,
            total_size_consumed,
            request,
            error,
          }}
        />
      </div>
    </div>
  );
};

export default ResumeCoverLetter;
