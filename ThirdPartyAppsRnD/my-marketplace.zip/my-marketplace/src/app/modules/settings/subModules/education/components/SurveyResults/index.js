import {CustomCollapse} from 'core/components';
import Results from './Results';

const SurveyResults = props => {
  return (
    <div className='savedPath-content'>
      <CustomCollapse header='My Career Interest Survey Results'>
        <Results {...props} />
      </CustomCollapse>
    </div>
  );
};

export default SurveyResults;
