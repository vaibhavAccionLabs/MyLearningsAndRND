import React from 'react';
import {CustomCollapse} from 'core/components';

import Interests from './Interests';

const OccupationsInterest = props => (
  <div className='occupations-interest'>
    <CustomCollapse header='My Career Interest Report'>
      <Interests {...props} />
    </CustomCollapse>
  </div>
);

export default OccupationsInterest;
