import {useEffect} from 'react';
import {Link} from 'react-router-dom';

import {PathCard, Carousel, RequestErrorLoader} from 'core/components';

const config = {
  type: 'appliedWorkforce',
  nameLabel: 'Company: ',
  buttonText: 'APPLIED',
  buttonDisabled: true,
  buttonClass: 'btn-workforce-applied',
};

const Workforces = ({
  appliedOpportunities,
  fetchAppliedOpportunities,
  resetAppliedOpportunities,
}) => {
  useEffect(() => {
    fetchAppliedOpportunities();
    return () => {
      resetAppliedOpportunities();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const Opportunities = [];
  appliedOpportunities?.data &&
    Array.isArray(appliedOpportunities?.data) &&
    appliedOpportunities?.data.map(jobData => {
      const {
        opp_application_uuid,
        opportunity_name,
        opportunity_type,
        institute_name,
        institute_uuid,
        job_post_thumbnail_cloudinary,
      } = jobData || {};
      Opportunities.push({
        title: opportunity_name,
        institute_details: {
          name: institute_name,
          institute_uuid: institute_uuid,
        },
        tagType: opportunity_type,
        uuid: opp_application_uuid,
        banner_cloudinary: job_post_thumbnail_cloudinary,
      });
    });

  return (
    <>
      <RequestErrorLoader body={{request: appliedOpportunities?.request}} />

      {!appliedOpportunities?.error &&
        !appliedOpportunities?.request &&
        Opportunities && (
          <>
            {Opportunities?.length > 0 ? (
              <div
                className={`appliedWorkforces ${
                  Opportunities?.length < 4 ? 'less_cards' : ''
                }`}>
                <ul className='workforce_card'>
                  <Carousel
                    config={{slidesToShow: 4}}
                    data={Opportunities.map(appliedData => (
                      <PathCard
                        config={config}
                        data={appliedData}
                        enableNavigation
                        key={appliedData.uuid}
                        disLogo={false}
                        customClass={
                          Opportunities?.length < 4 ? 'customPathcard' : ''
                        }
                      />
                    ))}
                  />
                </ul>
              </div>
            ) : (
              <>
                <div className='btnExplore_position notapplied'>
                  <Link className='btn-blue-outer' to='/occupations'>
                    EXPLORE OCCUPATIONS
                  </Link>
                </div>
                <div className='workforceNoSubscriptions text-center mt-3 mb-5'>
                  <p>
                    It looks like you have not applied to any opportunities.
                    Explore occupations to apply.
                  </p>
                </div>
              </>
            )}
          </>
        )}
    </>
  );
};

export default Workforces;
