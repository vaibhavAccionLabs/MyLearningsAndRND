import {CustomCollapse} from 'core/components';
import VolunteerProfile from './VolunteerProfile';
import profileData from 'data/settings-profile.json';

const VolunteerExperience = props => {
  return (
    <CustomCollapse
      header={profileData.volunteerExperienceData.collapseBarHeading}>
      <VolunteerProfile {...props} />
    </CustomCollapse>
  );
};

export default VolunteerExperience;
