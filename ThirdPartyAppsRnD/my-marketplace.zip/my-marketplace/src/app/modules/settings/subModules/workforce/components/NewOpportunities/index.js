import {CustomCollapse} from 'core/components';
import Opportunities from './Opportunities';

const NewOpportunities = props => (
  <CustomCollapse header='New Job Matches' defaultOpen>
    <Opportunities {...props} />
  </CustomCollapse>
);

export default NewOpportunities;
