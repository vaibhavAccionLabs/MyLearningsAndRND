import {Dropdown, Button} from 'antd';
import {Link} from 'react-router-dom';

import {formatViewDate} from 'core/utils';
import {CreateMenu, ErrorBoundary} from 'core/components';

import {compare_pathIcon} from 'assets/images';

const comparePathCard = ({data, onDelete, customClass = ''}) => {
  const {updated_at, comparison_title, compare_path_uuid} = data;
  const displayEllipses = [
    {
      title: 'Delete',
      action: path => onDelete(path),
    },
  ];

  const comparePathCardMenu = data => {
    let menu = displayEllipses.map(item => {
      item.dataPassed = eval(data);
      return item;
    });
    return <CreateMenu data={menu} />;
  };

  return (
    <ErrorBoundary nameOfComponent='mod-comp-settings-myeducation-comparecard'>
      {data && (
        <div
          className={`comparePathsCard ${customClass}`}
          key={`comparePathsCard-${compare_path_uuid}`}>
          <span className='cardEllipses'>
            <Dropdown
              overlay={() => comparePathCardMenu(data)}
              overlayClassName='ddl-comparecard-Opt'>
              <Button>...</Button>
            </Dropdown>
          </span>
          <Link
            to={`/compare-paths?comparison_title=${encodeURIComponent(
              comparison_title,
            )}`}>
            <div>
              <div className='comparePathsIconsContainer'>
                <img className='pt-3' src={compare_pathIcon} />
              </div>
              <div className='comparePathTitle'>{comparison_title}</div>
              <h3 className='savedOn'>{`Saved on: ${formatViewDate(
                updated_at,
              )}`}</h3>
            </div>
          </Link>
        </div>
      )}
    </ErrorBoundary>
  );
};

export default comparePathCard;
