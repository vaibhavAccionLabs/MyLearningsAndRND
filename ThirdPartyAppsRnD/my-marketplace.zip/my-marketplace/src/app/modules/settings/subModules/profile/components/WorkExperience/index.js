import {CustomCollapse, RequestErrorLoader} from 'core/components';
import {useSaveProfileLoader} from 'core/hooks';
import {EditProfileWrapper} from '../../sharedComponents';

import WorkExperienceComponent from './WorkExperience';
import profileStaticData from 'data/settings-profile.json';

import './style.less';

const WorkExperience = ({profileData, onProfileDataSubmit}) => {
  const {request, data} = profileData;
  const [isLoading, onSubmit] = useSaveProfileLoader(
    request,
    onProfileDataSubmit,
  );
  return (
    <CustomCollapse
      header={profileStaticData.workExperienceData.collapseBarHeading}>
      <RequestErrorLoader body={{...profileData, request: isLoading}}>
        <WorkExperienceComponent
          data={data}
          title={profileStaticData.workExperienceData.collapseBarHeading}
          hideTitle
          hideEmpty
          onChange={onSubmit}
        />
      </RequestErrorLoader>
    </CustomCollapse>
  );
};

export default EditProfileWrapper(WorkExperience);
