import {Tag, Row, Col} from 'antd';
import {CloseOutlined} from '@ant-design/icons';
import {editpurple, arrowpurple} from 'assets/images';
import './styles.less';

export default function SkillsTable({
  data = [],
  deleteSkill,
  editSkill,
  viewOnly,
}) {
  const getLineWidth = value => (value * 100) / 10;

  return (
    <div>
      {data?.length ? (
        <div className='graph-results'>
          <table className='graph-table'>
            <thead>
              <tr>
                <th style={{width: '25%'}}>Skills Tag</th>
                <th style={{width: '5%'}} className='dividerLine'></th>
                <th style={{width: '55%'}}>
                  Years of Experience
                  <Row justify='space-between' align='middle'>
                    <span>
                      <h5>0</h5>
                    </span>
                    <span>
                      <h5>10+</h5>
                    </span>
                  </Row>
                </th>
                {!viewOnly && <th>Actions</th>}
              </tr>
            </thead>
            <tbody>
              {data?.map((dt = {}) => (
                <tr key={dt.uuid}>
                  <td
                    style={{width: '25%'}}
                    title={`${dt.skill} (${dt.experience}${
                      dt.experience > 1 ? ' yrs' : ' yr'
                    })`}>
                    <Tag color='#2db7f5'>{`${
                      dt.skill?.length > 35
                        ? dt.skill.substring(0, 35) + '..'
                        : dt.skill
                    }

                    (${dt.experience}${
                      dt.experience > 1 ? ' yrs' : ' yr'
                    })`}</Tag>
                  </td>
                  <td style={{width: '5%'}} className='dividerLine'></td>
                  <td style={{width: '55%'}} title={dt.experience}>
                    <div className='bar-perc-c'>
                      <div className='bar-perc-h'>
                        <div
                          style={{width: `${getLineWidth(dt.experience)}%`}}
                          className='bar-perc'></div>
                      </div>
                    </div>
                  </td>
                  {!viewOnly && (
                    <td style={{width: '10%'}}>
                      <img
                        src={editpurple}
                        className='cursor-pointer'
                        onClick={() => editSkill(dt)}
                      />
                      <CloseOutlined
                        color='black'
                        onClick={() => deleteSkill(dt)}
                      />
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <Row className='noSkillFound' justify='center' align='middle'>
          <Col span={8} className='d-flex justify-content-center'>
            <img src={arrowpurple} alt='' />
          </Col>
          <Col span={16}>
            <h5>No Skills Found</h5>
            <p>
              It looks like you have not added any skills tags to this profile,
              skills tags will help better match you to the right pathway or
              employment opportunity. Add a skill to get started!
            </p>
          </Col>
        </Row>
      )}
    </div>
  );
}
