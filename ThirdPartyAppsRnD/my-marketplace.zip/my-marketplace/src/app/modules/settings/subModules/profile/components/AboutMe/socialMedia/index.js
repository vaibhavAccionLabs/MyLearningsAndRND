import {Checkbox, Row} from 'antd';
import {useUser} from 'core/hooks';
import {InputWithIcons} from 'core/components';
import {
  white_twitter,
  white_facebook,
  white_linkedin,
  color_instagram,
  color_medium,
  color_tiktok,
} from 'assets/images';
import profileData from 'data/settings-profile.json';

import styles from './style.module.less';

const medias = [
  {
    name: 'Facebook',
    icon: white_facebook,
    link: 'facebook_link',
    enabled: 'show_facebook_link',
    urlFormat: 'https://facebook.com',
  },
  {
    name: 'LinkedIn',
    icon: white_linkedin,
    link: 'linkedin_link',
    enabled: 'show_linkedin_link',
    urlFormat: 'https://linkedin.com',
  },
  {
    name: 'Twitter',
    icon: white_twitter,
    link: 'twitter_link',
    enabled: 'show_twitter_link',
    urlFormat: 'https://twitter.com',
  },
  {
    name: 'Instagram',
    icon: color_instagram,
    link: 'instagram_link',
    enabled: 'show_instagram_link',
    urlFormat: 'https://instagram.com',
  },
  {
    name: 'TikTok',
    icon: color_tiktok,
    link: 'tiktok_link',
    enabled: 'show_tiktok_link',
    urlFormat: 'https://tiktok.com',
  },
  {
    name: 'Medium',
    icon: color_medium,
    link: 'medium_link',
    enabled: 'show_medium_link',
    urlFormat: 'https://medium.com',
  },
];

const SocialMedia = ({updateUserProfile}) => {
  const {data} = useUser();

  const saveSocialLink = async (formData, _inputRef) => {
    const key = Object.keys(formData)[0];
    const link = `show_${key}`;
    formData[link] = true;
    if (data[key] !== formData[key]) {
      if (formData[key] === '') {
        formData[key] = null;
        formData[link] = false;
      }
      _inputRef?.current?.blur();
      await updateUserProfile(formData);
    }
  };

  const updateCheckBox = async (event, name) =>
    await updateUserProfile({[name]: !!event?.target?.checked});

  return (
    <div className={`${styles.social_media}`}>
      <h2>{profileData.aboutMeData.socialMediaData.title}</h2>
      <div
        dangerouslySetInnerHTML={{
          __html: profileData.aboutMeData.socialMediaData.desc,
        }}
      />
      <Row justify='space-between' wrap className='mt-4'>
        {data &&
          medias.map(({name, link, icon, enabled, urlFormat}) => {
            return (
              <div key={`___${name}___`} className={styles.media_item}>
                <Checkbox
                  className={data[enabled] ? 'active' : ''}
                  checked={!!data[enabled]}
                  onChange={event => updateCheckBox(event, enabled)}>
                  <img
                    src={icon}
                    alt={name}
                    className={styles[`${name}_icon`]}
                  />
                  <span>&nbsp;{name}</span>
                </Checkbox>
                <InputWithIcons
                  enableCheck
                  enableClear
                  label={`${name} URL:`}
                  name={link}
                  value={data[link] || ''}
                  placeholder={urlFormat}
                  handleSave={saveSocialLink}
                />
              </div>
            );
          })}
      </Row>
    </div>
  );
};

export default SocialMedia;
