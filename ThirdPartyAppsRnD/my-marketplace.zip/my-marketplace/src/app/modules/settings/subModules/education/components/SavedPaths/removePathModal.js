const DeletePath = ({title = ''}) => {
  return (
    <div className='delete-saved-path-modal'>
      <div className='ttl'>Unsave Path</div>
      <div className='desc'>
        Are you sure want to unsave this saved path <br />
        <span>{title}</span>?
      </div>
    </div>
  );
};

export default DeletePath;
