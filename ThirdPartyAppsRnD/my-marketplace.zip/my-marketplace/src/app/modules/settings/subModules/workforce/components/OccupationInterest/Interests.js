import {useEffect, useMemo} from 'react';
import {useHistory, Link} from 'react-router-dom';
import {Modal} from 'antd';
import {DeleteFilled} from '@ant-design/icons';
import {isArray, isEmpty} from 'lodash';

import {
  BarChart,
  RequestErrorLoader,
  NoContentNavigator,
} from 'core/components';

import DeleteConfirm from './deleteConfirm';

const sortInterest = interestData =>
  interestData &&
  Array.isArray(interestData) &&
  interestData?.sort((a, b) => b.score - a.score);

const Interests = ({
  fetchOccupationInterests,
  deleteOccupationInterest,
  occupationInterest,
}) => {
  const history = useHistory();
  const {data: interestData, request, deleteRequest} = occupationInterest || {};
  const data = useMemo(() => sortInterest(interestData), [interestData]);

  useEffect(() => {
    fetchOccupationInterests();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const onDeleteOccupationInterest = (id, name) => {
    Modal.confirm({
      title: null,
      centered: true,
      width: 800,
      icon: null,
      closable: true,
      okText: 'YES',
      className: 'modal-msg is-confirm',
      content: <DeleteConfirm title={name} />,
      onOk: async () => {
        await deleteOccupationInterest(id);
        fetchOccupationInterests();
      },
    });
  };

  const onDeleteClick = (idx, lbl) => {
    if (idx !== null && data[idx] && data[idx].uuid) {
      onDeleteOccupationInterest(data[idx].uuid, lbl);
    }
  };
  const onLabelClick = (idx, lbl) => {
    if (lbl) {
      history.push(`/occupation?query=${encodeURIComponent(lbl)}`);
    }
  };

  return (
    <RequestErrorLoader
      overideNoDataContainer={
        <NoContentNavigator
          message='It looks like you have not rated your interest in any occupations.'
          subHeading='Explore occupations to rate your interest.'
          pathTo='/occupations'
          label='Explore Occupations'
        />
      }
      body={{...occupationInterest, request: request || deleteRequest}}>
      {data && isArray(data) && !isEmpty(data) && (
        <>
          <div className='text-right'>
            <Link className='btn-blue-outer' to='/occupations'>
              EXPLORE OCCUPATIONS
            </Link>
          </div>
          <BarChart
            data={data.map(i => (i && i.score ? i.score : 0))}
            labels={data.map(i =>
              i && i.occupation_details && i.occupation_details.occupation_name
                ? i.occupation_details.occupation_name
                : '',
            )}
            onActionClick={onDeleteClick}
            onLabelClick={onLabelClick}
            height={40}
            maxTicks={5}
            tickStepSize={1}
            actionComponent={<DeleteFilled className='chart-delete-icon' />}
          />
        </>
      )}
    </RequestErrorLoader>
  );
};

export default Interests;
