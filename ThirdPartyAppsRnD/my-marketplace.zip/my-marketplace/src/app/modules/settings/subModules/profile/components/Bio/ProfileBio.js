import React, {useEffect, useState} from 'react';
import {Button, Input} from 'antd';

import {API} from 'config';
import profileData from 'data/settings-profile.json';

const {TextArea} = Input;

const ProfileBio = ({data, heading, onChange, viewOnly}) => {
  const {bio} = data || {};
  const [edit, setEdit] = useState(false);
  const [bioData, setBioData] = useState('');
  useEffect(() => {
    setBioData(bio);
  }, [bio, data]);
  const onEdit = async () => {
    if (onChange) {
      await onChange('bio', API.gps.student_profile, bioData, 'PATCH');
      cancelEdit();
    }
  };
  const cancelEdit = () => {
    setEdit(false);
    setBioData('');
  };
  const openEdit = () => {
    setBioData(bio);
    setEdit(true);
  };
  return (
    <div className={'profile-edit-section' + (viewOnly ? ' rounded ' : '')}>
      <div className='s-ttl'>{heading}</div>
      <div className='s-con'>
        {!edit ? (
          <div className='display-text wrap-content'>{bio}</div>
        ) : (
          <TextArea
            className='field-textarea'
            onChange={e => setBioData(e.target.value)}
            showCount
            value={bioData}
            maxLength={2500}
            rows={5}
          />
        )}
        {!bio ||
          (bio === '' && (
            <div className='empty-ct'>{profileData.bioData.noBioAddedTxt}</div>
          ))}
      </div>
      {!viewOnly && (
        <div className='s-actn'>
          {!edit ? (
            <Button className='btn btn-purple-outer' onClick={openEdit}>
              {profileData.bioData.editBioTxt}
            </Button>
          ) : (
            <>
              <Button
                className='btn btn-cancel'
                type='primary'
                onClick={cancelEdit}>
                {profileData.cancelBtnTxt}
              </Button>
              <Button className='btn' type='primary' onClick={onEdit}>
                {profileData.saveBtnTxt}
              </Button>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default ProfileBio;
