import {Modal, message} from 'antd';

import {CustomCollapse} from 'core/components';
import Workforces from './Workforces';
import {successTick} from 'assets/images';

const SavedWorkforces = props => {
  const {
    unSaveOpportunity,
    updateOpportunityInterest,
    fetchSavedOpportunities,
    fetchAppliedOpportunities,
  } = props;
  const onRemove = data => {
    const {title, opp_application_uuid} = data;
    const txt = (
      <div>
        Are you sure want to remove this
        <p>
          <span>{title}</span>?
        </p>
      </div>
    );
    Modal.confirm({
      content: txt,
      title: 'Remove Opportunity',
      onOk: () => removeOpportunity(opp_application_uuid),
      okText: 'Yes',
      className: 'occupation-unsubscribe',
      closable: true,
      confirmLoading: true,
    });
  };

  const removeOpportunity = async opp_application_uuid => {
    if (opp_application_uuid) {
      await unSaveOpportunity(opp_application_uuid, err => {
        if (err) {
          message.error(err);
        } else {
          message.success('Opportunity unsaved successfully.');
        }
      });
      fetchSavedOpportunities(); // Refresh saved opportunities content after removing
    }
  };

  const onApplyOpportunity = async data => {
    const {
      uuid,
      title,
      tagType,
      opp_application_uuid,
      institute_details: {name, institution_uuid},
      banner_cloudinary,
    } = data;
    const body = {
      job_post_thumbnail_cloudinary: banner_cloudinary,
      bp_opportunity_id: uuid,
      opportunity_name: title,
      opportunity_type: tagType,
      institute_uuid: institution_uuid,
      institute_name: name,
      action_type: 'apply',
    };
    try {
      await updateOpportunityInterest(body, err => {
        if (err) {
          message.error(err);
        } else {
          // Unsave the saved opportunity once applied
          unSaveOpportunity(opp_application_uuid, err => {
            if (err) {
              message.error(err);
              return;
            }
            onApplySuccess(title);
            // Refresh both saved & applied opportunities content after applying
            fetchSavedOpportunities();
            fetchAppliedOpportunities();
          });
        }
      });
    } catch (err) {
      console.log(err);
      err && message.error(err);
    }
  };

  const onApplySuccess = title => {
    const txt = (
      <div className='text-center'>
        <img src={successTick} alt='success-icon' />
        <h2 className='modalHeading'>Applied Successfully</h2>
        <p>
          You have applied for <span className='modalTitle'>'{title}'</span>
          &nbsp;Successfully.
        </p>
        <p>
          Now you can see the opportunities in Opportunities I've applied for
          section.
        </p>
      </div>
    );
    Modal.success({
      content: txt,
      okText: 'OK',
      className: 'occupation-unsubscribe-apply occupation-saved-workforces',
      closable: true,
    });
  };

  return (
    <CustomCollapse header='Saved Jobs'>
      <Workforces {...props} onRemove={onRemove} onApply={onApplyOpportunity} />
    </CustomCollapse>
  );
};

export default SavedWorkforces;
