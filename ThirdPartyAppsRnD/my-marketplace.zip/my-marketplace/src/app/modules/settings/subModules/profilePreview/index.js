import {useState, useEffect, useMemo} from 'react';
import {connect} from 'react-redux';
import {useParams} from 'react-router-dom';
import {Row, Col, Button} from 'antd';
//PDFViewer :: Can be used for development
import {PDFDownloadLink} from '@react-pdf/renderer';
import {getFilesAndTotalSize} from 'core/utils';

import {
  fetchSharedProfileData,
  profileDataSelector,
  fetchSeekingData,
  awardTypesSelector,
} from 'redux/modules/profile';
import {getAppConfig} from 'redux/modules/general';
import {useUser, useActivePath, useAuth} from 'core/hooks';
import {
  ErrorBoundary,
  RequestErrorLoader,
  MyProfileDocument,
  NoContentNavigator,
} from 'core/components';

import {Banner} from '../../components';
import ProfileBio from '../profile/components/Bio/ProfileBio';
import ProfileAwards from '../profile/components/Awards/ProfileAwards';
import WorkExperience from '../profile/components/WorkExperience/WorkExperience';

// Local component
import OverviewPanel from './components/OverviewPanel';
import ProfileStatus from './components/ProfileStatus';
import ResumeCoverLetter from './components/ResumeCoverLetter';
import Skills from './components/Skills';

import profilePreviewData from 'data/settings-profilePreview.json';

import './styles.less';

const ProfilePreview = ({
  awardTypes,
  profileData,
  fetchSeekingData,
  fetchSharedProfileData,
  appConfig,
  profileData: {data: student_profile, request: profileLoading},
}) => {
  const {userName = ''} = useParams();
  const [isAuthenticated] = useAuth();
  const {data: student_Info} = useUser();
  const {pathInfo = {}} = useActivePath();
  const [ready, setReady] = useState(false);
  const {data: document_files = []} = getFilesAndTotalSize(
    student_profile,
    'related_document',
  );

  const renderDownload = useMemo(() => {
    return (
      isAuthenticated &&
      student_profile &&
      student_Info &&
      awardTypes &&
      pathInfo && (
        <>
          <ErrorBoundary
            nameOfComponent='module-download-profile'
            typeOfUi='subPage'>
            {ready && (
              <PDFDownloadLink
                document={
                  <MyProfileDocument
                    pathInfo={pathInfo}
                    awardTypes={awardTypes}
                    studentInfo={student_Info}
                    studentProfile={student_profile}
                  />
                }
                fileName='my_profile.pdf'>
                {({loading}) => (
                  <Button className='btn btn-purple-outer mr-4'>
                    {loading
                      ? profilePreviewData.loadingBtnTxt
                      : profilePreviewData.downloadBtnTxt}
                  </Button>
                )}
              </PDFDownloadLink>
            )}
            {/* For development use only */}
            {/* {ready && (
              <PDFViewer width='100%' height='700vh'>
                <MyProfileDocument
                  pathInfo={pathInfo}
                  awardTypes={awardTypes}
                  studentInfo={student_Info}
                  studentProfile={student_profile}
                />
              </PDFViewer>
            )} */}
          </ErrorBoundary>
        </>
      )
    );
  }, [
    awardTypes,
    isAuthenticated,
    pathInfo,
    ready,
    student_Info,
    student_profile,
  ]);

  useEffect(() => {
    fetchSeekingData();
    const validUserName =
      userName && userName !== 'null' && userName !== 'undefined';

    !student_profile &&
      validUserName &&
      fetchSharedProfileData(userName, isAuthenticated);

    // need to fix pdf renderer crashing issue
    setTimeout(() => {
      setReady({ready: true});
    }, 5000);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <ErrorBoundary
      nameOfComponent='module-settings-my-profile-preview'
      typeOfUi='subPage'>
      <RequestErrorLoader body={profileData}>
        {student_profile && student_Info && pathInfo ? (
          <>
            <Banner profileData={profileData} appConfig={appConfig} viewOnly />
            <div className='d-flex mb-5 contentContainer previewProfile'>
              <div className='clearfix column-gap ProfilePreviewContent'>
                <div className='downloadContainer download_mob'>
                  {renderDownload}
                </div>
                <Row type='flex' gutter={40} className='profile-container'>
                  <Col md={7}>
                    <OverviewPanel
                      student_profile={student_profile || {}}
                      student_Info={student_Info || {}}
                      activePath={pathInfo || {}}
                    />
                  </Col>
                  <Col md={17}>
                    <div className='ProfileContent'>
                      <div className='downloadContainer download_web'>
                        {renderDownload}
                      </div>
                      <ProfileStatus data={student_profile} />
                      {student_profile?.bio && (
                        <div className='mb-2'>
                          <ProfileBio
                            viewOnly
                            data={student_profile}
                            heading={
                              profilePreviewData.professionalSummaryHeading
                            }
                          />
                        </div>
                      )}
                      {student_profile?.skills &&
                        Array.isArray(student_profile?.skills) &&
                        student_profile?.skills.length > 0 && (
                          <Skills profileData={profileData} />
                        )}
                      {student_profile?.work_exp &&
                        Array.isArray(student_profile?.work_exp) &&
                        student_profile?.work_exp.length > 0 && (
                          <WorkExperience
                            title={profilePreviewData.workExperienceHeading}
                            data={student_profile}
                            viewOnly
                          />
                        )}
                      {student_profile?.awards_leadership_projects_publications &&
                        Array.isArray(
                          student_profile?.awards_leadership_projects_publications,
                        ) &&
                        student_profile?.awards_leadership_projects_publications
                          .length > 0 && (
                          <ProfileAwards
                            heading={profilePreviewData.awardsLeadershipHeading}
                            data={student_profile}
                            viewOnly
                          />
                        )}
                      {document_files &&
                        Array.isArray(document_files) &&
                        document_files.length > 0 && (
                          <ResumeCoverLetter profileData={profileData} />
                        )}
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </>
        ) : (
          <div className='my-3 noContent-preview-profile'>
            {!profileLoading && (
              <NoContentNavigator
                heading={`${profilePreviewData?.noContentData?.noContentHeading}`}
                subHeading={`${profilePreviewData?.noContentData?.noContentSubHeading} ${userName}`}
                pathTo={'/'}
                label={`${profilePreviewData?.noContentData?.goToHomePageLabel}`}
                showImg
              />
            )}
          </div>
        )}
      </RequestErrorLoader>
    </ErrorBoundary>
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  awardTypes: awardTypesSelector(state),
  profileData: profileDataSelector(state),
});
export default connect(mapStateToProps, {
  fetchSharedProfileData,
  fetchSeekingData,
})(ProfilePreview);
