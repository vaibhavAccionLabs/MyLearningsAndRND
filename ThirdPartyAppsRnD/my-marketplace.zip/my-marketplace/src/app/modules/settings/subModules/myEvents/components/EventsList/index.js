import {useState, useEffect} from 'react';
import {Button, Modal, message} from 'antd';

import {EventCard, RequestErrorLoader, NoEvents} from 'core/components';

const EventsList = props => {
  const {
    events,
    fetchMyEvents,
    withdrawEvent,
    removeMyEvent,
    clearMyEvents,
  } = props;
  const [page, setPage] = useState(1);

  useEffect(() => {
    fetchMyEvents(page);
    return () => {
      clearMyEvents();
    };
  }, [page]); // eslint-disable-line react-hooks/exhaustive-deps

  const loadMoreEvents = () => setPage(page + 1);

  const withDrawEvent = async event_uuid => {
    try {
      const response = await withdrawEvent(event_uuid);
      if (response?.Success) {
        message.success(response?.Success);
        removeMyEvent(event_uuid);
      }
    } catch (error) {
      message.error(error.message || 'Something went wrong.');
    }
  };

  const onWithdraw = data => {
    const {title, uuid} = data;
    const txt = (
      <>
        <p>
          Are your sure that you no longer wish to attend the event
          <br />
          <span className='pink-text'>{title}</span> ?
        </p>
        {/* <p>This will remove the event from the dashboard.</p> */}
      </>
    );

    Modal.confirm({
      wrapClassName: 'WithdrawEventModal',
      content: txt,
      width: '70%',
      title: 'Withdraw Event Signup',
      onOk: () => withDrawEvent(uuid),
      okText: 'Yes',
      cancelText: 'Cancel',
      className: 'occupation-unsubscribe',
      closable: true,
      confirmLoading: true,
    });
  };

  const displayEllipses = [
    {
      title: 'withdraw',
      action: onWithdraw,
      passData: true,
    },
  ];

  return (
    <RequestErrorLoader
      body={{...events, data: events?.data?.event_details}}
      overideNoDataContainer={<NoEvents subTitle={false} />}>
      <div className='eventCard'>
        <ul>
          {events?.data?.event_details?.length > 0 &&
            events?.data.event_details.map((event, idx) => (
              <EventCard
                enableNavigation
                key={event?.event_id}
                data={event}
                displayEllipses={displayEllipses}
              />
            ))}
        </ul>
        {events?.data?.page_details &&
          page < events?.data?.page_details?.no_of_pages && (
            <div className='text-center'>
              <Button
                type='primary'
                className='events-load-more'
                onClick={loadMoreEvents}>
                {events?.request ? 'LOADING...' : 'LOAD MORE'}
              </Button>
            </div>
          )}
      </div>
    </RequestErrorLoader>
  );
};

export default EventsList;
