import React, {useEffect, useState} from 'react';
import {isArray} from 'lodash';
import {Modal, message} from 'antd';
import {
  RequestErrorLoader,
  NoContentNavigator,
  Carousel,
  ErrorBoundary,
} from 'core/components';

import ComparePathCard from './comparePathCard';

import {NoComparedPathFound, DeleteComparedPath} from 'data/pathway';

import './styles.less';

const MyComparedPaths = ({
  fetchComparePathsList,
  deleteComparedPath,
  comparePathData,
}) => {
  const {request, error, list: comparePathsList} = comparePathData;
  const [deleteComparePathItem, setDeleteComparePathItem] = useState({});
  const [showDeleteComparePathModal, setShowDeleteComparePathModal] = useState(
    false,
  );
  const onDeleteMenuClick = comparePath => {
    setShowDeleteComparePathModal(true);
    setDeleteComparePathItem(comparePath);
  };
  const onCloseDeleteComparedPathModal = () => {
    setShowDeleteComparePathModal(false);
    setDeleteComparePathItem({});
  };
  const onDeleteComparedPath = async () => {
    deleteComparePathItem &&
      deleteComparePathItem.compare_path_uuid &&
      (await deleteComparedPath(
        deleteComparePathItem.compare_path_uuid,
        res => {
          fetchComparePathsList();
          if (res) {
            message.error(res);
          } else {
            message.success('Path comparison deleted successfully');
          }
        },
      ));
    onCloseDeleteComparedPathModal();
  };

  useEffect(() => {
    fetchComparePathsList();
    return () => {};
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <ErrorBoundary nameOfComponent='mod-comp-settings-myeducation-mycomparepaths'>
      <RequestErrorLoader
        overideNoDataContainer={
          <NoContentNavigator
            message={NoComparedPathFound}
            pathTo='/directory/paths-list'
            label='Explore Paths'
          />
        }
        body={{request, error, data: comparePathsList}}>
        {comparePathsList &&
          isArray(comparePathsList) &&
          comparePathsList.length > 0 && (
            <div
              className={`comparePathsContent ${
                comparePathsList.length < 4 ? 'less_cards' : ''
              }`}>
              <Carousel
                config={{slidesToShow: 4}}
                data={comparePathsList.map(comparePath => (
                  <ComparePathCard
                    data={comparePath}
                    onDelete={onDeleteMenuClick}
                    customClass={
                      comparePathsList.length < 4 ? 'customPathcard' : ''
                    }
                  />
                ))}
              />
            </div>
          )}
      </RequestErrorLoader>

      {showDeleteComparePathModal && (
        <Modal
          centered
          okText='Yes'
          closable={true}
          maskClosable={false}
          onCancel={onCloseDeleteComparedPathModal}
          onOk={onDeleteComparedPath}
          visible={true}
          className='delete-compared-path-modal'
          title={DeleteComparedPath}>
          <>
            <h3 className='compared-path-modal-description'>
              Are you sure you want to remove{' '}
              <span style={{color: '#de4279'}}>
                {deleteComparePathItem.comparison_title}
              </span>{' '}
              from your compared paths ?
            </h3>
          </>
        </Modal>
      )}
    </ErrorBoundary>
  );
};

export default MyComparedPaths;
