import {PathCard} from 'core/components';
import {educationPathwaysData} from 'data/settings-profilePreview.json';

const EducationalPathways = ({activePath}) => {
  const {title = ''} = activePath || {};

  return (
    <div className='panel-section'>
      <div className='section-title'>
        {educationPathwaysData.educationPathwaysTitle}
      </div>
      <div className='educational-details-container'>
        {title && <PathCard data={activePath} />}
      </div>
    </div>
  );
};

export default EducationalPathways;
