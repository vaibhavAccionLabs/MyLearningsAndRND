import {useEffect} from 'react';
import {Link} from 'react-router-dom';

import {PathCard, Carousel, RequestErrorLoader} from 'core/components';

const config = {
  type: 'occupation',
};

const Subscriptions = ({
  onUnsubscribe,
  subscribedOccupation,
  fetchSubscribedOccupation,
  appConfig: {isMobileView},
}) => {
  useEffect(() => {
    !subscribedOccupation.data && fetchSubscribedOccupation();
  }, [fetchSubscribedOccupation]); // eslint-disable-line react-hooks/exhaustive-deps

  const displayEllipses = [
    {
      title: 'Unsubscribe',
      action: onUnsubscribe,
      passingData: ['occupation_name', 'uuid'],
    },
  ];

  const isSubscriptions =
    subscribedOccupation.data && subscribedOccupation.data.length > 0;

  return (
    <>
      <RequestErrorLoader body={{request: subscribedOccupation.request}} />
      {!subscribedOccupation.error &&
        !subscribedOccupation.request &&
        subscribedOccupation.data && (
          <>
            <div
              className={`btnExplore_position ${
                isSubscriptions ? 'subscribed' : 'noSubscription'
              }`}>
              <Link className='btn-blue-outer' to='/occupations'>
                EXPLORE OCCUPATIONS
              </Link>
            </div>

            {!isSubscriptions && (
              <div className='workforceNoSubscriptions text-center mt-3 mb-5'>
                <p>
                  It looks like you have not subscribed to any occupations.
                  Explore Occupations to subscribe.
                </p>
              </div>
            )}

            {subscribedOccupation.data.length > 0 && (
              <div
                className={`workforceSubscriptions ${
                  !isMobileView && subscribedOccupation?.data?.length < 4
                    ? 'less_cards'
                    : ''
                }`}>
                <ul className='workforce_card'>
                  <Carousel
                    config={{slidesToShow: 4}}
                    data={subscribedOccupation.data.map(
                      (subscribedData, idx) => (
                        <PathCard
                          disLogo={false}
                          config={config}
                          data={subscribedData}
                          displayEllipses={displayEllipses}
                          enableNavigation
                          key={subscribedData.uuid}
                          customClass={
                            subscribedOccupation.data.length < 4
                              ? 'customPathcard'
                              : ''
                          }
                        />
                      ),
                    )}
                  />
                </ul>
              </div>
            )}
          </>
        )}
    </>
  );
};

export default Subscriptions;
