import {InputWithIcons} from 'core/components';
import {getFilesAndTotalSize} from 'core/utils';
import {DocUploader} from '../../sharedComponents';
import {API} from 'config';
import style from './style.module.less';

const document_type = 'portfolio_document',
  fieldName = 'portfolio_url';

const PortfolioComponent = props => {
  const {
    profileStaticData,
    updateProfile,
    profileData: {data, request, error},
  } = props;

  const {data: document_files, total_size_consumed} = getFilesAndTotalSize(
    data,
    document_type,
  );

  const savePortfolioLink = async (formData, _inputRef) => {
    const key = Object.keys(formData)[0];
    if (data[key] !== formData[key]) {
      if (formData[key] === '') {
        formData[key] = null;
      }
      _inputRef?.current?.blur();
      const endPoint = `${API.gps.student_profile}/${data?.student_profile_uuid}/`,
        method = 'PATCH';
      await updateProfile(endPoint, method, formData);
    }
  };

  return (
    <div className={style.Portfolio_section}>
      <p>{profileStaticData.portfolioData.title}</p>

      <InputWithIcons
        inlineForm
        enableCheck
        enableClear
        name={fieldName}
        value={data?.[fieldName] || ''}
        handleSave={savePortfolioLink}
        label={profileStaticData.portfolioData.portfolioUrl.label}
        placeholder={profileStaticData.portfolioData.portfolioUrl.placeholder}
      />

      <DocUploader
        {...props}
        noLoader
        type={document_type}
        maxFileSize={profileStaticData.portfolioData.maxFileSize}
        profileData={{
          data: document_files,
          total_size_consumed,
          request,
          error,
        }}
      />
    </div>
  );
};

export default PortfolioComponent;
