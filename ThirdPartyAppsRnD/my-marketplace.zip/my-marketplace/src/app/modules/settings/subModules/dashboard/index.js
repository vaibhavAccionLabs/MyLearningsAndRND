import {ErrorBoundary} from 'core/components';

// local component
import {ContentHeader} from '../../components';
import {Resources} from './components';

import './style.less';

const Dashboard = () => {
  return (
    <ErrorBoundary
      nameOfComponent='module-settings-my-dashboard'
      typeOfUi='subPage'>
      <ContentHeader title='My Dashboard' />
      <div className='profile-dashboard pt-2'>
        <Resources />
      </div>
    </ErrorBoundary>
  );
};

export default Dashboard;
