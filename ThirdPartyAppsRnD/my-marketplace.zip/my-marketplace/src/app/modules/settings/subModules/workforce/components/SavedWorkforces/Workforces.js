import {useEffect} from 'react';
import {Link} from 'react-router-dom';

import {PathCard, Carousel, RequestErrorLoader} from 'core/components';

const Workforces = ({
  onApply,
  onRemove,
  savedOpportunities,
  fetchSavedOpportunities,
  resetSavedOpportunities,
}) => {
  useEffect(() => {
    !savedOpportunities?.data && fetchSavedOpportunities();
    return () => {
      resetSavedOpportunities();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const config = {
    type: 'appliedWorkforce',
    nameLabel: 'Company: ',
    buttonText: 'Apply',
    buttonDisabled: false,
    buttonClass: 'btn-workforce-applied',
    buttonAction: onApply,
    buttonActionData: true,
  };

  const displayEllipses = [
    {
      title: 'Remove',
      action: onRemove,
      passingData: ['title', 'opp_application_uuid'],
    },
  ];

  const Opportunities = [];
  savedOpportunities?.data &&
    Array.isArray(savedOpportunities?.data) &&
    savedOpportunities?.data.map(jobData => {
      const {
        opp_application_uuid,
        bp_opportunity_id,
        opportunity_name,
        opportunity_type,
        institute_name,
        institute_uuid,
        job_post_thumbnail_cloudinary,
      } = jobData || {};
      Opportunities.push({
        title: opportunity_name,
        institute_details: {
          name: institute_name,
          institution_uuid: institute_uuid,
        },
        opp_application_uuid,
        uuid: bp_opportunity_id,
        tagType: opportunity_type,
        banner_cloudinary: job_post_thumbnail_cloudinary,
      });
    });

  return (
    <>
      <RequestErrorLoader
        body={{
          request: savedOpportunities?.request,
        }}
      />

      {!savedOpportunities?.error &&
        !savedOpportunities?.request &&
        Opportunities && (
          <>
            {Opportunities?.length > 0 ? (
              <div
                className={`savedWorkforces ${
                  Opportunities?.length < 4 ? 'less_cards' : ''
                }`}>
                <ul className='workforce_card'>
                  <Carousel
                    config={{slidesToShow: 4}}
                    data={Opportunities.map(savedData => (
                      <PathCard
                        config={config}
                        data={savedData}
                        displayEllipses={displayEllipses}
                        enableNavigation
                        key={savedData.uuid}
                        disLogo={false}
                        customClass={
                          Opportunities?.length < 4 ? 'customPathcard' : ''
                        }
                      />
                    ))}
                  />
                </ul>
              </div>
            ) : (
              <>
                <div className='btnExplore_position notapplied'>
                  <Link className='btn-blue-outer' to='/occupations'>
                    EXPLORE OCCUPATIONS
                  </Link>
                </div>
                <div className='workforceNoSubscriptions text-center mt-3 mb-5'>
                  <p>
                    It looks like you have not saved any opportunities. <br />
                    Explore occupations to save.
                  </p>
                </div>
              </>
            )}
          </>
        )}
    </>
  );
};

export default Workforces;
