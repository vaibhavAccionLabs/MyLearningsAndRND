import {CustomCollapse} from 'core/components';
import EducationProfile from './EducationProfile';

const Education = props => {
  return (
    <CustomCollapse header='Education' defaultOpen>
      <EducationProfile {...props} />
    </CustomCollapse>
  );
};

export default Education;
