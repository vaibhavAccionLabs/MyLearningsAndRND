import {useEffect, useState} from 'react';
import {connect} from 'react-redux';
import {Modal, message} from 'antd';
import {
  fetchSkills,
  fetchProfileData,
  profileDataSelector,
  skillsSelector,
  studentSkillsSelector,
  fetchStudentSkills,
  saveStudentSkill,
  updateStudentSkill,
  deleteStudentSkill,
} from 'redux/modules/profile';
import {ErrorBoundary, RequestErrorLoader} from 'core/components';
//Local Components
import {ContentHeader} from '../../components';
import {SpiderChart, AddSkill, SkillsTable} from './components';
import './style.less';

const Skills = ({
  profileData,
  fetchProfileData,
  fetchSkills,
  fetchStudentSkills,
  saveStudentSkill,
  updateStudentSkill,
  deleteStudentSkill,
  studentSkills,
  skills,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [selectedSkill, updateSelectedSkill] = useState();

  useEffect(() => {
    !profileData.data && fetchProfileData();
    fetchSkills();
    fetchStudentSkills();
  }, [fetchProfileData, fetchSkills, fetchStudentSkills, profileData.data]);

  const {request, data = []} = studentSkills || {};
  const sortedData =
    data && Array.isArray(data)
      ? data.sort((a, b) => b.experience - a.experience)
      : [];
  const {request: skillsRequest, data: skillsData} = skills || {};

  const toggleModalState = value => {
    setShowModal(!showModal);
    value && updateSelectedSkill(value);
  };

  const deleteSkill = skill => {
    skill && deleteStudentSkill(skill, fetchStudentSkills);
  };

  const onSkillsSubmit = (values, editMode) => {
    if (editMode) {
      updateStudentSkill(
        {
          ...selectedSkill,
          ...values,
        },
        fetchStudentSkills,
      );
      toggleModalState();
    } else {
      if (data && data.length >= 16) {
        message.error(<strong>You can only add upto 16 skills</strong>);
      } else {
        values && saveStudentSkill(values, fetchStudentSkills);
      }
    }
  };

  return (
    <ErrorBoundary
      nameOfComponent='module-settings-my-skills'
      typeOfUi='subPage'>
      <RequestErrorLoader body={{request: request || skillsRequest}}>
        <div className='profile-skills'>
          <ContentHeader title='My Skills' />
          <div className='skills-description mb-4'>
            Welcome to your Skills Profile, a live, visual and marketable
            representation of your expertise and abilities. Your Skills Tags
            describe and connect your experience and skill sets needed for
            successful workforce performance to pathway and employment
            opportunities. By logging skills, you will see more clearly areas
            where you can grow and become better matched to your next
            opportunity.
          </div>
          <div className='outerBorder'>
            <div className='header'>Your Skills Profile</div>
            <SpiderChart data={sortedData} />
            <AddSkill
              data={sortedData}
              skillsData={skillsData}
              onSkillsSubmit={onSkillsSubmit}
              selectedSkill={selectedSkill}
              toggleModalState={toggleModalState}
            />
            {!skillsRequest && (
              <SkillsTable
                data={sortedData}
                editSkill={toggleModalState}
                deleteSkill={deleteSkill}
              />
            )}
          </div>
        </div>
        <Modal
          visible={showModal}
          footer={false}
          className='edit-skills-modal'
          destroyOnClose
          onCancel={() => toggleModalState()}>
          <h1>Edit Skill</h1>
          <AddSkill
            data={sortedData}
            skillsData={skillsData}
            onSkillsSubmit={onSkillsSubmit}
            selectedSkill={selectedSkill}
            toggleModalState={toggleModalState}
            editMode
          />
        </Modal>
      </RequestErrorLoader>
    </ErrorBoundary>
  );
};

const mapStateToProps = state => ({
  profileData: profileDataSelector(state),
  skills: skillsSelector(state),
  studentSkills: studentSkillsSelector(state),
});

export {SpiderChart, SkillsTable};
export default connect(mapStateToProps, {
  fetchSkills,
  fetchProfileData,
  fetchStudentSkills,
  saveStudentSkill,
  updateStudentSkill,
  deleteStudentSkill,
})(Skills);
