import {useState} from 'react';
import {Modal, message, Row, Col} from 'antd';
import {isObject, isEmpty, isArray} from 'lodash';

import {
  RequestErrorLoader,
  NoContentNavigator,
  PathCard,
  ErrorBoundary,
} from 'core/components';

import {skillsLearned} from 'core/utils';

import {
  NoActivePathFound,
  DeleteActivePath,
  PathWillBeRemoved,
} from 'data/pathway';

import './style.less';

const {error, success} = message;

const MyActivePaths = ({deleteActivePath, activePath}) => {
  const {data, pathInfo, request, error: activePathError} = activePath;
  const [showDeleteActivePathModal, setShowDeleteActivePathModal] = useState(
    false,
  );

  const onDeleteActivePath = async () => {
    const onBoard_uuid =
      data && Array.isArray(data) && data[0]?.student_onboard_uuid;
    if (onBoard_uuid) {
      await deleteActivePath(data[0].student_onboard_uuid, err => {
        if (err) {
          error(err);
        } else {
          onCloseDeleteActivePathModal();
          success('Active Path deleted successfully');
        }
      });
    }
  };

  const onCloseDeleteActivePathModal = () =>
    setShowDeleteActivePathModal(false);

  const onDeleteMenuClick = () => setShowDeleteActivePathModal(true);

  const displayEllipses = [
    {
      title: 'Delete',
      action: () => onDeleteMenuClick(),
    },
  ];

  return (
    <ErrorBoundary nameOfComponent='mod-comp-settings-myeducation-mypaths'>
      {request && <RequestErrorLoader body={{request: true}} />}

      {/* Todo: give the flexibility in above component to render the children */}
      {!request &&
        !activePathError &&
        (!data || (data && isArray(data) && data.length === 0)) &&
        (!pathInfo ||
          (pathInfo && isObject(pathInfo) && isEmpty(pathInfo))) && (
          <NoContentNavigator
            message={NoActivePathFound}
            pathTo='/directory/paths-list'
            label='Explore Paths'
          />
        )}
      {pathInfo &&
        isObject(pathInfo) &&
        !isEmpty(pathInfo) &&
        data &&
        isArray(data) &&
        data.length > 0 &&
        !request &&
        !activePathError && (
          <div className='activePathsContent'>
            <Row className='educational-details-container'>
              <Col xs={24} sm={8} md={8} lg={8}>
                <PathCard
                  enableNavigation
                  data={pathInfo}
                  displayEllipses={displayEllipses}
                />
              </Col>
              <Col xs={24} sm={16} md={16} lg={16}>
                <div className='educational-details'>
                  <div className='skills-learned'>
                    <div className='heading'>Skills Learned</div>
                    {skillsLearned(pathInfo)}
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        )}
      {showDeleteActivePathModal && (
        <Modal
          centered
          okText='Yes'
          closable={true}
          maskClosable={false}
          onOk={onDeleteActivePath}
          onCancel={onCloseDeleteActivePathModal}
          visible={showDeleteActivePathModal}
          className='delete-active-path-modal'
          title={DeleteActivePath}>
          <div className='delete-active-path-modal-container'>
            <h3 className='active-path-modal-description'>
              Are you sure you want to delete{' '}
              <span style={{color: '#de4279'}}>{pathInfo.title}</span>.
            </h3>
            <h3>{PathWillBeRemoved}</h3>
          </div>
        </Modal>
      )}
    </ErrorBoundary>
  );
};

export default MyActivePaths;
