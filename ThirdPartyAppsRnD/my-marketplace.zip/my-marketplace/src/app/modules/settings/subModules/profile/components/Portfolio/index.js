import {
  CustomCollapse,
  RequestErrorLoader,
  ErrorBoundary,
} from 'core/components';
import PortfolioComponent from './PortfolioComponent';
import profileStaticData from 'data/settings-profile.json';
import style from './style.module.less';

const Portfolio = props => {
  return (
    <section className={style.Portfolio_main}>
      <CustomCollapse
        header={profileStaticData.portfolioData.collapseBarHeading}>
        <RequestErrorLoader body={props.profileData}>
          <ErrorBoundary nameOfComponent='mod-comp-settings-myprofile-portfolio'>
            <PortfolioComponent
              profileStaticData={profileStaticData}
              {...props}
            />
          </ErrorBoundary>
        </RequestErrorLoader>
      </CustomCollapse>
    </section>
  );
};

export default Portfolio;
