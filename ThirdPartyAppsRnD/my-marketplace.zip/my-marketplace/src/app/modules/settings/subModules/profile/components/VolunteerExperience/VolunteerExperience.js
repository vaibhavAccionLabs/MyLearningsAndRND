import React, {useState} from 'react';
import {Button, Divider, Form, Row, Col, InputNumber} from 'antd';
import {DeleteOutlined, EditOutlined} from '@ant-design/icons';

import {API} from 'config';
import {PATTERN} from 'core/regex';
import {CountField} from 'core/components';
import profileData from 'data/settings-profile.json';

const layout = {
  labelCol: {span: 8},
  wrapperCol: {span: 16},
};
const AddVolunteerExperience = ({edit, onCancel, onSubmit, data = {}}) => {
  const onFinish = v => {
    if (onSubmit) onSubmit(v);
  };

  return (
    <div className='s-section'>
      <Form
        size={'large'}
        {...layout}
        name='basic'
        onFinish={onFinish}
        // onFinish={onFinish}
        // onFinishFailed={onFinishFailed}
      >
        <Form.Item
          label={profileData.volunteerExperienceData.experience.label}
          name='name'
          className='field-input'
          initialValue={data.name}
          rules={[
            {
              required: true,
              message:
                profileData.volunteerExperienceData.experience.requiredMsg,
            },
          ]}>
          <CountField
            placeholder={
              profileData.volunteerExperienceData.experience.placeholder
            }
            fieldtype='Input'
            showcount
            maxLength={60}
          />
        </Form.Item>
        <Form.Item
          label={profileData.volunteerExperienceData.hours.label}
          name='hours'
          className='field-input'
          initialValue={data.hours}
          rules={[
            {
              required: true,
              message: profileData.volunteerExperienceData.hours.requiredMsg,
            },
            {
              pattern: PATTERN.Number_With_Float,
              message: profileData.volunteerExperienceData.hours.validationMsg,
            },
          ]}>
          <InputNumber
            style={{width: 140}}
            placeholder={profileData.volunteerExperienceData.hours.placeholder}
          />
        </Form.Item>
        <Form.Item
          label={
            profileData.volunteerExperienceData.rolesResponsibilities.label
          }
          style={{marginBottom: 0}}>
          <Form.List
            name='roles_responsibilities'
            initialValue={data.roles_responsibilities || ['']}>
            {(fields, {add, remove}) => (
              <div>
                {fields.map(({key, name, fieldKey, ...restField}, idx) => (
                  <div className='input-arrays' key={idx}>
                    <Form.Item
                      name={[name, 'roles_responsibilities']}
                      fieldKey={[fieldKey, 'roles_responsibilities']}
                      className='field-input field-textarea'>
                      <CountField
                        placeholder={
                          profileData.volunteerExperienceData
                            .rolesResponsibilities.placeholder
                        }
                        className='field-textarea'
                        fieldtype={'TextArea'}
                        autoSize={{minRows: 1, maxRows: 6}}
                        showcount
                        maxLength={100}
                      />
                    </Form.Item>
                    {idx != 0 && (
                      <DeleteOutlined
                        onClick={() => remove(name)}
                        className={'delete-input-icon'}
                      />
                    )}
                  </div>
                ))}
                <Row justify={'end'} className='actn-section-link'>
                  <Col>
                    <Button type='link' onClick={() => add()}>
                      {profileData.addRoleBtnTxt}
                    </Button>
                  </Col>
                </Row>
              </div>
            )}
          </Form.List>
        </Form.Item>

        <div className='s-actn is-right'>
          <Button className='btn btn-cancel' type='primary' onClick={onCancel}>
            {profileData.cancelBtnTxt}
          </Button>
          <Button className='btn' type='primary' htmlType='submit'>
            {edit ? profileData.saveBtnTxt : profileData.addBtnTxt}
          </Button>
        </div>
      </Form>
    </div>
  );
};

const VolunteerExperience = ({data, onChange, viewOnly}) => {
  const {voluntary_exp: volunteer_experience} = data || {};
  const [isAdd, setAdd] = useState(false);
  const [editIndex, setEditIndex] = useState(-1);
  const cancelAddEdit = () => {
    setAdd(false);
    setEditIndex(-1);
  };
  const formatData = (v, id) => {
    const data = {...v};
    if (v.roles_responsibilities && v.roles_responsibilities.length > 0) {
      data['roles_responsibilities'] = v.roles_responsibilities.map(
        i => i.roles_responsibilities,
      );
    }
    if (id) {
      data['volunteer_exp_uuid'] = id;
    }
    return data;
  };
  const onVolunteerExperience = async v => {
    if (onChange)
      await onChange(
        false,
        API.gps.volunteer_experience,
        formatData(v),
        'POST',
        false,
      );
    cancelAddEdit();
  };
  const onEdit = async (v, id) => {
    if (onChange)
      await onChange(
        false,
        API.gps.volunteer_experience,
        formatData(v, id),
        'PATCH',
        id,
      );
    cancelAddEdit();
  };
  const editData = idx => {
    setAdd(false);
    setEditIndex(idx);
  };
  const deleteExp = async exp => {
    if (onChange)
      await onChange(
        false,
        API.gps.volunteer_experience,
        {},
        'DELETE',
        exp.volunteer_exp_uuid,
      );
    cancelAddEdit();
  };
  return (
    <div className='profile-edit-section'>
      <div className='s-ttl'>
        {profileData.volunteerExperienceData.collapseBarHeading}
      </div>
      <div className='s-con'>
        {volunteer_experience &&
          volunteer_experience.map((exp, idx) =>
            editIndex === idx ? (
              <div style={{maxWidth: 500}} key={idx}>
                <AddVolunteerExperience
                  data={exp}
                  edit
                  onSubmit={v => onEdit(v, exp.volunteer_exp_uuid)}
                  onCancel={cancelAddEdit}
                />
                <Divider />
              </div>
            ) : (
              <div className='list-itm' key={idx}>
                {!viewOnly && (
                  <div className='list-actns'>
                    <EditOutlined onClick={() => editData(idx)} />
                    <DeleteOutlined onClick={() => deleteExp(exp)} />
                  </div>
                )}

                <div className='list-itm-r'>
                  <span className='lbl'>
                    {profileData.volunteerExperienceData.experience.label}:
                  </span>
                  <span className='val'>{exp.name}</span>
                </div>
                <div className='list-itm-r'>
                  <span className='lbl'>
                    {profileData.volunteerExperienceData.hours.label}:{' '}
                  </span>
                  <span className='val no-margin'>
                    {exp.hours % 1 != 0 ? exp.hours : Math.round(exp.hours)}
                  </span>
                </div>
                <div className='list-itm-r'>
                  <span className='lbl'>
                    {
                      profileData.volunteerExperienceData.rolesResponsibilities
                        .label
                    }
                    :
                  </span>
                  <div className='list-bullets'>
                    {exp.roles_responsibilities &&
                      exp.roles_responsibilities.map((role, idx) => {
                        if (role.roles_responsibilities)
                          return (
                            <div className='itm wrap-content' key={idx}>
                              {role.roles_responsibilities}
                            </div>
                          );
                      })}
                  </div>
                </div>
                {idx !== volunteer_experience.length - 1 && <Divider />}
              </div>
            ),
          )}
        {!volunteer_experience ||
          !Array.isArray(volunteer_experience) ||
          (volunteer_experience.length === 0 && (
            <div className='empty-ct'>
              {
                profileData.volunteerExperienceData
                  .noVolunteerExperienceAddedTxt
              }
            </div>
          ))}
      </div>
      {!viewOnly && (
        <>
          {isAdd && (
            <div className='s-con' style={{maxWidth: 600}}>
              <AddVolunteerExperience
                onCancel={cancelAddEdit}
                onSubmit={onVolunteerExperience}
              />
            </div>
          )}
          {!isAdd && editIndex === -1 && (
            <div className='s-actn'>
              <Button
                className='btn btn-purple-outer'
                onClick={() => setAdd(true)}>
                {profileData.volunteerExperienceData.addVolunteerExperienceBtn}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
};
export default VolunteerExperience;
