import {CustomCollapse, ErrorBoundary} from 'core/components';
import AwardsProfile from './AwardsProfile';

import profileData from 'data/settings-profile.json';

const Awards = props => {
  return (
    <CustomCollapse header={profileData.awardsData.collapseBarHeading}>
      <ErrorBoundary nameOfComponent='mod-comp-settings-myprofile-awards'>
        <AwardsProfile {...props} />
      </ErrorBoundary>
    </CustomCollapse>
  );
};

export default Awards;
