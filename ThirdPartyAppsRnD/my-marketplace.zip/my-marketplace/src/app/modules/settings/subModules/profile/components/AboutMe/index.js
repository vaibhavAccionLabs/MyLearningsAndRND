import {
  CustomCollapse,
  RequestErrorLoader,
  ErrorBoundary,
} from 'core/components';
import {useUser} from 'core/hooks';
import AboutMe from './AboutMe';

import profileData from 'data/settings-profile.json';

const AboutMeWrapper = props => {
  const {request} = useUser();
  return (
    <CustomCollapse header={profileData.aboutMeData.collapseBarHeading}>
      <RequestErrorLoader body={{request}}>
        <ErrorBoundary nameOfComponent='mod-comp-settings-myprofile-aboutme'>
          <AboutMe {...props} />
        </ErrorBoundary>
      </RequestErrorLoader>
    </CustomCollapse>
  );
};

export default AboutMeWrapper;
