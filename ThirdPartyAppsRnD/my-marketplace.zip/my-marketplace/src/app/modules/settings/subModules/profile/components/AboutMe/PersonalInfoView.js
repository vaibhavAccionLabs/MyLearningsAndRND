import {isEmpty, isObject} from 'lodash';
import {Row, Col, message} from 'antd';
import {getCompleteDate, formatPhoneNumber} from 'core/utils';
import {useUser, useEmailTrigger} from 'core/hooks';
import profileData from 'data/settings-profile.json';
import {emailSuccess} from 'assets/images';

const {success, error} = message;

const PersonalInfoView = () => {
  const {data: userData} = useUser();
  const {onEmailVerify} = useEmailTrigger();
  const {
    dob,
    email,
    email_verified = false,
    gender,
    address: location_info,
    username,
    ethnicity,
    last_name,
    first_name,
    middle_name,
    citizenship,
    entry_semester,
    entry_semester_year,
    phone_number,
    native_language,
    alternate_email_id,
  } = userData || {};
  const {date, month, year} = getCompleteDate(dob);
  const phoneNumber = formatPhoneNumber(phone_number);
  let DOB_label = month && date && year ? `${month}/${date}/${year}` : '----';
  let address =
    isObject(location_info) &&
    !isEmpty(location_info) &&
    location_info['address']
      ? location_info['address']
      : null;
  let city =
    isObject(location_info) && !isEmpty(location_info) && location_info['city']
      ? location_info['city']
      : null;
  let state =
    isObject(location_info) && !isEmpty(location_info) && location_info['state']
      ? location_info['state']
      : null;
  let zip =
    isObject(location_info) && !isEmpty(location_info) && location_info['zip']
      ? location_info['zip']
      : null;
  let address_label =
    address || city || state || zip
      ? `${address || '-'}, ${city || '-'}, ${state || '-'}, ${zip || '-'}`
      : '----';
  let entry_semester_label =
    (entry_semester &&
      entry_semester_year &&
      `${entry_semester} - ${entry_semester_year}`) ||
    null;

  const onVerifyEmail = async () => {
    const res = await onEmailVerify();
    if (res?.Error) {
      error(res.Error);
    }
    if (res?.Success) {
      success(`Confimation email has been sent to ${email} id.`);
    }
  };
  return (
    <>
      <div className='personalInfo'>
        <h3 className='heading'>
          {profileData.aboutMeData.personalInformationTitle}
        </h3>
        <Row className='field-container'>
          <Col xs={24} sm={24} md={24} lg={24}>
            <Col xs={24} sm={24} md={12} lg={12}>
              <div className='field'>
                <div className='label'>
                  {profileData.aboutMeData.userName?.label}
                </div>
                <h4 className='value text-capitalize' title={username}>
                  {username || '----'}
                </h4>
              </div>
            </Col>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>
                {profileData.aboutMeData.firstName.label}
              </div>
              <h4
                className='value text-capitalize'
                title={first_name || '----'}>
                {first_name || '----'}
              </h4>
            </div>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>
                {profileData.aboutMeData.middleName.label}
              </div>
              <h4
                className='value text-capitalize'
                title={middle_name || '----'}>
                {middle_name || '----'}
              </h4>
            </div>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>
                {profileData.aboutMeData.lastName.label}
              </div>
              <h4 className='value text-capitalize' title={last_name || '----'}>
                {last_name || '----'}
              </h4>
            </div>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>
                {profileData.aboutMeData.gender.label}
              </div>
              <h4 className='value text-capitalize' title={gender || '----'}>
                {gender || '----'}
              </h4>
            </div>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>
                {profileData.aboutMeData.dateOfBirth.label}
              </div>
              <h4 className='value' title={DOB_label || '----'}>
                {DOB_label || '----'}
              </h4>
            </div>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>{profileData.aboutMeData.email.label}</div>
              <h4 className='value' title={email || '----'}>
                {email || '----'}
              </h4>
              <div className='email-verification-stats'>
                {email_verified ? (
                  <span>
                    <img src={emailSuccess} alt='success' />
                  </span>
                ) : (
                  <span className='ancVerify' onClick={onVerifyEmail}>
                    Verify
                  </span>
                )}
              </div>
            </div>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>
                {profileData.aboutMeData.raceEthnicity.label}
              </div>
              <h4 className='value text-capitalize' title={ethnicity || '----'}>
                {ethnicity || '----'}
              </h4>
            </div>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>
                {profileData.aboutMeData.nativeLanguage.label}
              </div>
              <h4
                className='value text-capitalize'
                title={native_language || '----'}>
                {native_language || '----'}
              </h4>
            </div>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>
                {profileData.aboutMeData.citizenship.label}
              </div>
              <h4 className='value' title={citizenship || '----'}>
                {citizenship || '----'}
              </h4>
            </div>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>
                {profileData.aboutMeData.currentOrPlannedSemester.label}
              </div>
              <h4
                className='value text-capitalize'
                title={entry_semester_label || '----'}>
                {entry_semester_label || '----'}
              </h4>
            </div>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>
                {profileData.aboutMeData.locationLabel}
              </div>
              <h4 className='value text-capitalize' title={address_label}>
                {address_label}
              </h4>
            </div>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>
                {profileData.aboutMeData.secondaryEmailLabel}
              </div>
              <h4 className='value' title={alternate_email_id || '----'}>
                {alternate_email_id || '----'}
              </h4>
            </div>
          </Col>
          <Col xs={24} sm={24} md={12} lg={12}>
            <div className='field'>
              <div className='label'>
                {profileData.aboutMeData.phoneNumberLabel}
              </div>
              <h4 className='value' title={phoneNumber || '----'}>
                {phoneNumber || '----'}
              </h4>
            </div>
          </Col>
        </Row>
      </div>
    </>
  );
};

export default PersonalInfoView;
