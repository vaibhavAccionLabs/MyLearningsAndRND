import {CustomCollapse} from 'core/components';
import MyActivePaths from './myActivePaths';

const WorkforceActivePaths = props => (
  <div className='myActivePaths-content'>
    <CustomCollapse header='My Active Programs'>
      <MyActivePaths {...props} />
    </CustomCollapse>
  </div>
);

export default WorkforceActivePaths;
