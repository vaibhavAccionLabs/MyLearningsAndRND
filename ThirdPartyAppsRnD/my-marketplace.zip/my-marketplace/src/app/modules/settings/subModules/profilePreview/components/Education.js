import {Divider} from 'antd';
import {formatViewDate} from 'core/utils';
import {educationData} from 'data/settings-profilePreview.json';

const Education = ({data: education}) => (
  <div className='panel-section'>
    <div className='section-title'>{educationData.educationTitle}</div>
    {education && Array.isArray(education) && education.length > 0 ? (
      education.map((ed, idx) => {
        const EdComments =
          (ed &&
            Array.isArray(ed?.comments) &&
            ed?.comments?.length > 0 &&
            ed.comments.filter(
              comment =>
                comment.comments && typeof comment.comments === 'string',
            )) ||
          [];
        return (
          <div className='_list' key={'edu-profile-' + idx}>
            {ed?.school_name && (
              <div className='_item'>
                <span className='_k' style={{fontWeight: '300px'}}>
                  {educationData.schoolLabel}
                </span>
                <span className='_v' style={{fontWeight: 'normal'}}>
                  {ed?.school_name}
                </span>
              </div>
            )}
            {ed?.school_start_date && (ed?.school_end_date || ed?.is_present) && (
              <div className='_item'>
                <span className='_k'>{educationData.attendedLabel}</span>
                <span className='_v'>
                  {ed?.school_start_date &&
                    formatViewDate(ed?.school_start_date)}
                  {' - '}
                  {ed?.is_present
                    ? educationData.presentTxt
                    : `${
                        ed?.school_end_date &&
                        formatViewDate(ed?.school_end_date)
                      }`}
                </span>
              </div>
            )}
            {ed?.degree_award && (
              <div className='_item'>
                <span className='_k'>{educationData.degreeAwardLabel}</span>
                <span className='_v'>{ed?.degree_award}</span>
              </div>
            )}
            {ed?.area_of_focus && (
              <div className='_item'>
                <span className='_k'>{educationData.areaOfFocusLabel}</span>
                <span className='_v'>{ed?.area_of_focus}</span>
              </div>
            )}
            {EdComments?.length > 0 && (
              <div className='_item as-list'>
                <div className='_k'>{educationData.commentsLabel}</div>
                <ul className='list_blueDot'>
                  {EdComments.map(
                    ({comments}, id) =>
                      comments && (
                        <li key={`comment-${id}`} className='preWrapText'>
                          {comments}
                        </li>
                      ),
                  )}
                </ul>
              </div>
            )}
            {idx + 1 !== education.length && <Divider />}
          </div>
        );
      })
    ) : (
      <div>N/A</div>
    )}
  </div>
);

export default Education;
