import {useState} from 'react';
import {Form, Input, Row, Button, AutoComplete, Select} from 'antd';
import uniqBy from 'lodash/uniqBy';
import debounce from 'lodash/debounce';
import {generateRange} from 'core/utils';

import './style.less';
const {Option} = Select;
const experienceCount = generateRange(1, 9, 1, true);
experienceCount.push(`${experienceCount.length + 1}+`);
const initialState = {
  experience: 1,
  skill: '',
};

export default function AddSkill({
  data,
  editMode,
  skillsData,
  selectedSkill,
  onSkillsSubmit,
  toggleModalState,
}) {
  const [form] = Form.useForm();
  const [filteredSkills, setFilteredSkills] = useState([]);

  const onSearch = keyword => {
    if (keyword === '') {
      setFilteredSkills([]);
      return;
    }
    if (skillsData?.length > 0) {
      const filteredSkills = skillsData.filter(skill => {
        if (skill.name.toLowerCase().includes(keyword.toLowerCase())) {
          return skill;
        }
      });
      setFilteredSkills(uniqBy(filteredSkills.slice(0, 21), 'name'));
    }
  };

  const onSubmit = values => {
    form.resetFields();
    onSkillsSubmit(values, editMode);
  };

  const checkSelected = d => {
    if (
      data?.filter(i => i?.skill?.toLowerCase() === d?.toLowerCase()).length > 0
    )
      return true;
    return false;
  };
  const options =
    filteredSkills?.length > 0 &&
    filteredSkills.map(({name}) => (
      <Option
        key={name}
        text={name}
        value={name}
        disabled={checkSelected(name)}
        className={checkSelected(name) ? 'disabled-opt' : ''}>
        {name}
      </Option>
    ));

  return (
    <div className='add-skill mt-5 mb-3 d-flex justify-content-center'>
      <Form
        onFinish={onSubmit}
        form={form}
        layout='vertical'
        initialValues={editMode ? selectedSkill : initialState}>
        <Row justify='space-around' align='middle'>
          <Form.Item label='Experience' name='experience' className='f-itms'>
            <Select>
              {experienceCount.map(item => (
                <Select.Option
                  key={item}
                  value={
                    item === `${experienceCount.length}+` ? 10 : Number(item)
                  }>
                  {item} {`${item}` === '1' ? 'Year' : 'Years'}
                </Select.Option>
              ))}
            </Select>
          </Form.Item>
          <p>of</p>
          <Form.Item
            label='Skills Tag'
            name='skill'
            rules={[{required: true, message: 'Please select skill'}]}
            className='f-itms'>
            <AutoComplete
              notFoundContent='No Match Found'
              onSearch={debounce(keyword => onSearch(keyword), 800)}
              showSearch
              placeholder='Enter Skill'
              dataSource={options?.length > 0 ? options : []}>
              <Input />
            </AutoComplete>
          </Form.Item>
          <div className='skill_btn'>
            {editMode && (
              <Button
                className='mt-1'
                type='secondary'
                htmlType='button'
                onClick={() => toggleModalState()}>
                CANCEL
              </Button>
            )}
            <Button
              htmlType='submit'
              type='primary'
              className='btn-purple mt-1'>
              {editMode ? 'SAVE' : 'ADD SKILL'}
            </Button>
          </div>
        </Row>
      </Form>
    </div>
  );
}
