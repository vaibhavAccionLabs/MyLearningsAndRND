import {Modal} from 'antd';

import {CustomCollapse} from 'core/components';
import Subscriptions from './subscriptions';

const OccupationSubscriptions = props => {
  const {fetchSubscribedOccupation, unSubscribeForOccupation} = props;
  const onUnsubscribe = data => {
    const {occupation_name, uuid} = data;
    const txt = (
      <div>
        Are you sure want to unsubscribe from
        <p>
          <span>{occupation_name}</span>?
        </p>
      </div>
    );
    Modal.confirm({
      content: txt,
      title: 'Unsubscribe',
      onOk: () => unSubscribeOccupation(uuid),
      okText: 'Yes',
      cancelText: 'Cancel',
      className: 'occupation-unsubscribe',
      closable: true,
      confirmLoading: true,
    });
  };

  const unSubscribeOccupation = async occupation_uuid => {
    if (occupation_uuid) {
      await unSubscribeForOccupation(occupation_uuid);
      fetchSubscribedOccupation();
    }
  };

  return (
    <CustomCollapse header='Career Favorites'>
      <Subscriptions {...props} onUnsubscribe={onUnsubscribe} />
    </CustomCollapse>
  );
};

export default OccupationSubscriptions;
