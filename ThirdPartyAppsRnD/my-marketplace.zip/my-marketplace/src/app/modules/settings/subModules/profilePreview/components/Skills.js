import {Col, Row} from 'antd';
import {SkillsTable, SpiderChart} from '../../skills';
import profilePreviewData from 'data/settings-profilePreview.json';

export default function DeclaredSkills(props) {
  const {
    profileData: {data: student_profile, request, error},
  } = props;

  const sortedSkills =
    student_profile?.skills && Array.isArray(student_profile?.skills)
      ? student_profile?.skills.sort((a, b) => b.experience - a.experience)
      : [];

  return (
    <div className='profile-edit-section profileCanvas'>
      <div className='s-ttl'>{profilePreviewData.declaredSkillsHeading}</div>
      <Row>
        <Col span={24}>
          <SpiderChart data={sortedSkills} />
        </Col>
        <Col span={24} className='mt-3'>
          <SkillsTable viewOnly data={sortedSkills} />
        </Col>
      </Row>
    </div>
  );
}
