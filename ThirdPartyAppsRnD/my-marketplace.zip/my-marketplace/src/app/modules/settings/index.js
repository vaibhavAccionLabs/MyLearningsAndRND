import {useEffect} from 'react';
import {connect} from 'react-redux';
import {useLocation, useRouteMatch} from 'react-router-dom';

import {getAppConfig} from 'redux/modules/general';
import {
  fetchProfileData,
  updateUserProfile,
  profileDataSelector,
} from 'redux/modules/profile';
import {fetchActivePathData} from 'redux/modules/pathways';

import {AppBreadcrumb} from 'core/components';

//SubModule Routes
import SettingsRoutes from './SettingsRoutes';

//LocalComponents
import {Navigation, Banner} from './components/';

import styles from './styles.module.less';

const getBreadcrumbLink = (path, modules) =>
  path && modules?.find(module => module.path === path)?.label;

const Settings = props => {
  const {submodules, fetchActivePathData, fetchProfileData} = props;
  const {pathname} = useLocation();
  const {url} = useRouteMatch();
  const path = pathname && pathname.trim().split(url).join('');

  useEffect(() => {
    fetchProfileData();
    fetchActivePathData();
    return () => {};
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const isHeaderDisplay = path === '/profile/preview';

  return (
    <>
      {!isHeaderDisplay && (
        <AppBreadcrumb
          dataList={[
            {
              name: getBreadcrumbLink(path, submodules),
            },
          ]}
        />
      )}
      <Banner {...props} viewOnly={isHeaderDisplay} />
      <div className='d-flex mb-5 contentContainer previewProfile'>
        {!isHeaderDisplay && (
          <div className={`${styles.dashboard_menu} mt-4`}>
            <Navigation modules={submodules} />
          </div>
        )}
        <div className={`${styles.dashboard_Content} mt-4 pl-4`}>
          <SettingsRoutes modules={submodules} />
        </div>
      </div>
    </>
  );
};

const mapStateToProps = state => ({
  appConfig: getAppConfig(state),
  profileData: profileDataSelector(state),
});

export default connect(mapStateToProps, {
  fetchActivePathData,
  fetchProfileData,
  updateUserProfile,
})(Settings);
