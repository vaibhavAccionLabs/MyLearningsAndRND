import {SubRouter} from 'core/components';

const SettingsRoutes = ({modules}) => (
  <SubRouter modules={modules} defaultRedirection='/settings/dashboard' />
);

export default SettingsRoutes;
