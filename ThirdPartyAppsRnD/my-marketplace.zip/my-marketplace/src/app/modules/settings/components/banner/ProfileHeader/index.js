import {RequestErrorLoader} from 'core/components';
import {useUser} from 'core/hooks';
import BannerUploader from './bannerUploader';

const ProfileHeader = props => {
  const userData = useUser();
  return (
    <RequestErrorLoader body={userData}>
      <div className='bannerContent'>
        <BannerUploader {...props} />
      </div>
    </RequestErrorLoader>
  );
};

export default ProfileHeader;
