import {Progress} from 'antd';
import './style.less';

const PogressBar = ({
  type = 'line',
  percent = 0,
  width = 100,
  className = 'progressLine',
}) => (
  <Progress
    type={type}
    percent={percent}
    showInfo={false}
    strokeColor={{
      '0%': '#108ee9',
      '100%': '#87d068',
    }}
    width={width}
    className={className}
  />
);

export default PogressBar;
