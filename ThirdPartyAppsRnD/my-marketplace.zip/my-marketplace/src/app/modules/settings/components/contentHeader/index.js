import {Button} from 'antd';
import style from './style.module.less';

const ContentHeader = ({title, label, actionConfig, children}) => (
  <div className={style.content_header}>
    <h3>{title}</h3>
    <div>
      {children && children}
      {actionConfig && (
        <Button {...actionConfig} className='btn-purple-outer'>
          {label}
        </Button>
      )}
    </div>
  </div>
);

export default ContentHeader;
