import ProfileHeader from './ProfileHeader';
import {ErrorBoundary} from 'core/components';

const Banner = props => {
  return (
    <ErrorBoundary nameOfComponent='mod-comp-settings-banner'>
      <ProfileHeader {...props} />
    </ErrorBoundary>
  );
};

export default Banner;
