import React from 'react';
import {Link, useRouteMatch} from 'react-router-dom';
import {ErrorBoundary} from 'core/components';
import styles from './style.module.less';

const Navigation = ({modules}) => {
  const {path, url} = useRouteMatch();
  return (
    <ErrorBoundary nameOfComponent='mod-comp-settings-navigation'>
      <div className={styles.settings_side_navigation}>
        <ul>
          {modules &&
            modules.map(
              ({key, path, label, icon, exact}) =>
                icon &&
                path && (
                  <ActiveLink
                    key={key}
                    label={label}
                    to={`${url}${path}`}
                    isExact={exact}
                    icon={icon}
                  />
                ),
            )}
        </ul>
      </div>
    </ErrorBoundary>
  );
};

const ActiveLink = ({label, to, icon, isExact}) => {
  const match = useRouteMatch({
    path: to,
    exact: isExact,
  });
  return (
    <li className={match ? styles.active : ''}>
      <Link to={to}>
        <img src={icon} className='pr-2' /> <span>{label}</span>
      </Link>
    </li>
  );
};

export default Navigation;
