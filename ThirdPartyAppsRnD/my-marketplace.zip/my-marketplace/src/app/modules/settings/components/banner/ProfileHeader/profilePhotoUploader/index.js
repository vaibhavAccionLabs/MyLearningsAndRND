import {message, Upload, Popover} from 'antd';

import {getProfilePhoto} from 'core/utils';
import {useProfileUpload} from 'core/hooks';
import PogressBar from '../progressBar';
import {avatarGray, editpurple} from 'assets/images';
import './style.less';

const ProfilePhotoUploader = ({updateUserProfile, viewOnly, isMobileView}) => {
  const [progress, userData, uploadImage] = useProfileUpload('photo');
  const {data, request: userRequest, error: userError} = userData || {};

  let userPhoto = avatarGray;
  if (data && data.photo) {
    userPhoto = getProfilePhoto(data.photo);
  }

  const props = {
    accept: 'image/*',
    showUploadList: false,
    maxCount: 1,
    beforeUpload: file => {
      if (
        file.type === 'image/png' ||
        file.type === 'image/jpg' ||
        file.type === 'image/jpeg'
      ) {
        return file.type === 'image/*' ? true : Upload.LIST_IGNORE;
      }
      message.error(`${file.name} is not a image file`);
      return false;
    },
    customRequest: uploadImage,
  };

  const deletePhoto = async () => {
    const body = {
      photo: null,
    };
    await updateUserProfile(body);
  };

  const actions = () => (
    <>
      <span onClick={deletePhoto}>Remove</span>
      <Upload {...props}>
        <span>Edit</span>
      </Upload>
    </>
  );

  return (
    <div className='profile-photo'>
      <div className='d-flex'>
        <div className='photo-img'>
          <img src={userPhoto} className='photo-img' />
          {progress > 0 && !isMobileView && (
            <PogressBar
              type='circle'
              percent={progress}
              width={100}
              className='progress-photo'
            />
          )}
          {!viewOnly && (
            <Popover
              placement='bottom'
              content={actions}
              overlayClassName='profile-menu-list'>
              <span>
                <img src={editpurple} alt='edit' />
              </span>
            </Popover>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfilePhotoUploader;
