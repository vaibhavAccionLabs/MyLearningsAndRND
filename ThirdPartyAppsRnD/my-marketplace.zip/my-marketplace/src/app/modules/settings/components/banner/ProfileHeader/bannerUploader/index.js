import {Popover, Upload, message, Button} from 'antd';
import {useProfileUpload, useActivePath} from 'core/hooks';
import {getBanner, getLogo} from 'core/utils';

import ProfilePhotoUploader from '../profilePhotoUploader';
import PogressBar from '../progressBar';

import {
  defaultbannerprofile,
  white_facebook,
  white_twitter,
  white_linkedin,
  black_instagram,
  black_medium,
  black_tiktok,
  editpurple,
} from 'assets/images';

import style from './style.module.less';

const BannerUploader = ({
  updateUserProfile,
  viewOnly,
  appConfig: {isMobileView},
}) => {
  const [progress, userData, uploadImage] = useProfileUpload('banner');
  const {data, request: userRequest, error: userError} = userData || {};
  const {pathInfo, request: pathRequest, error: pathError} = useActivePath();
  const {institute_details: {name} = {}} = pathInfo || {};

  const userName = `${data && data.first_name} ${data && data.last_name}`;
  const qrCodeImage = data?.qr_code && getLogo(data?.qr_code);

  let userBanner = defaultbannerprofile;
  if (data && data.banner) {
    userBanner = getBanner(data.banner);
  }

  const props = {
    accept: 'image/*',
    showUploadList: false,
    maxCount: 1,
    beforeUpload: file => {
      if (
        file.type === 'image/png' ||
        file.type === 'image/jpg' ||
        file.type === 'image/jpeg'
      ) {
        return file.type === 'image/*' ? true : Upload.LIST_IGNORE;
      }
      message.error(`${file.name} is not a image file`);
      return false;
    },
    customRequest: uploadImage,
  };

  const deleteBanner = async () => {
    const body = {
      banner: null,
    };
    await updateUserProfile(body);
  };

  const actions = () => (
    <>
      <span onClick={deleteBanner}>Remove</span>
      <Upload {...props}>
        <span>Edit</span>
      </Upload>
    </>
  );

  return (
    <div
      className={style.banner_preview}
      style={{backgroundImage: `url(${userBanner})`}}>
      {progress > 0 && !isMobileView && <PogressBar percent={progress} />}
      <div className={`contentContainer ${style.banner_userprofile}`}>
        <div className={style.banner_userdetails}>
          <ProfilePhotoUploader
            viewOnly={viewOnly}
            updateUserProfile={updateUserProfile}
            isMobileView={isMobileView}
          />
          <div className='pl-3'>
            <h2>{userName}</h2>
            {name && !pathError && <p>{name}</p>}
            <ul>
              {data && data.facebook_link && data.show_facebook_link && (
                <li>
                  <Button href={data.facebook_link} target='_blank'>
                    <img src={white_facebook} alt='fb' />
                  </Button>
                </li>
              )}
              {data && data.twitter_link && data.show_twitter_link && (
                <li>
                  <Button href={data.twitter_link} target='_blank'>
                    <img src={white_twitter} alt='tw' />
                  </Button>
                </li>
              )}
              {data && data.linkedin_link && data.show_linkedin_link && (
                <li>
                  <Button href={data.linkedin_link} target='_blank'>
                    <img src={white_linkedin} alt='li' />
                  </Button>
                </li>
              )}
              {data && data.instagram_link && data.show_instagram_link && (
                <li>
                  <Button href={data.instagram_link} target='_blank'>
                    <img
                      className={style.noFilter}
                      src={black_instagram}
                      alt='ig'
                    />
                  </Button>
                </li>
              )}
              {data && data.tiktok_link && data.show_tiktok_link && (
                <li>
                  <Button href={data.tiktok_link} target='_blank'>
                    <img
                      className={style.noFilter}
                      src={black_tiktok}
                      alt='tt'
                    />
                  </Button>
                </li>
              )}
              {data && data.medium_link && data.show_medium_link && (
                <li>
                  <Button href={data.medium_link} target='_blank'>
                    <img
                      className={style.noFilter}
                      src={black_medium}
                      alt='med'
                    />
                  </Button>
                </li>
              )}
            </ul>
          </div>
        </div>
        {!viewOnly && (
          <Popover
            placement='bottom'
            content={actions}
            overlayClassName='profile-menu-list'>
            <span>
              <img src={editpurple} alt='editpurple' />
            </span>
          </Popover>
        )}
        {qrCodeImage && <img src={qrCodeImage} className={style.mob_qrCode} />}
      </div>
    </div>
  );
};

export default BannerUploader;
