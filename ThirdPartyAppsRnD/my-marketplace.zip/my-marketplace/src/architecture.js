/**
 * Represents a app.
 *
 * @mermaid
 *   sequenceDiagram
 *       participant App
 *       App->>Store: Connect(initialState)
 *       CombineReducers->>Store: Pass data objects To Store
 *       Store->>App: Replay to App
 *       App->>Modules: Take the required data objects
 */

const ApplicationArchitecture = () =>
  console.log('Application Architecture diagram');
