const path = require(`path`);
const CracoAntDesignPlugin = require('craco-antd');
const CracoLessPlugin = require('craco-less');
const getCSSModuleLocalIdent = require('react-dev-utils/getCSSModuleLocalIdent');
const BundleAnalyzerPlugin = require("webpack-bundle-analyzer").BundleAnalyzerPlugin;
const ProgressBarPlugin = require('progress-bar-webpack-plugin');
const chalk = require('chalk');

const green = text => chalk.green.bold(text);

const ProgressBar = new ProgressBarPlugin({
  format: `analyzing... [:bar] ${green('[:percent]')} - :msg`
})

const isProductionBuild = process.env.NODE_ENV === "production";
const analyzerMode = process.env.REACT_APP_INTERACTIVE_ANALYZE ? "server" : "json";
const add = [];
isProductionBuild && add.push(new BundleAnalyzerPlugin({ analyzerMode }), ProgressBar);

module.exports = {
  plugins: [
    {
      plugin: CracoAntDesignPlugin,
      options: {
        customizeTheme: {
          // "@primary-color": "#1DA57A",
          // "@link-color": "#1DA57A",
        },
        customizeThemeLessPath: path.join(
          __dirname,
          'src/assets/styles/theme.less',
        ),
      },
    },
    {
      plugin: CracoLessPlugin,
      options: {
        cssLoaderOptions: {
          modules: {
            getLocalIdent: (context, localIdentName, localName, options) => {
              if (context.resourcePath.includes('node_modules')) {
                return localName;
              }
              return getCSSModuleLocalIdent(
                context,
                localIdentName,
                localName,
                options,
              );
            },
          },
        },
        lessLoaderOptions: {
          lessOptions: {
            modifyVars: {'@primary-color': '#3BC4FF'},
            javascriptEnabled: true,
          },
        },
        modifyLessRule: function (lessRule, _context) {
          lessRule.test = /\.(module)\.(less)$/;
          lessRule.exclude = path.join(__dirname, 'node_modules');
          return lessRule;
        },
      },
    },
  ],
  webpack: {
    plugins: {
      add /* An array of plugins */
    }
  },
};
